import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path('tools').resolve()))
from cache_gate import Gate, host_target, project_at
from compiler_profile import require_optimized

output = Path('build/cache-independence-final-review').resolve()
output.mkdir()
compiler = Path('build/cathedral-benchmark/omega-full-67358c0345be.exe').resolve()
gate = Gate(compiler, output, host_target())
record = dict(status='failed', producer=require_optimized(compiler), commands=gate.observations,
              comparisons=gate.comparisons,
              gate_sha256=hashlib.sha256(Path('tools/cache_gate.py').read_bytes()).hexdigest())
try:
    with tempfile.TemporaryDirectory(prefix='cache-gate-review-') as temporary:
        root = Path(temporary)
        project = project_at(root, gate.target)
        package = project / 'dependency'
        package.mkdir()
        (package / 'build.omg').write_text('machine build(builder: &mut Build) { Build::package(builder, "dependency"); }\n')
        (package / 'main.omg').write_text('use result;\n')
        (project / 'result.omg').rename(package / 'result.omg')
        main = project / 'main.omg'
        main.write_text(main.read_text().replace('use result;', 'use dependency::result;'))
        build = project / 'build.omg'
        build.write_text(build.read_text().replace('Build::application', 'Build::depend_as(builder, "dependency", Source::Path { location: "dependency" }); Build::application'))
        gate.pair(project, root / 'warm', root / 'fresh', 'review-settlement')
    checks = [
        ('harness-tests', [sys.executable, 'tools/tests/test_cache_gate.py', '-v']),
        ('shared-compilation', ['mbx', 'nextest', 'run', '--release', '-p', 'omega-build', '--test', 'shared_compilation']),
    ]
    record['checks'] = []
    for name, command in checks:
        with (output / (name + '.log')).open('wb') as log:
            run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        record['checks'].append(dict(command=command, exit_code=run.returncode, log=name + '.log'))
        assert run.returncode == 0, name
    record['status'] = 'passed'
finally:
    (output / 'result.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print('PASS final review settlement, harness tests, and shared compilation', flush=True)
