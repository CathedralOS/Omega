//! Compare independently admitted projects with separate or shared compiler storage.
use omega_build::{
    BuildRequest, BuildTargets, NativeDestination, ProjectProduct, build, build_with_compiler,
};
use std::path::PathBuf;
use std::time::Instant;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let arguments = std::env::args().skip(1).collect::<Vec<_>>();
    if arguments.as_slice() == ["--build-profile"] {
        println!("{}", compiler::compiler_build_profile());
        return Ok(());
    }
    if arguments.len() < 4 || !["shared", "separate", "retained"].contains(&arguments[0].as_str()) {
        return Err("usage: compile_projects <shared|separate|retained> <target> <new-output> <root.omg>...".into());
    }
    let profile = target::TargetProfile::from_canonical_target_name(&arguments[1])
        .map_err(|error| error.message)?;
    let directory = PathBuf::from(&arguments[2]);
    std::fs::create_dir(&directory)?;
    let started = Instant::now();
    let mut shared = compiler::CompilationSession::default();
    for (index, root) in arguments[3..].iter().enumerate() {
        let before = Instant::now();
        let checks = compiler::settled_check_totals();
        let sources = compiler::source_assembly_invocation_count();
        let request = BuildRequest {
            root_path: PathBuf::from(root),
            build_directory: Some(directory.join(index.to_string())),
            targets: BuildTargets::Single(profile),
            product: ProjectProduct::Native {
                destination: NativeDestination::Published,
                private_entry_ram: Vec::new(),
            },
            timings: true,
            offline: true,
            verify: false,
            require_package_project: false,
            optimization_rollback: Default::default(),
            build_snapshot: None,
        };
        let outcomes = match arguments[0].as_str() {
            "shared" => build_with_compiler(request, &mut shared),
            "separate" => {
                build_with_compiler(request, &mut compiler::CompilationSession::default())
            }
            _ => build(request),
        }?;
        for outcome in outcomes {
            let report = outcome.result?.into_report()?;
            for timing in report
                .timings
                .phases()
                .iter()
                .chain(report.report.timings())
            {
                println!("phase {index} {} {}", timing.microseconds, timing.phase);
            }
        }
        let after = compiler::settled_check_totals();
        println!(
            "project {index} wall_us={} checks={} check_us={} assemblies={}",
            before.elapsed().as_micros(),
            after.0 - checks.0,
            after.1 - checks.1,
            compiler::source_assembly_invocation_count() - sources
        );
    }
    let disposal = Instant::now();
    drop(shared);
    println!("disposal_us={}", disposal.elapsed().as_micros());
    println!("total_us={}", started.elapsed().as_micros());
    if phase_profile::enabled() {
        eprint!("{}", phase_profile::render());
    }
    Ok(())
}
