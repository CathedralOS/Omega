import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import statistics
import sys
import time

sys.path.insert(0, str(Path('tools').resolve()))
from cache_gate import Gate
from compiler_profile import require_optimized
from benchmark.benchmark import capture_compile

root = Path('build/ui-native-round').resolve()
root.mkdir(exist_ok=True)
original = Path(r'C:/Development/Cathedral/.agents/worktree/ui-shared-compilation/source/distribution/libraries/omega-ui')
snapshot = root / 'omega-ui'
if not snapshot.exists():
    shutil.copytree(original, snapshot, ignore=shutil.ignore_patterns('build', 'target', '.git', 'omega.lock', '__pycache__'))
compiler = Path(sys.argv[1]).resolve()
label = sys.argv[2]
output = root / label
output.mkdir()
project = snapshot / 'tests/native_component/exports'
cache = root / ('cache-' + label)
os.environ['LOCALAPPDATA'] = str(cache)
os.environ['OMEGA_PHASE_PROFILE'] = '1'
manifest = {str(path.relative_to(snapshot)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in snapshot.rglob('*.omg') if 'build' not in path.relative_to(snapshot).parts}
record = dict(compiler=require_optimized(compiler), inputs=manifest, runs=[], status='failed')
gate = Gate(compiler, output, 'linux_x86_64')
try:
    code, log = gate.prepare(project, cache, label)
    assert code == 0, log[-5000:]
    expected = None
    for index in range(4):
        destination = output / str(index)
        command = [str(compiler), '--offline', '--timings', '--target', 'linux_x86_64', '--build-dir', str(destination), str(project / 'main.omg')]
        code, wall, peak, log = capture_compile(command, str(project))
        (output / f'{index}.log').write_text(log, encoding='utf-8')
        row = dict(exit_code=code, wall_ms=wall, peak_bytes=peak, warmup=index == 0, command=command)
        record['runs'].append(row)
        assert code == 0, log[-5000:]
        artifacts = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in destination.iterdir()
                     if path.suffix in {'.so', '.component'} or path.name in {'omega-program', 'omega-components.tsv'}}
        assert sum(name.endswith('.so') for name in artifacts) == 2, artifacts
        assert sum(name.endswith('.component') for name in artifacts) == 2, artifacts
        assert 'omega-program' in artifacts and 'omega-components.tsv' in artifacts
        row['artifacts'] = artifacts
        if expected is None:
            expected = artifacts
        assert artifacts == expected, 'output changed between repetitions'
        row['phases'] = {name: float(value) for value, name in re.findall(r'^\s*([\d.]+) ms\s+\d+ x\s+(\S+)\s*$', log, re.MULTILINE)}
        print(label, index, round(wall, 3), peak, flush=True)
    assert all(hashlib.sha256((snapshot / name).read_bytes()).hexdigest() == value for name, value in manifest.items())
    assert hashlib.sha256(compiler.read_bytes()).hexdigest() == record['compiler']['sha256']
    values = [row['wall_ms'] for row in record['runs'] if not row['warmup']]
    record['summary_ms'] = dict(min=min(values), max=max(values), mean=statistics.mean(values), median=statistics.median(values))
    record['status'] = 'passed'
finally:
    (output / 'result.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
