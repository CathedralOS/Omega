import hashlib
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path('tools').resolve()))
from benchmark.benchmark import capture_compile

root = Path('build/ui-native-round').resolve()
cache = root / 'cache-instrumented'
compiler = root / 'omega-instrumented.exe'
project = root / 'omega-ui/tests/native_component/exports/main.omg'
output = root / 'source-retention-comparison'
output.mkdir()
directories = list(cache.rglob('source-graphs'))
assert len(directories) == 1
directory = directories[0].resolve()
saved = directory.with_name('source-graphs-saved')
assert directory.is_relative_to(cache.resolve()) and saved.is_relative_to(cache.resolve())
assert directory.is_dir() and not saved.exists()
expected = json.loads((root / 'instrumented/result.json').read_text())['runs'][-1]['artifacts']
os.environ['LOCALAPPDATA'] = str(cache)
os.environ['OMEGA_PHASE_PROFILE'] = '1'
record = dict(status='failed', runs=[], diagnostic='Disable only source-graph persistence; retain component and acquisition caches')
try:
    for index, retained in enumerate([False, True, False, True]):
        if not retained:
            directory.rename(saved)
            directory.write_bytes(b'Diagnostic: source-graph lane unavailable; original saved beside it.\n')
        try:
            destination = output / str(index)
            command = [str(compiler), '--offline', '--timings', '--target', 'linux_x86_64', '--build-dir', str(destination), str(project)]
            code, wall, peak, text = capture_compile(command, str(project.parent))
            (output / f'{index}.log').write_text(text, encoding='utf-8')
            row = dict(retained=retained, exit_code=code, wall_ms=wall, peak_bytes=peak, command=command)
            record['runs'].append(row)
            assert code == 0, text[-4000:]
            artifacts = {name: hashlib.sha256((destination / name).read_bytes()).hexdigest() for name in expected}
            assert artifacts == expected, 'native artifacts changed'
            assert 'component.cache.hit' in text
            assert ('source.graph.loaded' in text) == retained
            row['artifacts_match'] = True
            print('retained', retained, round(wall, 3), peak, flush=True)
        finally:
            if not retained:
                assert directory.is_file() and saved.is_dir()
                directory.unlink()
                saved.rename(directory)
    record['status'] = 'passed'
finally:
    (output / 'result.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
