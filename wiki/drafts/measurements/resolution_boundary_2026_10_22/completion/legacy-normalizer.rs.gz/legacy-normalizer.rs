use crate::data::DataMember;
use crate::expression::{ExpressionSource, ExpressionTable};
use crate::machine::{Machine, OwnedData};
use crate::signature::{StateParameter, StateSignature};
use crate::state::State;
use crate::statement::{Statement, StatementTable};
use crate::types::{TypeConstraint, TypeReference, TypeReferenceTable};
use crate::{SymbolResolvedDeclarationStorage, SymbolResolvedTrees};
use arena::{Arena, HandleSpan};

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct SymbolResolvedTreeTables {
    pub bodies: ResolvedBodyTables,
    pub types: ResolvedTypeTables,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ResolvedBodyTables {
    pub expressions: ExpressionTable,
    pub statements: StatementTable,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ResolvedTypeTables {
    pub references: TypeReferenceTable,
}

impl SymbolResolvedTreeTables {
    pub fn from_symbol_resolved_trees_with_state_spans(
        symbol_resolved_trees: &mut SymbolResolvedTrees,
    ) -> Self {
        let mut tables = Self::default();
        tables.append_declaration_tables(
            symbol_resolved_trees,
            &crate::SymbolResolvedRoots::default(),
            &[],
            0,
        );
        tables
    }

    /// Retain normalized rows belonging to earlier completed bodies. The
    /// successor expression table already contains newly resolved body graphs;
    /// only normalized statements/types are seeded from the predecessor.
    pub fn from_body_completion(
        symbol_resolved_trees: &mut SymbolResolvedTrees,
        predecessor: &SymbolResolvedTrees,
        completed_machines: &[symbols::SymbolHandle],
    ) -> Self {
        let mut tables = Self {
            bodies: ResolvedBodyTables {
                expressions: ExpressionTable::default(),
                statements: predecessor.tables.bodies.statements.clone(),
            },
            types: ResolvedTypeTables {
                references: predecessor.tables.types.references.clone(),
            },
        };
        tables.append_declaration_tables(
            symbol_resolved_trees,
            &predecessor.roots,
            completed_machines,
            predecessor.tables.declarations.assembly_blocks.len(),
        );
        tables
    }

    /// The same table insertions serve complete lowering and continuation.
    /// Root frontiers select new declarations; exact machine identities select
    /// existing declarations whose implementations have just been completed.
    fn append_declaration_tables(
        &mut self,
        symbol_resolved_trees: &mut SymbolResolvedTrees,
        frontier: &crate::SymbolResolvedRoots,
        completed_machines: &[symbols::SymbolHandle],
        assembly_frontier: usize,
    ) {
        let tables = self;
        let SymbolResolvedTrees {
            roots,
            tables: source_tables,
            ..
        } = symbol_resolved_trees;
        let type_constraints = &source_tables.types.constraints;
        // The expressions already have their final identities. Transfer the arena
        // and append normalized type-expression copies beside their originals;
        // a whole-table snapshot would only be discarded after normalization.
        tables.bodies.expressions = std::mem::take(&mut source_tables.bodies.expressions);
        let source_expressions = ExpressionSource::Own;
        let SymbolResolvedDeclarationStorage {
            data_members,
            data_payload_fields,
            machine_owned_data,
            machine_state_handles,
            machine_states,
            trait_machine_signatures,
            operator_definitions,
            proposition_binders,
            state_parameters,
            statement_path_members,
            state_statements,
            assembly_blocks,
            child_type_references,
            ..
        } = &mut source_tables.declarations;

        // Assembly scopes use the same statement normalization as machine
        // states. Only appended blocks are new during deferred completion;
        // retained predecessor views keep their exact node coordinates.
        let blocks: Vec<_> = assembly_blocks
            .iter()
            .skip(assembly_frontier)
            .map(|(handle, block)| (handle, block.instructions))
            .collect();
        for (handle, instructions) in blocks {
            let mut nodes = HandleSpan::empty();
            for statement in state_statements.span_or_empty(instructions) {
                let node = tables.bodies.statements.insert_tree_from_source(
                    statement,
                    source_expressions,
                    &mut tables.bodies.expressions,
                    &mut tables.types.references,
                    child_type_references,
                    type_constraints,
                    source_expressions,
                    statement_path_members,
                    false,
                );
                nodes.push_contiguous(node);
            }
            assembly_blocks.get_mut(handle).statement_nodes = nodes;
        }

        for data_definition in roots
            .data_definitions
            .iter()
            .skip(frontier.data_definitions.len())
        {
            tables.insert_data_definition(
                data_members.span_or_empty(data_definition.members),
                data_payload_fields,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }

        for domain_definition in roots
            .domain_definitions
            .iter()
            .skip(frontier.domain_definitions.len())
        {
            tables.insert_type_reference(
                &domain_definition.target_type,
                child_type_references,
                type_constraints,
                source_expressions,
            );
            for operator in operator_definitions.span_or_empty(domain_definition.operators) {
                tables.insert_operator(
                    operator,
                    state_parameters,
                    child_type_references,
                    type_constraints,
                    source_expressions,
                );
            }
        }

        for proposition in roots.propositions.iter().skip(frontier.propositions.len()) {
            for binder in proposition_binders.span_or_empty(proposition.binders) {
                if let crate::proposition::PropositionBinderKind::Const { type_reference } =
                    &binder.kind
                {
                    tables.insert_type_reference(
                        type_reference,
                        child_type_references,
                        type_constraints,
                        source_expressions,
                    );
                }
            }
            for parameter in state_parameters.span_or_empty(proposition.parameters) {
                tables.insert_type_reference(
                    &parameter.type_reference,
                    child_type_references,
                    type_constraints,
                    source_expressions,
                );
            }
            if let crate::proposition::PropositionBody::Witness { evidence } = &proposition.body {
                tables.insert_type_reference(
                    evidence,
                    child_type_references,
                    type_constraints,
                    source_expressions,
                );
            }
        }

        for trait_definition in roots.traits.iter().skip(frontier.traits.len()) {
            tables.insert_platform(
                trait_machine_signatures.span_or_empty(trait_definition.machines),
                state_parameters,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }

        for (_, machine) in roots
            .machines
            .iter()
            .enumerate()
            .filter(|(ordinal, machine)| {
                *ordinal >= frontier.machines.len() || completed_machines.contains(&machine.symbol)
            })
        {
            tables.insert_machine_with_state_spans(
                machine,
                machine_owned_data,
                machine_state_handles,
                machine_states,
                state_parameters,
                statement_path_members,
                state_statements,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }

        for operator in roots.operators.iter().skip(frontier.operators.len()) {
            tables.insert_operator(
                operator,
                state_parameters,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }

        for measure in roots.measures.iter().skip(frontier.measures.len()) {
            if let Some(parameter) = &measure.parameter {
                tables.insert_type_reference(
                    &parameter.type_reference,
                    child_type_references,
                    type_constraints,
                    source_expressions,
                );
            }
            if let Some(return_type) = &measure.return_type {
                tables.insert_type_reference(
                    return_type,
                    child_type_references,
                    type_constraints,
                    source_expressions,
                );
            }
        }
    }

    fn insert_parameter_and_return_types<'tree>(
        &mut self,
        parameters: impl Iterator<Item = &'tree StateParameter>,
        return_type: &Option<TypeReference>,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        for parameter in parameters {
            self.insert_type_reference(
                &parameter.type_reference,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }
        if let Some(return_type) = return_type {
            self.insert_type_reference(
                return_type,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }
    }

    fn insert_operator(
        &mut self,
        operator: &crate::operator::OperatorDefinition,
        state_parameters: &Arena<StateParameter>,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        self.insert_parameter_and_return_types(
            state_parameters.span_or_empty(operator.parameters).iter(),
            &operator.return_type,
            child_type_references,
            type_constraints,
            source_expressions,
        );
    }

    fn insert_data_definition(
        &mut self,
        members: &[DataMember],
        data_payload_fields: &Arena<crate::data::DataField>,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        for member in members {
            match member {
                DataMember::Field(field) => {
                    self.insert_type_reference(
                        &field.type_reference,
                        child_type_references,
                        type_constraints,
                        source_expressions,
                    );
                }
                DataMember::Variant(variant) => {
                    for field in data_payload_fields.span_or_empty(variant.payload) {
                        self.insert_type_reference(
                            &field.type_reference,
                            child_type_references,
                            type_constraints,
                            source_expressions,
                        );
                    }
                }
            }
        }
    }

    fn insert_platform(
        &mut self,
        states: &[StateSignature],
        state_parameters: &Arena<StateParameter>,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        for state in states {
            self.insert_state_signature(
                state_parameters.span_or_empty(state.parameters),
                state,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }
    }

    fn insert_machine_with_state_spans(
        &mut self,
        machine: &Machine,
        machine_owned_data: &Arena<OwnedData>,
        machine_state_handles: &Arena<arena::Handle<State>>,
        machine_states: &mut Arena<State>,
        state_parameters: &Arena<StateParameter>,
        statement_path_members: &Arena<crate::name::DiagnosticName>,
        state_statements: &Arena<Statement>,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        for owned_data in machine_owned_data.span_or_empty(machine.owned_data) {
            self.insert_owned_data(
                owned_data,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }

        for state in machine_state_handles
            .span_or_empty(machine.states)
            .iter()
            .copied()
        {
            let state = machine_states.get_mut(state);
            self.insert_state_with_statement_span(
                state,
                state_parameters,
                statement_path_members,
                state_statements,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }
    }

    fn insert_owned_data(
        &mut self,
        owned_data: &OwnedData,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        self.insert_type_reference(
            &owned_data.type_reference,
            child_type_references,
            type_constraints,
            source_expressions,
        );
    }

    fn insert_state_with_statement_span(
        &mut self,
        state: &mut State,
        state_parameters: &Arena<StateParameter>,
        statement_path_members: &Arena<crate::name::DiagnosticName>,
        state_statements: &Arena<Statement>,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        for parameter in state_parameters.span_or_empty(state.parameters) {
            self.insert_type_reference(
                &parameter.type_reference,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }

        if let Some(return_type) = &state.return_type {
            self.insert_type_reference(
                return_type,
                child_type_references,
                type_constraints,
                source_expressions,
            );
        }

        let mut statement_nodes = HandleSpan::empty();
        for statement in state_statements.span_or_empty(state.statements) {
            let statement = self.bodies.statements.insert_tree_from_source(
                statement,
                source_expressions,
                &mut self.bodies.expressions,
                &mut self.types.references,
                child_type_references,
                type_constraints,
                source_expressions,
                statement_path_members,
                false,
            );
            statement_nodes.push_contiguous(statement);
        }

        state.statement_nodes = statement_nodes;
    }

    fn insert_state_signature(
        &mut self,
        parameters: &[StateParameter],
        signature: &StateSignature,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        self.insert_parameter_and_return_types(
            parameters.iter(),
            &signature.return_type,
            child_type_references,
            type_constraints,
            source_expressions,
        );
    }

    fn insert_type_reference(
        &mut self,
        type_reference: &TypeReference,
        child_type_references: &Arena<TypeReference>,
        type_constraints: &Arena<TypeConstraint>,
        source_expressions: ExpressionSource<'_>,
    ) {
        self.types.references.insert_tree_from_source(
            type_reference,
            &mut self.bodies.expressions,
            child_type_references,
            type_constraints,
            source_expressions,
        );
    }
}

#[cfg(test)]
mod tests {

    #[test]
    fn rebuild_tables_collects_typed_program_payloads() {
        let (mut program, states) = crate::machine::test_program_with_guarded_transition();
        program.machines.push(crate::machine::test_machine(states));

        program.rebuild_tables();

        assert_eq!(program.tables.types.references.type_reference_count(), 1);
        assert_eq!(program.tables.bodies.expressions.expression_count(), 1);
        assert_eq!(program.tables.bodies.statements.statement_count(), 1);
        let state = program
            .machine_state_handles(program.machines[0].states)
            .first()
            .map(|state| program.machine_state(*state))
            .expect("entry state");
        assert_eq!(state.statement_nodes.count(), 1);
    }
}
