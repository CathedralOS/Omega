# Performance suite

# length matched compiler before/after

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 1521512600.0 | 1599130100.0 | +10.74% |
| cpu_cycles | 5595447150.0 | 5895833850.0 | +4.56% |
| native_image_bytes | 1536.0 | 1536.0 | +0.00% |
| peak_resident_bytes | 374099968.0 | 372652032.0 | -0.37% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 3.722 | 3.271 | -5.93% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 40.034 | 40.339 | +1.55% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 116.935 | 119.32 | +11.86% |
| stage_ms:compile: sources -> requested product | 241.715 | 260.271 | +6.08% |
| stage_ms:prepare: project -> prepared sources | 34.701499999999996 | 38.379000000000005 | +1.76% |
| stage_ms:publish: retained product -> published product | 5.4635 | 6.2509999999999994 | +9.24% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.0315 | 0.028 | -15.51% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 8.892 | 9.3155 | +7.18% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.001 | 0.001 | unavailable |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.1325 | 0.138 | +4.48% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.073 | 0.0815 | +7.77% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 9.3505 | 9.739 | +7.25% |
| stage_ms:total elapsed | 1231.7285 | 1322.743 | +17.88% |
| system_cpu_ns | 585937500.0 | 648437500.0 | +10.04% |
| total_page_faults | 92457.5 | 92060.5 | -0.43% |
| user_cpu_ns | 593750000.0 | 640625000.0 | +9.89% |

Scope and limitations: see report warnings and each observation's resource provider.

# square matched compiler before/after

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 1110704650.0 | 1092112100.0 | +3.41% |
| cpu_cycles | 4151432025.0 | 4180201875.0 | +1.67% |
| native_image_bytes | 1024.0 | 1024.0 | +0.00% |
| peak_resident_bytes | 366282752.0 | 364871680.0 | -0.39% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 2.5564999999999998 | 2.2119999999999997 | -6.00% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 37.548500000000004 | 37.429 | -1.89% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 73.2195 | 74.94800000000001 | +0.65% |
| stage_ms:compile: sources -> requested product | 143.9545 | 144.45350000000002 | +2.09% |
| stage_ms:prepare: project -> prepared sources | 24.906 | 22.9695 | -2.99% |
| stage_ms:publish: retained product -> published product | 4.7505 | 4.3605 | -1.66% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.0235 | 0.024 | -4.35% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 4.1955 | 5.0329999999999995 | +13.80% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.001 | 0.001 | unavailable |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.3955 | 0.3905 | +0.49% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.054 | 0.0555 | +1.61% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 4.731 | 5.6115 | +12.48% |
| stage_ms:total elapsed | 866.71 | 875.48 | +1.80% |
| system_cpu_ns | 460937500.0 | 492187500.0 | +11.25% |
| total_page_faults | 90480.0 | 90085.5 | -0.43% |
| user_cpu_ns | 468750000.0 | 468750000.0 | -1.72% |

Scope and limitations: see report warnings and each observation's resource provider.

