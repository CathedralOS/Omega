"""Adapt the existing compiler capture to omega-bench's reported-work protocol.

Gallery stdout contains frame timings, so an exact stdout oracle is inappropriate.
Validate its headless pixels separately, then require every measured compiler to
emit those exact validated image bytes. Only capture_compile's wall time is
reported: source hashing, artifact checks and native checks are outside the timer.
"""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, tempfile

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
from benchmark.benchmark import capture_compile

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')

def compile_one(role, profile=False):
    assert role in {'a', 'b'}
    directory = Path(tempfile.mkdtemp(prefix=('phase-' if profile else 'compile-')+role+'-', dir=OUT / 'observations'))
    compiler = ROOT/'build/performance/generation-domains'/('omega-before.exe' if role == 'a' else 'omega-after.exe')
    os.environ['LOCALAPPDATA'] = str(OUT/('cache-'+role))
    os.environ['OMEGA_LIBRARY_ROOT'] = str(ROOT/'source/library')
    os.environ.pop('OMEGA_PHASE_PROFILE', None)
    os.environ.pop('OMEGA_ALLOCATION_PROFILE', None)
    if profile:
        os.environ['OMEGA_PHASE_PROFILE'] = '1'
    project = OUT/('omega-ui-'+role)/'examples/gallery'
    command = [str(compiler), '--offline', '--timings', '--target', 'windows_x86_64', '--build-dir', str(directory/'build'), str(project/'main.omg')]
    code, wall_ms, peak_bytes, log = capture_compile(command, str(project))
    (directory/'compiler.log').write_text(log, encoding='utf-8')
    row = {'role':role, 'command':command, 'directory':str(directory), 'exit_code':code, 'compile_wall_ns':round(wall_ms*1e6), 'peak_bytes':peak_bytes, 'profile':profile}
    save(directory/'observation.json',row)
    assert code == 0, log[-5000:]
    assert not re.search(r'^\s*error(?:\[|:)',log,re.MULTILINE),log[-5000:]
    publications = re.findall(r'^published native output to (.+)$',log,re.MULTILINE)
    assert len(publications) == 1, publications
    image = Path(publications[0].strip()).resolve()
    assert image.is_relative_to((directory/'build').resolve()) and image.stat().st_size > 0,image
    row.update(image=str(image), image_sha256=digest(image), image_bytes=image.stat().st_size)
    row['phases_ms'] = {name:float(value) for value,name in re.findall(r'^\s*([\d.]+) ms\s+\d+ x\s+(\S+)\s*$',log,re.MULTILINE)}
    save(directory/'observation.json',row)
    return row

def native_check(row):
    image = Path(row['image']);directory=image.parent
    shutil.copytree(OUT/'omega-ui-a/assets/fonts/inter',directory/'fonts')
    environment=dict(os.environ,OMEGA_HEADLESS='1')
    p=subprocess.run([str(image)],cwd=directory,env=environment,capture_output=True,timeout=300)
    (directory.parent/'native.stdout').write_bytes(p.stdout)
    (directory.parent/'native.stderr').write_bytes(p.stderr)
    assert p.returncode == 0 and not p.stderr,(p.returncode,p.stdout[-2000:],p.stderr[-2000:])
    assert b'PASS: Omega UI gallery input, same-frame sliders, damage invalidation, dot hover, eleven page snapshots and pixel comparison frames' in p.stdout,p.stdout[-2000:]
    assert b'FAIL:' not in p.stdout,p.stdout[-3000:]
    sys.path.insert(0,str(OUT/'validation-tools/omega-ui'))
    import dev
    comparisons=dev.verify_snapshots(directory)
    snapshots={p.name:digest(p) for p in directory.glob('*.bmp')}
    assert len(snapshots)>=27
    return {'exit_code':p.returncode,'rgb_pairs':comparisons,'snapshots':snapshots,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest()}

if __name__ == '__main__':
    mode=sys.argv[1]
    if mode=='bootstrap':
        (OUT/'observations').mkdir()
        rows=[]
        for role in ['a','b']:
            row=compile_one(role)
            row['native']=native_check(row)
            rows.append(row)
            save(OUT/'bootstrap.json',rows)
            print(role,row['compile_wall_ns']/1e9,row['image_sha256'],flush=True)
        assert rows[0]['image_sha256']==rows[1]['image_sha256'],'before/after images differ'
        save(OUT/'expected-image.json',{'sha256':rows[0]['image_sha256'],'bytes':rows[0]['image_bytes']})
    elif mode in {'measure','profile'}:
        row=compile_one(sys.argv[2],mode=='profile')
        expected=json.loads((OUT/'expected-image.json').read_text())
        assert row['image_sha256']==expected['sha256'] and row['image_bytes']==expected['bytes'],'native image differs from validated oracle'
        row['validated_image_match']=True
        save(Path(row['directory'])/'observation.json',row)
        print(json.dumps({'schema':'omega-timed-work/1','elapsed_ns':row['compile_wall_ns'],'work_units':1,'checksum':row['image_sha256']}))
    else:
        raise ValueError(mode)
