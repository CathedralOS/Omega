from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time
root=Path.cwd();base=Path(__file__).resolve().parent;out=base/'progress-probe'
sys.path.insert(0,str(root/'tools'))
from sample_native_gate import kill_process_tree
manifest=json.loads((base/'source-identity.json').read_text())['files']
for name,expected in manifest.items():
    source=base/'omega-ui-a'/name;target=out/'omega-ui'/name
    assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
environment=dict(os.environ,LOCALAPPDATA=str(out/'cache'),OMEGA_LIBRARY_ROOT=str(root/'source/library'),OMEGA_PHASE_PROFILE='1')
command=[str(out/'omega-progress.exe'),'update','--offline','--project',str(out/'omega-ui/tests/native_component/exports'),'--target','linux_x86_64']
started=time.monotonic()
with (out/'update.stdout').open('wb') as stdout,(out/'update.stderr').open('wb') as stderr:
    with subprocess.Popen(command,env=environment,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr) as process:
        try:
            code=process.wait(timeout=180);status='exited'
        except subprocess.TimeoutExpired:
            kill_process_tree(process);process.wait();code=process.returncode;status='timeout'
(out/'update.json').write_text(json.dumps({'command':command,'status':status,'exit_code':code,'elapsed_s':time.monotonic()-started,'interpretation':'Instrumented setup diagnosis only; completed inclusive scope totals omit any still-active parent. Not an A/B performance observation.'},indent=2),encoding='utf-8')
print('DIAGNOSTIC',status,code,flush=True)
