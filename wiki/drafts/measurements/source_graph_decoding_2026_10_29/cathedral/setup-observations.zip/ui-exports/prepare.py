from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

ROOT = Path.cwd()
OUT = ROOT / 'build/performance/cathedral-ui-generation-domains'
SOURCE = Path('C:/SoftwareDevelopmentKits/Omega/.agents/worktree/cathedral-benchmark/build/ui-native-round/omega-ui')
sys.path.insert(0, str(ROOT / 'tools'))
import sample_native_gate as gate
from compiler_profile import require_optimized

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2), encoding='utf-8')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not (OUT / 'omega-ui-a').exists()
files = sorted(p for p in SOURCE.rglob('*') if p.is_file()
               and not any(part in {'build', '.git', '__pycache__'} for part in p.relative_to(SOURCE).parts)
               and p.name != 'omega.lock')
manifest = {str(p.relative_to(SOURCE)).replace('\\', '/'): digest(p) for p in files}
for role in ['a', 'b']:
    for source in files:
        target = OUT / ('omega-ui-' + role) / source.relative_to(SOURCE)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    assert all(digest(OUT / ('omega-ui-' + role) / name) == value for name, value in manifest.items())
save('source-identity.json', {'source':str(SOURCE), 'provenance':'Frozen Cathedral e493d887 plus working and compatibility migrations retained by the prior qualified native-round experiment; unchanged authored inputs for both current producers', 'files':manifest, 'file_count':len(files), 'bytes':sum(p.stat().st_size for p in files)})
(OUT/'cathedral-working.patch').write_bytes(subprocess.check_output(['git','-C',str(SOURCE),'diff','--binary','HEAD','--','.']))
identities={}
for role, name in [('a','omega-before.exe'), ('b','omega-after.exe')]:
    binary = ROOT/'build/performance/generation-domains'/name
    identities[role] = require_optimized(binary)
save('producer-identities.json',identities)
os.environ['OMEGA_LIBRARY_ROOT'] = str(ROOT/'source/library')
for role, name in [('a','omega-before.exe'), ('b','omega-after.exe')]:
    cache = OUT/('cache-'+role);cache.mkdir()
    os.environ['LOCALAPPDATA'] = str(cache)
    project = OUT/('omega-ui-'+role)/'tests/native_component/exports'
    print('PREPARE',role,flush=True)
    reason, detail = gate.accept_review(str(ROOT/'build/performance/generation-domains'/name),str(project),'linux_x86_64',300)
    save('prepare-'+role+'.json',{'reason':reason,'detail':detail})
    print('RESULT',reason,detail[-2000:],flush=True)
    assert reason is None, reason
