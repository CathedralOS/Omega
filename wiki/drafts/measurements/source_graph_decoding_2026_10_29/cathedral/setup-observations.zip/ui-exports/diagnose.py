from pathlib import Path
import json, os, subprocess, sys, time
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from sample_native_gate import kill_process_tree
os.environ.update(LOCALAPPDATA=str(out/'cache-a'),OMEGA_LIBRARY_ROOT=str(root/'source/library'),OMEGA_PHASE_PROFILE='1')
command=[str(root/'build/performance/generation-domains/omega-before.exe'),'update','--offline','--project',str(out/'omega-ui-a/tests/native_component/exports'),'--target','linux_x86_64']
started=time.monotonic()
with (out/'diagnostic.stdout').open('wb') as stdout,(out/'diagnostic.stderr').open('wb') as stderr:
    with subprocess.Popen(command,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL) as process:
        try:
            code=process.wait(timeout=180)
            status='exited'
        except subprocess.TimeoutExpired:
            kill_process_tree(process);process.wait();code=process.returncode;status='timeout'
(out/'diagnostic.json').write_text(json.dumps({'command':command,'status':status,'exit_code':code,'elapsed_s':time.monotonic()-started},indent=2),encoding='utf-8')
print(status,code,flush=True)
