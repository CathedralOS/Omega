from pathlib import Path
import subprocess,sys
out=Path(__file__).resolve().parent
for name in ['build-progress-probe.py','run-progress-probe.py']:
    print('STEP',name,flush=True)
    subprocess.run([sys.executable,str(out/name)],check=True)
