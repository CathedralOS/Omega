from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
root=Path.cwd();out=Path(__file__).resolve().parent/'release';out.mkdir(exist_ok=True)
source=root/'omega-rust/psi/foundation/compiler-storage/src/buffer.rs'
candidate=source.read_bytes()
baseline=subprocess.check_output(['git','show','b1d401fd1d3ddc5470d915bc5ab5044c2e093677:omega-rust/psi/foundation/compiler-storage/src/buffer.rs'])
identity={};environment=dict(os.environ,CARGO_BUILD_JOBS='6')
try:
    for role,contents in [('before',baseline),('after',candidate)]:
        source.write_bytes(contents)
        print('BUILD RELEASE',role,flush=True)
        command=['mbx','build','--locked','--release','-p','omega']
        with (out/(role+'-build.log')).open('wb') as log:
            process=subprocess.run(command,env=environment,stdout=log,stderr=subprocess.STDOUT)
        assert process.returncode==0,role
        binary=out/('omega-'+role+'.exe');shutil.copyfile(root/'target/release/omega.exe',binary)
        profile=json.loads(subprocess.check_output([str(binary),'--build-profile']))
        assert profile['opt_level']=='3',profile
        identity[role]={'base_revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
            'buffer_sha256':hashlib.sha256(contents).hexdigest(),'compiler_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
            'profile':profile,'command':command,'scope':'Both builds use the same current committed source except before uses the pre-optimization buffer.rs; test-only current changes are present in both builds.'}
        (out/'identities.json').write_text(json.dumps(identity,indent=2),encoding='utf-8')
finally:
    source.write_bytes(candidate)
    assert source.read_bytes()==candidate
