from pathlib import Path
import subprocess, sys
out=Path(__file__).resolve().parent
for script,arguments in [('prepare.py',[]),('observe.py',['bootstrap']),('run.py',[]),('summarize.py',[])]:
    print('STEP',script,*arguments,flush=True)
    subprocess.run([sys.executable,str(out/script),*arguments],check=True)
