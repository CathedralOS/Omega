"""Mirror the failed baseline setup, retaining live partial output on timeout."""
from pathlib import Path
import json, os, subprocess, sys, time
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import sample_native_gate as gate
os.environ.update(LOCALAPPDATA=str(OUT/'cache-b'),OMEGA_LIBRARY_ROOT=str(ROOT/'source/library'))
(OUT/'cache-b').mkdir()
commands=[]
def logged_run(command,timeout,stdin=subprocess.DEVNULL,cwd=None):
    index=len(commands);started=time.monotonic()
    stdout_path=OUT/f'candidate-prepare-{index}.stdout';stderr_path=OUT/f'candidate-prepare-{index}.stderr'
    with stdout_path.open('wb') as stdout,stderr_path.open('wb') as stderr:
        with subprocess.Popen(command,stdin=stdin,stdout=stdout,stderr=stderr,cwd=cwd) as process:
            try:
                code=process.wait(timeout=timeout);status='exited'
            except subprocess.TimeoutExpired:
                gate.kill_process_tree(process);process.wait();code=process.returncode;status='timeout'
    commands.append({'command':command,'status':status,'exit_code':code,'timeout_s':timeout,'elapsed_s':time.monotonic()-started})
    (OUT/'candidate-preparation-commands.json').write_text(json.dumps(commands,indent=2),encoding='utf-8')
    if status=='timeout':
        return None
    return subprocess.CompletedProcess(command,code,stdout_path.read_text(encoding='utf-8',errors='replace'),stderr_path.read_text(encoding='utf-8',errors='replace'))
gate.run=logged_run
reason,detail=gate.accept_review(str(OUT/'omega-after.exe'),str(OUT.parent/'omega-ui-b/tests/native_component/exports'),'linux_x86_64',600)
(OUT/'prepare-b.json').write_text(json.dumps({'reason':reason,'detail':detail},indent=2),encoding='utf-8')
print('CANDIDATE RESULT',reason,detail[-2500:],flush=True)
