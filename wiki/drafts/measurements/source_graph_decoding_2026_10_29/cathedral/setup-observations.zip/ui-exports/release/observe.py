"""Adapt the existing compiler capture to omega-bench's reported-work protocol.

Compile the prior qualified Cathedral combined UI export workload.
Validate both ELF components and execute the probe under WSL separately;
require every measured compiler to emit the same six artifact byte hashes. Only capture_compile's wall time is
reported: source hashing, artifact checks and native checks are outside the timer.
"""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, tempfile

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
from benchmark.benchmark import capture_compile

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')

def compile_one(role, profile=False):
    assert role in {'a', 'b'}
    directory = Path(tempfile.mkdtemp(prefix=('phase-' if profile else 'compile-')+role+'-', dir=OUT / 'observations'))
    compiler = OUT/('omega-before.exe' if role == 'a' else 'omega-after.exe')
    os.environ['LOCALAPPDATA'] = str(OUT/('cache-'+role))
    os.environ['OMEGA_LIBRARY_ROOT'] = str(ROOT/'source/library')
    os.environ.pop('OMEGA_PHASE_PROFILE', None)
    os.environ.pop('OMEGA_ALLOCATION_PROFILE', None)
    if profile:
        os.environ['OMEGA_PHASE_PROFILE'] = '1'
    project = OUT.parent/('omega-ui-'+role)/'tests/native_component/exports'
    command = [str(compiler), '--offline', '--timings', '--target', 'linux_x86_64', '--build-dir', str(directory/'build'), str(project/'main.omg')]
    code, wall_ms, peak_bytes, log = capture_compile(command, str(project))
    (directory/'compiler.log').write_text(log, encoding='utf-8')
    row = {'role':role, 'command':command, 'directory':str(directory), 'exit_code':code, 'compile_wall_ns':round(wall_ms*1e6), 'peak_bytes':peak_bytes, 'profile':profile}
    save(directory/'observation.json',row)
    assert code == 0, log[-5000:]
    assert not re.search(r'^\s*error(?:\[|:)',log,re.MULTILINE),log[-5000:]
    publications = re.findall(r'^published native output to (.+)$',log,re.MULTILINE)
    assert len(publications) == 1, publications
    image = Path(publications[0].strip()).resolve()
    assert image.is_relative_to((directory/'build').resolve()) and image.stat().st_size > 0,image
    sys.path.insert(0,str(OUT/'validation-tools/omega-component'))
    from elf import Elf, component
    dynamic=Elf(image.read_bytes(),2)
    shared=sorted(image.parent.glob('*.so'))
    assert len(shared)==2,shared
    for path in shared:
        component(path.read_bytes())
        assert path.with_name(path.name+'.component').is_file(),path
    artifacts={p.name:digest(p) for p in image.parent.iterdir() if p.is_file() and (p.suffix in {'.so','.component'} or p.name in {'omega-program','omega-components.tsv'})}
    assert len(artifacts)==6,artifacts
    checksum=hashlib.sha256(json.dumps(artifacts,sort_keys=True).encode()).hexdigest()
    row.update(image=str(image), image_sha256=checksum, image_bytes=sum(p.stat().st_size for p in image.parent.iterdir() if p.name in artifacts), artifacts=artifacts)
    row['phases_ms'] = {name:float(value) for value,name in re.findall(r'^\s*([\d.]+) ms\s+\d+ x\s+(\S+)\s*$',log,re.MULTILINE)}
    save(directory/'observation.json',row)
    return row

def native_check(row):
    image=Path(row['image'])
    drive_path=Path(str(image).removeprefix('\\\\?\\'))
    linux_path='/mnt/'+drive_path.drive[0].lower()+drive_path.as_posix()[2:]
    command=['wsl.exe','--distribution','Ubuntu','--exec','env','LD_LIBRARY_PATH='+str(Path(linux_path).parent).replace('\\','/'),linux_path]
    p=subprocess.run(command,capture_output=True,timeout=120)
    (image.parent.parent/'native.stdout').write_bytes(p.stdout)
    (image.parent.parent/'native.stderr').write_bytes(p.stderr)
    assert p.returncode==0 and not p.stdout and not p.stderr,(p.returncode,p.stdout[-2000:],p.stderr[-2000:])
    return {'command':command,'exit_code':p.returncode,'engine':'Linux executable under WSL Ubuntu; no GUI','oracle':'probe exits zero; both components also pass Cathedral ELF structure checks; no desktop interaction claim'}

if __name__ == '__main__':
    mode=sys.argv[1]
    if mode=='bootstrap':
        (OUT/'observations').mkdir()
        rows=[]
        for role in ['a','b']:
            row=compile_one(role)
            row['native']=native_check(row)
            rows.append(row)
            save(OUT/'bootstrap.json',rows)
            print(role,row['compile_wall_ns']/1e9,row['image_sha256'],flush=True)
        assert rows[0]['image_sha256']==rows[1]['image_sha256'],'before/after images differ'
        save(OUT/'expected-image.json',{'sha256':rows[0]['image_sha256'],'bytes':rows[0]['image_bytes']})
    elif mode in {'measure','profile'}:
        row=compile_one(sys.argv[2],mode=='profile')
        expected=json.loads((OUT/'expected-image.json').read_text())
        assert row['image_sha256']==expected['sha256'] and row['image_bytes']==expected['bytes'],'native image differs from validated oracle'
        row['validated_image_match']=True
        save(Path(row['directory'])/'observation.json',row)
        print(json.dumps({'schema':'omega-timed-work/1','elapsed_ns':row['compile_wall_ns'],'work_units':1,'checksum':row['image_sha256']}))
    else:
        raise ValueError(mode)
