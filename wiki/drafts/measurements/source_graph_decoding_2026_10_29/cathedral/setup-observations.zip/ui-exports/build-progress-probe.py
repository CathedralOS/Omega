"""Build a separate diagnostic binary; restore the CLI source unconditionally."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess
root=Path.cwd();out=Path(__file__).resolve().parent/'progress-probe';out.mkdir()
path=root/'omega-rust/omega/application/cli/src/main.rs';original=path.read_bytes()
insertion='''fn main() -> ExitCode {
    if phase_profile::enabled() {
        std::thread::spawn(|| loop {
            std::thread::sleep(std::time::Duration::from_secs(15));
            eprintln!("PROGRESS: completed inclusive scopes; not an A/B sample\\n{}", phase_profile::render());
        });
    }
'''
try:
    path.write_bytes(original.replace(b'fn main() -> ExitCode {\n',insertion.encode()))
    assert path.read_bytes()!=original
    (out/'diagnostic.patch').write_bytes(subprocess.check_output(['git','diff','--',str(path)]))
    with (out/'build.log').open('wb') as log:
        p=subprocess.run(['mbx','build','--locked','--release','-p','omega'],env=dict(os.environ,CARGO_BUILD_JOBS='6'),stdout=log,stderr=subprocess.STDOUT)
    assert p.returncode==0
    binary=out/'omega-progress.exe';shutil.copyfile(root/'target/release/omega.exe',binary)
    (out/'identity.json').write_text(json.dumps({'base_revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'main_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'purpose':'Temporary progress snapshots of completed scopes during blocked package preparation; never a performance sample'},indent=2),encoding='utf-8')
finally:
    path.write_bytes(original)
