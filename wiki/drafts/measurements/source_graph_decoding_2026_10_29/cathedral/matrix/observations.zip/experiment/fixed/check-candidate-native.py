from pathlib import Path
import json
from observe import compile_one,native_check
out=Path(__file__).resolve().parent
row=compile_one('b');row['native']=native_check(row)
(out/'candidate-qualification.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
print('CANDIDATE NATIVE PASS',row['compile_wall_ns']/1e9,row['image_sha256'],flush=True)
