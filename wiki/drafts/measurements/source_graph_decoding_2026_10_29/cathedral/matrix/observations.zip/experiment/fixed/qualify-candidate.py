from pathlib import Path
import json,os,sys
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
import sample_native_gate as gate
from observe import compile_one,native_check
(out/'cache-b').mkdir();(out/'observations').mkdir()
os.environ.update(LOCALAPPDATA=str(out/'cache-b'),OMEGA_LIBRARY_ROOT=str(root/'source/library'))
reason,detail=gate.accept_review(str(out/'omega-after.exe'),str(out.parent/'matrix-b/native'),'linux_x86_64',600)
(out/'prepare-b.json').write_text(json.dumps({'reason':reason,'detail':detail},indent=2),encoding='utf-8')
print('CANDIDATE PREPARE',reason,detail[-2500:],flush=True)
assert reason is None
row=compile_one('b');row['native']=native_check(row)
(out/'candidate-qualification.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
print('CANDIDATE NATIVE PASS',row['compile_wall_ns']/1e9,row['image_sha256'],flush=True)
