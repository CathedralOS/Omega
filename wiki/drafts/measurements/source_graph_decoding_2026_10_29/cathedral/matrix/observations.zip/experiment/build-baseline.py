from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent/'fixed'
source=root/'omega-rust/psi/foundation/compiler-storage/src/buffer.rs';candidate=source.read_bytes()
baseline=subprocess.check_output(['git','show','b1d401fd1d3ddc5470d915bc5ab5044c2e093677:omega-rust/psi/foundation/compiler-storage/src/buffer.rs'])
try:
    source.write_bytes(baseline)
    with (out/'baseline-build.log').open('wb') as log:
        p=subprocess.run(['mbx','build','--locked','-p','omega'],env=dict(os.environ,CARGO_BUILD_JOBS='6'),stdout=log,stderr=subprocess.STDOUT)
    assert p.returncode==0
    binary=out/'omega-before.exe';shutil.copyfile(root/'target/debug/omega.exe',binary)
    profile=json.loads(subprocess.check_output([str(binary),'--build-profile']));assert profile['opt_level']=='1'
    inputs=['omega-rust/psi/foundation/compiler-storage/src/buffer.rs','omega-rust/omega/compilation/backend/plans/provider-evidence/src/provider_evidence/providers/provider_plan/digest_encoder.rs','omega-rust/omega/compilation/backend/plans/provider-evidence/src/provider_evidence/providers/provider_plan/retained_inputs.rs']
    (out/'before-identity.json').write_text(json.dumps({'base_revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'profile':profile,'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in inputs}},indent=2),encoding='utf-8')
finally:
    if source.read_bytes()!=candidate:source.write_bytes(candidate)
print('BASELINE BUILT',flush=True)
