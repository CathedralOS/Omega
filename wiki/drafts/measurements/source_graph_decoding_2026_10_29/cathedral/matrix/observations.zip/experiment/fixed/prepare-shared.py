from pathlib import Path
import hashlib,json,os,shutil,sys
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sys.path.insert(0,str(ROOT/'tools'))
import sample_native_gate as gate
from observe import compile_one,native_check
manifest=json.loads((BASE/'source-identity.json').read_text())['files']
shared=BASE/'matrix-shared';assert not shared.exists()
for name,expected in manifest.items():
    source=BASE/'matrix-b'/name;assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
    target=shared/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
locks={}
for role,name in [('a','omega-before.exe'),('b','omega-after.exe')]:
    (OUT/('shared-cache-'+role)).mkdir()
    os.environ.update(LOCALAPPDATA=str(OUT/('shared-cache-'+role)),OMEGA_LIBRARY_ROOT=str(ROOT/'source/library'))
    reason,detail=gate.accept_review(str(OUT/name),str(shared/'native'),'linux_x86_64',600)
    (OUT/('shared-prepare-'+role+'.json')).write_text(json.dumps({'reason':reason,'detail':detail},indent=2),encoding='utf-8')
    print('SHARED PREPARE',role,reason,detail[-900:],flush=True);assert reason is None
    locks[role]={}
    for lock in shared.rglob('omega.lock'):
        if 'build' in lock.relative_to(shared).parts:continue
        relative=lock.relative_to(shared);copy=OUT/'accepted-locks'/role/relative
        copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(lock,copy)
        locks[role][relative.as_posix()]=hashlib.sha256(copy.read_bytes()).hexdigest()
    assert 'native/omega.lock' in locks[role]
    assert all(hashlib.sha256((shared/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
assert locks['a'].keys()==locks['b'].keys()
(OUT/'accepted-lock-identities.json').write_text(json.dumps(locks,indent=2),encoding='utf-8')
rows=[]
for role in ['a','b']:
    row=compile_one(role);row['native']=native_check(row);rows.append(row)
    (OUT/'shared-bootstrap.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print('SHARED COMPONENT PASS',role,row['image_sha256'],flush=True)
assert rows[0]['image_sha256']==rows[1]['image_sha256'],'same-root native product sets differ'
(OUT/'expected-image.json').write_text(json.dumps({'sha256':rows[0]['image_sha256'],'bytes':rows[0]['image_bytes'],'product':'same-root component, description and linked wrapper; component ABI replay is the runtime acceptance boundary; standalone wrapper remains a separate failure'},indent=2),encoding='utf-8')
import subprocess
for script in ['run.py','summarize.py']:
    print('MEASURE STEP',script,flush=True);subprocess.run([sys.executable,str(OUT/script)],check=True)
