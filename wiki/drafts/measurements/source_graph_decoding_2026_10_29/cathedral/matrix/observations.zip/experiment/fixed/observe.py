"""Adapt the existing compiler capture to omega-bench's reported-work protocol.

Compile the prior qualified Cathedral Matrix policy workload.
Validate the ELF component and execute the probe under WSL separately;
require every measured compiler to emit the same complete native artifact byte hashes. Only capture_compile's wall time is
reported: source hashing, artifact checks and native checks are outside the timer.
"""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, tempfile

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
from benchmark.benchmark import capture_compile

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')

def compile_one(role, profile=False):
    assert role in {'a', 'b'}
    directory = Path(tempfile.mkdtemp(prefix=('phase-' if profile else 'compile-')+role+'-', dir=OUT / 'observations'))
    compiler = OUT/('omega-before.exe' if role == 'a' else 'omega-after.exe')
    os.environ['LOCALAPPDATA'] = str(OUT/('shared-cache-'+role))
    os.environ['OMEGA_LIBRARY_ROOT'] = str(ROOT/'source/library')
    os.environ.pop('OMEGA_PHASE_PROFILE', None)
    os.environ.pop('OMEGA_ALLOCATION_PROFILE', None)
    if profile:
        os.environ['OMEGA_PHASE_PROFILE'] = '1'
    project = OUT.parent/'matrix-shared/native'
    accepted=json.loads((OUT/'accepted-lock-identities.json').read_text())[role]
    for relative,expected in accepted.items():
        snapshot=OUT/'accepted-locks'/role/relative
        assert digest(snapshot)==expected
        target=OUT.parent/'matrix-shared'/relative
        assert target.resolve().is_relative_to((OUT.parent/'matrix-shared').resolve())
        if not target.exists() or target.read_bytes()!=snapshot.read_bytes():
            target.write_bytes(snapshot.read_bytes())
    command = [str(compiler), '--offline', '--timings', '--target', 'linux_x86_64', '--build-dir', str(directory/'build'), str(project/'main.omg')]
    code, wall_ms, peak_bytes, log = capture_compile(command, str(project))
    (directory/'compiler.log').write_text(log, encoding='utf-8')
    assert all(digest(OUT.parent/'matrix-shared'/relative)==expected for relative,expected in accepted.items()),'compiler changed its accepted lock'
    row = {'accepted_locks':accepted,'role':role, 'command':command, 'directory':str(directory), 'exit_code':code, 'compile_wall_ns':round(wall_ms*1e6), 'peak_bytes':peak_bytes, 'profile':profile}
    save(directory/'observation.json',row)
    assert code == 0, log[-5000:]
    assert not re.search(r'^\s*error(?:\[|:)',log,re.MULTILINE),log[-5000:]
    publications = re.findall(r'^published native output to (.+)$',log,re.MULTILINE)
    assert len(publications) == 1, publications
    published = Path(publications[0].strip().removeprefix('\\\\?\\'))
    assert published.is_absolute(), published
    image = published.resolve()
    assert image.is_relative_to((directory/'build').resolve()) and image.stat().st_size > 0,image
    sys.path.insert(0,str(OUT.parent/'validator'))
    from elf import Elf, component
    dynamic=Elf(image.read_bytes(),2)
    shared=sorted(image.parent.glob('*.so'))
    assert len(shared)==1,shared
    assert dynamic.needed()==[b'$ORIGIN/'+shared[0].name.encode()],dynamic.needed()
    for path in shared:
        component(path.read_bytes())
        assert path.with_name(path.name+'.component').is_file(),path
    artifacts={p.name:digest(p) for p in image.parent.iterdir() if p.is_file() and (p.suffix in {'.so','.component'} or p.name in {'omega-program','omega-components.tsv'})}
    assert len(artifacts)==3,artifacts
    checksum=hashlib.sha256(json.dumps(artifacts,sort_keys=True).encode()).hexdigest()
    row.update(image=str(image), image_sha256=checksum, image_bytes=sum(p.stat().st_size for p in image.parent.iterdir() if p.name in artifacts), artifacts=artifacts)
    row['phases_ms'] = {name:float(value) for value,name in re.findall(r'^\s*([\d.]+) ms\s+\d+ x\s+(\S+)\s*$',log,re.MULTILINE)}
    save(directory/'observation.json',row)
    return row

def standalone_probe_check(row):
    image=Path(row['image'])
    drive_path=Path(str(image).removeprefix('\\\\?\\'))
    linux_path='/mnt/'+drive_path.drive[0].lower()+drive_path.as_posix()[2:]
    command=['wsl.exe','--distribution','Ubuntu','--exec','env','LD_LIBRARY_PATH='+str(Path(linux_path).parent).replace('\\','/'),linux_path]
    p=subprocess.run(command,capture_output=True,timeout=120)
    (image.parent.parent/'native.stdout').write_bytes(p.stdout)
    (image.parent.parent/'native.stderr').write_bytes(p.stderr)
    assert p.returncode==0 and not p.stdout and not p.stderr,(p.returncode,p.stdout[-2000:],p.stderr[-2000:])
    return {'command':command,'exit_code':p.returncode,'engine':'Linux executable under WSL Ubuntu; no GUI','oracle':'probe exits zero; the component also passes Cathedral ELF structure checks; no desktop interaction claim'}

def native_check(row):
    image=Path(row['image']);library=next(image.parent.glob('*.so'))
    sys.path.insert(0,str(OUT.parent/'validator'))
    from elf import component
    _,(symbol,_)=component(library.read_bytes())
    def linux(path):
        path=Path(str(path).removeprefix('\\\\?\\'))
        return '/mnt/'+path.drive[0].lower()+path.as_posix()[2:]
    script=OUT.parent/'component-replay.py'
    command=['wsl.exe','--distribution','Ubuntu','--exec','python3',linux(script),linux(library),symbol]
    p=subprocess.run(command,capture_output=True,timeout=120)
    (image.parent.parent/'component-native.stdout').write_bytes(p.stdout)
    (image.parent.parent/'component-native.stderr').write_bytes(p.stderr)
    assert p.returncode==0 and not p.stderr,(p.returncode,p.stdout[-2000:],p.stderr[-2000:])
    replay=json.loads(p.stdout)
    assert replay['schema']=='cathedral-matrix-policy-abi-replay/1' and len(replay['cases'])==11
    assert replay['all_packet_words_checked'] and replay['packet_words']==128
    return {'command':command,'exit_code':p.returncode,'engine':'WSL Ubuntu ctypes through the actual exported pointer/u64 component ABI','replay':replay,'standalone_probe_acceptance':'not established; a separate attempt exits SIGSEGV and remains a recorded failure'}

if __name__ == '__main__':
    mode=sys.argv[1]
    if mode=='bootstrap':
        (OUT/'observations').mkdir()
        rows=[]
        for role in ['a','b']:
            row=compile_one(role)
            row['native']=native_check(row)
            rows.append(row)
            save(OUT/'bootstrap.json',rows)
            print(role,row['compile_wall_ns']/1e9,row['image_sha256'],flush=True)
        assert rows[0]['image_sha256']==rows[1]['image_sha256'],'before/after images differ'
        save(OUT/'expected-image.json',{'sha256':rows[0]['image_sha256'],'bytes':rows[0]['image_bytes']})
    elif mode in {'measure','profile'}:
        row=compile_one(sys.argv[2],mode=='profile')
        expected=json.loads((OUT/'expected-image.json').read_text())
        assert row['image_sha256']==expected['sha256'] and row['image_bytes']==expected['bytes'],'native image differs from validated oracle'
        row['validated_image_match']=True
        save(Path(row['directory'])/'observation.json',row)
        print(json.dumps({'schema':'omega-timed-work/1','elapsed_ns':row['compile_wall_ns'],'work_units':1,'checksum':row['image_sha256']}))
    else:
        raise ValueError(mode)
