from pathlib import Path
import hashlib, json, statistics

OUT=Path(__file__).resolve().parent
MASK=(1<<64)-1
SEED=0x6f6d65676162656e

def summarize(pairs):
    before=[float(p['baseline_ns']) for p in pairs];after=[float(p['candidate_ns']) for p in pairs]
    differences=[b-a for a,b in zip(before,after)];changes=[(b/a-1)*100 for a,b in zip(before,after)]
    random=SEED;boots=[];percentage_boots=[]
    for _ in range(4000):
        sample=[];percent=[]
        for _ in pairs:
            random^=(random<<13)&MASK;random^=random>>7;random^=(random<<17)&MASK;position=random%len(pairs)
            sample.append(differences[position]);percent.append(changes[position])
        boots.append(statistics.median(sample));percentage_boots.append(statistics.median(percent))
    boots.sort();percentage_boots.sort()
    return {'pairs':len(pairs),'baseline_median_ms':statistics.median(before)/1e6,'candidate_median_ms':statistics.median(after)/1e6,
        'paired_difference_median_ms':statistics.median(differences)/1e6,'paired_percent_median':statistics.median(changes),
        'paired_percent_change_bootstrap_95':[percentage_boots[100],percentage_boots[3899]],
        'median_difference_bootstrap_95_ms':[boots[100]/1e6,boots[3899]/1e6]}

if __name__=='__main__':
    all_pairs=[];batches={};plans=[];identities=[]
    for name in ['initial','confirmation']:
        events=[json.loads(line) for line in (OUT/name/'journal.jsonl').read_text().splitlines()]
        report=json.loads((OUT/name/'report.json').read_text())
        plan=dict(events[0]['plan']);plan.pop('name');plan.pop('pairs');plan['_host']=events[0]['host'];plan['_inherited_settings']=events[0]['inherited_settings'];plans.append(plan)
        identity=dict(next(e['sha256'] for e in events if e['event']=='identities'));key=next(k for k,v in identity.items() if v==events[0]['plan_sha256']);identity.pop(key);identities.append(identity)
        rounds={}
        for event in events:
            if event['event']=='sample' and not event['sample']['warmup']:
                sample=event['sample'];rounds.setdefault(sample['round'],{})[sample['role']]=sample['primary_value']
        pairs=[{'batch':name,'round':number,'baseline_ns':s['baseline'],'candidate_ns':s['candidate']} for number,s in sorted(rounds.items())]
        observed=summarize(pairs)
        assert observed['paired_percent_change_bootstrap_95']==report['comparison']['paired_percent_change_bootstrap_95'],name
        assert observed['median_difference_bootstrap_95_ms']==[x/1e6 for x in report['comparison']['median_difference_bootstrap_95']],name
        batches[name]=observed;all_pairs.extend(pairs)
    assert plans[0]==plans[1],'plan/settings/host changed'
    assert identities[0]==identities[1],'source/binary/oracle bytes changed'
    all_rows=[json.loads(p.read_text()) for p in (OUT/'observations').glob('*/observation.json')]
    incomplete=[r for r in all_rows if 'image_sha256' not in r]
    assert all('qualification_failure' in r for r in incomplete)
    preliminary=[r for r in all_rows if 'image_sha256' in r and Path(r['command'][-1]).resolve()!=(OUT.parent/'matrix-shared/native/main.omg').resolve()]
    rows=[r for r in all_rows if 'image_sha256' in r and Path(r['command'][-1]).resolve()==(OUT.parent/'matrix-shared/native/main.omg').resolve()]
    expected=json.loads((OUT/'expected-image.json').read_text())
    assert all(row['exit_code']==0 and row['image_sha256']==expected['sha256'] for row in rows)
    phase_rows=[r for r in rows if r['profile']]
    phases={role:{name:statistics.median(r['phases_ms'][name] for r in phase_rows if r['role']==role)
        for name in phase_rows[0]['phases_ms'] if all(name in r['phases_ms'] for r in phase_rows)} for role in ['a','b']}
    result={'metric':'child-reported compiler process wall ns per one complete native compile','batches':batches,
        'exploratory_all_pairs':summarize(all_pairs),'raw_pairs':all_pairs,'phase_medians_ms':phases,'validated_image':expected,'compile_observations':len(rows),'unqualified_adapter_attempts':incomplete,'separate_root_qualification_only':preliminary}
    (OUT/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result['batches'],indent=2));print(json.dumps(result['exploratory_all_pairs'],indent=2))
