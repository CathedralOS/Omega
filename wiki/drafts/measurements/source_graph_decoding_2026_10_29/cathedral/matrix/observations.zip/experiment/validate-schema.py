from pathlib import Path
import hashlib,json,os,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent/'schema-repair';out.mkdir(exist_ok=True)
files=[root/'omega-rust/omega/compilation/backend/plans/provider-evidence/src/provider_evidence/providers/provider_plan'/name for name in ['digest_encoder.rs','retained_inputs.rs']]
saved={str(p):p.read_bytes() for p in files}
environment=dict(os.environ,CARGO_BUILD_JOBS='6')
command=['mbx','nextest','run','-p','effects']
p=subprocess.run(command,env=environment,capture_output=True)
(out/'effects-current.stdout').write_bytes(p.stdout);(out/'effects-current.stderr').write_bytes(p.stderr)
print('EFFECTS',p.returncode,p.stderr.decode(errors='replace')[-1800:],flush=True)
listing=subprocess.run(['mbx','nextest','list','-p','effects','--message-format','json'],env=environment,capture_output=True,check=True)
metadata=json.loads(listing.stdout)
binary=Path(next(iter(metadata['rust-suites'].values()))['binary-path'])
try:
    for path in files:
        path.write_bytes(subprocess.check_output(['git','show','HEAD:'+path.relative_to(root).as_posix()]))
    baseline=subprocess.run([str(binary),'--exact','source_guards::crate_carries_no_string_identity_fields','--nocapture'],capture_output=True)
    (out/'guard-baseline.stdout').write_bytes(baseline.stdout);(out/'guard-baseline.stderr').write_bytes(baseline.stderr)
    assert baseline.returncode!=0
    for fragment in [b'behavior_exclusions',b'evaluated_bindings']:
        assert fragment in baseline.stderr and fragment in p.stderr
    print('Existing source guard fails on unchanged HEAD source with the same two files',flush=True)
finally:
    for path in files:path.write_bytes(saved[str(path)])
assert p.returncode!=0 and b'13 passed, 1 failed' in p.stderr
assert b'source_guards::crate_carries_no_string_identity_fields' in p.stderr
for name in ['provider_evidence/executable_scopes/behavior_exclusions/authored.rs','provider_evidence/providers/provider_plan/evaluated_bindings.rs','source_guards.rs']:
    path=files[0].parents[2]/name
    if not path.exists():path=root/'omega-rust/omega/compilation/backend/plans/provider-evidence/src'/name
    assert path.read_bytes()==subprocess.check_output(['git','show','HEAD:'+path.relative_to(root).as_posix()])
with (out/'component-description.log').open('wb') as log:
    check=subprocess.run(['mbx','nextest','run','-p','component-description'],env=environment,stdout=log,stderr=subprocess.STDOUT)
print('COMPONENT DESCRIPTION',check.returncode,flush=True)
assert check.returncode==0 or (check.returncode==4 and b'Starting 0 tests' in (out/'component-description.log').read_bytes())
(out/'source-overlay.json').write_text(json.dumps({path.relative_to(root).as_posix():hashlib.sha256(path.read_bytes()).hexdigest() for path in files},indent=2),encoding='utf-8')
