from pathlib import Path
import json, os, sys
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import sample_native_gate as gate
os.environ['OMEGA_LIBRARY_ROOT']=str(ROOT/'source/library')
for role,name in [('a','omega-before.exe'),('b','omega-after.exe')]:
    (OUT/('cache-'+role)).mkdir()
    os.environ['LOCALAPPDATA']=str(OUT/('cache-'+role))
    project=OUT/('matrix-'+role)/'native'
    print('PREPARE MATRIX',role,flush=True)
    reason,detail=gate.accept_review(str(ROOT/'build/performance/generation-domains'/name),str(project),'linux_x86_64',600)
    (OUT/('prepare-'+role+'.json')).write_text(json.dumps({'reason':reason,'detail':detail},indent=2),encoding='utf-8')
    print('RESULT',reason,detail[-2200:],flush=True)
    assert reason is None,reason
