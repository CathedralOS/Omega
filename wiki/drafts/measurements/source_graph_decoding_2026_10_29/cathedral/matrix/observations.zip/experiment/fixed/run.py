from pathlib import Path
import hashlib, json, os, subprocess, sys

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
BENCH=ROOT/'build/performance/generation-domains/omega-bench.exe'

def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2),encoding='utf-8')

def caches():
    return {role:{str(p.relative_to(OUT/('shared-cache-'+role))):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in (OUT/('shared-cache-'+role)).rglob('*.rec')} for role in ['a','b']}

commands=[]
def run(label,args,accepted=(0,)):
    p=subprocess.run([str(x) for x in args],capture_output=True)
    (OUT/(label+'.stdout')).write_bytes(p.stdout);(OUT/(label+'.stderr')).write_bytes(p.stderr)
    commands.append({'label':label,'command':[str(x) for x in args],'exit_code':p.returncode});save('commands.json',commands)
    print(label,p.returncode,p.stdout.decode(errors='replace')[:700],flush=True)
    assert p.returncode in accepted,p.stderr.decode(errors='replace')[-3000:]

source=json.loads((OUT.parent/'source-identity.json').read_text())['files']
inputs=[]
for name,expected in source.items():
    path=OUT.parent/'matrix-shared'/name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,path
    inputs.append(str(path))
inputs += [str(OUT/'accepted-locks'),str(OUT/'accepted-lock-identities.json')]
inputs += [str(ROOT/'source/library'),str(OUT/'observe.py'),str(OUT/'expected-image.json'),str(OUT.parent/'component-replay.py'),str(OUT.parent/'validator'),str(ROOT/'tools/benchmark/benchmark.py'),str(ROOT/'tools/compiler_profile.py')]
inputs += [str(OUT/name) for name in ['omega-before.exe','omega-after.exe']]
checksum=json.loads((OUT/'expected-image.json').read_text())['sha256']
initial_caches=caches();assert all(initial_caches.values());save('cache-identities-before.json',initial_caches)
for batch,pairs in [('initial',32),('confirmation',16)]:
    plan={'schema':'omega-performance-plan/1','name':'Cathedral Matrix policy component publication; standalone probe runtime remains failing '+batch,'working_directory':str(ROOT),'inputs':inputs,
        'baseline':{'program':sys.executable,'arguments':[str(OUT/'observe.py'),'measure','a']},
        'candidate':{'program':sys.executable,'arguments':[str(OUT/'observe.py'),'measure','b']},
        'warmups':2,'pairs':pairs,'timeout_ms':240000,
        'measurement':{'kind':'reported_work','stdin':'','work_units':1,'checksum':checksum}}
    save(batch+'-plan.json',plan)
    run(batch,[BENCH,'compare',OUT/(batch+'-plan.json'),OUT/batch])
    run(batch+'-validate',[BENCH,'validate',OUT/batch])
    run(batch+'-check',[BENCH,'check',OUT/batch,'0'],accepted=(0,2,3))
    assert caches()==initial_caches,'retained cache bytes changed'
for trial in range(3):
    for role in (['a','b'] if trial%2==0 else ['b','a']):
        run(f'phase-{trial}-{role}',[sys.executable,OUT/'observe.py','profile',role])
assert caches()==initial_caches,'retained cache bytes changed'
save('cache-identities-after.json',caches())
print('COMPLETE',flush=True)
