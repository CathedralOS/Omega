"""Exercise the emitted policy component through its actual pointer/u64 ABI.

The stock lifecycle policy defines these results and writes. Neighbour and tail
canaries make wrong argument placement and unintended stores observable.
"""
import ctypes,json,sys
library=ctypes.CDLL(sys.argv[1]);decide=getattr(library,sys.argv[2])
decide.argtypes=[ctypes.POINTER(ctypes.c_uint64)];decide.restype=ctypes.c_uint64
cases=[('unknown',{},0,{}),('begin',{0:3,16:85,17:102},1,{16:0,17:0}),
    ('sent',{0:4,1:2,2:1,16:1},1,{16:5}),('answered',{0:5,1:2,2:1,16:5},1,{16:1}),
    ('finish',{0:6},1,{}),('finish-loss',{0:6,17:1},2,{}),
    ('close-child',{0:7,1:1},3,{}),('close-clean',{0:7,2:1},2,{}),
    ('close-uncertain',{0:7},1,{}),('gate',{0:8,1:1,2:1},1,{}),('gate-refuse',{0:8,1:1},0,{})]
observed=[]
for name,values,expected_result,writes in cases:
    packet=(ctypes.c_uint64*128)()
    for position,value in {15:0x123456789ABCDEF,18:0x3456789ABCDEF01,120:0x456789ABCDEF012,127:0x56789ABCDEF0123,**values}.items():packet[position]=value
    expected_packet=list(packet)
    for position,value in writes.items():expected_packet[position]=value
    result=decide(packet)
    assert result==expected_result,(name,result,expected_result)
    assert list(packet)==expected_packet,(name,'unexpected packet write')
    observed.append({'case':name,'result':result})
print(json.dumps({'schema':'cathedral-matrix-policy-abi-replay/1','cases':observed,'packet_words':128,'all_packet_words_checked':True}))
