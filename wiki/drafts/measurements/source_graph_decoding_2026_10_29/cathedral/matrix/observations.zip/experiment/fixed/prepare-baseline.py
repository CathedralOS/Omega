from pathlib import Path
import json,os,sys
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
import sample_native_gate as gate
from observe import compile_one,native_check
(out/'cache-a').mkdir()
os.environ.update(LOCALAPPDATA=str(out/'cache-a'),OMEGA_LIBRARY_ROOT=str(root/'source/library'))
reason,detail=gate.accept_review(str(out/'omega-before.exe'),str(out.parent/'matrix-a/native'),'linux_x86_64',600)
(out/'prepare-a.json').write_text(json.dumps({'reason':reason,'detail':detail},indent=2),encoding='utf-8')
print('BASELINE PREPARE',reason,detail[-900:],flush=True)
assert reason is None
rows=[]
for role in ['a','b']:
    row=compile_one(role);row['native']=native_check(row);rows.append(row)
    (out/'bootstrap.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print('COMPONENT ABI PASS',role,row['compile_wall_ns']/1e9,row['image_sha256'],flush=True)
assert rows[0]['image_sha256']==rows[1]['image_sha256'],'native product sets differ'
(out/'expected-image.json').write_text(json.dumps({'sha256':rows[0]['image_sha256'],'bytes':rows[0]['image_bytes'],'product':'complete component plus linked wrapper publication; runtime acceptance is the actual component ABI, not the failing standalone wrapper'},indent=2),encoding='utf-8')

# Keep this lane's acquisition for the complete local measurement chain.
import subprocess
for script in ['run.py','summarize.py']:
    print('MEASURE STEP',script,flush=True)
    subprocess.run([sys.executable,str(out/script)],check=True)
