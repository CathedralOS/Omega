import json,os,signal,subprocess,sys
from pathlib import Path
image=Path(sys.argv[1])
environment=dict(os.environ,LD_LIBRARY_PATH=str(image.parent))
p=subprocess.run([str(image)],env=environment,capture_output=True,timeout=30)
print(json.dumps({'schema':'cathedral-standalone-probe-observation/1','returncode':p.returncode,'signal':signal.Signals(-p.returncode).name if p.returncode<0 else None,'expected_exit_code':0,'passed':p.returncode==0 and not p.stdout and not p.stderr,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}))
