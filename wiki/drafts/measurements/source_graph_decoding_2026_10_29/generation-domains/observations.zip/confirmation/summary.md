# Performance suite

# length independent confirmation

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 1527656650.0 | 1520727700.0 | -0.78% |
| cpu_cycles | 5517736875.0 | 5304665475.0 | -6.10% |
| native_image_bytes | 1536.0 | 1536.0 | +0.00% |
| peak_resident_bytes | 358502400.0 | 370876416.0 | +1.87% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 4.0765 | 3.7990000000000004 | -3.24% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 44.1465 | 41.955 | -4.71% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 137.25349999999997 | 123.848 | -8.51% |
| stage_ms:compile: sources -> requested product | 265.236 | 254.69 | -1.94% |
| stage_ms:prepare: project -> prepared sources | 31.628 | 38.075 | +10.63% |
| stage_ms:publish: retained product -> published product | 6.007 | 6.1515 | +4.23% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.037 | 0.033 | -17.65% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 10.504000000000001 | 10.577 | -4.75% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.002 | 0.003 | unavailable |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.1645 | 0.154 | -9.46% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.0945 | 0.08349999999999999 | -7.54% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 11.003 | 11.106 | -4.61% |
| stage_ms:total elapsed | 1206.1895 | 1153.036 | -5.84% |
| system_cpu_ns | 562500000.0 | 601562500.0 | +2.44% |
| total_page_faults | 92628.5 | 91598.0 | -0.13% |
| user_cpu_ns | 656250000.0 | 562500000.0 | -11.65% |

Scope and limitations: see report warnings and each observation's resource provider.

# square independent confirmation

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 1696873700.0 | 1579823350.0 | -6.43% |
| cpu_cycles | 5917558275.0 | 5523902325.0 | -3.93% |
| native_image_bytes | 1024.0 | 1024.0 | +0.00% |
| peak_resident_bytes | 355045376.0 | 364304384.0 | +0.05% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 4.07 | 4.468999999999999 | +1.71% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 62.852000000000004 | 62.0675 | -4.98% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 141.5195 | 147.44850000000002 | +2.45% |
| stage_ms:compile: sources -> requested product | 272.31 | 272.76099999999997 | -2.63% |
| stage_ms:prepare: project -> prepared sources | 34.2175 | 31.2995 | +1.86% |
| stage_ms:publish: retained product -> published product | 6.1715 | 6.1535 | +1.92% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.037 | 0.042 | +8.60% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 9.474499999999999 | 8.689 | -5.96% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.0025 | 0.002 | -16.67% |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.601 | 0.643 | -0.11% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.0905 | 0.0945 | +1.35% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 10.36 | 9.7095 | -5.22% |
| stage_ms:total elapsed | 1308.5435 | 1222.742 | -9.02% |
| system_cpu_ns | 664062500.0 | 664062500.0 | +7.66% |
| total_page_faults | 92061.0 | 90105.5 | +0.00% |
| user_cpu_ns | 640625000.0 | 562500000.0 | -12.20% |

Scope and limitations: see report warnings and each observation's resource provider.

