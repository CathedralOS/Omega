# Performance suite

# length matched compiler before/after

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 1095003000.0 | 939261450.0 | -9.92% |
| cpu_cycles | 4188185325.0 | 3514832775.0 | -12.96% |
| native_image_bytes | 1536.0 | 1536.0 | +0.00% |
| peak_resident_bytes | 370724864.0 | 371005440.0 | +0.08% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 2.2815000000000003 | 2.123 | -9.56% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 26.401 | 26.325 | -2.01% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 77.136 | 73.5715 | -8.25% |
| stage_ms:compile: sources -> requested product | 152.23899999999998 | 145.8225 | -7.22% |
| stage_ms:prepare: project -> prepared sources | 21.43 | 20.22 | -2.63% |
| stage_ms:publish: retained product -> published product | 4.7285 | 4.508 | -2.44% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.022 | 0.022 | -1.43% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 6.9535 | 6.3955 | -5.11% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.001 | 0.001 | unavailable |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.109 | 0.103 | -12.48% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.06 | 0.055 | -4.55% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 7.2795000000000005 | 6.6985 | -5.98% |
| stage_ms:total elapsed | 869.9205 | 721.356 | -12.78% |
| system_cpu_ns | 453125000.0 | 437500000.0 | -12.41% |
| total_page_faults | 91511.0 | 91593.0 | +0.08% |
| user_cpu_ns | 460937500.0 | 437500000.0 | -12.25% |

Scope and limitations: see report warnings and each observation's resource provider.

# square matched compiler before/after

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 959203300.0 | 917821900.0 | -3.80% |
| cpu_cycles | 3585567375.0 | 3411247275.0 | -6.16% |
| native_image_bytes | 1024.0 | 1024.0 | +0.00% |
| peak_resident_bytes | 364797952.0 | 364855296.0 | +0.01% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 1.919 | 1.9455 | -1.81% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 33.691500000000005 | 34.203500000000005 | -0.64% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 64.0365 | 64.256 | -0.24% |
| stage_ms:compile: sources -> requested product | 130.39499999999998 | 128.0185 | +1.05% |
| stage_ms:prepare: project -> prepared sources | 19.205 | 19.3545 | +0.05% |
| stage_ms:publish: retained product -> published product | 4.547499999999999 | 4.1579999999999995 | -3.23% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.0225 | 0.023 | +0.00% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 4.749499999999999 | 4.692500000000001 | -1.43% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.001 | 0.001 | unavailable |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.358 | 0.367 | -0.84% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.0535 | 0.0555 | +1.92% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 5.2795000000000005 | 5.202500000000001 | -0.72% |
| stage_ms:total elapsed | 740.1324999999999 | 694.8715 | -6.60% |
| system_cpu_ns | 367187500.0 | 375000000.0 | -1.92% |
| total_page_faults | 90055.5 | 90076.5 | +0.02% |
| user_cpu_ns | 429687500.0 | 390625000.0 | -9.36% |

Scope and limitations: see report warnings and each observation's resource provider.

