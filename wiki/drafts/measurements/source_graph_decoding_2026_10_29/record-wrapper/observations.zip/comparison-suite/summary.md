# Performance suite

# length matched compiler before/after

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 1306696450.0 | 1250437050.0 | +1.26% |
| cpu_cycles | 4966944750.0 | 4845008925.0 | +0.95% |
| native_image_bytes | 1536.0 | 1536.0 | +0.00% |
| peak_resident_bytes | 371939328.0 | 370755584.0 | -0.31% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 3.6905 | 3.904 | +2.26% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 33.566 | 38.495999999999995 | +1.90% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 113.57300000000001 | 111.6015 | +4.92% |
| stage_ms:compile: sources -> requested product | 218.313 | 221.86450000000002 | +2.52% |
| stage_ms:prepare: project -> prepared sources | 29.47 | 28.04 | -1.72% |
| stage_ms:publish: retained product -> published product | 6.42 | 6.093500000000001 | -4.43% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.034 | 0.0325 | -3.49% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 8.091 | 9.2915 | +10.29% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.002 | 0.001 | unavailable |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.1405 | 0.152 | +7.83% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.081 | 0.083 | +4.18% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 8.46 | 9.729 | +9.54% |
| stage_ms:total elapsed | 1031.8255 | 1010.913 | +1.27% |
| system_cpu_ns | 531250000.0 | 515625000.0 | +3.87% |
| total_page_faults | 91920.0 | 91540.5 | -0.42% |
| user_cpu_ns | 562500000.0 | 531250000.0 | -5.90% |

Scope and limitations: see report warnings and each observation's resource provider.

# square matched compiler before/after

Primary metric: `compiler_process_wall_ns`

| Metric | Baseline median | Candidate median | Paired change |
| --- | ---: | ---: | ---: |
| primary | 1079598450.0 | 1147859500.0 | +5.18% |
| cpu_cycles | 4050521550.0 | 4351763025.0 | +7.38% |
| native_image_bytes | 1024.0 | 1024.0 | +0.00% |
| peak_resident_bytes | 366268416.0 | 364910592.0 | -0.37% |
| stage_ms:Stage 05: TypedTrees -> CheckedTrees | 2.7714999999999996 | 3.3005 | +12.65% |
| stage_ms:Step: build: AssembledSyntax -> CheckedTrees (contains Stage 01-05) | 39.4915 | 43.391 | +12.22% |
| stage_ms:Step: settle: CheckedTrees -> SelectedExecution | 83.535 | 89.9125 | +12.64% |
| stage_ms:compile: sources -> requested product | 159.1865 | 174.813 | +11.76% |
| stage_ms:prepare: project -> prepared sources | 24.0365 | 24.997999999999998 | +1.28% |
| stage_ms:publish: retained product -> published product | 5.132 | 5.453 | +6.48% |
| stage_ms:terminal-production/entry-receipt: OptimizedLoweredPsi -> ProgramEntryReceipt | 0.025 | 0.027 | +0.00% |
| stage_ms:terminal-production/lowering: CheckedTrees -> LoweredPsi | 5.25 | 7.04 | +40.45% |
| stage_ms:terminal-production/machine-selection: CheckedTrees -> TerminalMachine | 0.001 | 0.001 | unavailable |
| stage_ms:terminal-production/optimization: LoweredPsi -> OptimizedLoweredPsi | 0.4555 | 0.4845 | +4.68% |
| stage_ms:terminal-production/publication: OptimizedLoweredPsi -> CanonicalTerminalArtifact | 0.06 | 0.063 | +7.81% |
| stage_ms:terminal-production: CheckedTrees -> CanonicalTerminalArtifact | 5.934 | 7.814 | +37.38% |
| stage_ms:total elapsed | 841.617 | 898.5525 | +6.43% |
| system_cpu_ns | 421875000.0 | 476562500.0 | +2.00% |
| total_page_faults | 90469.5 | 90085.5 | -0.42% |
| user_cpu_ns | 460937500.0 | 500000000.0 | +9.97% |

Scope and limitations: see report warnings and each observation's resource provider.

