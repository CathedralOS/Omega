import json,subprocess,hashlib
from pathlib import Path
record=json.loads(Path('build/tpr6/owner-review.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert record['candidate']==head
assert record['reviewer_role']=='implementation owner; not independent'
assert record['accepted'] is True
subprocess.run(['git','diff','--check',record['base'],head],check=True)
for row in record['evidence']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
subprocess.run(['python3','build/tpr6/verify-shape.py'],check=True)
print(json.dumps({'candidate':head,'owner_review':'accepted','independent_review':False,'evidence_files':len(record['evidence'])}))
