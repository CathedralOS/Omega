import subprocess,json,sys,re,hashlib,os,time
from pathlib import Path
binary=Path(sys.argv[1]).resolve();label=sys.argv[2];out=Path('build/tpr6')/label;out.mkdir(exist_ok=True)
paths=['pass/domains/progress_domain_provider','pass/termination/target_family_published_progress','pass/termination/native_layout_family_premises','pass/termination/native_layout_ordinary_progress','pass/progress/provider_receiver_progress_installation','fail/termination/native_layout_family_missing_premise','pass/borrows/local_fixed_array_shared_state_loan_exit','pass/borrows/nested_reference_join_state_backing_exit','pass/borrows/owned_reference_arrival_projection_exit','pass/borrows/returned_record_call_binding_state_exit','fail/borrows/indexed_carrier_state_local_escape','fail/borrows/state_arrival_recast_keeps_backing_loan','pass/termination/progress_selector_owned_snapshot_exit','pass/termination/progress_selector_reference_snapshot_exit','fail/termination/progress_selector_owned_snapshot_rejected','fail/termination/progress_selector_reference_snapshot_rejected']
rows=[]
for relative in paths:
 folder=Path('tests/omega')/relative;source=folder/'main.omg';negative=relative.startswith('fail/');native=(folder/'expected_native_exit.txt').exists() and not negative
 command=[str(binary),*(['run','--both','--keep'] if native else ['--check']),str(source)]
 p=subprocess.run(command,capture_output=True,text=True,timeout=180,env={**os.environ,'XDG_CACHE_HOME':'/workspace/.cache'})
 expected=(folder/'expected.txt').read_text().strip().splitlines() if negative else []
 # Some fixture expectations contain explanatory lines; first line is the diagnostic substring.
 if negative: accepted=p.returncode==1 and expected[0] in p.stderr
 elif native:
  oracle=(folder/'expected_native_exit.txt').read_text().strip();accepted=p.returncode==0 and re.search(r'(?m)^native exit '+re.escape(oracle)+r'\s*$',p.stderr) is not None and re.search(r'(?m)^interp exit: '+re.escape(oracle)+r'\s*$',p.stderr) is not None
 else: accepted=p.returncode==0
 key=relative.replace('/','_');(out/(key+'.stdout')).write_text(p.stdout);(out/(key+'.stderr')).write_text(p.stderr)
 row={'source':str(source),'command':command,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'exit':p.returncode,'native':native,'accepted':accepted,'stderr':p.stderr};rows.append(row);print(json.dumps(row),flush=True);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
sys.exit(0 if all(r['accepted'] for r in rows) else 1)
