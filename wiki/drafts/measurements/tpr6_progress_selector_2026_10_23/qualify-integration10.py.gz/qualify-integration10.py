import json,subprocess,sys,hashlib
from pathlib import Path
binary=Path(sys.argv[1]).resolve();label=sys.argv[2]
manifest=json.loads(Path('build/tpr6/integration10-runtime-artifacts.json').read_text())
for path in manifest:
 p=Path(path)
 if p.name=='omega-program':
  run=subprocess.run([str(p)],capture_output=True,stdin=subprocess.DEVNULL,timeout=30)
  assert run.returncode==0 and run.stdout==b'' and run.stderr==b'',path
print('Pinned native artifacts replayed: nine exact exit-0 programs',flush=True)
subprocess.run([sys.executable,'build/tpr6/run-row-parallel.py',str(binary),label,'all'],check=True)
focused=subprocess.run([sys.executable,'build/tpr6/focused-parallel.py',str(binary),label+'-focused'])
base={row['source']:row for row in json.loads(Path('build/tpr6/baseline-focused/results.json').read_text())}
rows=json.loads((Path('build/tpr6')/(label+'-focused')/'results.json').read_text())
known={'tests/omega/pass/borrows/local_fixed_array_shared_state_loan_exit/main.omg','tests/omega/pass/borrows/owned_reference_arrival_projection_exit/main.omg'}
for row in rows:
 if row['accepted']:continue
 assert row['source'] in known,row
 old=base[row['source']]
 assert row['sha256']==old['sha256'] and row['exit']==old['exit'] and row['stderr']==old['stderr'],row
 print('Exact retained baseline failure: '+row['source'],flush=True)
assert focused.returncode in [0,1]
print('Focused oracles passed with only byte-identical recorded baseline failures',flush=True)
