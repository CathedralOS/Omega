from pathlib import Path
places=['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']
root=Path('samples/cli/facts/progress_selector')
fact='// A finite selector retains every exact progress subject required by its selected operation.'
for place in places:
 folder=root/place;positive=(folder/'main.omg').read_text();negative=(folder/'invalid/main.omg').read_text()
 assert positive.splitlines()[0]==fact
 assert negative==positive.replace('right in Token::Fair, ','')
 for target in ['linux_x86_64','linux_arm64','macos_arm64','windows_x86_64']:
  assert target+'::ProgramEntry' in (folder/'build.omg').read_text()
 for name in ['expected_native_exit.txt','expected_interpreter_exit.txt']:assert (folder/name).read_text().strip()=='0'
 for category,origin,suffix,files in [('pass',folder,'exit',['main.omg','build.omg','expected_native_exit.txt','expected_interpreter_exit.txt']),('fail',folder/'invalid','rejected',['main.omg','build.omg','expected.txt'])]:
  fixture=Path('tests/omega')/category/'facts'/('progress_selector_through_'+place+'_'+suffix)
  for name in files:assert (origin/name).read_bytes()==(fixture/name).read_bytes()
print('Nine identical-fact placements, exact premise-only reject twins, four hosted bindings and pinned fixture copies verified')
