import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
binary=Path(sys.argv[1]).resolve();label=sys.argv[2];mode=sys.argv[3] if len(sys.argv)>3 else 'all'
output=Path('build/tpr6')/label;output.mkdir(exist_ok=True);root=Path('samples/cli/facts/progress_selector')
places=['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body'];projects=[]
if mode in ['all','native']:projects += [(p,root/p/'main.omg',True) for p in places]
if mode in ['all','negative']:
 projects += [(p+'_invalid',root/p/'invalid/main.omg',False) for p in places]
 projects += [('control_'+p.name,p/'main.omg',False) for p in sorted((root/'controls').glob('*'))]
producer=hashlib.sha256(binary.read_bytes()).hexdigest()
def execute(project):
 name,source,positive=project;command=[str(binary),*(['run','--both','--keep'] if positive else ['--check']),str(source)];start=time.monotonic()
 try:
  p=subprocess.run(command,capture_output=True,text=True,env={**os.environ,'XDG_CACHE_HOME':'/workspace/.cache'},stdin=subprocess.DEVNULL,timeout=180);stdout=p.stdout;stderr=p.stderr;code=p.returncode
 except subprocess.TimeoutExpired as error:stdout=str(error.stdout);stderr=str(error.stderr);code=None
 (output/(name+'.stdout')).write_text(stdout);(output/(name+'.stderr')).write_text(stderr)
 native=re.search(r'(?m)^native exit (\d+)\s*$',stderr);terminal=re.search(r'(?m)^interp exit: (\d+)\s*$',stderr)
 expected=[] if positive else json.loads((source.parent/'sample.json').read_text())['rejection_contains']
 if not positive:assert expected
 accepted=(code==0 and native is not None and native.group(1)=='0' and terminal is not None and terminal.group(1)=='0') if positive else (code==1 and all(text in stderr for text in expected))
 return {'name':name,'command':command,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'producer_sha256':producer,'exit':code,'native_exit':int(native.group(1)) if native else None,'terminal_exit':int(terminal.group(1)) if terminal else None,'seconds':time.monotonic()-start,'accepted':accepted,'expected_diagnostics':expected,'stderr':stderr}
rows=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for row in pool.map(execute,projects):
  rows.append(row);print(json.dumps(row),flush=True);(output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
sys.exit(0 if rows and len(rows)==len(projects) and all(row['accepted'] for row in rows) else 1)
