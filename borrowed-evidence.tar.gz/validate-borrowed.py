from pathlib import Path
import json,hashlib,subprocess
r=Path('build/retired-state-consumers');root=Path('samples/cli/facts/nested_machine_invocation/borrowed_result')
def load(name):return json.loads((r/name).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
producer='a333043e988f60910a8ee26f3775c99b5d1a562a';base='25647e44e4b9e86232598a6b829e90e794f3b2f8'
for receipt,binary in [('producer.json','omega'),('runner-producer.json','corpus_runner')]:
 x=load('borrowed-producer-2/'+receipt);assert x['revision']==producer and digest(r/'borrowed-producer-2'/binary)==x['sha256'] and x['profile']['opt_level']=='1'
subprocess.run(['git','diff','--exit-code',producer,'HEAD','--','omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml','clippy.toml'],check=True)
x=load('base/producer.json');assert x['revision']==base and digest(r/'base/omega')==x['sha256'] and x['profile']['opt_level']=='1'
for source,sha in load('borrowed-result-frozen.json').items():assert digest(source)==sha
for source,sha in load('borrowed-control-formed-frozen.json')['sources'].items():assert digest(source)==sha
baseline=load('borrowed-row-baseline.json');assert len(baseline)==18
for a in baseline:
 assert digest(a['source'])==a['source_sha256'] and a['exit']==1
 if not a['invalid']:assert 'cannot prove default-domain field requirement for return from qualify' in a['stderr']
rows=load('borrowed-row-repaired-2.json');assert len(rows)==18
for a in rows:
 assert digest(a['source'])==a['source_sha256'];source=Path(a['source']);place=source.parent.parent.name if a['invalid'] else source.parent.name
 pin=Path('tests/omega')/('fail' if a['invalid'] else 'pass')/'facts'/('nested_machine_borrowed_result_'+place+('_rejected' if a['invalid'] else '_exit'))
 for name in ['main.omg','build.omg']:assert (source.parent/name).read_bytes()==(pin/name).read_bytes()
 if a['invalid']:assert a['exit']==1 and all(fragment in a['stderr'] for fragment in (pin/'expected.txt').read_text().splitlines())
 else:assert a['exit']==0 and 'native exit 0' in a['stderr'] and 'interp exit: 0' in a['stderr']
controls=load('borrowed-controls-repaired.json');assert len(controls)==7
for a in controls:
 source=Path(a['source']);assert digest(source)==a['source_sha256'];name=source.parent.name;pin=Path('tests/omega')/('pass' if a['trap'] else 'fail')/'facts'/('nested_machine_borrowed_result_'+name+('' if a['trap'] else '_rejected'))
 for file in ['main.omg','build.omg']:assert (source.parent/file).read_bytes()==(pin/file).read_bytes()
 if a['trap']:assert a['exit']==255 and 'native signal 5' in a['stderr'] and 'interp crash: Trap (host presentation agrees)' in a['stderr']
 else:assert a['exit']==1 and all(fragment in a['stderr'] for fragment in (pin/'expected.txt').read_text().splitlines())
for mode,n in [('source',25),('runtime',10)]:
 x=load('pin-'+mode+'.json');assert len(x['observations'])==n and x['verdict']=='recorded' and not x['oracle_failures'] and not x['infrastructure_error']
 for a in x['observations']:
  if mode=='source':assert a['status']==('rejected' if a['tier']=='fail' else 'checked') and(a['tier']!='fail' or a['expected_satisfied'] is True)
  elif a['fixture'].endswith('invalid_utf8'):assert a['status']=='built' and a['facts'].get('interpreter')=='trapped' and a['facts'].get('exit')=='signal' and a['facts'].get('signal')=='5',a
  else:assert a['status']=='built' and a['facts'].get('exit')==a['facts'].get('interpreter-exit')=='0' and a['facts'].get('interpreter')=='agrees',a
source=load('neighbor-source.json');assert len(source['observations'])==63 and not source['oracle_failures'] and not source['infrastructure_error']
baseline_controls={a['source']:a for a in load('neighbor-all-negative-baseline.json')}
for a in source['observations']:
 if a['tier']=='fail':
  assert a['status']=='rejected'
  if not a['expected_satisfied']:
   b=baseline_controls['tests/omega/'+a['fixture']+'/main.omg'];assert b['exit']==1 and digest(b['source'])==b['source_sha256'];assert all(d in b['stderr'] for d in a['diagnostics'])
 else:assert a['status']=='checked' or (a['fixture']=='pass/facts/borrowed_restoration_window_through_other_state_exit' and a['status']=='incomplete')
runtime=load('neighbor-runtime.json');assert len(runtime['observations'])==18 and not runtime['infrastructure_error']
for a in runtime['observations']:
 if a['fixture']=='pass/facts/borrowed_restoration_window_through_other_state_exit':assert a['status']=='incomplete' and 'structural result has no selected disposition' in a['diagnostics'][0]
 else:assert a['status']=='built' and a['facts'].get('exit')==a['facts'].get('interpreter-exit')=='0' and a['facts'].get('interpreter')=='agrees'
b=load('neighbor-runtime-baseline.json')[0];assert b['exit']==200 and 'structural result has no selected disposition' in b['stderr'] and digest(b['source'])==b['source_sha256']
for name in ['build','runner-build','clippy']:assert load('borrowed-producer-2/'+name+'-command.json')['exit']==0
assert load('format.json')['exit']==0
counter=load('borrowed-counterfactual.json');assert digest(counter['source'])==counter['source_sha256'] and counter['exit']==255 and 'native signal 5' in counter['stderr'] and 'interp crash: Trap (host presentation agrees)' in counter['stderr']
print(json.dumps(dict(accepted=True,retained_producer=producer,fixed_base=base,target='macos_arm64',row_native_terminal=9,row_requires_refusals=9,soundness_refusals=6,invalid_utf8_trap='nativeSIG5/TerminalTrap',counterfactual='nativeSIG5/TerminalTrap',corpus_source=25,corpus_runtime=10,neighbor_source=63,neighbor_runtime_agreements=17,baseline_incomplete_runtime=1,baseline_wrong_fragment_controls=5,compiler_and_library_inputs='byte-identical to retained producer; migrated customer sources separated before submission',scope='qualified borrowed completion prerequisite; full declaration migration and other-host runtime remain open'),indent=2))
