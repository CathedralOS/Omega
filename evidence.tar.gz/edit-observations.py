exec(open('build/private-cycle-ranks/edit.py').read().split("p=ck/'facts/termination/arrival_correspondence.rs'")[0])
p=v/'proof_contracts/contract_entailment/ranking_range.rs';s=p.read_text();a=s.index('pub fn ranking_slice_length_observation(');b=s.index('/// Exact collection geometry',a)
s=s[:a]+'''/// Read the exact admitted descriptor coordinate in its own state's namespace.
/// The source witness and inferred private coordinates use this same query;
/// neither execution planning nor lowering needs an authored AST occurrence.
pub fn ranking_slice_length_observation(
    program: &dyn crate::CheckingInput,
    state: &State,
    coordinate: &RankSubjectCoordinate,
) -> Option<(symbols::SymbolHandle, u32, checked_trees::CheckedScalarExpression)> {
    let (parameter, path) = if coordinate.path.is_empty() {
        let parameter = program.state_parameter_by_symbol(state, coordinate.parameter)?;
        lengths::is_slice(program, parameter.type_reference).then_some(())?;
        (parameter, Vec::new())
    } else {
        let field = coordinate::Coordinate::at_coordinate(
            program, state, coordinate, coordinate::CoordinateKind::Length,
        )?;
        let path = field.steps.iter().chain([&field.field]).map(|field| {
            checked_trees::CheckedStructuralPredicatePathSegment::Field(
                checked_trees::CheckedMemberIdentity::of_member(field.identity, field.name.clone()),
            )
        }).collect();
        (field.parameter, path)
    };
    let position = program.state_parameters(state).iter()
        .position(|candidate| candidate.symbol == parameter.symbol)?;
    let position = u32::try_from(position).ok()?;
    Some((parameter.symbol, position, checked_trees::CheckedScalarExpression::StructuralSequenceLength {
        root: checked_trees::CheckedStorageRoot::Parameter { index: position },
        path: path.into_iter().map(checked_trees::CheckedScalarReadProjection::Static).collect(),
    }))
}

''' + s[b:];p.write_text(s)
p=sc/'checks/termination/ranking/observations.rs'
edit(p,'admitted: &checked_trees::CheckedRankArrivalPlan,','admitted: &mut checked_trees::CheckedRankArrivalPlan,')
edit(p,'''                CheckedNaturalRankMeasure::SequenceLength { subject }''','''                let path = admitted.path_segments.insert_many(destination.path.clone());
                let coordinate = admitted.coordinates.insert(checked_trees::CheckedRankCoordinate {
                    parameter: destination.parameter,
                    path,
                });
                CheckedNaturalRankMeasure::SequenceLength { coordinate }''')
p=sc/'execution/scalar_computations/rank_observations.rs'
edit(p,'observation(&mut builder, rank, subject, &bindings)','observation(&mut builder, rank, subject, &bindings, admitted)')
edit(p,'''fn observation(
    builder: &mut Builder<'_, '_>,
    rank: &CheckedStateNaturalRank,
    subject: Option<ExpressionHandle>,
    bindings: &validation::RankStateBindings,
)''','''fn observation(
    builder: &mut Builder<'_, '_>,
    rank: &CheckedStateNaturalRank,
    subject: Option<ExpressionHandle>,
    bindings: &validation::RankStateBindings,
    admitted: &checked_trees::CheckedRankArrivalPlan,
)''')
edit(p,'''        CheckedNaturalRankMeasure::SequenceLength { subject } => {
            let (owner, state) = validation::find_state(builder.program, builder.state)?;
            let (parameter, position, expression) = validation::ranking_slice_length_observation(
                builder.program,
                owner,
                state,
                bindings,
                subject,
            )?;''','''        CheckedNaturalRankMeasure::SequenceLength { coordinate } => {
            let (_, state) = validation::find_state(builder.program, builder.state)?;
            let coordinate = admitted.coordinates.get(coordinate);
            let coordinate = validation::RankSubjectCoordinate {
                parameter: coordinate.parameter,
                path: admitted.path_segments.span(coordinate.path)?.to_vec(),
            };
            let (parameter, position, expression) = validation::ranking_slice_length_observation(
                builder.program,
                state,
                &coordinate,
            )?;''')
p=sc/'checks/termination.rs'
edit(p,'.map(|coordinate| checked_trees::CheckedStateNaturalRank {','.map(|coordinate| {\n                let measure = match coordinate.observation {\n                    validation::RankPremiseObservation::Value => checked_trees::CheckedNaturalRankMeasure::IntegerParameter { primitive_type: coordinate.primitive_type },\n                    validation::RankPremiseObservation::Length => {\n                        let path = admitted.path_segments.insert_many(coordinate.coordinate.path.clone());\n                        let coordinate = admitted.coordinates.insert(checked_trees::CheckedRankCoordinate { parameter: coordinate.parameter, path });\n                        checked_trees::CheckedNaturalRankMeasure::SequenceLength { coordinate }\n                    }\n                };\n                checked_trees::CheckedStateNaturalRank {')
edit(p,'''                measure: checked_trees::CheckedNaturalRankMeasure::IntegerParameter {
                    primitive_type: coordinate.primitive_type,
                },
                observation: Default::default(),
            })''','''                measure,
                observation: Default::default(),
            }})''')
edit(p,'ranking::prepare_natural_observations(program, machine, &admitted)','ranking::prepare_natural_observations(program, machine, &mut admitted)')
