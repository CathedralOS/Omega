from pathlib import Path
r=Path('omega-rust/psi/compilation/checking/src/proof_contracts/contract_entailment/ranking_range.rs');s=r.read_text();a='''    let bindings = match entry_parameters {
        Some(entries) => calls::telescoped_bindings(program, machine, state, entries)?,
        None => integer_bindings(program, state)?,
    };
''';assert a in s
s=s.replace(a,'''    let mut bindings = match entry_parameters {
        Some(entries) => calls::telescoped_bindings(program, machine, state, entries)?,
        None => integer_bindings(program, state)?,
    };
    // One invocation's Type/Const declaration context does not move between
    // its body states. These exact immutable binders are not runtime arrival
    // slots. Cross-invocation judgments still owe explicit actual substitution.
    for (symbol, reference) in invocation_value_parameters(program, machine, state) {
        if let Some(primitive) = integer_parameter(program, reference) {
            bindings.push(StrictArithmeticSymbolBinding::unsigned_integer_atom(
                symbol, format!("\\0ranking:invocation:{:?}:value:{symbol:?}", machine.symbol), primitive,
            ));
        }
    }
''')
start=s.index('fn parameter_comparisons(');end=s.index('\nfn comparison_proven(',start);part=s[start:end]
part=part.replace('for parameter in program.state_parameters(root).iter() {','''for (symbol, reference) in program.state_parameters(root).iter()
        .map(|parameter| (parameter.symbol, parameter.type_reference))
        .chain(invocation_value_parameters(program, machine, root))
    {''').replace('parameter.type_reference','reference').replace('parameter.symbol','symbol')
# Preserve the tuple producer's ordinary declaration fields.
part=part.replace('.map(|parameter| (symbol, reference))','.map(|parameter| (parameter.symbol, parameter.type_reference))')
s=s[:start]+part+s[end:]
i=s.index('\nfn integer_bindings(')
s=s[:i]+'''
/// Immutable declaration indices beside one invocation's runtime formal roster.
/// Exact symbols establish identity; lexical names and carrier matches do not.
fn invocation_value_parameters<'program>(
    program: &'program dyn crate::CheckingInput,
    machine: &'program Machine,
    state: &'program State,
) -> impl Iterator<Item = (symbols::SymbolHandle, typed_trees::types::TypeReferenceHandle)> + 'program {
    program.machine_type_parameters(machine).iter().filter_map(move |parameter| {
        let reference = match parameter.kind {
            typed_trees::data::TypeParameterKind::Value { type_reference }
            | typed_trees::data::TypeParameterKind::Const { type_reference } => type_reference,
            _ => return None,
        };
        (!program.state_parameters(state).iter().any(|formal| formal.symbol == parameter.symbol))
            .then_some((parameter.symbol, reference))
    })
}
''' +s[i:];r.write_text(s)
