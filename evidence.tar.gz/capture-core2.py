from pathlib import Path
import json,subprocess,hashlib,shutil
b=Path('build/moving-upper');out=b/'core2-producer';out.mkdir(exist_ok=False)
patch=subprocess.check_output(['git','diff','HEAD','--binary','--','omega-rust','source/library','Cargo.toml','Cargo.lock'])
(out/'source.diff').write_bytes(patch)
rows=[json.loads(s) for s in (b/'core2-build.jsonl').read_text().splitlines()];row=next(r for r in reversed(rows) if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='omega' and r.get('executable'));dst=out/'omega';shutil.copy2(row['executable'],dst);p=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),compiler_inputs_dirty=bool(patch),source_patch_sha256=hashlib.sha256(patch).hexdigest(),executable=str(dst.resolve()),sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),opt_level=row['profile']['opt_level']);assert p['opt_level']!='0';(out/'producer.json').write_text(json.dumps(p,indent=2)+'\n')
