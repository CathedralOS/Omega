from pathlib import Path
import subprocess,json,time,hashlib
root=Path('build/private-cycle-ranks');cli=str((root/'candidate-producer/omega').resolve());rows=[]
for source in sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/structural_view/main.omg')):
 command=[cli,'run','--both',str(source)];start=time.monotonic();p=subprocess.run(command,input='',text=True,capture_output=True,timeout=180)
 row=dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,elapsed_seconds=time.monotonic()-start);rows.append(row)
 (root/'qualified-samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(source,p.returncode,p.stderr[-500:],flush=True)
 assert p.returncode==0 and 'native exit 0' in p.stderr and 'interp exit: 0' in p.stderr,row
assert len(rows)==9
