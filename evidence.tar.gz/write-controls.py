from pathlib import Path
import json
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank')
base=Path('build/ranged-cycle-ranks/local/main.omg').read_text()
# The same seven-step operation, with its explicit bound carried through the helper.
s=base.replace('machine count(counter: &mut u64, remaining: u64)','machine count(counter: &mut u64, remaining: u64, ceiling: u64)').replace('terminates by remaining in 0..=7;','terminates by remaining in 0..=ceiling;').replace('requires remaining <= 7;','requires remaining <= ceiling && remaining <= 7;').replace('forward(remaining, counter)','forward(remaining, ceiling, counter)').replace('machine forward(pending: u64, counter: &mut u64)','machine forward(pending: u64, limit: u64, counter: &mut u64)').replace('requires pending > 0 && pending <= 7;','requires pending > 0 && pending <= limit && pending <= 7;').replace('count(counter, pending - 1)','count(counter, pending - 1, limit)').replace('count(counter, remaining);','count(counter, remaining, 7);')
variants=[('local/ranged_value/carried_bound',s,None),('controls/ranged_foreign_bound',s.replace('forward(remaining, ceiling, counter)','forward(remaining, 7, counter)'),'dependent rank endpoints'),('controls/ranged_missing_entry',base.replace('requires remaining <= 7;\n',''),'independent entry formation')]
# Exercise the same range owner on the existing descriptor observation.
s=Path('samples/cli/facts/nested_machine_invocation/joint_rank/local/structural_view/main.omg').read_text().replace('terminates by remaining -> Slice::Length;','terminates by remaining -> Slice::Length in 0..=7;\nrequires remaining.len <= 7;').replace('requires pending.len > 0;','requires pending.len > 0 && pending.len <= 7;').replace('machine perform(counter: &mut u64, bytes: &[u8], select: bool) {','machine perform(counter: &mut u64, bytes: &[u8], select: bool)\nrequires bytes.len <= 7;\n{')
variants.append(('local/ranged_value/sequence_length',s,None))
for path,src,reason in variants:
 p=root/path;p.mkdir(parents=True,exist_ok=True);(p/'main.omg').write_text(src)
 name='ranged_'+path.replace('/','_');build=Path('build/ranged-cycle-ranks/local/build.omg').read_text().replace('private_ranged_joint_rank',name);(p/'build.omg').write_text(build)
 if reason:
  (p/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=[reason]),indent=2)+'\n')
 else:
  d=p/'invalid';d.mkdir(exist_ok=True);(d/'main.omg').write_text(src.replace('pending - 1','pending').replace('pending[1..]','pending'));(d/'build.omg').write_text(build);(d/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['no exact private-coordinate assignment proves every edge and complete cycle']),indent=2)+'\n')
