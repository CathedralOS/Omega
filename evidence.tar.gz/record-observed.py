from pathlib import Path
import copy,json,subprocess,sys,hashlib
sys.path.insert(0,'tools');import corpus_records
root=Path('build/private-cycle-ranks');scope=json.loads((root/'scope.json').read_text());revision=json.loads((root/'candidate-producer/corpus-producer.json').read_text())['revision'];ledger=[]
for mode,golden in [('source','tests/omega/corpus_outcomes.txt'),('both','tests/omega/corpus_both_macos_arm64.txt')]:
 report=json.loads((root/('qualified-corpus-'+mode+'.json')).read_text());wanted={x.removeprefix('tests/omega/') for x in scope['new'] if mode!='both' or '/pass/' in x}
 rows=[copy.deepcopy(x) for x in report['observations'] if x['fixture'] in wanted];assert {x['fixture'] for x in rows}==wanted
 for row in rows:
  if row['tier']=='fail':assert row['status']=='rejected' and row['expected_satisfied'] is True
  else:
   assert row['status']==('built' if mode=='both' else 'checked')
   if mode=='both':assert row['facts']['exit']=='0' and row['facts']['interpreter-exit']=='0' and row['facts']['interpreter']=='agrees'
  row['recorded_at']=revision
 path=Path(golden);old=path.read_text();(root/('pre-record-'+path.name)).write_text(old);previous={x['fixture']:x for x in corpus_records.read(path)}
 result=corpus_records.splice(old,rows);path.write_text(result);after={x['fixture']:x for x in corpus_records.read(path)}
 assert len(after)==len(previous)+len(wanted-set(previous))
 assert all(after[key]==value for key,value in previous.items() if key not in wanted)
 assert all(after[row['fixture']]==row for row in rows)
 ledger.append(dict(golden=golden,new_rows=len(rows),unchanged_prior_rows=len(previous.keys()-wanted),before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=hashlib.sha256(result.encode()).hexdigest(),actual_producer=revision,measurement_checkout=report['revision']))
(root/'recorded-observations.json').write_text(json.dumps(ledger,indent=2)+'\n');print(json.dumps(ledger,indent=2))
subprocess.run(['git','update-ref','refs/corpus-observations/'+revision,revision],check=True)
