exec(open('build/private-cycle-ranks/edit.py').read().split("p=ck/'facts/termination/arrival_correspondence.rs'")[0])
p=sc/'checks/termination/joint_natural.rs'
edit(p,'    primitive: PrimitiveType,','    primitive: PrimitiveType,\n    observation: validation::RankPremiseObservation,')
edit(p,'''/// Ranged and non-natural views retain their existing measure/endpoint owner.
/// An unranged natural coordinate is checked directly at every call, including
/// when a private participant has no authored ranking clause of its own.''','''/// Select a natural observation, then judge its exact actual at every call.
/// An integer and a descriptor extent use the same component/edge owner; only
/// reading the carrier differs. Ranged and declared views keep their complete
/// measure/endpoint admission. Private inference supplies no ambient entry facts.''')
edit(p,'    let mut primitive = None;','    let mut selected_observation = None;')
a=p.read_text().index('        if !matches!(\n            RankingOrder::resolve_witness');b=p.read_text().index('        let [subject]',a)
s=p.read_text();s=s[:a]+'''        let observation = match RankingOrder::resolve_witness(program, entry, witness, &subjects, &arguments) {
            OrderResolution::Resolved(RankingOrder::NatDescending) => validation::RankPremiseObservation::Value,
            OrderResolution::Resolved(RankingOrder::SliceLength) => validation::RankPremiseObservation::Length,
            _ => return None,
        };
''' +s[b:];p.write_text(s)
edit(p,'''        let carrier = program.primitive_type_reference(declaration.type_reference)?;
        if !carrier.is_fixed_integer() || primitive.is_some_and(|previous| previous != carrier) {
            return None;
        }
        primitive = Some(carrier);''','''        let carrier = observation_carrier(program, entry, declaration.symbol, observation)?;
        if selected_observation.is_some_and(|previous| previous != (observation, carrier)) {
            return None;
        }
        selected_observation = Some((observation, carrier));''')
edit(p,'            primitive: carrier,','            primitive: carrier,\n            observation,')
edit(p,'    let primitive = primitive?;','    let (observation, primitive) = selected_observation?;')
edit(p,'                && program.primitive_type_reference(parameter.type_reference) == Some(primitive)','                && observation_carrier(program, entry, parameter.symbol, observation) == Some(primitive)')
edit(p,'                    primitive,','                    primitive,\n                    observation,')
edit(p,'''    let initial = edge.values.initial_symbol(source.parameter)?;
    let next = edge
        .values
        .current(*edge.arguments.get(destination.position)?)
        .map(ScopedArithmeticValue::Term)?;''','''    let actual = *edge.arguments.get(destination.position)?;
    let (initial, next) = match source.observation {
        validation::RankPremiseObservation::Value => (
            edge.values.initial_symbol(source.parameter)?,
            edge.values.current(actual).map(ScopedArithmeticValue::Term)?,
        ),
        validation::RankPremiseObservation::Length => (
            edge.values.initial_collection_length(source.parameter)?,
            edge.values.current_collection_length(actual)?,
        ),
    };''')
edit(p,'                primitive_type: coordinate.primitive,','                primitive_type: coordinate.primitive,\n                observation: coordinate.observation,')
s=p.read_text();i=s.index('\nfn compare(');s=s[:i]+'''
fn observation_carrier(
    program: &dyn validation::CheckingInput,
    state: &typed_trees::state::State,
    parameter: SymbolHandle,
    observation: validation::RankPremiseObservation,
) -> Option<PrimitiveType> {
    match observation {
        validation::RankPremiseObservation::Value => {
            let parameter = program.state_parameter_by_symbol(state, parameter)?;
            let primitive = program.primitive_type_reference(parameter.type_reference)?;
            primitive.is_fixed_integer().then_some(primitive)
        }
        validation::RankPremiseObservation::Length => {
            validation::ranking_slice_length_observation(program, state, &validation::RankSubjectCoordinate {
                parameter,
                path: Vec::new(),
            })?;
            Some(PrimitiveType::U64)
        }
    }
}
''' +s[i:];p.write_text(s)
