import json,hashlib
from pathlib import Path
r=Path("build/descriptor-cycle-ranks");rows=json.load(open(r/"baseline.json"));assert len(rows)==2
for x in rows:
 assert hashlib.sha256(Path(x["source"]).read_bytes()).hexdigest()==x["sha256"]
 assert x["reason"]=="review-failed" and "a member lacks a supported exact ranking witness" in x["output"]
print("Frozen descriptor-field positive refuses; nondecrease twin refuses. Neither is runtime acceptance.")
