from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import corpus_gate
r=Path('build/projected-cycle-ranks');mode=sys.argv[1];scope=json.load(open(r/'scope.json'));original=corpus_gate.run_runner

def capture(*args,**kwargs):
 rows=original(*args,**kwargs)
 root=Path(args[1]) if len(args)>1 else Path.cwd()
 path=r/((mode+'-observations.json') if root.resolve()==Path.cwd().resolve() else (mode+'-baseline-observations.json'))
 path.write_text(json.dumps(rows,indent=2)+'\n');return rows
corpus_gate.run_runner=capture
sys.argv=['corpus_gate','--runner',str((r/'corpus-producer/corpus_runner').resolve()),'--baseline-runner',str(Path('build/ranged-cycle-ranks/integrated-producer/corpus_runner').resolve()),'--compare',scope['base'],'--filter',','.join(scope[mode]),'--json',str(r/(mode+'-compare.json'))]
if mode=='both':sys.argv+=['--both']
raise SystemExit(corpus_gate.main())
