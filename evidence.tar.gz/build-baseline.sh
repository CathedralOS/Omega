set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/moving-upper/baseline-build.jsonl 2> build/moving-upper/baseline-build.stderr
python3 build/moving-upper/capture-baseline.py
python3 build/moving-upper/probe-baseline.py
