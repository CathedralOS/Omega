from pathlib import Path
import hashlib,json,subprocess,shutil
b=Path('build/joint-lexicographic');out=b/'review-fix-producer';out.mkdir(exist_ok=False)
patch=subprocess.check_output(['git','diff','HEAD','--binary','--','omega-rust','source/library','Cargo.toml','Cargo.lock']);(out/'source.diff').write_bytes(patch)
meta=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),compiler_inputs_dirty=True,source_patch_sha256=hashlib.sha256(patch).hexdigest())
for name,log in [('omega','review-fix-cli-build.jsonl'),('corpus_runner','review-fix-corpus-build.jsonl')]:
 rows=[json.loads(s) for s in (b/log).read_text().splitlines()]
 row=next(r for r in reversed(rows) if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('executable'))
 dst=out/name;shutil.copy2(row['executable'],dst)
 record=dict(meta,executable=str(dst.resolve()),sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),opt_level=row['profile']['opt_level']);assert record['opt_level']!='0'
 (out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 if name=='omega':(out/'producer.json').write_text(json.dumps(record,indent=2)+'\n')
