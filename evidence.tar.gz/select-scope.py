from pathlib import Path
import json
new=sorted([str(p) for tier in ['pass','fail'] for p in (Path('tests/omega')/tier/'facts').glob('nested_machine_joint_rank_structural_*')])
reg=[
'pass/termination/runtime_shrinking_slice_recursion_exit',
'pass/termination/runtime_receiver_byte_slice_recursion_exit',
'pass/termination/slice_rank_unrelated_float_operator',
'pass/termination/rankless_boundary_slice_suffix',
'pass/termination/runtime_rank_range_state_call_exit',
'pass/termination/measure_field_projection',
'pass/termination/measure_field_rank_step',
'pass/termination/measure_nested_projection_range_relational',
'pass/termination/measure_field_fresh_arrival',
'pass/termination/runtime_rank_arrival_field_premise_disjoint_write_exit',
'pass/termination/runtime_public_result_field_rank_arrivals_exit',
'fail/termination/mixed_endpoint_stored_length_write',
'fail/termination/rank_arrival_unrelated_field_step',
'fail/termination/rank_range_call_component_prefix_write',
'fail/termination/measure_field_limit_changed',
'fail/termination/rank_arrival_missing_public_result_field_equation',
'pass/facts/nested_machine_joint_rank_local_exit',
'pass/facts/nested_machine_joint_rank_carried_restoration_local_exit',
'fail/facts/nested_machine_joint_rank_local_rejected',
'fail/facts/nested_machine_joint_rank_carried_restoration_local_rejected',
]
reg=[str(Path('tests/omega')/p) for p in reg]
missing=[p for p in reg if not Path(p).is_dir()];print('missing',missing)
assert not missing
scope=dict(new=new,regressions=reg,filters=','.join(p.removeprefix('tests/omega/') for p in new+reg))
Path('build/private-cycle-ranks/scope.json').write_text(json.dumps(scope,indent=2)+'\n')
