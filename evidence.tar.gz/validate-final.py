from pathlib import Path
import json,subprocess,time,hashlib,os
b=Path('build/moving-upper');p=json.loads((b/'final-producer/producer.json').read_text());assert hashlib.sha256(Path(p['executable']).read_bytes()).hexdigest()==p['sha256'];patch=subprocess.check_output(['git','diff','HEAD','--binary','--','omega-rust','source/library','Cargo.toml','Cargo.lock']);assert hashlib.sha256(patch).hexdigest()==p['source_patch_sha256']
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');reason='no exact private-coordinate assignment proves every edge and complete cycle';rows=[]
for place in ['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']:
 d=root/place/'bounded_distance/moving_upper';rows.extend([(place,d/'main.omg',None),(place+' invalid',d/'invalid/main.omg',reason)])
rows.extend([
 ('fixed upper',root/'parameter/bounded_distance/main.omg',None),
 ('clamped overshoot',root/'parameter/bounded_distance/increasing_to_overshoot/main.omg',None),
 ('clamped preserving',root/'parameter/bounded_distance/increasing_to_overshoot/invalid/main.omg',reason),
 ('post clamp',root/'controls/increasing_to_post_clamp/main.omg',reason),
 ('upper drift',root/'controls/bounded_distance_upper_drift/main.omg',reason),
 ('signed neighbor',Path('samples/cli/facts/nested_machine_signed_rank/parameter/main.omg'),None),
 ('tuple neighbor',Path('samples/cli/facts/nested_machine_lexicographic_rank/parameter/main.omg'),None),
 ('narrow endpoints',root/'parameter/bounded_distance/moving_upper/controls/narrow_endpoints/main.omg',None),
 ('invalid falling interval',root/'parameter/bounded_distance/moving_upper/controls/invalid_falling_interval/main.omg','ceiling <= ceiling - 1'),
]);rows.extend([
 ('original frozen probe',root/'parameter/bounded_distance/moving_upper/probe/main.omg',None),
 ('exact requirement',root/'parameter/bounded_distance/moving_upper/controls/exact_requirement/main.omg',None),
 ('invalid exact requirement',root/'parameter/bounded_distance/moving_upper/controls/invalid_exact_requirement/main.omg','from `u64` to `u8` is not provably representable'),
]);results=[]
for name,source,expected in rows:
 cmd=[p['executable'],*(['--check'] if expected else ['run','--both']),str(source)];start=time.monotonic();o=subprocess.run(cmd,capture_output=True,text=True,timeout=120,env=dict(os.environ,OMEGA_LIBRARY_ROOT=str(Path('source/library').resolve())));r=dict(name=name,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),expected_rejection=expected,command=cmd,exit=o.returncode,stdout=o.stdout,stderr=o.stderr,seconds=time.monotonic()-start);results.append(r);(b/'final-row.json').write_text(json.dumps(dict(producer=p,results=results),indent=2)+'\n');print(name,o.returncode,flush=True)
 if expected:assert o.returncode==1 and expected in o.stderr,r
 else:assert o.returncode==0 and 'native exit 0' in o.stderr and 'interp exit: 0' in o.stderr,r
print('16BOTH0;14intendedrefusals')
