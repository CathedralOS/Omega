An authored `Slice::Length` termination rank previously refused a tail-call component containing a private helper without its own rank clause. The checker now selects an exact value/length observation in the existing joint-component owner, proves each edge from its actual current arguments, and retains the selected descriptor coordinate through ordinary scalar observation lowering. Entry lengths are captured before prefix writes; descriptor replacement cannot manufacture descent.

The same counter fact runs across all nine transport places, including reordered helper arguments and a Build-selected implementation. Each positive traverses seven elements (counter 3 → 10), then an empty view without changing the result. Nine nondecreasing twins plus restored-descriptor and missing-bound controls reject. The old source-AST-dependent length observation route is replaced by the admitted-coordinate query.

Validation on macOS ARM64, fixed base `9a4ec4a40c352ea4eb51f49f2d23ee03e3e3a78e`, optimized exact producer `e3c13ae2455c62f31486b028dab0fd6705ab6c4e`:

- All nine public programs pass `omega run --both`; all nine pinned fixtures also agree in native and Terminal execution.
- Focused corpus: 43 source observations and 25 pass-fixture realization observations, including existing projected byte/element ranks and integer/custody cycles. Every new positive and reject control meets its oracle.
- Affected `validation`, `typed-trees-to-checked-trees`, and `checked-trees` crate Clippy, plus changed-file formatting, pass.
- Independent static semantic review found no blocking issue. The final metadata commit only pins measured rows; earlier execution identities remain unchanged.

Seven inherited defects remain explicitly red: five older positive fixtures refuse or have incomplete lowering, and `rank_arrival_missing_public_result_field_equation` / `rank_arrival_unrelated_field_step` still accept their invalid controls. Immutable baseline comparisons confirm these outcomes; they are not counted as successes. Other-host execution, ranged/declared-view private ranks, and the remaining nested-machine acceptance remain open.

Claim: `09f3c72fc8de4b5098d7f012d2f2e869`. Implementation: Codex (GPT-6); independent review: `/root/terminal_policy_audit_resume`. No new compiler rebuild is needed for result-record metadata; the merge queue owns integration checking.
