from pathlib import Path
import json,subprocess
r=Path('build/ranged-cycle-ranks')
fixtures=[p.removeprefix('tests/omega/') for p in json.load(open(r/'new-fixtures.json')) if '/pass/' in p]+['pass/termination/runtime_rank_range_state_call_exit','pass/facts/nested_machine_joint_rank_local_exit','pass/facts/nested_machine_joint_rank_structural_view_local_exit','pass/facts/nested_machine_joint_rank_carried_restoration_local_exit']
fixtures=[p for p in fixtures if (Path('tests/omega')/p/'main.omg').exists()]
cmd=['python3','tools/corpus_gate.py','--runner',str((r/'final-producer/corpus_runner').resolve()),'--both','--filter',','.join(fixtures),'--json',str(r/'both.json')]
p=subprocess.run(cmd,capture_output=True,text=True,timeout=900)
(r/'both.stdout').write_text(p.stdout);(r/'both.stderr').write_text(p.stderr)
report=json.load(open(r/'both.json'));assert report['infrastructure_error'] is None,report
rows=report['observations'];assert {x['fixture'] for x in rows}==set(fixtures),(len(rows),len(fixtures))
for x in rows:
 folder=Path('tests/omega')/x['fixture']; oracle=folder/'expected_native_exit.macos_arm64.txt'
 if not oracle.exists():oracle=folder/'expected_native_exit.txt'
 expected=oracle.read_text().strip() if oracle.exists() else '0'
 assert x['status']=='built' and x['facts'].get('exit')==expected and x['facts'].get('interpreter-exit')==expected and x['facts'].get('interpreter')=='agrees',x
assert not report['oracle_failures'],report['oracle_failures']
print('Validated',len(rows),'native/Terminal authored outcomes; historical golden differences remain visible.',flush=True)
