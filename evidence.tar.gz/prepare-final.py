from pathlib import Path
import json,sys
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/ranged-cycle-ranks');cli=str((r/'final-producer/omega').resolve())
samples=sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/ranged_value/main.omg'))+sorted(p for p in Path('samples/cli/facts/nested_machine_invocation/joint_rank/local/ranged_value').glob('*/main.omg') if p.parent.name!='invalid')
projects=[p.parent for p in samples]+[Path(p) for p in json.load(open(r/'new-fixtures.json')) if '/pass/' in p]+[Path('tests/omega')/p for p in ['pass/termination/runtime_rank_range_state_call_exit','pass/facts/nested_machine_joint_rank_local_exit','pass/facts/nested_machine_joint_rank_structural_view_local_exit','pass/facts/nested_machine_joint_rank_carried_restoration_local_exit']]+[r/'authored-helper']
rows=[]
for p in sorted(set(projects),key=lambda p:(-len(p.parts),str(p))):
 reason,output=accept_review(cli,str(p),'macos_arm64',180);row=dict(project=str(p),reason=reason,output=output);rows.append(row);(r/'final-preparation.json').write_text(json.dumps(rows,indent=2)+'\n');print(p,reason,output[-1500:] if reason else '',flush=True);assert reason is None,row
