set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/joint-lexicographic/integrated-cli-build.jsonl 2> build/joint-lexicographic/integrated-cli-build.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/joint-lexicographic/integrated-corpus-build.jsonl 2> build/joint-lexicographic/integrated-corpus-build.stderr
cargo test --locked -p terminal-codec rank_tuple -- --nocapture > build/joint-lexicographic/integrated-wire-test.stdout 2> build/joint-lexicographic/integrated-wire-test.stderr
python3 build/joint-lexicographic/capture-integrated.py
python3 build/joint-lexicographic/validate-integrated.py
bash build/joint-lexicographic/integrated-corpus-chain.sh
