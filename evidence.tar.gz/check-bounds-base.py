from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/ranged-cycle-ranks');source=Path('samples/cli/facts/nested_machine_invocation/joint_rank/local/ranged_value/rebound_ceiling/main.omg');no_range=r/'rebound-without-range';no_range.mkdir(exist_ok=True);(no_range/'main.omg').write_text(source.read_text().replace('terminates by remaining in 0..=ceiling;','terminates by remaining;'));(no_range/'build.omg').write_text((source.parent/'build.omg').read_text());cli=str(Path('build/private-cycle-ranks/candidate-producer/omega').resolve());reason,output=accept_review(cli,str(no_range),'macos_arm64',180);record=dict(source=str(no_range/'main.omg'),producer='e3c13ae2455c62f31486b028dab0fd6705ab6c4e',review_reason=reason,review_output=output)
if reason is None:
 p=subprocess.run([cli,'run','--both',str(no_range/'main.omg')],input='',capture_output=True,text=True,timeout=180);record.update(exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
(r/'without-range-baseline.json').write_text(json.dumps(record,indent=2)+'\n');print(record,flush=True)
