from pathlib import Path
base=Path('omega-rust/psi/compilation');v=base/'checking/src';sc=base/'pipeline/04_typed-trees-to-checked-trees/src'
def edit(p,a,b):
 s=p.read_text();assert a in s,(p,a[:70]);p.write_text(s.replace(a,b))
p=v/'proof_contracts/contract_entailment/ranking_range/calls/endpoint_pins.rs'
edit(p,'pub struct RankingRangeCallEdge', '''/// Captured invocation indices at one exact call. These are observations,
/// not equality evidence; endpoint conservation proves each comparison.
pub struct RankInvocationCallValues {
    pub source: Vec<(symbols::SymbolHandle, crate::ScopedArithmeticValue)>,
    pub destination: Vec<(symbols::SymbolHandle, crate::ScopedArithmeticValue)>,
    pub hypotheses: Vec<crate::ScopedArithmeticHypothesis>,
}

pub struct RankingRangeCallEdge''')
edit(p,'    pub guards: Vec<(ExpressionHandle, bool)>,','    pub guards: Vec<(ExpressionHandle, bool)>,\n    pub invocation_values: Option<RankInvocationCallValues>,')
edit(p,"struct Arrival<'program> {","struct Arrival<'program> {")
edit(p,'    after_call: bool,','    after_call: bool,\n    invocation_values: Option<&\'program RankInvocationCallValues>,')
# Calls borrow observations independently of the program arena lifetime.
edit(p,"    calls: &[RankingRangeCallEdge<'program>],","    calls: &'program [RankingRangeCallEdge<'program>],")
edit(p,'                    after_call: statement.continuation == arrival.target,','                    after_call: statement.continuation == arrival.target,\n                    invocation_values: None,')
edit(p,'                after_call: false,','                after_call: false,\n                invocation_values: call.invocation_values.as_ref(),')
edit(p,'        let mut endpoints = Vec::new();','        let mut endpoints = EndpointReads::default();')
edit(p,'        for origin in endpoints {','        for origin in endpoints.storage {')
edit(p,'''            conserve(program, &states, &arrivals, &origin, frames)?;
        }
        Some(())''','''            conserve(program, &states, &arrivals, &origin, frames)?;
        }
        for origin in endpoints.invocation {
            invocation::conserve(program, &states, &arrivals, &origin)?;
        }
        Some(())''')
edit(p,'fn endpoint_reads(','''mod invocation;
mod relation;

#[derive(Clone, Debug, PartialEq, Eq)]
struct InvocationCoordinate {
    state: usize,
    parameter: symbols::SymbolHandle,
}

#[derive(Default)]
struct EndpointReads {
    storage: Vec<ValueCoordinate>,
    invocation: Vec<InvocationCoordinate>,
}

fn endpoint_reads(''')
edit(p,'    reads: &mut Vec<ValueCoordinate>,','    reads: &mut EndpointReads,')
edit(p,'''        ExpressionNode::Name(_) | ExpressionNode::Member(_) => {
            let collection''','''        ExpressionNode::Name(_) | ExpressionNode::Member(_) => {
            if let ExpressionNode::Name(name) = node
                && name.head_symbol == name.symbol
                && invocation::parameters(program, frame.machine).any(|symbol| symbol == name.symbol)
            {
                let coordinate = InvocationCoordinate { state, parameter: name.symbol };
                if !reads.invocation.contains(&coordinate) {
                    reads.invocation.push(coordinate);
                }
                return Some(());
            }
            let collection''')
edit(p,'            if !reads.contains(&value) {\n                reads.push(value);','            if !reads.storage.contains(&value) {\n                reads.storage.push(value);')
s=p.read_text();start=s.index('    let mut retained = vec![true; domain.len()];');end=s.index('\nfn include_coordinate(',start)
loop=s[start:end];assert loop.endswith('}\n')
# Preserve the same rooted greatest-fixed-point relation for both kinds.
loop=loop[:-2].replace('domain.len()','states.len()').replace('value.state','*value').replace('domain\n                    .iter()','states\n                    .iter()')
body='''//! A conserved endpoint needs an equality predecessor at every arrival and
//! a productive equality path from its authored origin (coordinate zero).

use super::Arrival;

pub(super) fn conserve(
    states: &[usize],
    arrivals: &[Arrival<'_>],
    evidence: &[Vec<Vec<usize>>],
) -> Option<()> {
'''+loop+'}\n'
folder=p.parent/'endpoint_pins';folder.mkdir(exist_ok=True);(folder/'relation.rs').write_text(body)
s=s[:start]+'''    let domain_states = domain.iter().map(|value| value.state).collect::<Vec<_>>();
    relation::conserve(&domain_states, arrivals, &evidence)
}
''' +s[end:];p.write_text(s)
# Export only transient observations and their owner entry.
for p in [v/'proof_contracts/contract_entailment/ranking_range/calls.rs',v/'proof_contracts/contract_entailment/ranking_range.rs']:
 edit(p,'RankingRangeCallEdge, RankingRangeEndpointMember,','RankInvocationCallValues, RankingRangeCallEdge, RankingRangeEndpointMember,')
p=v/'lib.rs';edit(p,'RankingRangeCallEdge, RankingRangeEdgeProof,','RankInvocationCallValues, RankingRangeCallEdge, RankingRangeEdgeProof,')
p=v/'machine_calls/call_cycles/runtime_ranking.rs';edit(p,'                                guards: site_guards,','                                guards: site_guards,\n                                invocation_values: None,')
p=sc/'checks/current_scalar_values/call_contracts.rs';edit(p,'    pub(crate) fn machine_value_bindings(','''    /// Immutable source indices and exact static actuals share the ordinary
    /// invocation substitution. No selected range or callee requirement enters
    /// this captured roster; the endpoint owner still proves its equalities.
    pub(crate) fn invocation_call_values(
        &self,
        callee: &Machine,
        site: CallSite<'_>,
    ) -> Option<validation::RankInvocationCallValues> {
        let source = self.initial.iter().filter(|binding| binding.immutable_coordinate)
            .map(|binding| Some((binding.symbol, binding.value.clone()?)))
            .collect::<Option<Vec<_>>>()?;
        Some(validation::RankInvocationCallValues {
            source,
            destination: self.machine_value_bindings(callee, site)?,
            hypotheses: self.hypotheses.clone(),
        })
    }

    pub(crate) fn machine_value_bindings(''')
p=sc/'checks/termination/joint_natural/ranges.rs';edit(p,'            guards: edge.values.selected_guards().to_vec(),','            guards: edge.values.selected_guards().to_vec(),\n            invocation_values: edge.values.invocation_call_values(machines[edge.destination], edge.call),')
