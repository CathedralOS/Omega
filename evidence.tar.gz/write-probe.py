from pathlib import Path
r=Path('build/private-cycle-ranks/slice-rank');r.mkdir(parents=True,exist_ok=True)
s='''// Expected exit: 0
// A private helper preserves the invocation rank on a tail edge, and every complete cycle strictly descends while advancing the explicit counter once.
machine count(counter: &mut u64, remaining: &[u8])
terminates;
terminates by remaining -> Slice::Length;
{
    transition remaining.len > 0 {
        true -> forward(counter, remaining)
        false -> done()
    }
    machine forward(counter: &mut u64, pending: &[u8])
    requires pending.len > 0;
    {
        counter = ((counter as u64 in Wrapping) + 1) as u64;
        transition { _ -> count(counter, pending[1..]) }
    }
    machine done() {}
}
machine main() crashes Trap {
    let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    let mut counted: u64 = 3;
    count(&mut counted, &bytes[..]);
    let matched: bool = counted == 10;
    count(&mut counted, &bytes[0..0]);
    transition matched && counted == 10 {
        true -> done() false -> bad()
    }
    machine done() {}
    machine bad() crashes Trap { crash Trap; }
}
'''
(r/'main.omg').write_text(s);(r/'build.omg').write_text('''machine build(builder: &mut Build) {
    Build::application(builder, "private_joint_slice_rank");
    Build::bind(builder, windows_x86_64::ProgramEntry, main);
    Build::bind(builder, linux_x86_64::ProgramEntry, main);
    Build::bind(builder, macos_arm64::ProgramEntry, main);
    Build::bind(builder, linux_arm64::ProgramEntry, main);
}
''')
p=r/'invalid';p.mkdir(exist_ok=True);(p/'main.omg').write_text(s.replace('count(counter, pending[1..])','count(counter, pending)'));(p/'build.omg').write_text((r/'build.omg').read_text())
