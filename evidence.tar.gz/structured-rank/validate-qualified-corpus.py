import hashlib,json
from pathlib import Path
root=Path.cwd();b=root/'build/structured-rank'
def load(name): return json.loads((b/(name+'.json')).read_text())
new=load('qualified-corpus-new-source')
assert new['counts']['fixtures']==27 and new['counts']['by_status']=={'checked':13,'rejected':14}
assert new['counts']['wrong_reason']==new['counts']['fail_not_rejected']==new['counts']['lost_successes']==0
for name,count in [('qualified-corpus-new-both',13),('qualified-corpus-neighbors-both',42)]:
 record=load(name);assert record['counts']['fixtures']==count and record['counts']['by_status']=={'built':count}
 assert not record['oracle_failures'] and not record['infrastructure_error']
 for row in record['observations']:
  assert row['facts']['exit']==row['facts']['interpreter-exit']=='0' and row['facts']['interpreter']=='agrees'
 assert record['counts']['lost_successes']==0
neighbors=load('qualified-corpus-neighbors-source');assert neighbors['counts']['fixtures']==117 and neighbors['counts']['wrong_reason']==0
assert neighbors['counts']['fail_not_rejected_fixtures']==['fail/core/scoped_integer_call_guarantee_requires_published_equality']
baseline=load('neighbors-baseline-attribution');assert len(baseline['results'])==8
assert hashlib.sha256(Path(baseline['producer']['executable']).read_bytes()).hexdigest()==baseline['producer']['sha256']
current={row['fixture']:row for row in neighbors['observations']}
for row in baseline['results']:
 source=root/'tests/omega'/row['fixture']/'main.omg';assert hashlib.sha256(source.read_bytes()).hexdigest()==row['source_sha256']
 diagnostics=[line[len('error: '):].replace(str(root)+'/', '') for line in row['stderr'].splitlines() if line.startswith('error: ')]
 assert diagnostics==current[row['fixture']]['diagnostics']
 assert (row['exit']==0)==(current[row['fixture']]['status']=='checked')
print('27 new source outcomes; 13 new and 42 neighboring programs execute native0/Terminal0. Eight source exceptions exactly reproduce fixed05812 baseline status and diagnostics. Timing-only movement is not an execution failure.')
