//! Exact conditional values retain selected-path predicates beside their values.
//! These are denotations, not formation certificates or ambient premises. A
//! lower-bound query splits only conditional dependencies of its actual goal,
//! and must prove every feasible arm under that arm's captured predicates.

use super::{BigInt, BinaryOperator, Engine, OpaqueTerm, Polynomial};
use std::collections::BTreeSet;

pub(super) type Comparison = (BinaryOperator, Polynomial, Polynomial);

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct ConditionalValueArm {
    pub(super) conditions: Vec<Comparison>,
    pub(super) value: Polynomial,
}

impl ConditionalValueArm {
    pub(super) fn visit_operands(&self, mut visit: impl FnMut(&Polynomial)) {
        for (_, left, right) in &self.conditions {
            visit(left);
            visit(right);
        }
        visit(&self.value);
    }

    pub(super) fn mapped(
        &self,
        mut map: impl FnMut(&Polynomial) -> Option<Polynomial>,
    ) -> Option<Self> {
        Some(Self {
            conditions: self
                .conditions
                .iter()
                .map(|(operator, left, right)| Some((*operator, map(left)?, map(right)?)))
                .collect::<Option<Vec<_>>>()?,
            value: map(&self.value)?,
        })
    }
}

impl Engine<'_> {
    /// The formation owner establishes coverage and independent arm formation.
    /// Re-minting a captured definition imports neither old bounds nor proofs.
    pub(super) fn conditional_value(
        &mut self,
        arms: Vec<ConditionalValueArm>,
    ) -> Option<Polynomial> {
        if arms.is_empty() {
            return None;
        }
        if arms.iter().all(|arm| arm.value == arms[0].value) {
            return Some(arms[0].value.clone());
        }
        let atom = format!("\0conditional:{arms:?}");
        self.register_opaque_term(atom.clone(), OpaqueTerm::Conditional { arms });
        Some(Polynomial::atom(atom))
    }

    /// Import only operation definitions from a selected branch. Its bounds,
    /// substitutions and result guarantees stay local; normalized operands carry
    /// their exact mathematical consequences without granting global authority.
    pub(super) fn retain_operation_definitions(&mut self, branch: &Self) {
        for (atom, operation) in &branch.opaque_terms {
            self.register_opaque_term(atom.clone(), operation.clone());
        }
    }

    pub(super) fn conditional_lower_bound(
        &self,
        polynomial: &Polynomial,
        bound: &BigInt,
    ) -> Option<bool> {
        let polynomial = self.substituted(polynomial);
        let mut dependencies: BTreeSet<String> = polynomial
            .terms
            .keys()
            .flat_map(|monomial| monomial.keys().cloned())
            .collect();
        for (atom, operation) in self.opaque_terms.iter().rev() {
            if dependencies.contains(atom) {
                operation.visit_operands(|operand| {
                    dependencies.extend(
                        operand
                            .terms
                            .keys()
                            .flat_map(|monomial| monomial.keys().cloned()),
                    );
                });
            }
        }
        let (atom, arms) = self.opaque_terms.iter().find_map(|(atom, operation)| {
            if !dependencies.contains(atom)
                || self.substituted(&Polynomial::atom(atom.clone()))
                    != Polynomial::atom(atom.clone())
            {
                return None;
            }
            let OpaqueTerm::Conditional { arms } = operation else {
                return None;
            };
            Some((atom, arms))
        })?;
        Some(arms.iter().all(|arm| {
            let mut selected = self.clone();
            // Definition dependencies precede their result in mint order; this
            // equation cannot recursively mention the conditional being selected.
            selected.harvest_substitution(&Polynomial::atom(atom.clone()), &arm.value);
            if selected.integer_comparisons_unsatisfiable(arm.conditions.clone()) {
                return true;
            }
            selected.prove_at_least(&selected.substituted(&polynomial), bound)
        }))
    }
}
