import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd(); store=root/'build/structured-rank'; producer=json.loads((store/'final-producer/producer.json').read_text()); cli=producer['executable']
assert hashlib.sha256(Path(cli).read_bytes()).hexdigest()==producer['sha256']
base=Path('samples/cli/facts/nested_machine_invocation/joint_rank'); rows=[]
for place in ['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']:
 source=base/place/'computed_measure/structured'; rows.extend([(source/'main.omg',None),(source/'invalid/main.omg','a preserving cycle has no strict measure DECREASE')])
rows.append((base/'parameter/computed_measure/structured/probe/main.omg',None))
for name,reason in [('connectives',None),('guarded_division',None),('wrong_guard','cannot prove rank range'),('nonmonotone','captured ranks do not prove natural nonincrease'),('partial_subject','cannot prove rank range'),('branch_requires','cannot prove rank range')]:
 rows.append((base/'controls'/('structured_'+name)/'main.omg',reason))
for source in ['parameter/computed_measure/call/main.omg','local/computed_measure/authored_indexed/main.omg','local/main.omg','local/borrowed_value/stored_reference/main.omg','long_cycle/main.omg']: rows.append((base/source,None))
results=[]
for source,reason in rows:
 command=[cli,*(['--check'] if reason else ['run','--both']),str(source)]; started=time.monotonic()
 p=subprocess.run(command,stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=120,env=dict(os.environ,OMEGA_LIBRARY_ROOT=str(root/'source/library')))
 result=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-started,expected_rejection=reason); results.append(result); print(json.dumps(result),flush=True)
 (store/'final-row.json').write_text(json.dumps(dict(producer=producer,results=results),indent=2)+'\n')
 if reason: assert p.returncode==1 and reason in p.stderr,result
 else: assert p.returncode==0 and 'native exit 0' in p.stderr and 'interp exit: 0' in p.stderr,result
assert len(results)==30
print('17 native/Terminal successes and 13 fact-sensitive refusals')
