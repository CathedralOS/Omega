import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();b=root/'build/structured-rank'; producer=json.loads((b/'baseline-producer/producer.json').read_text()); cli=producer['executable'];assert hashlib.sha256(Path(cli).read_bytes()).hexdigest()==producer['sha256']
observed=json.loads((b/'corpus-neighbors-source.json').read_text()); by={p['fixture']:p for p in observed['observations']}
selected=set(observed['counts']['pinned_off_target_fixtures'])|{r['fixture'] for r in observed['fixtures'] if r['verdict']=='moved'}
results=[]
for name in sorted(selected):
 source=Path('tests/omega')/name/'main.omg';command=[cli,'--check',str(source)];start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=120,env=dict(os.environ,OMEGA_LIBRARY_ROOT=str(root/'source/library')))
 row=dict(fixture=name,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start);results.append(row);print(json.dumps(row),flush=True)
 diagnostics=[line[len('error: '):].replace(str(root)+'/', '') for line in p.stderr.splitlines() if line.startswith('error: ')]
 assert diagnostics==by[name]['diagnostics'],(name,diagnostics,by[name]['diagnostics'])
 assert (p.returncode==0)==(by[name]['status']=='checked'),name
(b/'neighbors-baseline-attribution.json').write_text(json.dumps(dict(producer=producer,results=results),indent=2)+'\n');print('all',len(results),'source exceptions reproduce fixed baseline exactly')
