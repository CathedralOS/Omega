set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/structured-rank/completed-ingress-cli-build2.jsonl 2> build/structured-rank/completed-ingress-cli-build2.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/structured-rank/completed-ingress-corpus-build2.jsonl 2> build/structured-rank/completed-ingress-corpus-build2.stderr
