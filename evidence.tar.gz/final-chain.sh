set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/moving-upper/final-cli-build.jsonl 2> build/moving-upper/final-cli-build.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/moving-upper/final-corpus-build.jsonl 2> build/moving-upper/final-corpus-build.stderr
python3 build/moving-upper/capture-final.py
python3 build/moving-upper/validate-final.py
python3 tools/corpus_gate.py --runner build/moving-upper/final-producer/corpus_runner --both --filter pass/facts/nested_machine_joint_rank_moving_upper_ --record --json build/moving-upper/corpus-both.json > build/moving-upper/corpus-both.stdout 2> build/moving-upper/corpus-both.stderr
python3 tools/corpus_gate.py --runner build/moving-upper/final-producer/corpus_runner --filter nested_machine_joint_rank_moving_upper_,fail/facts/nested_machine_joint_rank_increasing_to_post_clamp_rejected,fail/facts/nested_machine_joint_rank_increasing_to_overshoot_rejected,fail/facts/nested_machine_joint_rank_bounded_distance_upper_drift_rejected,fail/facts/nested_machine_joint_rank_bounded_distance_inverted_entry_rejected --record --json build/moving-upper/corpus-source.json > build/moving-upper/corpus-source.stdout 2> build/moving-upper/corpus-source.stderr
