from pathlib import Path
import json,subprocess,time,hashlib,os
b=Path('build/moving-upper');p=json.loads((b/'core1-producer/producer.json').read_text());assert hashlib.sha256(Path(p['executable']).read_bytes()).hexdigest()==p['sha256'];patch=subprocess.check_output(['git','diff','HEAD','--binary','--','omega-rust','source/library','Cargo.toml','Cargo.lock']);assert hashlib.sha256(patch).hexdigest()==p['source_patch_sha256']
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');reason='no exact private-coordinate assignment proves every edge and complete cycle';rows=[]
rows=[
 ('narrow endpoints',root/'parameter/bounded_distance/moving_upper/controls/narrow_endpoints/main.omg',None),
 ('invalid falling interval',root/'parameter/bounded_distance/moving_upper/controls/invalid_falling_interval/main.omg','cannot prove requires contract for call count from forward'),
];results=[]
for name,source,expected in rows:
 cmd=[p['executable'],*(['--check'] if expected else ['run','--both']),str(source)];start=time.monotonic();o=subprocess.run(cmd,capture_output=True,text=True,timeout=120,env=dict(os.environ,OMEGA_LIBRARY_ROOT=str(Path('source/library').resolve())));r=dict(name=name,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),expected_rejection=expected,command=cmd,exit=o.returncode,stdout=o.stdout,stderr=o.stderr,seconds=time.monotonic()-start);results.append(r);(b/'core1-controls-formed.json').write_text(json.dumps(dict(producer=p,results=results),indent=2)+'\n');print(name,o.returncode,flush=True)
 if expected:assert o.returncode==1 and expected in o.stderr,r
 else:assert o.returncode==0 and 'native exit 0' in o.stderr and 'interp exit: 0' in o.stderr,r
print('Control pair complete')
