set -eu
bash build/joint-lexicographic/corpus.sh
python3 build/joint-lexicographic/long-cycle.py
