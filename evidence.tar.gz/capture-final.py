from pathlib import Path
import hashlib,json,subprocess,shutil
root=Path.cwd();b=root/'build/signed-rank';out=b/'final-producer';out.mkdir(exist_ok=False)
patch=subprocess.check_output(['git','diff','--binary','--','omega-rust','source/library','Cargo.toml','Cargo.lock'])
(out/'source.diff').write_bytes(patch)
meta=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),dirty=True,source_patch_sha256=hashlib.sha256(patch).hexdigest())
for kind,log in [('omega','final-cli-build.jsonl'),('corpus_runner','final-corpus-build.jsonl')]:
 rows=[json.loads(s) for s in (b/log).read_text().splitlines()]
 row=next(r for r in reversed(rows) if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==kind and r.get('executable'))
 dst=out/kind;shutil.copy2(row['executable'],dst)
 record=dict(meta,executable=str(dst),sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),opt_level=row['profile']['opt_level'])
 assert record['opt_level']!='0'
 (out/(kind+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 if kind=='omega':(out/'producer.json').write_text(json.dumps(record,indent=2)+'\n')
