from pathlib import Path
import json,hashlib,subprocess,shutil
b=Path('build/moving-upper');out=b/'final-producer';out.mkdir(exist_ok=False)
patch=subprocess.check_output(['git','diff','HEAD','--binary','--','omega-rust','source/library','Cargo.toml','Cargo.lock']);assert not patch
(out/'source.diff').write_bytes(patch)
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for name,log in [('omega','final-cli-build.jsonl'),('corpus_runner','final-corpus-build.jsonl')]:
 rows=[json.loads(s) for s in (b/log).read_text().splitlines()];row=next(r for r in reversed(rows) if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('executable'));dst=out/name;shutil.copy2(row['executable'],dst);p=dict(base=base,compiler_inputs_dirty=False,source_patch_sha256=hashlib.sha256(patch).hexdigest(),executable=str(dst.resolve()),sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),opt_level=row['profile']['opt_level']);assert p['opt_level']!='0';(out/(name+'.json')).write_text(json.dumps(p,indent=2)+'\n')
 if name=='omega':(out/'producer.json').write_text(json.dumps(p,indent=2)+'\n')
