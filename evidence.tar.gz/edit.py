from pathlib import Path
r=Path('omega-rust/psi/compilation');sc=r/'pipeline/04_typed-trees-to-checked-trees/src';ck=r/'representations/checked-trees/src/checked_trees';v=r/'checking/src'
def edit(p,a,b):
 s=p.read_text();assert a in s,(p,a[:80]);p.write_text(s.replace(a,b))
p=ck/'facts/termination/arrival_correspondence.rs'
edit(p,'#[derive(Debug, Clone, PartialEq, Eq, compiler_storage::Record)]\npub struct CheckedRuntimeNaturalState', '''/// The part of an exact rank carrier observed by the component judgment.
/// Payload writes preserve an extent; descriptor replacement does not.
#[derive(Debug, Clone, Copy, PartialEq, Eq, compiler_storage::Record)]
pub enum CheckedRankObservation {
    Value,
    Length,
}

#[derive(Debug, Clone, PartialEq, Eq, compiler_storage::Record)]
pub struct CheckedRuntimeNaturalState''')
edit(p,'pub primitive_type: typed_trees::types::PrimitiveType,','pub primitive_type: typed_trees::types::PrimitiveType,\n    pub observation: CheckedRankObservation,')
edit(p,'primitive_type: typed_trees::types::PrimitiveType::Bool,','primitive_type: typed_trees::types::PrimitiveType::Bool,\n            observation: CheckedRankObservation::Value,')
for p in [ck/'facts/termination.rs',ck/'facts.rs',ck.parent/'checked_trees.rs']:
 edit(p,'CheckedRankPremiseRegime, CheckedRankReceivingCoordinate','CheckedRankObservation, CheckedRankPremiseRegime, CheckedRankReceivingCoordinate')
p=v/'proof_contracts/contract_entailment/ranking_range.rs'
start=p.read_text().index('/// How a ranking judgment reads one carrier:');end=p.read_text().index('/// One root formal a ranking judgment reads',start)
s=p.read_text();p.write_text(s[:start]+'pub use checked_trees::CheckedRankObservation as RankPremiseObservation;\n\n'+s[end:])
p=v/'machine_calls/call_cycles/runtime_ranking.rs'
edit(p,'pub primitive_type: typed_trees::types::PrimitiveType,','pub primitive_type: typed_trees::types::PrimitiveType,\n    pub observation: crate::RankPremiseObservation,')
p=v/'machine_calls/call_cycles/runtime_ranking/projection.rs'
edit(p,'                primitive_type,\n            });','                primitive_type,\n                observation: crate::RankPremiseObservation::Value,\n            });')
p=v/'machine_calls/call_cycles/rank_components.rs'
edit(p,'primitive_type: state.primitive_type,','primitive_type: state.primitive_type,\n                    observation: state.observation,')
p=ck/'flow/terminal/composed_unit_control_plans.rs'
edit(p,'subject: typed_trees::expression::ExpressionHandle::invalid(),','coordinate: crate::CheckedRankCoordinateHandle::invalid(),')
edit(p,'''    /// `Slice::Length`: exact source subject identity; its element or byte
    /// count and arrival projection live in the shared computation root.
    SequenceLength {
        subject: typed_trees::expression::ExpressionHandle,
    },''','''    /// `Slice::Length`: exact admitted arrival coordinate. Private participants
    /// need no fabricated source occurrence to read their descriptor extent.
    SequenceLength {
        coordinate: crate::CheckedRankCoordinateHandle,
    },''')
p=sc/'checks/current_scalar_values.rs'
edit(p,'    lengths: Vec<Length>,','    lengths: Vec<Length>,\n    initial_lengths: Vec<Length>,')
edit(p,'            lengths,\n            fields:', '            lengths,\n            initial_lengths: Vec::new(),\n            fields:')
edit(p,'        values.seed_parameter_fields();','        values.seed_parameter_fields();\n        values.initial_lengths = values.lengths.clone();')
p=sc/'checks/current_scalar_values/collections.rs'
edit(p,'    pub(super) fn collection_length(','''    /// The arrival observation remains bound to this formal even if its
    /// descriptor is subsequently replaced. Current operands use the ordinary
    /// transfer roster below, so replacement cannot manufacture descent.
    pub(crate) fn initial_collection_length(
        &self,
        parameter: SymbolHandle,
    ) -> Option<ScopedArithmeticValue> {
        self.initial_lengths.iter()
            .find(|length| length.subject == LengthSubject::Storage(parameter))?
            .value.clone()
    }

    pub(crate) fn current_collection_length(
        &self,
        expression: ExpressionHandle,
    ) -> Option<ScopedArithmeticValue> {
        self.collection_length(expression, 0)
    }

    pub(super) fn collection_length(''')
