from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import corpus_gate
r=Path('build/ranged-cycle-ranks');scope=json.load(open(r/'scope.json'));fixtures=[p for p in scope['fixtures'] if (Path('tests/omega')/p/'main.omg').exists()]
original=corpus_gate.run_runner
def capture(*args,**kwargs):
 rows=original(*args,**kwargs)
 if len(args)<2 or Path(args[1]).resolve()==Path.cwd().resolve():(r/'source-observations.json').write_text(json.dumps(rows,indent=2)+'\n')
 return rows
corpus_gate.run_runner=capture
sys.argv=['corpus_gate','--runner',str((r/'final-producer/corpus_runner').resolve()),'--baseline-runner',str(Path('build/private-cycle-ranks/candidate-producer/corpus_runner').resolve()),'--compare','bd57535230243699e595f565e84d75fa19be881d','--filter',','.join(fixtures),'--json',str(r/'final-source-compare.json')]
raise SystemExit(corpus_gate.main())
