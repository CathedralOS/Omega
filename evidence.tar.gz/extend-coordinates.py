from pathlib import Path
root=Path('omega-rust/psi/compilation/pipeline/04_typed-trees-to-checked-trees/src/checks')
p=root/'current_scalar_values/scalar_fields.rs';s=p.read_text();needle="impl CurrentScalarValues<'_> {\n";assert needle in s
s=s.replace(needle,'''impl CurrentScalarValues<'_> {
    /// Exact retained inline fields of one formal. The caller selects the
    /// frame: an entry frame supplies entry values; a later frame supplies
    /// only associations that survived its executed writes and calls.
    pub(crate) fn scalar_field_observations(
        &self,
        parameter: SymbolHandle,
    ) -> impl Iterator<Item = (&[SymbolHandle], PrimitiveType, &ScopedArithmeticValue)> {
        self.fields.iter().filter_map(move |field| {
            (field.owner == parameter)
                .then_some(field.value.as_ref())?
                .map(|value| (field.path.as_slice(), field.carrier, value))
        })
    }

    /// Read the selected leaf from the completed actual, including retained
    /// copies and constructed values. No source expression is synthesized for
    /// an inferred field and no withdrawn current association is revived.
    pub(crate) fn projected_scalar_value(
        &self,
        actual: ExpressionHandle,
        path: &[facts::PlaceSegment],
    ) -> Option<ScopedArithmeticValue> {
        if path.is_empty() {
            return self.current(actual).map(ScopedArithmeticValue::Term);
        }
        self.captured_scalar_fields(actual, 0)
            .into_iter()
            .find(|field| {
                field.path.len() == path.len()
                    && field.path.iter().zip(path).all(|(field, segment)| {
                        matches!(segment, facts::PlaceSegment::Field { symbol } if symbol == field)
                    })
            })
            .map(|field| field.value)
    }

''',1);p.write_text(s)
p=root/'termination/joint_natural.rs';s=p.read_text();s=s.replace('    parameter: SymbolHandle,\n    position: usize,','    parameter: SymbolHandle,\n    path: Vec<facts::PlaceSegment>,\n    entry_value: ScopedArithmeticValue,\n    position: usize,',1)
a=s.index('        if !place.segments.is_empty()');b=s.index('        if selected_observation.is_some_and',a)
s=s[:a]+'''        let parameter = place.root.as_symbol()?;
        let selected = coordinates(program, machine, entry, observation, frames)?
            .into_iter()
            .find(|coordinate| coordinate.parameter == parameter && coordinate.path == place.segments)?;
        let carrier = selected.primitive;
'''+s[b:]
a=s.index('        candidates.push(vec![Coordinate {');b=s.index('        if candidates.is_empty()',a)
s=s[:a]+'''        candidates.push(vec![selected]);
    }
    let (observation, primitive) = selected_observation?;
    for (machine, candidates) in machines.iter().zip(&mut candidates) {
        if !candidates.is_empty() {
            continue;
        }
        // Private correspondence changes neither public schemas nor source
        // signatures. Only exact runtime leaves in this invocation participate.
        if machine.is_public {
            return None;
        }
        let entry = &program.machine_states(machine)[0];
        *candidates = coordinates(program, machine, entry, observation, frames)?
            .into_iter()
            .filter(|coordinate| coordinate.primitive == primitive)
            .collect();
'''+s[b:]
a=s.index('impl Coordinate {');b=s.index('    fn current(',a)
s=s[:a]+'''impl Coordinate {
'''+s[b:];s=s.replace('values.current(actual).map(ScopedArithmeticValue::Term)','values.projected_scalar_value(actual, &self.path)',1)
a=s.index('fn observation_carrier(')
s=s[:a]+'''/// Capture eligible coordinates once before the first admitted executable
/// statement. An invalid target applies no branch guard or operand effects.
/// Each candidate owns only its selected value, not a second field roster.
fn coordinates(
    program: &dyn validation::CheckingInput,
    machine: &typed_trees::machine::Machine,
    state: &typed_trees::state::State,
    observation: validation::RankPremiseObservation,
    frames: Option<&validation::CallFrameResolver<'_>>,
) -> Option<Vec<Coordinate>> {
    let order = program.statement_table.admitted_execution_order(state.statement_nodes);
    let first = *order.indices().first()?;
    let values = CurrentScalarValues::at(program, machine, state, first, Default::default(), frames)?;
    let mut coordinates = Vec::new();
    for (position, parameter) in program.state_parameters(state).iter().enumerate() {
        if parameter.relevance.is_erased() || parameter.is_const {
            continue;
        }
        if let Some(primitive) = observation_carrier(program, state, parameter.symbol, observation) {
            let entry_value = match observation {
                validation::RankPremiseObservation::Value => values.initial_symbol(parameter.symbol),
                validation::RankPremiseObservation::Length => values.initial_collection_length(parameter.symbol),
            };
            if let Some(entry_value) = entry_value {
                coordinates.push(Coordinate {
                    parameter: parameter.symbol,
                    path: Vec::new(),
                    entry_value,
                    position,
                    primitive,
                    observation,
                });
            }
        }
        if observation == validation::RankPremiseObservation::Value {
            // The entry seed walks owned inline records only. Borrowed storage
            // and erased/static parameters cannot acquire a private read here.
            for (path, primitive, value) in values.scalar_field_observations(parameter.symbol) {
                coordinates.push(Coordinate {
                    parameter: parameter.symbol,
                    path: path.iter().map(|symbol| facts::PlaceSegment::Field { symbol: *symbol }).collect(),
                    entry_value: value.clone(),
                    position,
                    primitive,
                    observation,
                });
            }
        }
    }
    Some(coordinates)
}

'''+s[a:]
s=s.replace('    let initial = source.initial(&edge.values)?;','    let initial = &source.entry_value;',1).replace('proves(BinaryOperator::GreaterOrEqual, &initial, &zero)','proves(BinaryOperator::GreaterOrEqual, initial, &zero)').replace('proves(BinaryOperator::LessOrEqual, &next, &initial)','proves(BinaryOperator::LessOrEqual, &next, initial)').replace('proves(BinaryOperator::Less, &next, &initial)','proves(BinaryOperator::Less, &next, initial)').replace('                    path: Vec::new(),\n                },\n                parameter_position:', '                    path: coordinate.path.clone(),\n                },\n                parameter_position:',1)
p.write_text(s)
