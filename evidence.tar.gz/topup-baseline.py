from pathlib import Path
import json,sys,os
sys.path.insert(0,'tools');import corpus_gate
r=Path('build/descriptor-cycle-ranks');p=r/'scope.json';scope=json.loads(p.read_text())
positives=['pass/contracts/nested_call_later_operand_preserves_storage_fact','pass/contracts/call_write_keeps_disjoint_guard_exit','pass/contracts/normal_return_contextual_call_arguments_exit']
negatives=['fail/contracts/runtime_requirement_after_argument_write','fail/contracts/runtime_requirement_after_transition_argument_write','fail/contracts/nested_call_later_operand_clears_storage_fact','fail/contracts/returned_length_cannot_use_later_operand_guarantee','fail/proofs/call_argument_snapshot_precedes_write','fail/proofs/scalar_field_snapshot_before_argument_write']
scope['source']=sorted(set(scope['source']+positives+negatives));scope['both']=sorted(set(scope['both']+positives));p.write_text(json.dumps(scope,indent=2)+'\n');original=corpus_gate.run_runner

def run(*args,**kwargs):
 root=Path(args[1]);old=os.environ.get('OMEGA_LIBRARY_ROOT');os.environ['OMEGA_LIBRARY_ROOT']=str(root/'source/library')
 try:rows=original(*args,**kwargs)
 finally:
  if old is None:os.environ.pop('OMEGA_LIBRARY_ROOT',None)
  else:os.environ['OMEGA_LIBRARY_ROOT']=old
 (r/('baseline-extra-'+('both' if os.environ.get('OMEGA_CORPUS_NATIVE') else 'source')+'-observations.json')).write_text(json.dumps(rows,indent=2)+'\n');return rows
corpus_gate.run_runner=run
runner=Path('build/projected-cycle-ranks/integrated-producer/corpus_runner').resolve()
for mode,leg in [('source',''),('both','both')]:
 # Same controls as the official main entrypoint sets for this leg.
 if mode=='both':
  os.environ['OMEGA_CORPUS_NATIVE']='1';os.environ['OMEGA_CORPUS_INTERPRET']='1'
 else:
  os.environ.pop('OMEGA_CORPUS_NATIVE',None);os.environ.pop('OMEGA_CORPUS_INTERPRET',None)
 rows=corpus_gate.base_records_for(scope['base'],leg,scope[mode],runner);print('Cached baseline',mode,len(rows),flush=True)
