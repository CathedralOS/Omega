from pathlib import Path
import json,subprocess
r=Path('build/private-cycle-ranks');base=json.loads((r/'context-config.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();scope=json.loads((r/'scope.json').read_text());compiler=['omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo'];harness=['tools/corpus_gate.py','tools/corpus_records.py','tools/compiler_profile.py','tools/corpus_perf.py']
compiler=[p for p in compiler if Path(p).exists()];harness=[p for p in harness if Path(p).exists()];checks=[]
def add(id,kind,command,inputs,artifacts,reason,producer=None):
 row=dict(id=id,kind=kind,command=command,inputs=inputs,artifacts=[str(Path(p).resolve()) for p in artifacts],closure_reason=reason,final=False,expected_exit=0,timeout_seconds=900)
 if producer:row['producer']=dict(revision=head,inputs=compiler,executables=[str((r/'candidate-producer'/producer).resolve())])
 checks.append(row)
for mode in ['source','both']:
 add('corpus-'+mode,'native' if mode=='both' else 'tests',['python3',str(r/'validate-corpus.py'),mode],compiler+harness+scope['new']+scope['regressions']+['tests/omega/corpus_outcomes.txt','tests/omega/corpus_both_macos_arm64.txt'],[r/'validate-corpus.py',r/'scope.json',r/'candidate-producer/corpus_runner',r/'candidate-producer/corpus-producer.json'],'Exact selected fixtures and all exercised compiler/library/harness inputs. Validator checks each actual status, authored reject reason, and both engine exits; golden differences alone are not semantic failures.', 'corpus_runner' if mode=='both' else None)
add('samples','native',['python3',str(r/'validate-samples.py')],compiler+[str(p) for p in Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/structural_view')],[r/'validate-samples.py',r/'candidate-producer/omega',r/'candidate-producer/cli-producer.json']+list(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/structural_view/omega.lock')),'Nine exact authored source/Build inputs and accepted locks, compiler and library; direct public CLI observes both engines.', 'omega')
add('rust','tests',['python3',str(r/'validate-rust.py')],compiler,[r/'validate-rust.py'],'Affected crate Clippy and changed Rust formatting.')
base['checks']=checks;(r/'qualification-config.json').write_text(json.dumps(base,indent=2)+'\n')
