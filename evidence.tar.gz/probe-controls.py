from pathlib import Path
import sys,json
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/descriptor-cycle-ranks');cli=str((r/'producer/omega').resolve());rows=[]
for name in ['mutated_copy','restored_copy','nested_record','element_write']:
 p=r/name;reason,output=accept_review(cli,str(p),'macos_arm64',180);rows.append(dict(name=name,reason=reason,output=output));(r/'control-baseline.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,reason,output[-2500:] if reason else '',flush=True)
