from pathlib import Path
import json,subprocess,sys,time,hashlib
sys.path.insert(0,'tools');from sample_native_gate import accept_review
cli=str(Path(sys.argv[1]).resolve());label=sys.argv[2];sources=[Path(x) for x in sys.argv[3:]]
if not sources:sources=[Path('build/private-cycle-ranks/slice-rank/main.omg'),Path('build/private-cycle-ranks/slice-rank/invalid/main.omg')]
rows=[]
for source in sources:
 reason,output=accept_review(cli,str(source.parent),'macos_arm64',180)
 row=dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),review_reason=reason,review_output=output)
 if reason is None:
  cmd=[cli,'run','--both',str(source)];start=time.monotonic();x=subprocess.run(cmd,input='',text=True,capture_output=True,timeout=180);row.update(command=cmd,exit=x.returncode,stdout=x.stdout,stderr=x.stderr,elapsed_seconds=time.monotonic()-start)
 rows.append(row);Path('build/private-cycle-ranks/'+label+'.json').write_text(json.dumps(rows,indent=2)+'\n');print(source,reason,row.get('exit'),row.get('stderr',output)[-2600:],flush=True)
