set -eu
bash build/joint-lexicographic/review-fix-corpus.sh
python3 build/joint-lexicographic/review-fix-long-cycle.py
