set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/moving-upper/core2-build.jsonl 2> build/moving-upper/core2-build.stderr
python3 build/moving-upper/capture-core2.py
python3 build/moving-upper/probe-core2.py
