set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/joint-lexicographic/core2-build.jsonl 2> build/joint-lexicographic/core2-build.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/joint-lexicographic/core2-corpus-build.jsonl 2> build/joint-lexicographic/core2-corpus-build.stderr
cargo test --locked -p terminal-codec rank_tuple -- --nocapture > build/joint-lexicographic/rank-tuple-wire-test.stdout 2> build/joint-lexicographic/rank-tuple-wire-test.stderr
