from pathlib import Path
r=Path('omega-rust/psi/compilation');sc=r/'pipeline/04_typed-trees-to-checked-trees/src';v=r/'checking/src'
def edit(p,a,b):
 s=p.read_text();assert a in s,(p,a[:80]);p.write_text(s.replace(a,b))
p=v/'proof_contracts/contract_entailment/ranking_range/calls/endpoint_pins.rs'
edit(p,'use super::{BinaryOperator, RankingRangeCallMember};','use super::BinaryOperator;')
edit(p,'pub(crate) struct RankingRangeCallEdge', '''/// Endpoint conservation reads authored bounds and completed arrivals only.
/// A private participant need not manufacture an authored rank subject.
pub struct RankingRangeEndpointMember<'program> {
    pub machine: &'program Machine,
    pub range: Option<ExpressionHandle>,
}

pub struct RankingRangeCallEdge''')
edit(p,"pub(crate) fn mixed_call_endpoints_are_pinned<'program>(","pub fn rank_call_endpoints_are_pinned<'program>(")
edit(p,"members: &[RankingRangeCallMember<'program>]","members: &[RankingRangeEndpointMember<'program>]")
edit(p,'''            if !member.range.is_valid() {
                continue;
            }
            let range = program.expression_table.range_node(member.range)?;''','''            let Some(range) = member.range else {
                continue;
            };
            let range = program.expression_table.range_node(range)?;''')
p=v/'proof_contracts/contract_entailment/ranking_range/calls.rs'
edit(p,'pub(crate) use endpoint_pins::{RankingRangeCallEdge, mixed_call_endpoints_are_pinned};','pub use endpoint_pins::{RankingRangeCallEdge, RankingRangeEndpointMember, rank_call_endpoints_are_pinned};')
p=v/'proof_contracts/contract_entailment/ranking_range.rs'
edit(p,'''pub(crate) use calls::{
    RankingRangeCallEdge, RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,
    call_member_premise_symbols, mixed_call_endpoints_are_pinned, prove_ranking_range_call,
};''','''pub use calls::{RankingRangeCallEdge, RankingRangeEndpointMember, rank_call_endpoints_are_pinned};
pub(crate) use calls::{
    RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,
    call_member_premise_symbols, prove_ranking_range_call,
};''')
p=v/'proof_contracts/contract_entailment.rs'
edit(p,'RankingRangeCallEdge, RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,','RankingRangeCallEdge, RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite, RankingRangeEndpointMember,')
edit(p,'mixed_call_endpoints_are_pinned','rank_call_endpoints_are_pinned')
p=v/'lib.rs'
edit(p,'    RankingRangeEdgeProof, RankingRangeMeasure, RankingRangePremises, RankingRangeState,','    RankingRangeEdgeProof, RankingRangeMeasure, RankingRangePremises, RankingRangeState,\n    RankingRangeCallEdge, RankingRangeEndpointMember, rank_call_endpoints_are_pinned,')
p=v/'machine_calls/call_cycles/runtime_ranking.rs'
edit(p,'RankingRangeCallEdge, RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,','RankingRangeCallEdge, RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite, RankingRangeEndpointMember,')
edit(p,'mixed_call_endpoints_are_pinned','rank_call_endpoints_are_pinned')
edit(p,'''            .map(|(rank, index)| RankingRangeCallMember {
                machine: &program.machines()[*index],
                subject: rank.subject,
                paired_subject: rank.paired_subject,
                range: rank.range,
            })''','''            .map(|(rank, index)| RankingRangeEndpointMember {
                machine: &program.machines()[*index],
                range: rank.range.is_valid().then_some(rank.range),
            })''')
p=sc/'checks/current_scalar_values.rs'
edit(p,'    initial_lengths: Vec<Length>,','    initial_lengths: Vec<Length>,\n    initial_fields: Vec<ScalarField>,\n    guards: Vec<(ExpressionHandle, bool)>,')
edit(p,'            initial_lengths: Vec::new(),','            initial_lengths: Vec::new(),\n            initial_fields: Vec::new(),\n            guards: Vec::new(),')
edit(p,'        values.initial_lengths = values.lengths.clone();','        values.initial_lengths = values.lengths.clone();\n        values.initial_fields = values.fields.clone();')
edit(p,'                    values.assume(program, machine, state, guard, holds);','                    values.assume(program, machine, state, guard, holds);\n                    values.guards.push((guard, holds));')
edit(p,'                values.assume(program, machine, state, guard, transition.target == target);','                values.assume(program, machine, state, guard, transition.target == target);\n                values.guards.push((guard, transition.target == target));')
edit(p,'''        let occurrence = self.occurrence();
        admitted(occurrence, expression, &self.initial, &[], 0)
            .then(|| scoped(occurrence, expression, &self.initial, &[]))''','''        let occurrence = self.occurrence_at(self.program, self.machine, self.state, &self.initial_lengths);
        admitted(occurrence, expression, &self.initial, &self.initial_fields, 0)
            .then(|| scoped(occurrence, expression, &self.initial, &self.initial_fields))''')
edit(p,'    pub(crate) fn current(\n','''    /// Raw selected guard ancestry, for owners that separately prove prefix
    /// preservation before consuming it. The live arithmetic hypotheses above
    /// retain their own captured rosters across writes.
    pub(crate) fn selected_guards(&self) -> &[(ExpressionHandle, bool)] {
        &self.guards
    }

    pub(crate) fn current(
''')
