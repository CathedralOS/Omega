from pathlib import Path
import json,subprocess,sys,hashlib,time
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/private-cycle-ranks');cli=str((r/'base-producer/omega').resolve());records=[]
for source in [r/'slice-rank/main.omg',r/'slice-rank/invalid/main.omg']:
 reason,output=accept_review(cli,str(source.parent),'macos_arm64',180);row=dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),producer=json.loads((r/'base-producer/producer.json').read_text())['revision'],review_reason=reason,review_output=output)
 if reason is None:
  cmd=[cli,'run','--both',str(source)];start=time.monotonic();x=subprocess.run(cmd,input='',text=True,capture_output=True,timeout=180);row.update(command=cmd,exit=x.returncode,stdout=x.stdout,stderr=x.stderr,elapsed_seconds=time.monotonic()-start)
 records.append(row);(r/'baseline-slice-rank.json').write_text(json.dumps(records,indent=2)+'\n');print(source,reason,row.get('exit'),row.get('stderr',output)[-3000:],flush=True)
