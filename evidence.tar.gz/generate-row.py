from pathlib import Path
import json
r=Path('samples/cli/facts/nested_machine_invocation/joint_rank'); places=['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body'];sentence='A private helper preserves the invocation rank on a tail edge, and every complete cycle strictly descends while advancing the explicit counter once.'
for place in places:
 s=(r/place/'projected_value/main.omg').read_text().replace('count: u64','values: &[u8]').replace('remaining.count','remaining.values.len').replace('pending.count','pending.values.len').replace('received.count','received.values.len').replace('result.count','result.values.len').replace('terminates by remaining.values.len;','terminates by remaining.values -> Slice::Length;').replace('count: pending.values.len - 1','values: pending.values[1..]').replace('count: 7','values: bytes').replace('count: 0','values: bytes[0..0]')
 s=s.replace('select: bool)', 'bytes: &[u8], select: bool)').replace('input(select)', 'input(bytes, select)').replace('perform(&mut counted, true)','perform(&mut counted, &bytes[..], true)').replace('perform(&mut counted, false)','perform(&mut counted, &bytes[..], false)').replace('    let mut counted: u64 = 3;','    let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];\n    let mut counted: u64 = 3;')
 s=s.replace('bytes: &[u8], select: bool) crashes Trap {','bytes: &[u8], select: bool) crashes Trap\nrequires bytes.len <= 7;\n{').replace('machine input(bytes: &[u8], select: bool) -> Remaining\n','machine input(bytes: &[u8], select: bool) -> Remaining\nrequires bytes.len <= 7;\n')
 if place=='const_name':
  s=s.replace('const Limit: u64 = 7;','const Bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];').replace('count: Limit','values: &stored[..]').replace('false -> count(counter, Remaining { canary: 641, values: bytes[0..0] })','false -> count(counter, Remaining { canary: 641, values: &stored[0..0] })').replace('    transition select {','    let stored: [u8; 7] = Bytes;\n    transition select {')
 if place=='target_body':s=s.replace('reaches crashes Trap;','reaches crashes Trap\n    requires bytes.len <= 7;')
 p=r/place/'descriptor_field';(p/'invalid').mkdir(parents=True,exist_ok=True);(p/'main.omg').write_text(s);(p/'invalid/main.omg').write_text(s.replace('pending.values[1..]','pending.values'))
 for d in [p,p/'invalid']:
  (d/'build.omg').write_text((r/place/'projected_value/build.omg').read_text().replace('projected','descriptor'))
 (p/'invalid/sample.json').write_text(json.dumps({'role':'intended-invalid','entry':'main.omg','rejection_contains':['no exact private-coordinate assignment proves every edge and complete cycle']},indent=2)+'\n')
 (p/'README.md').write_text(f'''# Descriptor field rank: {place}

Owner: `NESTED-MACHINE-UNIFICATION` in [TASKS.md](../../../../../../../TASKS.md).

{sentence}

[Positive](main.omg) preserves `Remaining.values` through `{place}` and executes
both seven-element and empty inputs. The caller observes counter3→10, then10;
the sibling canary remains641. [Twin](invalid/main.omg) removes only the suffix.
All four hosted targets bind ProgramEntry; only actual observed execution counts.

The finite descriptor extent and each helper's own requirements establish the
rank. Exact field declaration identities, saved entry extents and current actual
substitution establish nonincrease on every edge and descent on every cycle.
No parent facts or fresh storage snapshots are assumed. The caller retains
backing through the complete call; ordinary loans, access, cleanup, effects and
partial window formation remain independent. The admitted SequenceLength
coordinate becomes an ordinary Terminal structural length read, then normal
layout/calling plans, register/frame assignment and final encoding. Wrong field
geometry, skipped increments or wrong branch selection trap at the caller.
The reject removes descent while preserving formation and contracts.

Frozen local baseline3835 refuses the private rank; candidate measurements live
in `build/descriptor-cycle-ranks/`. Parent acceptance remains on TASKS.md,
including borrowed/indexed/case projections, custom/dependent measures, other
normal completion/custody obligations and both product implementations.
''')
 for disposition,source,suffix in [('pass',p/'main.omg','exit'),('fail',p/'invalid/main.omg','rejected')]:
  f=Path('tests/omega')/disposition/'facts'/f'nested_machine_joint_rank_descriptor_field_{place}_{suffix}';f.mkdir(parents=True,exist_ok=True);(f/'main.omg').write_bytes(source.read_bytes());(f/'build.omg').write_bytes((p/'build.omg').read_bytes())
  if disposition=='pass':
   for name in ['expected_native_exit.txt','expected_interpreter_exit.txt']:(f/name).write_text('0\n')
  else:(f/'expected_errors.txt').write_text('no exact private-coordinate assignment proves every edge and complete cycle\n')
# The local source remains exactly the frozen preimplementation program.
assert (r/'local/descriptor_field/main.omg').read_bytes()==Path('build/descriptor-cycle-ranks/local/main.omg').read_bytes()
