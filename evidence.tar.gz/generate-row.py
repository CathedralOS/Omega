from pathlib import Path
import json,textwrap
r=Path('build/borrowed-cycle-ranks');root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');base=(r/'local/main.omg').read_text();count=base[:base.index('machine perform(')];main=base[base.index('machine main('):];places=['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body'];fact=base.splitlines()[0][3:]
construct='''    let mut remaining: Remaining = match select {
        true -> Remaining { canary: 641, count: 7 }
        false -> Remaining { canary: 641, count: 0 }
    };
'''
check='''    transition remaining.count == 0 && remaining.canary == 641 {
        true -> done() false -> bad()
    }
    machine done() {}
    machine bad() crashes Trap { crash Trap; }
'''
for place in places:
 prefix=count;body='machine perform(counter: &mut u64, select: bool) crashes Trap {\n'+construct+'    count(counter, &mut remaining);\n'+check+'}\n'
 if place=='field':
  prefix=prefix.replace('machine count(', 'data Envelope { prefix: u64; value: Remaining; }\nmachine count(',1)
  body='''machine perform(counter: &mut u64, select: bool) crashes Trap {
    let mut envelope: Envelope = Envelope { prefix: 207, value: match select {
        true -> Remaining { canary: 641, count: 7 }
        false -> Remaining { canary: 641, count: 0 }
    } };
    count(counter, &mut envelope.value);
    transition envelope.prefix == 207 && envelope.value.count == 0 && envelope.value.canary == 641 {
        true -> done() false -> bad()
    }
    machine done() {}
    machine bad() crashes Trap { crash Trap; }
}
'''
 elif place=='parameter':
  body=body.replace('count(counter, &mut remaining);','invoke(counter, &mut remaining);')+'''machine invoke(counter: &mut u64, received: &mut Remaining) crashes Trap
requires received.count <= 7;
{ count(counter, received); }
'''
 elif place in ['call_result','other_machine']:
  input='''machine input(select: bool) -> Remaining
ensures result.count <= 7;
{ match select { true -> Remaining { canary: 641, count: 7 } false -> Remaining { canary: 641, count: 0 } } }
'''
  body=body.replace(construct,'    let mut remaining: Remaining = input(select);\n')
  if place=='other_machine':body=body.replace('count(counter, &mut remaining);','relay(counter, &mut remaining);')+'''machine relay(counter: &mut u64, received: &mut Remaining) crashes Trap
requires received.count <= 7;
{ count(counter, received); }
'''
  prefix+=input
 elif place=='match_join':
  body='''machine perform(counter: &mut u64, select: bool) crashes Trap {
    let mut full: Remaining = Remaining { canary: 641, count: 7 };
    let mut empty: Remaining = Remaining { canary: 641, count: 0 };
    let selected: &mut Remaining = match select { true -> &mut full false -> &mut empty };
    count(counter, selected);
    let full_done: bool = match select { true -> full.count == 0 false -> full.count == 7 };
    transition full_done && empty.count == 0 && full.canary == 641 && empty.canary == 641 {
        true -> done() false -> bad()
    }
    machine done() {}
    machine bad() crashes Trap { crash Trap; }
}
'''
 elif place=='const_name':prefix=prefix.replace('machine count(', 'const Limit: u64 = 7;\nmachine count(',1);body=body.replace('count: 7','count: Limit')
 elif place=='other_state':
  declarations=count[count.index('machine count('):]
  prefix=count[:count.index('machine count(')]
  body=body[:-2]+textwrap.indent(declarations,'    ')+'}\n'
 elif place=='target_body':
  body='''boundary trait HostedBorrowed {
    machine perform(counter: &mut u64, select: bool) reaches crashes Trap;
}
HostedBorrowedBody satisfies HostedBorrowed {
'''+textwrap.indent(body,'    ')+'}\n';main=main.replace('perform(&mut counted,','HostedBorrowed::perform(&mut counted,')
 s=prefix+body+main;p=root/place/'borrowed_value';(p/'invalid').mkdir(parents=True,exist_ok=True);(p/'main.omg').write_text(s);(p/'invalid/main.omg').write_text(s.replace('pending.count = pending.count - 1;','pending.count = pending.count;'));build=(root/place/'projected_value/build.omg').read_text().replace('projected_value','borrowed_value').replace('HostedProjected','HostedBorrowed')
 for dest in [p,p/'invalid']:(dest/'build.omg').write_text(build)
 (p/'invalid/sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['no exact private-coordinate assignment proves every edge and complete cycle']),indent=2)+'\n')
 (p/'README.md').write_text(f'''# Borrowed private rank: {place}

Owner: `NESTED-MACHINE-UNIFICATION` in [TASKS.md](../../../../../../../TASKS.md).

{fact}

[Positive](main.omg) transports the original caller-owned `Remaining` through
`{place}`. Seven and empty inputs keep the same count field and exact decrement;
the counter advances3→10, then stays10. The caller checks original count0 and
canary641 after the ranked invocation. [Twin](invalid/main.omg) removes only
descent, preserving formation, loans, input and operation shape.

Each helper's own requirements establish nonnegative rank. An admitted readable
reference crosses only its formal boundary; its binding identity does not freeze
its referent. Saved entry observations stay distinct from current field versions.
Exact field paths and current actual substitution establish every-edge nonincrease
and every-cycle descent; overlapping writes retire current associations. Borrowed
access, immediate-parent lineage, selected cleanup/restoration and caller backing
remain independent requirements. An owned carrier never owns the referent it denotes.

Checked scalar coordinates and complete captured loan resources feed ordinary
Terminal reads and state arrivals. Provider settlement, layout/ABI placement,
instruction/register/frame realization and image encoding must preserve the pointer,
original record and counter through the complete cycle. Runtime writeback checks
expose staged copies, wrong offsets and lost mutation; wrong branch/count traps.
Build binds all four hosted targets; only observed engine/host outcomes count.
Baseline6465 refuses the frozen local private witness. Candidate run records are
under `build/borrowed-cycle-ranks/`; other parent obligations remain on TASKS.md.
''')
 for tier,source,suffix in [('pass',p/'main.omg','exit'),('fail',p/'invalid/main.omg','rejected')]:
  f=Path('tests/omega')/tier/'facts'/f'nested_machine_joint_rank_borrowed_value_{place}_{suffix}';f.mkdir(parents=True,exist_ok=True);(f/'main.omg').write_bytes(source.read_bytes());(f/'build.omg').write_text(build)
  if tier=='pass':
   for name in ['expected_native_exit.txt','expected_interpreter_exit.txt']:(f/name).write_text('0\n')
  else:(f/'expected.txt').write_text('no exact private-coordinate assignment proves every edge and complete cycle\n')
assert (root/'local/borrowed_value/main.omg').read_bytes()==(r/'local/main.omg').read_bytes()
