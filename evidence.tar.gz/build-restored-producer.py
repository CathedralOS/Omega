from pathlib import Path
import subprocess,json,hashlib,shutil,time,os
root=Path('build/borrowed-cycle-ranks');output=root/'final-producer';output.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
inputs=['omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']
identity={p:subprocess.check_output(['git','rev-parse',head+':'+p],text=True).strip() for p in inputs if Path(p).exists()}
for label,command,target in [('cli',['cargo','build','--locked','-p','omega','--bin','omega','--message-format=json'],'omega'),('corpus',['cargo','test','--locked','-p','compiler','--test','corpus_runner','--no-run','--message-format=json'],'corpus_runner')]:
 start=time.monotonic()
 with (output/(label+'-build.stdout')).open('w') as stdout,(output/(label+'-build.stderr')).open('w') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,timeout=900)
 receipt=dict(command=command,exit=result.returncode,elapsed_seconds=time.monotonic()-start,revision=head,inputs=identity)
 (output/(label+'-build.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(label,result.returncode,round(receipt['elapsed_seconds'],2),flush=True);assert result.returncode==0
 rows=[json.loads(line) for line in (output/(label+'-build.stdout')).read_text().splitlines() if line.startswith('{')]
 artifact=[row for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and row['target']['name']==target][-1]
 executable=output/target;shutil.copy2(artifact['executable'],executable)
 profile=json.loads(subprocess.check_output([str(executable.resolve()),'--build-profile'],text=True));assert profile['opt_level']=='1'
 receipt.update(executable=str(executable.resolve()),sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),profile=profile,artifact=artifact)
 (output/(label+'-producer.json')).write_text(json.dumps(receipt,indent=2)+'\n')

command=['cargo','test','--locked','-p','target-operations-to-selected-instructions','--lib','borrowed_arrivals::restoration::tests','--','--nocapture']
start=time.monotonic()
with (root/'restoration-unit.stdout').open('w') as out,(root/'restoration-unit.stderr').open('w') as err:x=subprocess.run(command,stdout=out,stderr=err,timeout=900)
(root/'restoration-unit-command.json').write_text(json.dumps(dict(command=command,exit=x.returncode,elapsed_seconds=time.monotonic()-start,revision=head),indent=2)+'\n');print('restoration units',x.returncode,flush=True);assert x.returncode==0
