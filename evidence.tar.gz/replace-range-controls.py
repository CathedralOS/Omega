from pathlib import Path
import shutil,json
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank')
old=root/'controls/ranged_foreign_bound';dest=root/'local/ranged_value/rebound_ceiling';dest.mkdir(parents=True,exist_ok=True)
s=(old/'main.omg').read_text().replace('count(counter, remaining, 7);','count(counter, remaining, 9);')
(dest/'main.omg').write_text(s);(dest/'build.omg').write_text((old/'build.omg').read_text().replace('ranged_controls_ranged_foreign_bound','ranged_rebound_ceiling'));shutil.rmtree(old)
base=Path('build/ranged-cycle-ranks/local/main.omg').read_text();s=base.replace('machine count(counter: &mut u64, remaining: u64)','machine count(counter: &mut u64, remaining: u64, floor: i64)').replace('in 0..=7;','in floor..=7;').replace('requires remaining <= 7;','requires remaining <= 7 && floor <= 0;').replace('count(counter, pending - 1)','count(counter, pending - 1, 0)').replace('count(counter, remaining);','count(counter, remaining, -1);')
p=root/'local/ranged_value/rebound_floor';p.mkdir(parents=True,exist_ok=True);(p/'main.omg').write_text(s);(p/'build.omg').write_text(Path('build/ranged-cycle-ranks/local/build.omg').read_text().replace('private_ranged_joint_rank','ranged_rebound_floor'))
for folder in ['carried_bound','sequence_length','partial_floor','static_bound','rebound_ceiling','rebound_floor']:
 p=root/'local/ranged_value'/folder;src=(p/'main.omg').read_text();d=p/'invalid';d.mkdir(exist_ok=True)
 if folder=='rebound_ceiling':
  invalid=src.replace('forward(remaining, 7, counter)','forward(remaining, 0, counter)');reason='requires'
 elif folder=='rebound_floor':
  invalid=src.replace('count(counter, pending - 1, 0)','count(counter, pending - 1, 8)');reason='destination rank range'
 elif folder=='partial_floor':
  invalid=src.replace('remaining <= 7 && cap > 0 && cap <= remaining + 1','remaining <= 7 && cap <= remaining + 1');reason='independent entry formation'
 else:
  invalid=src.replace('pending - 1','pending').replace('pending[1..]','pending');reason='no exact private-coordinate assignment proves every edge and complete cycle'
 (d/'main.omg').write_text(invalid);(d/'build.omg').write_text((p/'build.omg').read_text());(d/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=[reason]),indent=2)+'\n')
# This one is now the partial-floor twin, kept at its ordinary invalid location.
shutil.rmtree(root/'controls/ranged_partial_floor_unformed')
