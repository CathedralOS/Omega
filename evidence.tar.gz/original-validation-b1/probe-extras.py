from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/borrowed-cycle-ranks');cli=str((r/'home-retry-producer/omega').resolve());rows=[]
for name in ['disjoint_write','nested_record','descriptor_field']:
 p=r/name;reason,out=accept_review(cli,str(p),'macos_arm64',180);row=dict(name=name,sha256=hashlib.sha256((p/'main.omg').read_bytes()).hexdigest(),reason=reason,output=out);rows.append(row);(r/'extras-prototype-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,reason,out[-2400:] if reason else '',flush=True)
 if reason is None:
  x=subprocess.run([cli,'run','--both',str(p/'main.omg')],input='',text=True,capture_output=True,timeout=180);row['runtime']=dict(exit=x.returncode,stdout=x.stdout,stderr=x.stderr);(r/'extras-prototype-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print('runtime',x.returncode,x.stderr[-2600:],flush=True)
