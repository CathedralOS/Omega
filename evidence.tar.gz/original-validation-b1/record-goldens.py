from pathlib import Path
import json,sys,hashlib,subprocess
sys.path.insert(0,'tools');import corpus_records
r=Path('build/borrowed-cycle-ranks');scope=json.load(open(r/'scope.json'));owned=set(scope['new']);proof=[];observed='5f44e91a12645dc2747474a110d7cbd7860398b1'
def blocks(text):
 out=[]
 for line in text.splitlines(keepends=True):
  if line.startswith('\t') and out and corpus_records.block_fixture([out[-1][0]]):out[-1].append(line)
  else:out.append([line])
 return out
for mode,name in [('source','corpus_outcomes.txt'),('both','corpus_both_macos_arm64.txt')]:
 p=Path('tests/omega')/name;old=p.read_text();rows=[dict(x,recorded_at=observed[:12]) for x in json.load(open(r/(mode+'-observations.json'))) if x['fixture'] in owned];expected=32 if mode=='source' else 13;assert len(rows)==expected
 for row in rows:
  if mode=='source':assert row['status']=='checked' if row['tier']=='pass' else row['status']=='rejected' and row['expected_satisfied'] is True,row
  else:assert row['status']=='built' and row['facts']['exit']=='0' and row['facts']['interpreter-exit']=='0' and row['facts']['interpreter']=='agrees',row
 changed={x['fixture'] for x in rows};prior={x['fixture']:x for x in corpus_records.parse(old)};assert not (changed & prior.keys());new=corpus_records.splice(old,rows);after={x['fixture']:x for x in corpus_records.parse(new)};assert all(after[k]==v for k,v in prior.items());assert [b for b in blocks(new) if corpus_records.block_fixture([b[0]]) not in changed]==blocks(old)
 (r/(name+'.before')).write_text(old);p.write_text(new);proof.append(dict(file=str(p),owned_records=len(rows),preserved_records=len(prior),preserved_raw_blocks=True,before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=hashlib.sha256(new.encode()).hexdigest(),observation_revision=observed))
(r/'golden-content-guard.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
