from pathlib import Path
import sys,json,subprocess,time,hashlib
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/borrowed-cycle-ranks');cli=str((r/'home-retry-producer/omega').resolve());rows=[]
for name in ['local','alias_move','direct_reset','whole_reset','alias_reset','local/invalid','alias_reset_formed']:
 p=r/name;reason,output=accept_review(cli,str(p),'macos_arm64',180);row=dict(name=name,source=str(p/'main.omg'),sha256=hashlib.sha256((p/'main.omg').read_bytes()).hexdigest(),reason=reason,output=output);rows.append(row);(r/'home-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,reason,output[-2500:] if reason else '',flush=True)
 if reason is None and name in ['local','alias_move']:
  cmd=[cli,'run','--both',str(p/'main.omg')];x=subprocess.run(cmd,input='',text=True,capture_output=True,timeout=120);row['runtime']=dict(command=cmd,exit=x.returncode,stdout=x.stdout,stderr=x.stderr);(r/'home-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print('runtime',x.returncode,x.stderr[-3000:],flush=True)
