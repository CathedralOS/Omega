from pathlib import Path
import json
scratch=Path('build/borrowed-cycle-ranks');root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');local=root/'local/borrowed_value';fact=(local/'main.omg').read_text().splitlines()[0]
fragment='no exact private-coordinate assignment proves every edge and complete cycle'
for name in ['alias_move','disjoint_write','nested_record','descriptor_field']:
 p=local/name;(p/'invalid').mkdir(parents=True,exist_ok=True);source=(scratch/name/'main.omg').read_text();assert source.splitlines()[0]==fact
 build=(scratch/name/'build.omg').read_text().replace('joint_rank_projected_value_local','joint_rank_borrowed_'+name)
 (p/'main.omg').write_text(source);(p/'build.omg').write_text(build)
 if name=='alias_move':old,new='alias.count = alias.count - 1;','alias.count = alias.count;'
 elif name=='nested_record':old,new='pending.payload.count = pending.payload.count - 1;','pending.payload.count = pending.payload.count;'
 elif name=='descriptor_field':old,new='pending.values = pending.values[1..];','pending.values = pending.values;'
 else:old,new='pending.count = pending.count - 1;','pending.count = pending.count;'
 assert source.count(old)==1,(name,old)
 (p/'invalid/main.omg').write_text(source.replace(old,new));(p/'invalid/build.omg').write_text(build)
 (p/'invalid/sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=[fragment]),indent=2)+'\n')
 (p/'README.md').write_text(f'''# Borrowed rank composition: {name.replace('_',' ')}

{fact[3:]}

Owner: `NESTED-MACHINE-UNIFICATION`; this is a composition of the
[borrowed-value row](../README.md), with the same seven-step and empty inputs,
counter3→10 and caller-visible original-record/canary checks.
[Positive](main.omg) must agree in native and Terminal execution.
[Twin](invalid/main.omg) removes only descent and must refuse at the joint rank.
''')
 for mode,suffix,content in [('pass','exit',source),('fail','rejected',source.replace(old,new))]:
  dest=Path('tests/omega')/mode/'facts'/('nested_machine_joint_rank_borrowed_'+name+'_'+suffix);dest.mkdir(exist_ok=True);(dest/'main.omg').write_text(content);(dest/'build.omg').write_text(build)
  if mode=='pass':
   for engine in ['native','interpreter']:(dest/('expected_'+engine+'_exit.txt')).write_text('0\n')
  else:(dest/'expected.txt').write_text(fragment+'\n')
for name in ['direct_reset','whole_reset','alias_reset_formed','pointer_reseat']:
 p=root/'controls'/('borrowed_'+name);p.mkdir(parents=True,exist_ok=True);s=(scratch/name/'main.omg').read_text();b=(scratch/name/'build.omg').read_text().replace('joint_rank_projected_value_local','joint_rank_borrowed_'+name)
 (p/'main.omg').write_text(s);(p/'build.omg').write_text(b);(p/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=[fragment]),indent=2)+'\n')
 d=Path('tests/omega/fail/facts')/('nested_machine_joint_rank_borrowed_'+name+'_rejected');d.mkdir(exist_ok=True);(d/'main.omg').write_text(s);(d/'build.omg').write_text(b);(d/'expected.txt').write_text(fragment+'\n')
