from pathlib import Path
import subprocess,json,time,hashlib
root=Path('build/borrowed-cycle-ranks');cli=str((root/'restored-producer/omega').resolve());rows=[]
sources=sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/borrowed_value/main.omg'))+sorted(p for p in Path('samples/cli/facts/nested_machine_invocation/joint_rank/local/borrowed_value').glob('*/main.omg') if p.parent.name != 'invalid')
for source in sources:
 command=[cli,'run','--both',str(source)];start=time.monotonic();p=subprocess.run(command,input='',text=True,capture_output=True,timeout=180)
 row=dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,elapsed_seconds=time.monotonic()-start);rows.append(row)
 (root/'qualified-samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(source,p.returncode,p.stderr[-500:],flush=True)
 assert p.returncode==0 and 'native exit 0' in p.stderr and 'interp exit: 0' in p.stderr,row
assert len(rows)==13

for place in ['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']:
    sample=Path('samples/cli/facts/nested_machine_invocation/joint_rank')/place/'borrowed_value'
    for mode,child,suffix in [('pass','', 'exit'),('fail','invalid','rejected')]:
        fixture=Path('tests/omega')/mode/'facts'/('nested_machine_joint_rank_borrowed_value_'+place+'_'+suffix)
        assert (sample/child/'main.omg').read_bytes()==(fixture/'main.omg').read_bytes()
