from pathlib import Path
import json,sys,subprocess
sys.path.insert(0,'tools');import corpus_records,corpus_gate
r=Path('build/borrowed-cycle-ranks');mode=sys.argv[1];scope=json.load(open(r/'scope.json'));p=subprocess.run(['python3',str(r/'capture-gate.py'),mode],timeout=1200);comparison=json.load(open(r/(mode+'-compare.json')));assert not comparison['losses'],comparison['losses'];rows=json.load(open(r/(mode+'-observations.json')));assert {x['fixture'] for x in rows}==set(scope[mode]);base={x['fixture']:x for x in corpus_records.read(corpus_gate.baseline_path(scope['base'],'both' if mode=='both' else ''))};new=set(scope['new']);passed=0;inherited=[]
for row in rows:
 old=base.get(row['fixture'])
 if mode=='source':
  okay=row['status']=='rejected' and row['expected_satisfied'] is True if row['tier']=='fail' else row['status']=='checked'
  if not okay:assert row['fixture'] not in new and old and old['status']==row['status'] and old['expected_satisfied']==row['expected_satisfied'],row
 else:
  folder=Path('tests/omega')/row['fixture'];oracle=folder/'expected_native_exit.macos_arm64.txt'
  if not oracle.exists():oracle=folder/'expected_native_exit.txt'
  expected=oracle.read_text().strip() if oracle.exists() else '0';facts=row['facts'];okay=row['status']=='built' and facts.get('exit')==expected and facts.get('interpreter-exit')==expected and facts.get('interpreter')=='agrees'
  if not okay:assert row['fixture'] not in new and old and old['status']==row['status'] and old['facts']==facts,row
 if okay:passed+=1
 else:inherited.append(row);print('Unchanged baseline defect (not a pass):',row,flush=True)
(r/(mode+'-validated.json')).write_text(json.dumps(dict(fixtures=len(rows),authored_oracles_satisfied=passed,inherited_defects=inherited,losses=0),indent=2)+'\n');print('Validated',mode,len(rows),'observations;',passed,'authored oracles satisfied;',len(inherited),'unchanged baseline defects.',flush=True)
