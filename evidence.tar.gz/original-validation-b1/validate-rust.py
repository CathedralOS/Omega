from pathlib import Path
import json,subprocess,time
r=Path('build/borrowed-cycle-ranks')
cmd=['cargo','clippy','--locked','--lib','-p','validation','-p','typed-trees-to-checked-trees','-p','checked-trees','-p','checked-trees-to-lowered-psi','-p','target-operations-to-selected-instructions']
start=time.monotonic()
with(r/'closure-clippy.stdout').open('w') as out,(r/'closure-clippy.stderr').open('w') as err:x=subprocess.run(cmd,stdout=out,stderr=err,timeout=600)
(r/'closure-clippy-command.json').write_text(json.dumps(dict(command=cmd,exit=x.returncode,elapsed_seconds=time.monotonic()-start),indent=2)+'\n');print('clippy',x.returncode,round(time.monotonic()-start,2),flush=True);assert x.returncode==0
files=subprocess.check_output(['git','diff','--name-only','6465dca654f09c65a88454cb260d6ccc2b5bee82','HEAD','--','*.rs'],text=True).splitlines()
# Formatting root-owned edited sources only; imported current-main files were validated by their lanes.
owned=[f for f in files if Path(f).is_file()]
x=subprocess.run(['rustfmt','--check','--edition','2024','--config','skip_children=true',*owned],capture_output=True,text=True,timeout=60);(r/'closure-format.stdout').write_text(x.stdout);(r/'closure-format.stderr').write_text(x.stderr);print('format',x.returncode,len(owned),flush=True);assert x.returncode==0

cmd=['cargo','test','--locked','-p','validation','--lib','summary_windows::tests','--','--nocapture']
start=time.monotonic()
with(r/'window-unit.stdout').open('w') as out,(r/'window-unit.stderr').open('w') as err:x=subprocess.run(cmd,stdout=out,stderr=err,timeout=900)
(r/'window-unit-command.json').write_text(json.dumps(dict(command=cmd,exit=x.returncode,elapsed_seconds=time.monotonic()-start),indent=2)+'\n');print('window unit tests',x.returncode,round(time.monotonic()-start,2),flush=True);assert x.returncode==0

receipt=json.loads((r/'restoration-unit-command.json').read_text())
assert receipt['exit']==0 and receipt['revision']=='b1fb01ab0a2d96520cf9cd1f6ac49a79f4be05d4'
assert '3 passed; 0 failed' in (r/'restoration-unit.stdout').read_text()
print('Retained exact-candidate restoration unit execution:3passed,0failed',flush=True)
