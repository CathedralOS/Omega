from pathlib import Path
import json,sys,subprocess
sys.path.insert(0,'tools');import corpus_records,corpus_gate
r=Path('build/borrowed-cycle-ranks');base='6465dca654f09c65a88454cb260d6ccc2b5bee82';old=Path('build/descriptor-cycle-ranks/integrated-validation');state=json.loads(Path('build/descriptor-cycle-ranks/qualification.json').read_text())
pro=json.loads(Path('build/descriptor-cycle-ranks/integrated-producer/corpus-producer.json').read_text());assert pro['revision']==base
seed=[]
for mode in ['source','both']:
 run=[x for x in state['runs'] if x['revision']==base and x['check']==mode][-1]
 rows=json.loads((old/(mode+'-observations.json')).read_text());cache=corpus_gate.baseline_path(base,'both' if mode=='both' else '')
 prior={x['fixture']:x for x in corpus_records.read(cache)} if cache.exists() else {}
 for row in rows:
  assert row.get('recorded_at') in [None,base[:12]]
  row['recorded_at']=base[:12];prior.setdefault(row['fixture'],row)
 cache.parent.mkdir(exist_ok=True);cache.write_text(corpus_records.render([prior[k] for k in sorted(prior)]));seed.append(dict(mode=mode,rows=len(rows),source=str(old/(mode+'-observations.json')),qualification_run=run['id'],producer=str(Path('build/descriptor-cycle-ranks/integrated-producer/corpus-producer.json')),cache=str(cache),applicability='These are actual exact6465 observations, not executions relabelled from3835. Their qualified producer and captured source revision both equal the current fixed base. Raw records had no Git stamp; cache render adds the observed revision.'))
(r/'baseline-cache-seed.json').write_text(json.dumps(seed,indent=2)+'\n')
oldscope=json.loads((old/'scope.json').read_text());names=subprocess.check_output(['git','diff','--name-only',base,'HEAD','--','tests/omega'],text=True).splitlines();new=sorted(set('/'.join(x.split('/')[2:5]) for x in names));source=set(new)
for f in oldscope['source']:
 if any(w in f for w in ['_local_','mutated_copy','reset_entry','restored_copy','scalar_field_snapshot','later_operand','argument_write','stored_reference_endpoint','runtime_stored_exclusive','nested_borrowed_rank','nested_slice_carrier_borrowed','projected_slice_length']):source.add(f)
for p in Path('tests/omega').glob('*/borrows/*/main.omg'):
 if any(w in p.parent.name for w in ['stored_reference','descriptor_slot','normal_exit','window']):source.add(str(p.parent.relative_to('tests/omega')))
both={x for x in new if x.startswith('pass/')}
for f in source:
 p=Path('tests/omega')/f
 if (p/'expected_interpreter_exit.txt').exists() or f in oldscope['both']:both.add(f)
scope=dict(base=base,new=new,source=sorted(source),both=sorted(both));(r/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');print({k:len(v) if isinstance(v,list) else v for k,v in scope.items()})
for name in ['capture-gate.py','validate-corpus.py','prepare-samples.py','validate-samples.py','validate-rust.py']:
 s=Path('build/descriptor-cycle-ranks',name).read_text().replace('build/descriptor-cycle-ranks','build/borrowed-cycle-ranks')
 if name=='capture-gate.py':s=s.replace('build/projected-cycle-ranks/integrated-producer/corpus_runner','build/descriptor-cycle-ranks/integrated-producer/corpus_runner')
 if name in ['prepare-samples.py','validate-samples.py']:
  s=s.replace('*/descriptor_field/main.omg','*/borrowed_value/main.omg').replace('local/descriptor_field','local/borrowed_value').replace('assert len(rows)==12','assert len(rows)==13')
 if name=='validate-rust.py':s=s.replace('3835b27b7784b496536837cd2b02698795eefa7e',base).replace("'-p','checked-trees'","'-p','checked-trees','-p','checked-trees-to-lowered-psi'")
 (r/name).write_text(s)
