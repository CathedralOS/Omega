from pathlib import Path
import subprocess,json,time
r=Path('build/borrowed-cycle-ranks');cmd=[str((r/'home-retry-producer/omega').resolve()),'update','--project',str(r/'descriptor_field'),'--target','macos_arm64'];start=time.monotonic()
with (r/'descriptor-profile.stdout').open('w') as out,(r/'descriptor-profile.stderr').open('w') as err:
 p=subprocess.Popen(cmd,stdout=out,stderr=err,stdin=subprocess.DEVNULL);(r/'descriptor-live-process.json').write_text(json.dumps(dict(pid=p.pid,command=cmd,start=time.time()),indent=2)+'\n');print('PID',p.pid,flush=True);code=p.wait()
(r/'descriptor-profile-result.json').write_text(json.dumps(dict(command=cmd,exit=code,seconds=time.monotonic()-start),indent=2)+'\n');print('exit',code,round(time.monotonic()-start,2),flush=True)
