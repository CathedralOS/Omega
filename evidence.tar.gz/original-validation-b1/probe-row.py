from pathlib import Path
import json,sys,subprocess,hashlib
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/borrowed-cycle-ranks');cli=str((r/'home-retry-producer/omega').resolve());rows=[]
for source in sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/borrowed_value/main.omg')):
 reason,out=accept_review(cli,str(source.parent),'macos_arm64',180);row=dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),reason=reason,output=out);rows.append(row);(r/'row-prototype-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(source.parent.parent.name,reason,out[-2200:] if reason else '',flush=True)
 if reason is None:
  x=subprocess.run([cli,'run','--both',str(source)],input='',text=True,capture_output=True,timeout=180);row['runtime']=dict(exit=x.returncode,stdout=x.stdout,stderr=x.stderr);(r/'row-prototype-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print('runtime',x.returncode,x.stderr[-2600:],flush=True)
