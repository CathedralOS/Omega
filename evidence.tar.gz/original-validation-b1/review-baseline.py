import json,hashlib
from pathlib import Path
rows=json.load(open("build/borrowed-cycle-ranks/baseline.json"));assert len(rows)==2
for x in rows:
 assert hashlib.sha256(Path(x["source"]).read_bytes()).hexdigest()==x["sha256"]
 assert x["reason"]=="review-failed" and "a member lacks a supported exact ranking witness" in x["output"]
print("Valid borrowed-record rank refuses; no-descent twin refuses. Neither is runtime acceptance.")
