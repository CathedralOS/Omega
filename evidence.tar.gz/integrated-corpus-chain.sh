set -eu
bash build/joint-lexicographic/integrated-corpus.sh
python3 build/joint-lexicographic/integrated-long-cycle.py
