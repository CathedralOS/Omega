from pathlib import Path
import tarfile,hashlib,subprocess,json,os
r=Path('build/projected-cycle-ranks');public=r/'public-evidence';public.mkdir(exist_ok=True)
paths=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.bundle','.txt','.omg']]
for folder in ['prototype-producer','corpus-producer','integrated-producer','integrated-validation','qualification.records']:
 paths += [p for p in (r/folder).iterdir() if p.is_file() and p.suffix in ['.json','.stdout','.stderr']]
paths+=list((r/'local').glob('*.omg'))+list((r/'local/invalid').glob('*.omg'))+list((r/'baseline-row').glob('**/*.omg'))
archive=public/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 for suffix in ['', '-both']:
  p=Path('build/corpus_baselines')/('4bf998b1c43499afb1f5238e183a41ea3488d886'+suffix+'.txt');tar.add(p,arcname='baseline/'+p.name)
 for name in ['cli','corpus']:tar.add('build/ranged-cycle-ranks/integrated-producer/'+name+'-producer.json',arcname='baseline/'+name+'-producer.json')
(public/'README.md').write_text("""# Projected private-rank execution evidence

Submitted integrated source and optimized producer3835b27b7784b496536837cd2b02698795eefa7e. Actual PR759 conflicts against9008a382ee4 required source integration. The resolution preserves incoming completed-remainder evidence through the existing current-value owner and keeps all incoming float, selected-exit, arithmetic and allocation repairs. Fresh integrated-validation/ observations remain distinct from historical observations at82c75bb805841c243362312ba954f68342276bd5 (CLI21cbf0f9, corpus5b5c0b2) and metadata checkpoint9af85cb9.

The archive contains frozen refusal evidence and hashes, canonical excerpts, source bundles, exact validators, build/provenance/profile receipts,216original and220integrated source comparisons (no losses),36original and39integrated native/Terminal authored agreements (including legacy70),11sample agreements, and independent semantic/metadata reuse reviews. Inherited source defects remain explicitly unclosed. Only macOS ARM64 has native execution evidence. Own24source and11BOTH golden rows retain their original observation identities; all unrelated incoming records remain preserved.

Rebuild with the pinned toolchain and optimized profile. Replay samples/cli/facts/nested_machine_invocation/joint_rank/*/projected_value/main.omg and local nested_record/mutated_copy with omega run --both. Generate ordinary fresh package approval; retained approvals grant no authority elsewhere. integrated-validation/scope.json identifies the focused220/39consumer set including three incoming remainder positives and their invalid twin. The fixed original basebc460 is tree-identical to immutable baseline producer4bf998; the baseline library is pinned to its compared checkout if execution is needed, and retained complete baseline caches retain their authentic observations. Source bundles and build receipts permit rebuilding; binaries remain immutable in the workbench. The parent task remains open for descriptor fields, borrowed/indexed/case projections, declared views, dependent distances and other acceptance.
""")
(public/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
index=r/'evidence.index';env=dict(os.environ,GIT_INDEX_FILE=str(index.resolve()));subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for p in sorted(public.iterdir()):
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p.name],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();previous=r/'published-evidence.json';parents=['-p',json.load(open(previous))['commit']] if previous.exists() else [];commit=subprocess.check_output(['git','commit-tree',tree,*parents],input='psi: preserve projected private-rank execution evidence\n',text=True).strip();subprocess.run(['git','push','origin',commit+':refs/heads/evidence/private-projected-ranks'],check=True);previous.write_text(json.dumps(dict(commit=commit,url='https://github.com/CathedralOS/Omega/tree/'+commit,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size),indent=2)+'\n');print(commit,archive.stat().st_size)
