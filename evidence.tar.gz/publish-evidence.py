from pathlib import Path
import tarfile,hashlib,subprocess,json,os
r=Path('build/descriptor-cycle-ranks');public=r/'public-evidence';public.mkdir(exist_ok=True);head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();bundle=r/('source-'+head[:12]+'.bundle')
if not bundle.exists():subprocess.run(['git','bundle','create',str(bundle),'HEAD','^3835b27b7784b496536837cd2b02698795eefa7e'],check=True)
archive=public/'evidence.tar.gz';paths=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.bundle','.txt','.stdout','.stderr','.before'] and not p.name.startswith('next-')]
for folder in ['producer','fixed-producer','final-producer','integrated-producer','integrated-validation','original-sample-locks','qualification.records']:
 paths += [p for p in (r/folder).glob('*') if p.is_file() and (p.suffix in ['.json','.stdout','.stderr','.py'] or folder=='original-sample-locks')]
for folder in ['local','reset-call','element_write','mutable_no_store','payload_shared_rank','fresh-replay','wrong-payload-expectation']:
 paths += list((r/folder).glob('*.omg'))
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 for suffix in ['', '-both']:
  p=Path('build/corpus_baselines')/('3835b27b7784b496536837cd2b02698795eefa7e'+suffix+'.txt');tar.add(p,arcname='baseline/'+p.name)
 for label in ['cli','corpus']:tar.add('build/projected-cycle-ranks/integrated-producer/'+label+'-producer.json',arcname='baseline/'+label+'-producer.json')
 for mode in ['source','both']:tar.add('build/projected-cycle-ranks/integrated-validation/'+mode+'-observations.json',arcname='baseline/original-'+mode+'-observations.json')
state=json.load(open(r/'qualification.json'))
(public/'README.md').write_text(f"""# Private descriptor-field rank evidence

Submitted source and optimized integrated producer {head}, resolving actual PR765 conflicts against main9fb1e5715f05736a5a1c5af7e1b9b92b8edb59a0. All six owner Rust files are byte-identical to independently acceptedb4799756; every incoming history record is preserved. Original b479 observations remain distinct from fresh integrated-validation results. Qualification revision{state['revision']} preserves both histories and immutable receipts. Original fixed source baseline3835b27b7784b496536837cd2b02698795eefa7e is PR759's head, fetchable as refs/pull/759/head; its source ancestry differs from squash publication. Source bundles retain both original and integrated candidates.

Fresh integrated qualification:255source observations,222authored oracles satisfied,33unchanged baseline defects,zero losses.54native/Terminal observations include53authored agreements and one inherited unsupported provider refusal; all12new positives execute0. Twelve CLI programs agree at0: nine descriptor-field transport places plus nested record, moved copy and mutable payload composition. Fourteen new controls reject at the intended cycle obligation. Three affected crates pass Clippy and six owner Rust files pass formatting. Fresh independent project replay exits0; changing one expected byte yields native signal5 and Terminal Trap with host presentation agreement. Only macOS ARM64 execution was observed.

The archive retains frozen refusals, original inference and extent-dependency prototypes, canonical passages, original/integrated optimized build/profile receipts, validators and raw observations, fixed-base caches/provenance, qualification receipts, independent static reviews and golden content guards. All26source and12runtime history rows retain their actual original b479observation identity; fresh integration corroborates them without relabeling. Exploratory reset-call failures are not counted as clean rejection evidence. Retired binary artifacts have SHA-verified compressed recovery archives locally; binaries are rebuilt with the pinned optimized toolchain for replay. Original accepted sample locks are preserved as historical artifacts; acquire ordinary new consent in another project/checkout. Parent nested-machine and other-host acceptance remain open.
""")
(public/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n');env=dict(os.environ,GIT_INDEX_FILE=str((r/'evidence.index').resolve()));subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for p in sorted(public.iterdir()):
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p.name],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();old=r/'published-evidence.json';parents=['-p',json.load(open(old))['commit']] if old.exists() else [];commit=subprocess.check_output(['git','commit-tree',tree,*parents],input='psi: preserve private descriptor-rank execution evidence\n',text=True).strip();subprocess.run(['git','push','origin',commit+':refs/heads/evidence/private-descriptor-ranks'],check=True);old.write_text(json.dumps(dict(commit=commit,url='https://github.com/CathedralOS/Omega/tree/'+commit,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size),indent=2)+'\n');print(commit,archive.stat().st_size)
