from pathlib import Path
import tarfile,hashlib,subprocess,json,os
r=Path('build/private-cycle-ranks');public=r/'public-evidence';public.mkdir(exist_ok=True)
paths=[p for p in r.iterdir() if p.is_file() and (p.suffix in ['.json','.py','.log','.bundle'] or p.name=='pr-body.md')]
for folder in ['base-producer','candidate-producer','qualification.records']:
 paths += [p for p in (r/folder).iterdir() if p.is_file() and p.suffix in ['.json','.stdout','.stderr']]
paths += list((r/'slice-rank').glob('**/*.omg'))
archive=public/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
(public/'README.md').write_text('''# PR744 execution evidence

Source head bd57535230243699e595f565e84d75fa19be881d; exact optimized producer e3c13ae2455c62f31486b028dab0fd6705ab6c4e; fixed base9a4ec4a40c352ea4eb51f49f2d23ee03e3e3a78e.

The archive contains qualification state/immutable receipts and raw streams, baseline comparisons, canonical excerpts, build provenance, exact validators, measured fixture outcomes and a Git source bundle. Failed setup/harness attempts remain distinct from accepted observations. Seven inherited defects remain red. Binaries are retained in the workbench; the source bundle and build receipts permit rebuilding without trusting them.

Apply source.bundle to a clone containing the fixed base. Build with the pinned toolchain and optimized profile (`cargo build --locked -p omega --bin omega`; use mbx if available). Generate ordinary fresh package acceptance rather than copying this machine's approval state. The core witnesses are `samples/cli/facts/nested_machine_invocation/joint_rank/*/structural_view/main.omg`, each run with `omega run --both`. The retained scope.json names the focused43-source/25-realization corpus checks. Only macOS ARM64 native execution is observed.
''')
(public/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
index=r/'evidence.index';env=dict(os.environ,GIT_INDEX_FILE=str(index.resolve()))
subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for p in sorted(public.iterdir()):
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p.name],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',json.loads((r/'published-evidence.json').read_text())['commit']],input='evidence: private structural rank execution for PR744\n',text=True).strip()
subprocess.run(['git','push','origin',commit+':refs/heads/evidence/pr744'],check=True)
(r/'published-evidence.json').write_text(json.dumps(dict(commit=commit,url='https://github.com/CathedralOS/Omega/tree/'+commit,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size),indent=2)+'\n');print(commit,archive.stat().st_size)
