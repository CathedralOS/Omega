from pathlib import Path
import hashlib, json, os, subprocess, tarfile

root = Path('build/borrowed-cycle-ranks')
integrated = root / 'integrated-validation'
public = root / 'public-evidence'
public.mkdir(exist_ok=True)
state = json.loads((root / 'qualification.json').read_text())
head = json.loads((root / 'actual-integration.json').read_text())['integrated']
base = '6465dca654f09c65a88454cb260d6ccc2b5bee82'
source = json.loads((integrated / 'source-validated.json').read_text())
both = json.loads((integrated / 'both-validated.json').read_text())
samples = json.loads((integrated / 'qualified-samples.json').read_text())
assert len(samples) == 13
latest = {}
for run in state['runs']:
    latest[run['check']] = run
assert all(run['exit'] == 0 and not run['invalidations'] for run in latest.values())
bundle = root / ('source-' + head[:12] + '.bundle')
source_ref = 'refs/corpus-observations/' + head
subprocess.run(['git', 'update-ref', source_ref, head], check=True)
if bundle.exists() and bundle.stat().st_size == 0:
    bundle.unlink()
if not bundle.exists():
    subprocess.run(['git', 'bundle', 'create', str(bundle), source_ref, '^' + base], check=True)
paths = [p for p in root.iterdir() if p.is_file() and p.suffix in {
    '.json', '.py', '.bundle', '.txt', '.stdout', '.stderr', '.before', '.md'
} and p.name != 'published-evidence.json']
for folder in [
    'final-producer', 'restored-producer', 'integrated-producer',
    'integrated-validation', 'pre-custody-validation', 'original-validation-b1',
    'qualification.records',
]:
    paths.extend(p for p in (root / folder).glob('*') if p.is_file()
        and p.suffix in {'.json', '.py', '.stdout', '.stderr'}
        and not (folder in {'pre-custody-validation', 'original-validation-b1'}
            and p.name == 'qualification.json'))
for folder in [
    'local', 'alias_move', 'descriptor_field', 'direct_reset', 'whole_reset',
    'alias_reset_formed', 'pointer_reseat', 'erased_descriptor',
    'erased_intermediate',
]:
    paths.extend((root / folder).glob('*.omg'))
archive = public / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(set(paths)):
        tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
    for suffix in ['', '-both']:
        path = Path('build/corpus_baselines') / (base + suffix + '.txt')
        tar.add(path, arcname='baseline/' + path.name)
    for label in ['cli', 'corpus']:
        path = Path('build/descriptor-cycle-ranks/integrated-producer') / (label + '-producer.json')
        tar.add(path, arcname='baseline/' + path.name)
    for mode in ['source', 'both']:
        path = Path('build/descriptor-cycle-ranks/integrated-validation') / (mode + '-observations.json')
        tar.add(path, arcname='baseline/original-' + mode + '-observations.json')
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
(public / 'README.md').write_text(f'''# Borrowed record rank evidence

Exact integrated source/optimized producer: `{head}`. Fixed author source base:
`{base}` (PR765 source head, distinct from its squash publication). Fetch the
base with `git fetch origin refs/pull/765/head`, then import the included
incremental source bundle. Final source is also retained under
`refs/corpus-observations/{head}`. Rebuild with the pinned optimized toolchain
and obtain ordinary package consent in a fresh authored-input project.

The nine borrowed-value places and four local compositions run native and
Terminal exit0, with original caller-visible count, descriptor, counter and
canary checks. Thirteen positive and nineteen rejecting corpus fixtures pin
these programs. Seventeen reject controls fail the rank obligation; two reject
erased runtime storage. Fresh independent replay succeeds; changing the expected
writeback gives native signal5 and Terminal Trap with agreeing host presentation.

Fresh integrated source: {source['fixtures']} observations,
{source['authored_oracles_satisfied']} authored oracles,
{len(source['inherited_defects'])} unchanged baseline issues, zero losses.
Fresh native/Terminal corpus: {both['fixtures']} observations,
{both['authored_oracles_satisfied']} authored agreements,
{len(both['inherited_defects'])} unchanged baseline issues, zero losses.
All13 new positive programs agree at0. Five affected crates pass Clippy,
17 owned Rust files pass formatting, and six focused unit tests pass.
Only macOS ARM64 execution is observed. Other hosts and remaining parent
NESTED-MACHINE-UNIFICATION acceptance remain open.

Historical5f source acceptance is distinct from its failed alias-move native
receiver check; that failure was repaired, never waived. Fully qualifiedb1
results and dirty exploratory diagnostics retain their actual identities.
Three demonstrated text conflicts were resolved against pinned incoming3ef;
all17 owner Rust files stayed byte-identical to b1. Incoming source-graph and
length-query changes received fresh integrated acceptance. The archive contains
canonical context, actual producer/profile/digest receipts, original frozen
refusals, validators, qualification receipts, engine observations, fixed-base
cache lineage, and the golden content guard. Binaries are reproducible from the
source bundle; superseded local binary archives retain SHA-verified recovery
metadata and are not shipped here. No historical observation is relabelled as
an execution of the final metadata-only history commit.
''')
(public / 'SHA256SUMS').write_text(sha + '  evidence.tar.gz\n')
index = root / 'evidence.index'
env = dict(os.environ, GIT_INDEX_FILE=str(index.resolve()))
subprocess.run(['git', 'read-tree', '--empty'], env=env, check=True)
for path in sorted(public.iterdir()):
    blob = subprocess.check_output(['git', 'hash-object', '-w', str(path)], text=True).strip()
    subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644', blob, path.name], env=env, check=True)
tree = subprocess.check_output(['git', 'write-tree'], env=env, text=True).strip()
record = root / 'published-evidence.json'
parents = ['-p', json.loads(record.read_text())['commit']] if record.exists() else []
commit = subprocess.check_output(['git', 'commit-tree', tree, *parents], input='psi: preserve borrowed record rank execution evidence\n', text=True).strip()
subprocess.run(['git', 'push', 'origin', head + ':refs/corpus-observations/' + head], check=True)
subprocess.run(['git', 'push', 'origin', commit + ':refs/heads/evidence/borrowed-private-ranks'], check=True)
record.write_text(json.dumps(dict(commit=commit, url='https://github.com/CathedralOS/Omega/tree/' + commit, archive_sha256=sha, bytes=archive.stat().st_size), indent=2) + '\n')
print(commit, archive.stat().st_size)
