from pathlib import Path
import tarfile,hashlib,subprocess,json,os
r=Path('build/projected-cycle-ranks');public=r/'public-evidence';public.mkdir(exist_ok=True)
paths=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.bundle','.txt','.omg']]
for folder in ['prototype-producer','corpus-producer','qualification.records']:
 paths += [p for p in (r/folder).iterdir() if p.is_file() and p.suffix in ['.json','.stdout','.stderr']]
paths+=list((r/'local').glob('*.omg'))+list((r/'local/invalid').glob('*.omg'))+list((r/'baseline-row').glob('**/*.omg'))
archive=public/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 for suffix in ['', '-both']:
  p=Path('build/corpus_baselines')/('4bf998b1c43499afb1f5238e183a41ea3488d886'+suffix+'.txt');tar.add(p,arcname='baseline/'+p.name)
 for name in ['cli','corpus']:tar.add('build/ranged-cycle-ranks/integrated-producer/'+name+'-producer.json',arcname='baseline/'+name+'-producer.json')
(public/'README.md').write_text('''# Projected private-rank execution evidence

Submitted source9af85cb9c41c128fbd067289bf7a4ac19d869f51. Actual observations were captured at82c75bb805841c243362312ba954f68342276bd5. CLI producer21cbf0f988b28da80b7a6359ea9501857b11a3c1 and corpus producer5b5c0b2101a48aa4cc5866ff8574368cc39e9cd9 have exactly the current compiler/library/build inputs; verified optimized profiles and actual binary digests are retained. Baseline producer4bf998b1c43499afb1f5238e183a41ea3488d886 is tree-identical to published main basebc460742ba936344495b21c68a8e1640ca91456f. Squash-ancestry conflicts were resolved with the entire candidate tree unchanged; this did not import newer source.

Archive retains the original frozen refusal, eleven exact baseline program hashes, prototype attempts (including malformed aggregate const formation, not counted as valid acceptance), actual216source comparisons (184authored oracles satisfied,32inherited defects,0loss),36native/Terminal authored agreements (35exit0,legacy70),11sample agreements, canonical source passages, validators, immutable qualification receipts and metadata-only reuse review. The24new source and11new BOTH golden additions preserve every prior raw record. Only macOS ARM64 has native execution evidence.

Rebuild with the pinned toolchain and optimized profile. Replay the nine samples/cli/facts/nested_machine_invocation/joint_rank/*/projected_value/main.omg programs and the local nested_record/mutated_copy productions using omega run --both. Recreate ordinary package approval on the replay machine; retained approvals grant no authority elsewhere. scope.json identifies exact source/runtime regression consumers and refused controls. Binaries remain in the workbench; source bundle and build receipts permit rebuilding without trusting them. The parent task remains open for collection descriptor fields, borrowed/indexed/case projections, declared views, dependent distances, and its other acceptance.
''')
(public/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
index=r/'evidence.index';env=dict(os.environ,GIT_INDEX_FILE=str(index.resolve()));subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for p in sorted(public.iterdir()):
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p.name],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();previous=r/'published-evidence.json';parents=['-p',json.load(open(previous))['commit']] if previous.exists() else [];commit=subprocess.check_output(['git','commit-tree',tree,*parents],input='psi: preserve projected private-rank execution evidence\n',text=True).strip();subprocess.run(['git','push','origin',commit+':refs/heads/evidence/private-projected-ranks'],check=True);previous.write_text(json.dumps(dict(commit=commit,url='https://github.com/CathedralOS/Omega/tree/'+commit,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size),indent=2)+'\n');print(commit,archive.stat().st_size)
