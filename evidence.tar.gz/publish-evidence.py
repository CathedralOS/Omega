from pathlib import Path
import tarfile,hashlib,subprocess,json,os
r=Path('build/ranged-cycle-ranks');public=r/'public-evidence';public.mkdir(exist_ok=True)
paths=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.bundle','.txt']]
for folder in ['candidate-producer','final-producer','qualification.records']:
 paths += [p for p in (r/folder).iterdir() if p.is_file() and p.suffix in ['.json','.stdout','.stderr']]
paths+=list((r/'authored-helper').glob('**/*.omg'))
archive=public/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 tar.add('build/corpus_baselines/bd57535230243699e595f565e84d75fa19be881d.txt',arcname='baseline/observations.txt')
 tar.add('build/private-cycle-ranks/candidate-producer/corpus-producer.json',arcname='baseline/producer.json')
(public/'README.md').write_text('''# Private ranged-rank execution evidence

Submitted source b8ad4e63f20e260492fe88c50e422de8196a04d9. Observations were captured at15a66acf6a302237a01ef59563bcacacf5915b0a using optimized producer e559ee8edb43ae92e5ce1b31a7ed51a6991f0bf0. Only corpus golden records changed afterward. Warm comparison base bd57535230243699e595f565e84d75fa19be881d has the same compiler/library/build trees as retained baseline producer e3c13ae2455c62f31486b028dab0fd6705ab6c4e. Canonical authority and original fixed base9a4ec4a40c352ea4eb51f49f2d23ee03e3e3a78e remain unchanged.

Archive includes canonical excerpts, actual192-source comparison (no losses,44gains),19native/Terminal agreements (15new0,3existing0,legacy70),16sample agreements, invalid controls, provenance, qualification state and immutable receipts, independent source-scope review, and Git source bundle. Failed setup/admission captures remain distinct from accepted final observations. The32inherited source defects remain defects. Only macOS ARM64 has native execution evidence.

Rebuild with the pinned toolchain and optimized profile. Generate ordinary fresh package acceptance on the replay machine; retained approvals grant no authority elsewhere. Core witnesses are samples/cli/facts/nested_machine_invocation/joint_rank/*/ranged_value/main.omg, plus six same-fact compositions, run with omega run --both. Source bundle and build receipts permit rebuilding; immutable compiler binaries remain in the workbench and are omitted here.
''')
(public/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
index=r/'evidence.index';env=dict(os.environ,GIT_INDEX_FILE=str(index.resolve()))
subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for p in sorted(public.iterdir()):
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p.name],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree],input='psi: preserve ranged private-cycle execution evidence\n',text=True).strip()
subprocess.run(['git','push','origin',commit+':refs/heads/evidence/private-ranged-ranks'],check=True)
(r/'published-evidence.json').write_text(json.dumps(dict(commit=commit,url='https://github.com/CathedralOS/Omega/tree/'+commit,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size),indent=2)+'\n');print(commit,archive.stat().st_size)
