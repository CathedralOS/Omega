from pathlib import Path
import tarfile,hashlib,subprocess,json,os
r=Path('build/descriptor-cycle-ranks');public=r/'public-evidence';public.mkdir(exist_ok=True);head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();bundle=r/('source-'+head[:12]+'.bundle')
if not bundle.exists():subprocess.run(['git','bundle','create',str(bundle),'HEAD','^3835b27b7784b496536837cd2b02698795eefa7e'],check=True)
archive=public/'evidence.tar.gz';paths=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.bundle','.txt','.stdout','.stderr','.before']]
for folder in ['producer','fixed-producer','final-producer','qualification.records']:
 paths += [p for p in (r/folder).glob('*') if p.is_file() and p.suffix in ['.json','.stdout','.stderr']]
for folder in ['local','reset-call','element_write','mutable_no_store','payload_shared_rank','fresh-replay','wrong-payload-expectation']:
 paths += list((r/folder).glob('*.omg'))
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 for suffix in ['', '-both']:
  p=Path('build/corpus_baselines')/('3835b27b7784b496536837cd2b02698795eefa7e'+suffix+'.txt');tar.add(p,arcname='baseline/'+p.name)
 for label in ['cli','corpus']:tar.add('build/projected-cycle-ranks/integrated-producer/'+label+'-producer.json',arcname='baseline/'+label+'-producer.json')
 for mode in ['source','both']:tar.add('build/projected-cycle-ranks/integrated-validation/'+mode+'-observations.json',arcname='baseline/original-'+mode+'-observations.json')
(public/'README.md').write_text(f'''# Private descriptor-field rank evidence

Submitted source {head}; optimized CLI and corpus producerb4799756ea9cd4efa3d636f5174aebfa8fb7848d. The final commit only adds26source and12native/Terminal history rows. All compiler/library/program/oracle trees are identical to the qualified checkpoint. Qualification revision11 reuses four unchanged check closures without relabeling the original runs. Fixed baseline3835b27b7784b496536837cd2b02698795eefa7e is PR759's source head, fetchable as refs/pull/759/head. The source bundle adds this change to that base.

All12new positives execute0 in native and Terminal on macOS ARM64: nine descriptor-field transport places, nested record, moved copy and mutable payload composition. All14new rejects reach the private-cycle obligation. Focused255source observations have222satisfied authored oracles and33unchanged baseline defects;54native/Terminal observations have53authored agreements and one inherited unsupported provider refusal. Neither inherited defects nor other-host execution count as acceptance. Three affected crates pass Clippy and six changed Rust sources pass formatting. A fresh independent project executes0; changing one expected byte produces native signal5 and Terminal Trap with host presentation agreement.

The archive retains frozen preimplementation refusals, original inference and extent-dependency prototypes, canonical passages, immutable producer/profile/build receipts, exact validators and raw engine observations, fixed-base caches/provenance, qualification receipts, source-only review, and raw-content golden guards. The temporary trace build is diagnostic evidence only. Superseded binary archives are local recovery state, not new producers. The exploratory reset-call project still has independent post-storage/window refusals and is not counted as a validated reject control. Rebuild with the pinned toolchain and optimization; acquire ordinary fresh per-project package consent. Historical accepted locks grant no authority in another checkout. The product and remaining nested-machine capability requirements stay open.
''')
(public/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n');env=dict(os.environ,GIT_INDEX_FILE=str((r/'evidence.index').resolve()));subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for p in sorted(public.iterdir()):
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p.name],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();old=r/'published-evidence.json';parents=['-p',json.load(open(old))['commit']] if old.exists() else [];commit=subprocess.check_output(['git','commit-tree',tree,*parents],input='psi: preserve private descriptor-rank execution evidence\n',text=True).strip();subprocess.run(['git','push','origin',commit+':refs/heads/evidence/private-descriptor-ranks'],check=True);old.write_text(json.dumps(dict(commit=commit,url='https://github.com/CathedralOS/Omega/tree/'+commit,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size),indent=2)+'\n');print(commit,archive.stat().st_size)
