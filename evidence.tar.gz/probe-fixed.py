from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/descriptor-cycle-ranks');cli=str((r/'fixed-producer/omega').resolve());rows=[]
for name in ['mutated_copy','restored_copy','nested_record','element_write','wrong-field','reset-call']:
 p=r/name;reason,output=accept_review(cli,str(p),'macos_arm64',180);row=dict(name=name,source=str(p/'main.omg'),sha256=hashlib.sha256((p/'main.omg').read_bytes()).hexdigest(),reason=reason,output=output);rows.append(row);(r/'fixed-control-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,reason,output[-2200:] if reason else '',flush=True)
 if reason is None and name in ['mutated_copy','nested_record','element_write']:
  x=subprocess.run([cli,'run','--both',str(p/'main.omg')],input='',text=True,capture_output=True,timeout=120);row['runtime']=dict(exit=x.returncode,stdout=x.stdout,stderr=x.stderr);(r/'fixed-control-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print('runtime',x.returncode,x.stderr[-2500:],flush=True)
