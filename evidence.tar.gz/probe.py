from pathlib import Path
import sys,json,subprocess,hashlib,time
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/descriptor-cycle-ranks');cli=str((r/'producer/omega').resolve());rows=[]
paths=[r/'reset-call/main.omg']+sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/descriptor_field/main.omg'))
for p in paths:
 start=time.monotonic();reason,output=accept_review(cli,str(p.parent),'macos_arm64',180);row=dict(source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),reason=reason,output=output,seconds=time.monotonic()-start);rows.append(row);(r/'prototype-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(p,reason,output[-2200:] if reason or 'reset-call' in str(p) else '',flush=True)
 if reason is None and 'reset-call' not in str(p):
  x=subprocess.run([cli,'run','--both',str(p)],input='',text=True,capture_output=True,timeout=120);row['runtime']=dict(exit=x.returncode,stdout=x.stdout,stderr=x.stderr);(r/'prototype-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print('runtime',x.returncode,x.stderr[-2200:],flush=True)
