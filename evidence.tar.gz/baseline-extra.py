from pathlib import Path
import subprocess,json,sys
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/private-cycle-ranks');cli=str((r/'base-producer/omega').resolve());rows=[]
for fixture in ['pass/termination/runtime_nested_borrowed_rank_carrier_exit','fail/termination/rank_arrival_missing_public_result_field_equation','fail/termination/rank_arrival_unrelated_field_step']:
 source=Path('tests/omega')/fixture/'main.omg';reason,output=accept_review(cli,str(source.parent),'macos_arm64',180);row=dict(fixture=fixture,review_reason=reason,review_output=output)
 if reason is None:
  cmd=[cli,'--check',str(source)];p=subprocess.run(cmd,input='',text=True,capture_output=True,timeout=180);row.update(command=cmd,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
 rows.append(row);(r/'baseline-extra.json').write_text(json.dumps(rows,indent=2)+'\n');print(fixture,row,flush=True)
