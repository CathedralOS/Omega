from pathlib import Path
import sys,json,hashlib,shutil
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/borrowed-cycle-ranks');cli=str(Path('build/descriptor-cycle-ranks/integrated-producer/omega').resolve());rows=[]
for source in sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/borrowed_value/main.omg')):
 p=r/'baseline-row'/source.parent.parent.name;p.mkdir(parents=True,exist_ok=True)
 for name in ['main.omg','build.omg']:shutil.copy2(source.parent/name,p/name)
 reason,out=accept_review(cli,str(p),'macos_arm64',180);row=dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),replay=str(p),reason=reason,output=out,producer='6465dca654f09c65a88454cb260d6ccc2b5bee82');rows.append(row);(r/'baseline-row.json').write_text(json.dumps(rows,indent=2)+'\n');print(source.parent.parent.name,reason,out[-1600:] if '1 diagnostic(s)' not in out else '',flush=True)
