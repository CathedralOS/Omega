from pathlib import Path
import json,subprocess,sys
root=Path('build/private-cycle-ranks');scope=json.loads((root/'scope.json').read_text());mode=sys.argv[1]
command=['python3','tools/corpus_gate.py','--runner',str((root/'candidate-producer/corpus_runner').resolve()),'--filter',scope['filters'],'--json',str(root/('qualified-corpus-'+mode+'.json'))]
if mode=='both':command+=['--both']
p=subprocess.run(command,stdin=subprocess.DEVNULL,text=True,capture_output=True,timeout=900)
(root/('qualified-corpus-'+mode+'.stdout')).write_text(p.stdout);(root/('qualified-corpus-'+mode+'.stderr')).write_text(p.stderr)
print('corpus',mode,'exit',p.returncode,p.stdout[-7000:],p.stderr[-2500:],flush=True)
report=json.loads((root/('qualified-corpus-'+mode+'.json')).read_text())
assert report['infrastructure_error'] is None,report['infrastructure_error']
rows=report['observations'];expected={x.removeprefix('tests/omega/') for x in scope['new']+scope['regressions'] if mode!='both' or '/pass/' in x}
assert {x['fixture'] for x in rows}==expected,(len(rows),len(expected))
for row in rows:
 if row['fixture'] in scope['inherited_invalid_acceptance']:
  assert row['status']=='checked',row
  print('Unchanged invalid acceptance (still a defect):',row['fixture'],flush=True)
  continue
 if row['fixture'] in scope['inherited_incomplete']:
  assert row['status'] in ['incomplete','unimplemented','rejected'],row
  assert scope['inherited_incomplete'][row['fixture']] in '\n'.join(row['diagnostics']),row
  print('Unchanged incomplete lowering:',row['fixture'],flush=True)
  continue
 if row['fixture'] in scope['inherited_refusals']:
  assert row['status'] in ['rejected','unimplemented'],row
  assert scope['inherited_refusals'][row['fixture']] in '\n'.join(row['diagnostics']),row
  print('Unchanged baseline refusal:',row['fixture'],flush=True)
  continue
 if row['tier']=='fail':
  assert row['status']=='rejected' and row['expected_satisfied'] is True,row
 else:
  assert row['status'] in (['built','checked'] if mode=='both' else ['checked']),row
  if mode=='both' and any((Path('tests/omega')/row['fixture']/name).exists() for name in ['expected_native_exit.txt','expected_interpreter_exit.txt']):
   assert row['facts'].get('exit')=='0' and row['facts'].get('interpreter-exit')=='0' and row['facts'].get('interpreter')=='agrees',row
for failure in report['oracle_failures']:
 assert any(fixture in str(failure) for fixture in list(scope['inherited_refusals'])+list(scope['inherited_incomplete'])),failure
print('Validated',len(rows),'actual fixture outcomes; golden differences are reported separately.',flush=True)
