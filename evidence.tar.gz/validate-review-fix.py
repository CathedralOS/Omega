from pathlib import Path
import os,json,subprocess,time,hashlib
root=Path.cwd();b=root/'build/joint-lexicographic';producer=json.loads((b/'review-fix-producer/producer.json').read_text());assert hashlib.sha256(Path(producer['executable']).read_bytes()).hexdigest()==producer['sha256'];base=Path('samples/cli/facts/nested_machine_lexicographic_rank');rows=[]
for place in ['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']:
 src=base/place;rows.extend([(place,src/'main.omg',None),(place+' invalid',src/'invalid/main.omg','a preserving cycle has no strict measure DECREASE')])
rows.append(('frozen probe',base/'parameter/probe/main.omg',None))
for name,reason in [('self_alias',None),('negative_prefix',None),('scalar_return',None),('negative_preserving','a preserving cycle has no strict measure DECREASE'),('reset_without_outer_decrease','captured ranks do not prove lexicographic nonincrease'),('unsafe_suffix','construction of `Progress` field `inner` may overflow')]:rows.append((name,base/'controls'/name/'main.omg',reason))
for name,source in [('signed neighbor','samples/cli/facts/nested_machine_signed_rank/parameter/main.omg'),('signed no range','samples/cli/facts/nested_machine_signed_rank/controls/no_authored_range/main.omg'),('unsigned neighbor','samples/cli/facts/nested_machine_invocation/joint_rank/local/main.omg')]:rows.append((name,Path(source),None))
results=[]
for name,source,reason in rows:
 cmd=[producer['executable'],*(['--check'] if reason else ['run','--both']),str(source)];start=time.monotonic();o=subprocess.run(cmd,capture_output=True,text=True,timeout=120,env=dict(os.environ,OMEGA_LIBRARY_ROOT=str(root/'source/library')));r=dict(name=name,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),expected_rejection=reason,command=cmd,exit=o.returncode,stdout=o.stdout,stderr=o.stderr,seconds=time.monotonic()-start);results.append(r);(b/'review-fix-row.json').write_text(json.dumps(dict(producer=producer,results=results),indent=2)+'\n');print(name,o.returncode,flush=True)
 if reason:assert o.returncode==1 and reason in o.stderr,r
 else:assert o.returncode==0 and 'native exit 0' in o.stderr and 'interp exit: 0' in o.stderr,r
assert len(results)==28
print('16sampleBOTH0;12intendedrefusals')
