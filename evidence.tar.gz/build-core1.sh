set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/moving-upper/core1-build.jsonl 2> build/moving-upper/core1-build.stderr
python3 build/moving-upper/capture-core1.py
python3 build/moving-upper/probe-core1.py
