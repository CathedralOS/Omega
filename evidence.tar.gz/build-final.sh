set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/cross-carrier-rank/final-cli-build.jsonl 2> build/cross-carrier-rank/final-cli-build.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/cross-carrier-rank/final-corpus-build.jsonl 2> build/cross-carrier-rank/final-corpus-build.stderr
