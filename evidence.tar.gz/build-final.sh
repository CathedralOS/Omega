set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/joint-lexicographic/final-cli-build.jsonl 2> build/joint-lexicographic/final-cli-build.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/joint-lexicographic/final-corpus-build.jsonl 2> build/joint-lexicographic/final-corpus-build.stderr
cargo test --locked -p terminal-codec rank_tuple -- --nocapture > build/joint-lexicographic/final-wire-test.stdout 2> build/joint-lexicographic/final-wire-test.stderr
python3 build/joint-lexicographic/capture-final.py
python3 build/joint-lexicographic/validate-final.py
