set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/signed-rank/final-cli-build.jsonl 2> build/signed-rank/final-cli-build.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/signed-rank/final-corpus-build.jsonl 2> build/signed-rank/final-corpus-build.stderr
python3 build/signed-rank/capture-final.py
python3 build/signed-rank/validate-row.py
