from pathlib import Path
import json,shutil
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');rows=[]
def pin(project,name,invalid=False):
 dest=Path('tests/omega')/('fail' if invalid else 'pass')/'facts'/(name+('_rejected' if invalid else '_exit'));dest.mkdir(parents=True,exist_ok=True)
 for f in ['main.omg','build.omg']:shutil.copyfile(project/f,dest/f)
 if invalid:(dest/'expected.txt').write_text('\n'.join(json.loads((project/'sample.json').read_text())['rejection_contains'])+'\n')
 else:
  for engine in ['native','interpreter']:(dest/f'expected_{engine}_exit.txt').write_text('0\n')
 rows.append(str(dest))
for p in sorted(root.glob('*/projected_value')):
 name='nested_machine_joint_rank_projected_value_'+p.parent.name;pin(p,name);pin(p/'invalid',name,True)
for name in ['mutated_copy','nested_record']:
 p=root/'local/projected_value'/name;pin(p,'nested_machine_joint_rank_projected_'+name);pin(p/'invalid','nested_machine_joint_rank_projected_'+name,True)
for p in sorted((root/'controls').glob('projected_*')):pin(p,'nested_machine_joint_rank_'+p.name,True)
Path('build/projected-cycle-ranks/new-fixtures.json').write_text(json.dumps(rows,indent=2)+'\n');assert len(rows)==24;print('Pinned',len(rows),'fixtures')
