from pathlib import Path
import shutil,json,re
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank')
manifest=lambda reason: json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=[reason]),indent=2)+'\n'
(root/'local/ranged_value/rebound_ceiling/invalid/sample.json').write_text(manifest('cannot prove requires contract for call forward from count'))
(root/'local/ranged_value/rebound_floor/invalid/sample.json').write_text(manifest('violates required fact `remaining <= 7 && floor <= 0`'))
(root/'controls/ranged_self_justifying_floor/sample.json').write_text(manifest('exact arithmetic in machine `count` requires contract may overflow `u64`'))
for p in root.glob('*/ranged_value/**/main.omg'):
 s=p.read_text();s=re.sub(r'(?m)^(\s*)terminates by remaining in 0\.\.=7;\nrequires remaining <= 7;',r'\1terminates by remaining in 0..=7;\n\1requires remaining <= 7;',s);p.write_text(s)
rows=[]
def pin(p,stem,invalid=False):
 tier='fail' if invalid else 'pass';dest=Path('tests/omega')/tier/'facts'/(stem+('_rejected' if invalid else '_exit'));dest.mkdir(parents=True,exist_ok=True)
 for name in ['main.omg','build.omg']:shutil.copyfile(p/name,dest/name)
 if invalid:
  reasons=json.loads((p/'sample.json').read_text())['rejection_contains'];(dest/'expected.txt').write_text('\n'.join(reasons)+'\n')
 else:
  for engine in ['native','interpreter']:(dest/('expected_'+engine+'_exit.txt')).write_text('0\n')
 rows.append(str(dest))
for p in sorted(root.glob('*/ranged_value')):
 stem='nested_machine_joint_rank_ranged_value_'+p.parent.name
 pin(p,stem);pin(p/'invalid',stem,True)
for name in ['carried_bound','sequence_length','partial_floor','static_bound','rebound_ceiling','rebound_floor']:
 p=root/'local/ranged_value'/name;stem='nested_machine_joint_rank_ranged_'+name
 pin(p,stem);pin(p/'invalid',stem,True)
for p in sorted((root/'controls').glob('ranged_*')):
 pin(p,'nested_machine_joint_rank_'+p.name,True)
Path('build/ranged-cycle-ranks/new-fixtures.json').write_text(json.dumps(rows,indent=2)+'\n');print('Pinned',len(rows),'new fixtures')
