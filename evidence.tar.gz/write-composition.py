from pathlib import Path
import json
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');base=(root/'local/projected_value/main.omg').read_text();programs={}
programs['mutated_copy']=base.replace('let next: Remaining = Remaining { canary: pending.canary, count: pending.count - 1 };','let mut next: Remaining = pending;\n        next.count = next.count - 1;')
s=base.replace('data Remaining { canary: u64; count: u64; }','data Counter { spare: u64; count: u64; }\ndata Remaining { canary: u64; payload: Counter; }').replace('remaining.count','remaining.payload.count').replace('pending.count','pending.payload.count').replace('finish(remaining.canary)','finish(remaining.canary, remaining.payload.spare)').replace('machine finish(canary: u64)','machine finish(canary: u64, spare: u64)').replace('transition canary == 641','transition canary == 641 && spare == 827').replace('Remaining { canary: pending.canary, count: pending.payload.count - 1 }','Remaining { canary: pending.canary, payload: Counter { spare: pending.payload.spare, count: pending.payload.count - 1 } }').replace('Remaining { canary: 641, count: 7 }','Remaining { canary: 641, payload: Counter { spare: 827, count: 7 } }').replace('Remaining { canary: 641, count: 0 }','Remaining { canary: 641, payload: Counter { spare: 827, count: 0 } }');programs['nested_record']=s
for name,src in programs.items():
 p=root/'local/projected_value'/name
 for invalid in [False,True]:
  dest=p/'invalid' if invalid else p;dest.mkdir(parents=True,exist_ok=True)
  decrement='next.count - 1' if name=='mutated_copy' else 'pending.payload.count - 1';replacement='next.count' if name=='mutated_copy' else 'pending.payload.count';assert decrement in src
  (dest/'main.omg').write_text(src.replace(decrement,replacement) if invalid else src);(dest/'build.omg').write_text((root/'local/projected_value/build.omg').read_text().replace('joint_rank_projected_value_local','joint_rank_projected_'+name))
  if invalid:(dest/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['no exact private-coordinate assignment proves every edge and complete cycle']),indent=2)+'\n')
# This reset defeats descent against the original invocation, despite a local decrement.
s=base.replace('counter: &mut u64, remaining: Remaining)','counter: &mut u64, mut remaining: Remaining)',1).replace('    transition remaining.count > 0 {','    remaining.count = 7;\n    transition remaining.count > 0 {',1)
controls={'projected_reset_entry':s,'projected_wrong_subject':base.replace('canary: pending.canary, count: pending.count - 1','canary: ((pending.canary as u64 in Wrapping) - 1) as u64, count: pending.count')}
for name,src in controls.items():
 p=root/'controls'/name;p.mkdir(parents=True,exist_ok=True);(p/'main.omg').write_text(src);(p/'build.omg').write_text((root/'local/projected_value/build.omg').read_text().replace('joint_rank_projected_value_local','joint_rank_'+name));(p/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['no exact private-coordinate assignment proves every edge and complete cycle']),indent=2)+'\n')
print('Authored nested-field and moved/mutated-copy compositions plus entry-reset and wrong-subject controls')
