from pathlib import Path
import os,json,subprocess,time,hashlib
root=Path.cwd();b=root/'build/cross-carrier-rank';producer=json.load(open(b/'final-producer/producer.json'));assert hashlib.sha256(Path(producer['executable']).read_bytes()).hexdigest()==producer['sha256'];base=Path('samples/cli/facts/nested_machine_invocation/joint_rank');rows=[]
for place in ['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']:
 src=base/place/'computed_measure/cross_carrier';rows.extend([(place,src/'main.omg',None),(place+' invalid',src/'invalid/main.omg','a preserving cycle has no strict measure DECREASE')])
rows += [('frozen probe',base/'parameter/computed_measure/cross_carrier/probe/main.omg',None)]
for name,reason in [('widened_helper',None),('explicit_conversion',None),('anonymous_arm',None),('all_anonymous',None),('precondition','cannot prove rank range'),('unsafe_cast','is not provably representable'),('implicit_conversion','cannot prove rank range'),('typed_arm','cannot prove rank range')]:rows.append((name,base/'controls'/('cross_carrier_'+name)/'main.omg',reason))
for suffix in ['local/computed_measure/structured/main.omg','parameter/computed_measure/call/main.omg','local/main.omg']:rows.append(('existing '+suffix,base/suffix,None))
results=[]
for name,source,reason in rows:
 command=[producer['executable'],*(['--check'] if reason else ['run','--both']),str(source)];s=time.monotonic();o=subprocess.run(command,capture_output=True,text=True,timeout=120,env=dict(os.environ,OMEGA_LIBRARY_ROOT=str(root/'source/library')));r=dict(name=name,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),expected_rejection=reason,command=command,exit=o.returncode,stdout=o.stdout,stderr=o.stderr,seconds=time.monotonic()-s);results.append(r);(b/'final-row.json').write_text(json.dumps(dict(producer=producer,results=results),indent=2)+'\n');print(name,o.returncode,flush=True)
 if reason:assert o.returncode==1 and reason in o.stderr,r
 else:assert o.returncode==0 and 'native exit 0' in o.stderr and 'interp exit: 0' in o.stderr,r
assert len(results)==30
print('17 programs native0/Terminal0;13own-obligation controls rejected')
