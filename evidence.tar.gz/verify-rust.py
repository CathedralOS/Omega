import json
from pathlib import Path
r=Path('build/ranged-cycle-ranks');receipt=json.load(open(r/'closure-clippy-command.json'));assert receipt['exit']==0,receipt
log=(r/'final-rust.log').read_text();assert 'clippy 0' in log and 'format 0' in log,log
print('Verified current compiler-input Clippy and formatting receipts:',receipt['command'],log)
