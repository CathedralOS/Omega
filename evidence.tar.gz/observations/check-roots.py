import json,pathlib,subprocess,time
r=pathlib.Path(__file__).parent
out=[]
checks=[('check',['mbx','check','-p','validation','-p','typed-trees-to-checked-trees','-p','checked-trees-to-lowered-psi']),('lowering-clippy',['mbx','clippy','--no-deps','-p','typed-trees-to-checked-trees','-p','checked-trees-to-lowered-psi','--','-D','warnings'])]
for name,cmd in checks:
 start=time.monotonic()
 with (r/(name+'.log')).open('w') as log:
  p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 out.append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start})
 print(name,p.returncode,flush=True)
(r/'root-checks.json').write_text(json.dumps(out,indent=2)+'\n')
