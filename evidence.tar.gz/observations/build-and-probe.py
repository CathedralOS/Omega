import sys, pathlib, subprocess, json, hashlib, time, os, shutil
root=pathlib.Path.cwd();sys.path.insert(0,str(root/'tools'))
import compiler_profile,corpus_gate
out=root/'build/swarm/nov1/borrowed-input/candidate3';out.mkdir(exist_ok=True)
start=time.monotonic();env=compiler_profile.optimized_environment();env['CARGO_TARGET_DIR']=str(root/'target')
result=subprocess.run(['mbx','build','-p','omega','--message-format=json'],env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True)
(out/'cli-build.jsonl').write_text(result.stdout);(out/'cli-build.stderr').write_text(result.stderr)
if result.returncode:print(result.stderr[-6000:]);sys.exit(result.returncode)
cli=None
for line in result.stdout.splitlines():
 try:item=json.loads(line)
 except ValueError:continue
 if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='omega' and item.get('executable'):cli=pathlib.Path(item['executable'])
if cli is None:raise RuntimeError('no CLI executable')
profile=compiler_profile.require_optimized(cli);shutil.copy2(cli,out/'omega');cli=out/'omega'
(out/'producer.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'profile':profile,'cli':str(cli),'build_seconds':time.monotonic()-start},indent=2)+'\n')
probe=root/'samples/cli/facts/nested_machine_invocation/joint_rank/parameter/declared_measure/computed_record/call/borrowed_input/main.omg'
result=subprocess.run([str(cli),'run','--both',str(probe)],stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=120)
(out/'probe.stdout').write_text(result.stdout);(out/'probe.stderr').write_text(result.stderr)
(out/'probe.json').write_text(json.dumps({'command':[str(cli),'run','--both',str(probe)],'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
print('FIRST_PROBE',result.returncode,result.stderr,flush=True)
if result.returncode:sys.exit(result.returncode)
runner=corpus_gate.build_runner();compiler_profile.require_optimized(runner);shutil.copy2(runner,out/'corpus_runner')
print('RUNNER_READY',out/'corpus_runner',flush=True)
result=subprocess.run(['mbx','clippy','-p','validation','-p','typed-trees-to-checked-trees','-p','checked-trees-to-lowered-psi','--','-D','warnings'],env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True)
(out/'clippy.stdout').write_text(result.stdout);(out/'clippy.stderr').write_text(result.stderr)
print('CLIPPY',result.returncode,result.stderr[-3000:],flush=True)
sys.exit(result.returncode)
