from pathlib import Path
import subprocess,shutil
base=Path('omega-rust/psi/compilation');v=base/'checking/src';sc=base/'pipeline/04_typed-trees-to-checked-trees/src'
def from_head(p):p.write_bytes(subprocess.check_output(['git','show','HEAD:'+str(p)]))
# Remove machinery introduced solely to uphold the optional-endpoint restriction.
for p in [sc/'checks/current_scalar_values.rs',sc/'checks/current_scalar_values/call_contracts.rs',v/'lib.rs',v/'proof_contracts/contract_entailment.rs']:
 from_head(p)
p=v/'proof_contracts/contract_entailment.rs';s=p.read_text().replace('    RankingRangeCallEdge, RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,','    RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,').replace('    call_member_premise_symbols, mixed_call_endpoints_are_pinned, prove_ranking_range_call,','    call_member_premise_symbols, prove_ranking_range_call,');p.write_text(s)
p=v/'proof_contracts/contract_entailment/ranking_range.rs';s=p.read_text();a=s.index('pub use calls::{');b=s.index('\n/// A collection descriptor',a)
s=s[:a]+'''pub(crate) use calls::{
    RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,
    call_member_premise_symbols, prove_ranking_range_call,
};
''' +s[b:];p.write_text(s)
p=v/'proof_contracts/contract_entailment/ranking_range/calls.rs';s=p.read_text();a=s.index('mod endpoint_pins;');b=s.index('/// The exact transition site',a);s=s[:a]+s[b:]
a=s.index('    if let (Some((floor, ceiling, _)), Some((next_floor, next_ceiling, _))) =');b=s.index('    let clamped =',a)
s=s[:a]+'''    // Optional intervals constrain each invocation's produced rank. They do
    // not parameterize the shared nonnegative relation, so their endpoints
    // may differ after exact actual substitution. View bounds above remain
    // part of the selected view and still owe their own equality proof.
''' +s[b:]
s=s.replace('''/// ranges additionally require membership and equality of their endpoints.
/// When only one side authors a range, the component owner must separately
/// conserve its endpoint inputs through every unranged participant.''','''/// ranges additionally require independently formed endpoint expressions and
/// membership at each invocation; their endpoints need not be equal.''')
p.write_text(s)
p=v/'proof_contracts/contract_entailment/ranking_range/calls/endpoint_pins.rs';p.unlink();shutil.rmtree(p.parent/'endpoint_pins')
p=v/'machine_calls/call_cycles/runtime_ranking.rs';s=subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
s=s.replace('    RankingRangeCallEdge, RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,','    RankingRangeCallMember, RankingRangeCallProgress, RankingRangeCallSite,').replace('    call_member_premise_symbols, mixed_call_endpoints_are_pinned, prove_ranking_range_call,','    call_member_premise_symbols, prove_ranking_range_call,')
a=s.index('    let mixed_ranges =');b=s.index(';',a)+1;s=s[:a]+s[b:]
s=s.replace('    let mut range_edges = Vec::new();\n','')
a=s.index('                        if mixed_ranges {');b=s.index('\n                    }\n                    None =>',a);s=s[:a]+s[b:]
a=s.index('    if complete && mixed_ranges {');b=s.index('    // Removing all strict edges',a);s=s[:a]+s[b:];p.write_text(s)
p=sc/'checks/termination/joint_natural/ranges.rs';s=p.read_text();a=s.index('        let source = ranges[edge.source]');b=s.index('        let destination =',a);s=s[:a]+s[b:]
a=s.index('        if let Some(source) = source {');b=s.index('\n    }\n',a);s=s[:a]+s[b:]
a=s.index('    // With an authored range at every participant');s=s[:a]+'''    Ok(())
}
'''
s=s.replace('''//! conservation then follows every private participant, including members with
//! no authored range, under the existing prefix-write fences. Only after these
//! obligations does the component compare ranks and remove strict edges.''','''//! constraints belong to each invocation, not to the shared Nat₀ relation.
//! Rebinding an optional ceiling may be valid; moving a bound that belongs to
//! the selected view is a different obligation. Every edge still proves a
//! nonnegative, nonincreasing rank and every complete cycle strictly descends.''')
s=s.replace('//! Endpoint\n','//! These\n')
s=s.replace("pub(super) fn arrivals<'program>(\n    program: &'program dyn validation::CheckingInput,\n    machines: &[&'program Machine],", "pub(super) fn arrivals(\n    program: &dyn validation::CheckingInput,\n    machines: &[&Machine],")
s=s.replace("    edges: &[Edge<'program>],\n    frames: Option<&validation::CallFrameResolver<'program>>,","    edges: &[Edge<'_>],")
p.write_text(s)
p=sc/'checks/termination/joint_natural.rs';s=p.read_text().replace('''        &edges,
        frames,
    )''','''        &edges,
    )''').replace('''/// entry formation, actual membership and complete endpoint conservation.''','''/// entry formation and membership under exact actual substitution.''');p.write_text(s)
