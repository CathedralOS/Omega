set -eu
cargo build --locked -p omega --bin omega --message-format=json > build/joint-lexicographic/review-fix-cli-build.jsonl 2> build/joint-lexicographic/review-fix-cli-build.stderr
cargo build --locked -p compiler --test corpus_runner --message-format=json > build/joint-lexicographic/review-fix-corpus-build.jsonl 2> build/joint-lexicographic/review-fix-corpus-build.stderr
cargo test --locked -p terminal-codec rank_tuple -- --nocapture > build/joint-lexicographic/review-fix-wire-test.stdout 2> build/joint-lexicographic/review-fix-wire-test.stderr
python3 build/joint-lexicographic/capture-review-fix.py
python3 build/joint-lexicographic/validate-review-fix.py
bash build/joint-lexicographic/review-fix-corpus-chain.sh
