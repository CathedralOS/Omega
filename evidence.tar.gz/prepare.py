from pathlib import Path
import sys,json,time
sys.path.insert(0,'tools');from sample_native_gate import accept_review
root=Path('build/private-cycle-ranks');cli=str((root/'candidate-producer/omega').resolve());sources=sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/structural_view/main.omg'))
scope=json.loads((root/'scope.json').read_text());sources += [Path(p)/'main.omg' for p in scope['new']+scope['regressions'] if '/pass/' in p]
rows=[]
for source in sources:
 reason,output=accept_review(cli,str(source.parent),'macos_arm64',180);rows.append(dict(source=str(source),reason=reason,output=output));(root/'preparation.json').write_text(json.dumps(rows,indent=2)+'\n');print(source,reason,output[-1000:] if reason else '',flush=True)
