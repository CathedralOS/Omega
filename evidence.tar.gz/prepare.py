from pathlib import Path
import json,sys
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/ranged-cycle-ranks');cli=str((r/'candidate-producer/omega').resolve());existing=json.load(open(r/'ranged-consumers.json'));new=json.load(open(r/'new-fixtures.json'))
samples=sorted(Path('samples/cli/facts/nested_machine_invocation/joint_rank').glob('*/ranged_value/main.omg'))+sorted(p for p in Path('samples/cli/facts/nested_machine_invocation/joint_rank/local/ranged_value').glob('*/main.omg') if p.parent.name != 'invalid')
projects=[(p.parent,True) for p in samples]+[(Path(p),p in new) for p in existing+new if '/pass/' in p and (Path(p)/'build.omg').exists()];rows=[]
for p,required in projects:
 reason,output=accept_review(cli,str(p),'macos_arm64',180);row=dict(project=str(p),reason=reason,output=output,required_new=required);rows.append(row);(r/'preparation.json').write_text(json.dumps(rows,indent=2)+'\n');print(p,reason,output[-1400:] if reason else '',flush=True)
 if required:assert reason is None,row
