from pathlib import Path
import shutil
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank')
for p in root.glob('*/structural_view'):
 for invalid in [False,True]:
  src=p/'invalid' if invalid else p
  dst=Path('tests/omega')/('fail' if invalid else 'pass')/'facts'/('nested_machine_joint_rank_structural_view_'+p.parent.name+('_rejected' if invalid else '_exit'))
  dst.mkdir(parents=True,exist_ok=True)
  for name in ['main.omg','build.omg']:shutil.copyfile(src/name,dst/name)
  if invalid:(dst/'expected.txt').write_text('strict descent\n')
  else:
   for engine in ['native','interpreter']:(dst/('expected_'+engine+'_exit.txt')).write_text('0\n')
base=Path('build/private-cycle-ranks/slice-rank/main.omg').read_text()
for name,source,reason in [
 ('restored_descriptor',base.replace('transition { _ -> count(counter, pending[1..]) }','let mut next: &[u8] = pending[1..];\n        next = pending;\n        transition { _ -> count(counter, next) }'),'strict descent'),
 ('missing_bound',base.replace('    requires pending.len > 0;\n',''),'strict descent'),
]:
 p=root/'controls'/('structural_'+name);p.mkdir(parents=True,exist_ok=True);(p/'main.omg').write_text(source)
 shutil.copyfile('build/private-cycle-ranks/slice-rank/build.omg',p/'build.omg')
 dst=Path('tests/omega/fail/facts')/('nested_machine_joint_rank_structural_'+name+'_rejected');dst.mkdir(parents=True,exist_ok=True)
 for f in ['main.omg','build.omg']:shutil.copyfile(p/f,dst/f)
 (dst/'expected.txt').write_text(reason+'\n')
