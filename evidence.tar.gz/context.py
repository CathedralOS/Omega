import json,pathlib,subprocess
root=pathlib.Path.cwd(); out=root/'build/private-cycle-ranks'
mappings=[]
for path,start,end,reason in [
('wiki/spec/language/termination.md','Runtime invocation components use one joint ranking judgment','exact same-subject', 'Joint cyclic calls preserve or strictly decrease exact coordinates, including unranked private participants.'),
]:
    pass
for path,lo,hi,reason in [('wiki/spec/language/termination.md',78,96,'Select exact private descriptor coordinates for the same invocation-component ranking; every full cycle descends.'),('wiki/spec/terminal-psi/control_flow.md',108,133,'Carry the admitted rank observation into Terminal Psi; compare actual descriptor versions without deriving bounds from the ranking goal.')]:
    passage='\n'.join((root/path).read_text().splitlines()[lo-1:hi])
    mappings.append({'implementation':['omega-rust/psi/compilation/pipeline/04_typed-trees-to-checked-trees/src/checks/termination','omega-rust/psi/compilation/checking/src/machine_calls/call_cycles','omega-rust/psi/compilation/representations/checked-trees'],'contract':path,'classification':'missing_implementation','reason':reason,'passages':[passage]})
config={'context':{'host':'macos_arm64','task':'NESTED-MACHINE-UNIFICATION private structural joint rank','fixed_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},'semantic_contracts':mappings,'checks':[{'id':'baseline','kind':'tests','command':['python3','build/private-cycle-ranks/check-base.py'],'inputs':['omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml'],'artifacts':[],'closure_reason':'Compiler and bundled source; baseline replay retains its immutable producer receipt. Candidate checks will replace this definition before capture.','final':False,'expected_exit':0,'timeout_seconds':300}]}
(out/'context-config.json').write_text(json.dumps(config,indent=2)+'\n')
