from pathlib import Path
import subprocess,hashlib,json,time,os
b=Path('build/moving-upper');p=json.loads((b/'core2-producer/producer.json').read_text());root=Path('samples/cli/facts/nested_machine_invocation/joint_rank/parameter/bounded_distance/moving_upper');rows=[]
for name,src in [('positive',root/'main.omg'),('twin',root/'invalid/main.omg')]:
 cmd=[p['executable'],*(['run','--both'] if name=='positive' else ['--check']),str(src)];start=time.monotonic();o=subprocess.run(cmd,capture_output=True,text=True,timeout=120,env=dict(os.environ,OMEGA_LIBRARY_ROOT=str(Path('source/library').resolve())));rows.append(dict(name=name,source=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest(),command=cmd,exit=o.returncode,stdout=o.stdout,stderr=o.stderr,seconds=time.monotonic()-start));print(name,o.returncode,o.stderr[-1600:],flush=True)
(b/'core2-probe.json').write_text(json.dumps(dict(producer=p,results=rows),indent=2)+'\n')
