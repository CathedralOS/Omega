import json,subprocess,sys
from pathlib import Path
sys.path.insert(0,'tools');import corpus_records,corpus_gate
r=Path('build/ranged-cycle-ranks');p=subprocess.run(['python3',str(r/'capture-source.py')],timeout=900)
report=json.load(open(r/'final-source-compare.json'));rows=json.load(open(r/'source-observations.json'));assert not report['losses'],report['losses']
expected={p for p in json.load(open(r/'scope.json'))['fixtures'] if (Path('tests/omega')/p/'main.omg').exists()};assert {x['fixture'] for x in rows}==expected
base={x['fixture']:x for x in corpus_records.read(corpus_gate.baseline_path('bd57535230243699e595f565e84d75fa19be881d'))}
for x in rows:
 old=base.get(x['fixture'])
 if x['tier']=='fail' and not(x['status']=='rejected' and x['expected_satisfied'] is True):
  assert old and old['status']==x['status'] and old['expected_satisfied']==x['expected_satisfied'],x
  print('Retained baseline defect:',x['fixture'],x['status'],x['diagnostics'],flush=True)
 if x['tier']=='pass' and x['status']!='checked':
  assert old and old['status']==x['status'],x
  print('Retained baseline refusal:',x['fixture'],x['diagnostics'],flush=True)
print('Validated',len(rows),'source outcomes and exact reject oracles against fixed baseline.',flush=True)
