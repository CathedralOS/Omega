from pathlib import Path
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');frozen=Path('build/private-cycle-ranks/slice-rank/main.omg').read_text();rank=frozen[:frozen.index('machine main()')]
main='''machine main() crashes Trap {
    let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    let mut counted: u64 = 3;
    CALL(&mut counted, &bytes[..], true);
    let matched: bool = counted == 10;
    CALL(&mut counted, &bytes[..], false);
    transition matched && counted == 10 {
        true -> done() false -> bad()
    }
    machine done() {}
    machine bad() crashes Trap { crash Trap; }
}
'''
variants={
'local':'''machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    let remaining: &[u8] = match select { true -> bytes false -> bytes[0..0] };
    count(counter, remaining);
}
''',
'field':'''data Window<'storage> { remaining: &'storage [u8]; }
machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    let window: Window = Window { remaining: match select { true -> bytes false -> bytes[0..0] } };
    count(counter, window.remaining);
}
''',
'parameter':'''machine input(counter: &mut u64, remaining: &[u8]) { count(counter, remaining); }
machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    input(counter, match select { true -> bytes false -> bytes[0..0] });
}
''',
'call_result':'''machine input<'storage>(bytes: &'storage [u8], select: bool) -> &'storage [u8] {
    match select { true -> bytes false -> bytes[0..0] }
}
machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    let received: &[u8] = input(bytes, select);
    count(counter, received);
}
''',
'match_join':'''machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    count(counter, match select { true -> bytes false -> bytes[0..0] });
}
''',
'const_name':'''const Bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    let remaining: &[u8] = match select { true -> &Bytes[..] false -> &Bytes[0..0] };
    count(counter, remaining);
}
''',
'other_state':'''machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    forward_input(counter, match select { true -> bytes false -> bytes[0..0] });
    machine forward_input(counter: &mut u64, remaining: &[u8]) {
        count(counter, remaining);
    }
}
''',
'other_machine':'''machine forward_input(counter: &mut u64, remaining: &[u8]) {
    count(counter, remaining);
}
machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
    forward_input(counter, match select { true -> bytes false -> bytes[0..0] });
}
''',
 'target_body':'''boundary trait HostedCount {
    machine perform(counter: &mut u64, bytes: &[u8], select: bool) reaches;
}
HostedCountBody satisfies HostedCount {
    machine perform(counter: &mut u64, bytes: &[u8], select: bool) {
        let remaining: &[u8] = match select { true -> bytes false -> bytes[0..0] };
        count(counter, remaining);
    }
}
'''}
for place,body in variants.items():
 p=root/place/'structural_view';p.mkdir(parents=True,exist_ok=True)
 src=rank+body+main.replace('CALL','HostedCount::perform' if place=='target_body' else 'perform')
 for invalid in [False,True]:
  d=p/'invalid' if invalid else p;d.mkdir(exist_ok=True)
  (d/'main.omg').write_text(src.replace('count(counter, pending[1..])','count(counter, pending)') if invalid else src)
  build='machine build(builder: &mut Build) {\n    Build::application(builder, "joint_rank_structural_view_'+place+('");\n')
  if place=='target_body':
   for target in ['windows_x86_64','linux_x86_64','macos_arm64','linux_arm64']:build+='    Build::select_provider<HostedCount, HostedCountBody>(builder, '+target+');\n'
  for target in ['windows_x86_64','linux_x86_64','macos_arm64','linux_arm64']:build+='    Build::bind(builder, '+target+'::ProgramEntry, main);\n'
  (d/'build.omg').write_text(build+'}\n')
