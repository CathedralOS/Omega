from pathlib import Path
import json
root=Path('samples/cli/facts/nested_machine_invocation/joint_rank')
for place in ['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']:
 if place=='target_body':
  local=(root/'local/main.omg').read_text();a=local.index('machine perform(');b=local.index('machine main()',a)
  body=local[a:b];src=local[:a]+'''boundary trait HostedRange {
    machine perform(counter: &mut u64, select: bool) reaches;
}
HostedRangeBody satisfies HostedRange {
'''+''.join('    '+line+'\n' for line in body.splitlines())+'}\n'+local[b:].replace('perform(&mut counted,','HostedRange::perform(&mut counted,')
 else:src=(root/place/'main.omg').read_text()
 src=src.replace('terminates by remaining;','terminates by remaining in 0..=7;\nrequires remaining <= 7;').replace('forward(counter, remaining)','forward(remaining, counter)').replace('machine forward(counter: &mut u64, pending: u64)','machine forward(pending: u64, counter: &mut u64)').replace('requires pending > 0;','requires pending > 0 && pending <= 7;')
 if place=='parameter':src=src.replace('machine invoke(counter: &mut u64, remaining: u64) {','machine invoke(counter: &mut u64, remaining: u64)\nrequires remaining <= 7;\n{')
 if place=='call_result':src=src.replace('machine remaining(select: bool) -> u64 {','machine remaining(select: bool) -> u64\nensures result <= 7;\n{')
 if place=='other_machine':src=src.replace('machine input(select: bool) -> u64 {','machine input(select: bool) -> u64\nensures result <= 7;\n{').replace('machine forward_input(counter: &mut u64, received: u64) {','machine forward_input(counter: &mut u64, received: u64)\nrequires received <= 7;\n{')
 p=root/place/'ranged_value';p.mkdir(parents=True,exist_ok=True)
 build='machine build(builder: &mut Build) {\n    Build::application(builder, "joint_rank_ranged_value_'+place+'");\n'
 if place=='target_body':
  for target in ['windows_x86_64','linux_x86_64','macos_arm64','linux_arm64']:build+='    Build::select_provider<HostedRange, HostedRangeBody>(builder, '+target+');\n'
 for target in ['windows_x86_64','linux_x86_64','macos_arm64','linux_arm64']:build+='    Build::bind(builder, '+target+'::ProgramEntry, main);\n'
 build+='}\n'
 for invalid in [False,True]:
  d=p/'invalid' if invalid else p;d.mkdir(exist_ok=True)
  (d/'main.omg').write_text(src.replace('count(counter, pending - 1)','count(counter, pending)') if invalid else src);(d/'build.omg').write_text(build)
  if invalid:(d/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['no exact private-coordinate assignment proves every edge and complete cycle']),indent=2)+'\n')
