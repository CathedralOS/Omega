from pathlib import Path
import json
r=Path('build/projected-cycle-ranks');root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');base=(r/'local/main.omg').read_text();a=base.index('machine count(');b=base.index('machine perform(');c=base.index('machine main()');header=base[:a];counter=base[a:b];main=base[c:];value='match select { true -> Remaining { canary: 641, count: 7 } false -> Remaining { canary: 641, count: 0 } }'
places=['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']
for place in places:
 prefix=header;count=counter;entry=main
 if place=='local':src=base
 else:
  if place=='field':
   prefix+='data Envelope { value: Remaining; }\n';perform=f'machine perform(counter: &mut u64, select: bool) crashes Trap {{\n    let envelope: Envelope = Envelope {{ value: {value} }};\n    count(counter, envelope.value);\n}}\n'
  elif place=='parameter':perform=f'''machine perform(counter: &mut u64, select: bool) crashes Trap {{
    invoke(counter, {value});
}}
machine invoke(counter: &mut u64, received: Remaining) crashes Trap
requires received.count <= 7;
{{ count(counter, received); }}
'''
  elif place=='call_result':perform=f'''machine input(select: bool) -> Remaining
ensures result.count <= 7;
{{ {value} }}
machine perform(counter: &mut u64, select: bool) crashes Trap {{
    let received: Remaining = input(select);
    count(counter, received);
}}
'''
  elif place=='match_join':perform=f'machine perform(counter: &mut u64, select: bool) crashes Trap {{\n    count(counter, {value});\n}}\n'
  elif place=='const_name':
   prefix+='const Limit: u64 = 7;\n';perform='''machine perform(counter: &mut u64, select: bool) crashes Trap {
    transition select {
        true -> count(counter, Remaining { canary: 641, count: Limit })
        false -> count(counter, Remaining { canary: 641, count: 0 })
    }
}
'''
  elif place=='other_state':
   perform=f'machine perform(counter: &mut u64, select: bool) crashes Trap {{\n    let remaining: Remaining = {value};\n    transition {{ _ -> count(counter, remaining) }}\n'+''.join('    '+line+'\n' for line in counter.splitlines())+'}\n';count=''
  elif place=='other_machine':perform=f'''machine input(select: bool) -> Remaining
ensures result.count <= 7;
{{ {value} }}
machine perform(counter: &mut u64, select: bool) crashes Trap {{
    relay(counter, input(select));
}}
machine relay(counter: &mut u64, received: Remaining) crashes Trap
requires received.count <= 7;
{{ transition {{ _ -> count(counter, received) }} }}
'''
  elif place=='target_body':
   perform='''boundary trait HostedProjected {
    machine perform(counter: &mut u64, select: bool) reaches crashes Trap;
}
HostedProjectedBody satisfies HostedProjected {
'''+''.join('    '+line+'\n' for line in base[b:c].splitlines())+'}\n';entry=entry.replace('perform(&mut counted,','HostedProjected::perform(&mut counted,')
  src=prefix+count+perform+entry
 project=root/place/'projected_value';project.mkdir(parents=True,exist_ok=True)
 build='machine build(builder: &mut Build) {\n    Build::application(builder, "joint_rank_projected_value_'+place+'");\n'
 if place=='target_body':
  for target in ['windows_x86_64','linux_x86_64','macos_arm64','linux_arm64']:build+=f'    Build::select_provider<HostedProjected, HostedProjectedBody>(builder, {target});\n'
 for target in ['windows_x86_64','linux_x86_64','macos_arm64','linux_arm64']:build+=f'    Build::bind(builder, {target}::ProgramEntry, main);\n'
 build+='}\n'
 for invalid in [False,True]:
  dest=project/'invalid' if invalid else project;dest.mkdir(exist_ok=True);(dest/'main.omg').write_text(src.replace('pending.count - 1','pending.count') if invalid else src);(dest/'build.omg').write_text(build)
  if invalid:(dest/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['no exact private-coordinate assignment proves every edge and complete cycle']),indent=2)+'\n')
 (project/'README.md').write_text(f'''# Projected private rank: {place}

Owner: `NESTED-MACHINE-UNIFICATION` in [TASKS.md](../../../../../../../TASKS.md).

A private helper preserves the invocation rank on a tail edge, and every complete cycle strictly descends while advancing the explicit counter once.

The selected coordinate is the second field `Remaining.count`. Its sibling
`canary` must remain641. The matching input performs seven increments3→10;
the fallback preserves10. Both execute. [Positive](main.omg) must agree at
exit0 in native and Terminal; [twin](invalid/main.omg) removes only the decrement.
This place carries the same record and operation through `{place}`.

Entry requirements and unsigned carriers establish the field fact. Each helper
owns its own count requirement; no enclosing runtime fact is assumed. Exact
formal and field identities survive copies and actual substitution. The complete
cycle, not each forwarding edge, must descend. Static proof does not authorize
loans, mutation, cleanup or partial arithmetic. Checked observation retains the
full path into ordinary Terminal structural reads. Build binds all four hosted
targets; target layout/calling plans and register/frame lowering carry the record
and caller-owned counter, and native canary/counter checks expose incorrect
field geometry, lost increments or wrong dispatch. Only observed host execution
counts. Parent closure still owes the remaining requirements on TASKS.md.

Current baseline producer4bf998b1 refuses the private component before execution.
Candidate run records are retained under `build/projected-cycle-ranks/`.
''')
assert (root/'local/projected_value/main.omg').read_text()==base
print('Authored nine unchanged-fact places and their nondecrease twins')
