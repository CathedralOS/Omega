from pathlib import Path
import json,sys
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/descriptor-cycle-ranks/integrated-validation');cli=str((r.parent/'integrated-producer/omega').resolve());root=Path('samples/cli/facts/nested_machine_invocation/joint_rank');sources=sorted(root.glob('*/descriptor_field/main.omg'))+sorted(p for p in (root/'local/descriptor_field').glob('*/main.omg') if p.parent.name!='invalid');rows=[]
for source in sorted(sources,key=lambda p:(-len(p.parts),str(p))):
 reason,output=accept_review(cli,str(source.parent),'macos_arm64',180);row=dict(source=str(source),reason=reason,output=output);rows.append(row);(r/'sample-preparation.json').write_text(json.dumps(rows,indent=2)+'\n');print(source,reason,output[-1200:] if reason else '',flush=True);assert reason is None,row
