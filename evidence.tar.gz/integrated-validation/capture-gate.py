from pathlib import Path
import json,sys,os
sys.path.insert(0,'tools');import corpus_gate
r=Path('build/borrowed-cycle-ranks/integrated-validation');mode=sys.argv[1];scope=json.load(open(r/'scope.json'));original=corpus_gate.run_runner

def capture(*args,**kwargs):
 root=Path(args[1]) if len(args)>1 else Path.cwd()
 previous=os.environ.get('OMEGA_LIBRARY_ROOT')
 try:
  if root.resolve()!=Path.cwd().resolve():os.environ['OMEGA_LIBRARY_ROOT']=str(root/'source/library')
  rows=original(*args,**kwargs)
 finally:
  if previous is None:os.environ.pop('OMEGA_LIBRARY_ROOT',None)
  else:os.environ['OMEGA_LIBRARY_ROOT']=previous
 path=r/((mode+'-observations.json') if root.resolve()==Path.cwd().resolve() else (mode+'-baseline-observations.json'))
 path.write_text(json.dumps(rows,indent=2)+'\n');return rows
corpus_gate.run_runner=capture
sys.argv=['corpus_gate','--runner',str((r.parent/'integrated-producer/corpus_runner').resolve()),'--baseline-runner',str(Path('build/descriptor-cycle-ranks/integrated-producer/corpus_runner').resolve()),'--compare',scope['base'],'--filter',','.join(scope[mode]),'--json',str(r/(mode+'-compare.json'))]
if mode=='both':sys.argv+=['--both']
raise SystemExit(corpus_gate.main())
