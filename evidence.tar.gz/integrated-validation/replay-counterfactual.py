from pathlib import Path
import json,subprocess,sys,hashlib
sys.path.insert(0,'tools');from sample_native_gate import accept_review
r=Path('build/descriptor-cycle-ranks/integrated-validation');cli=str((r.parent/'integrated-producer/omega').resolve());src=Path('samples/cli/facts/nested_machine_invocation/joint_rank/local/descriptor_field/element_write');rows=[]
for name,content in [('fresh-replay',(src/'main.omg').read_text()),('wrong-payload-expectation',(src/'main.omg').read_text().replace('bytes[0] == 53','bytes[0] == 54'))]:
 p=r/name;p.mkdir(exist_ok=True);(p/'main.omg').write_text(content);(p/'build.omg').write_bytes((src/'build.omg').read_bytes());reason,out=accept_review(cli,str(p),'macos_arm64',180);assert reason is None,(reason,out);cmd=[cli,'run','--both',str(p/'main.omg')];x=subprocess.run(cmd,input='',text=True,capture_output=True,timeout=120);row=dict(name=name,command=cmd,source_sha256=hashlib.sha256((p/'main.omg').read_bytes()).hexdigest(),review=dict(reason=reason,output=out),exit=x.returncode,stdout=x.stdout,stderr=x.stderr);rows.append(row);(r/'fresh-replay-and-counterfactual.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,x.returncode,x.stderr[-1600:],flush=True)
 if name=='fresh-replay':assert x.returncode==0 and 'native exit 0' in x.stderr and 'interp exit: 0' in x.stderr
 else:assert x.returncode!=0 and 'native exit 0' not in x.stderr and ('interp exit: 0' not in x.stderr),row
