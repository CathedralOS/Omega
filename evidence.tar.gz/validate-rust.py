from pathlib import Path
import json,subprocess,time
r=Path('build/descriptor-cycle-ranks')
cmd=['cargo','clippy','--locked','--lib','-p','validation','-p','typed-trees-to-checked-trees','-p','checked-trees']
start=time.monotonic()
with(r/'closure-clippy.stdout').open('w') as out,(r/'closure-clippy.stderr').open('w') as err:x=subprocess.run(cmd,stdout=out,stderr=err,timeout=600)
(r/'closure-clippy-command.json').write_text(json.dumps(dict(command=cmd,exit=x.returncode,elapsed_seconds=time.monotonic()-start),indent=2)+'\n');print('clippy',x.returncode,round(time.monotonic()-start,2),flush=True);assert x.returncode==0
files=subprocess.check_output(['git','diff','--name-only','3835b27b7784b496536837cd2b02698795eefa7e','HEAD','--','*.rs'],text=True).splitlines()
# Formatting root-owned edited sources only; imported current-main files were validated by their lanes.
owned=[f for f in files if Path(f).is_file()]
x=subprocess.run(['rustfmt','--check','--edition','2024','--config','skip_children=true',*owned],capture_output=True,text=True,timeout=60);(r/'closure-format.stdout').write_text(x.stdout);(r/'closure-format.stderr').write_text(x.stderr);print('format',x.returncode,len(owned),flush=True);assert x.returncode==0
