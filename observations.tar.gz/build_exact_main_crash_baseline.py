from pathlib import Path
import subprocess,sys,time,json,os
h=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('5209eac451c');assert not subprocess.check_output(['git','status','--porcelain']);rows=[]
for package in ['semantic-vocabulary','typed-trees','validation','typed-trees-to-checked-trees','checked-trees-to-lowered-psi','build-time-evaluation','compiler']:
 name='guarded-crash-main-baseline-'+package;command=['cargo','build','--locked','--lib','-p',package,'-p','package-source'];t=time.monotonic()
 with(h/(name+'.stdout')).open('wb')as out,(h/(name+'.stderr')).open('wb')as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
 rows.append({'command':command,'source':head,'exit':r.returncode,'seconds':time.monotonic()-t});(h/'guarded-crash-main-baseline-builds.json').write_text(json.dumps(rows,indent=2)+'\n');print(package,'build exit',r.returncode,'seconds',round(rows[-1]['seconds'],2),flush=True)
 if r.returncode:print((h/(name+'.stderr')).read_text()[-5000:],flush=True);sys.exit(r.returncode)
 subprocess.run([sys.executable,str(h/'compress_baseline_cache.py'),name],check=True)
assert not subprocess.check_output(['git','status','--porcelain'])
sys.exit(subprocess.run([sys.executable,str(h/'build_corpus.py'),'guarded-crash-main-baseline-runner']).returncode)
