from pathlib import Path
import hashlib,json,os,subprocess,sys,time
h=Path(__file__).parent;label,producer_label,selection_name=sys.argv[1:4];w=Path.cwd()
sys.path.insert(0,str(w/'tools'));import compiler_profile
selection=json.loads((h/selection_name).read_text());keys=sorted(set(selection['fixtures']));runner=h/(producer_label+'-omega');profile=compiler_profile.require_optimized(runner)
inputs={};overlay=h/(label+'-inputs');overlay.mkdir()
for key in keys:
 root=Path('tests/omega')/key
 for p in [*root.glob('*.omg'),*root.glob('expected*.txt')]:
  payload=p.read_bytes();inputs[str(p)]=hashlib.sha256(payload).hexdigest();q=overlay/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(payload)
 lock=root/'omega.lock'
 if lock.exists():q=overlay/lock;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(lock.read_bytes())
record={'producer':profile,'producer_build':json.loads((h/(producer_label+'-producer.json')).read_text()),'fixtures':keys,'files':inputs,'harness_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
(h/(label+'-input-record.json')).write_text(json.dumps(record,indent=2)+'\n')
stage=h/(label+'-staged.txt');assert not stage.exists();stage.write_bytes(Path('tests/omega/corpus_outcomes.txt').read_bytes())
command=[sys.executable,'tools/corpus_gate.py','--runner',str(runner),'--filter',','.join(keys),'--golden',str(stage),'--record','--json',str(h/(label+'-verdict.json'))]
t=time.monotonic()
with (h/(label+'.stdout')).open('wb')as out,(h/(label+'.stderr')).open('wb')as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL,env=dict(os.environ,OMEGA_CORPUS_HOST_PROVISIONS='1'))
(h/(label+'-command.json')).write_text(json.dumps({'command':command,'exit':r.returncode,'seconds':time.monotonic()-t,'environment':{'OMEGA_CORPUS_HOST_PROVISIONS':'1'}},indent=2)+'\n')
for name,digest in inputs.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
v=json.loads((h/(label+'-verdict.json')).read_text());print(label,'exit',r.returncode,'counts',v.get('counts'),flush=True)
assert v['counts']['fixtures']==len(keys),(len(keys),v['counts'])
print('Oracle failures:',v.get('oracle_failures'),flush=True)
