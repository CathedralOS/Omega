# R13 focused termination execution

The merged compiler passes all five selected positive source checks and executes all three selected runtime controls with native exit 0 and interpreter exit 0. All six invalid controls reject; four match every retained expected.txt fragment, while two preserve the previously measured stale-fragment mismatches. Those two remain uncredited as matched controls.

This report covers exactly 11 delegated fixtures, 25 commands: 11 normal offline update attempts, 11 source checks, and three run --both commands. The root separately owns the folded wrapper, making 12 fixtures overall. No optional controls, builds, repository edits, expected-file changes, or HEAD changes were performed by this helper.

Producer source: 4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2. Actual producer: pending-admission-r13-omega, SHA256 0420b257867901596eec8c2fb1bca87d547932d304fd107db2adb2b49c7b4bc7. Every run_cli.py receipt verifies opt-level 1 and the actual binary digest. Each command supplied the exact fixture through VALIDATION_PROJECT and selected pending-admission-r13 through VALIDATION_PRODUCER.

| Fixture | Offline update | Source check | Runtime or oracle status |
| --- | --- | --- | --- |
| pass/comptime/const_joint_ranked_call_component | 0 | 0 | --both exit 0; observed native 0 / interpreter 0 |
| pass/termination/runtime_joint_rank_computed_copy_exit | 0 | 0 | --both exit 0; observed native 0 / interpreter 0 |
| pass/termination/proof_non_tail_joint_machine_cycle_compile | 1: fixture has no build.omg | 0 | Checking only |
| pass/proofs/nested_machine_rank_forwarding | 1: fixture has no build.omg | 0 | Checking only |
| fail/termination/joint_machine_call_cycle_stalled | 1: fixture has no build.omg | 1 | All expected fragments match |
| fail/termination/proof_joint_machine_cycle_unmeasured | 1: fixture has no build.omg | 1 | Historical stale fragment; not credited |
| fail/termination/runtime_non_tail_joint_machine_cycle | 1: fixture has no build.omg | 1 | Historical stale fragment; not credited |
| fail/proofs/nested_machine_rank_bypassed | 1: fixture has no build.omg | 1 | All expected fragments match |
| fail/termination/saved_field_predicate_overwritten | 1: fixture has no build.omg | 1 | All expected fragments match |
| pass/comptime/const_recursive_counter_survives_unrelated_writes | 0 | 0 | --both exit 0; observed native 0 / interpreter 0 |
| fail/comptime/const_recursive_counter_survives_unrelated_writes | 1: fixture has no build.omg | 1 | All expected fragments match |

The eight update failures are missing-build.omg setup outcomes for checking-only fixtures. Their subsequent source checks reached ordinary semantic diagnostics. No compiler-identity setup fence occurred. The three fixtures with authored Build inputs update successfully. Update setup failures are not counted as invalid-language controls.

## Direct diagnostic checks

- fail/termination/joint_machine_call_cycle_stalled: retained fragment `preserving cycle has no strict measure DECREASE` occurs in the raw rejection. Actual message:

```text
error: machine call cycle: `Main::scan_a`, `Main::scan_b` -- a preserving cycle has no strict measure DECREASE; runtime calls must be tail; a termination promise additionally requires strict descent on every complete cycle
```

- fail/proofs/nested_machine_rank_bypassed: retained fragment `helper-only cycle can avoid every ranked entry` occurs in the raw rejection. Actual message:

```text
error: proof-only machine call cycle: `descend`, `forward` -- no complete structural ranking establishes strict descent on every cycle; exact arguments must preserve or descend from the ranking subject, and preserving edges must be acyclic; computed ranking: a helper-only cycle can avoid every ranked entry
```

- fail/termination/saved_field_predicate_overwritten: retained fragment `construction of `Countdown` field `remaining` may overflow `u64`` occurs in the raw rejection. Actual message:

```text
error: exact arithmetic in construction of `Countdown` field `remaining` may overflow `u64`: the operands are not provably in range (decision 17 -- exact arithmetic is a proof obligation). Widen with an `as` cast to a larger type, constrain the operands' range (bound a parameter with a `requires` clause, or narrow a value with a dominating guard), or opt into a defined-overflow domain (`u64 in Wrapping`/`Saturating`/`Trapping`).
```

- fail/comptime/const_recursive_counter_survives_unrelated_writes: retained fragment `no exact private-coordinate assignment proves every edge and complete cycle` occurs in the raw rejection. Actual message:

```text
error: fixed-array length `[u8; extent()]`: const evaluation of `extent` failed: machine call cycle: `count`, `forward` -- no exact private-coordinate assignment proves every edge and complete cycle; runtime calls must be tail; a termination promise additionally requires strict descent on every complete cycle
```

## Historical diagnostic mismatches

- fail/termination/proof_joint_machine_cycle_unmeasured: retained expected fragment `unmeasured proof machine` is still absent. Full output is byte-for-byte identical to R12. Actual R13 output:

```text
error: proof-only machine call cycle: `left`, `right` -- no complete structural ranking establishes strict descent on every cycle; exact arguments must preserve or descend from the ranking subject, and preserving edges must be acyclic; computed ranking: the proof component has no authored ranking entry
```

- fail/termination/runtime_non_tail_joint_machine_cycle: retained expected fragment `non-tail call` is still absent. Full output is byte-for-byte identical to R12. Actual R13 output:

```text
error: machine call cycle: `Main::left`, `Main::right` -- an internal call occurrence lacks a classified tail edge; runtime calls must be tail; a termination promise additionally requires strict descent on every complete cycle
```

Both mismatches were independently demonstrated on exact R11 and R12 producers in r11-r12-termination-diagnostic-attribution.json. They remain stale oracle text, not an R13 accepted invalid program or a newly introduced R13 diagnostic change. No expected.txt was rewritten.

## Frozen inputs and records

r13-focused-termination-inputs.json retains all authored .omg and oracle hashes and points to their frozen copies under r13-focused-termination-frozen-inputs/. Each original was checked unchanged before and after execution. r13-focused-termination-outcomes.json indexes every receipt and distinguishes missing fragments from setup errors. Raw command receipts, stdout, stderr, and helper transcripts use unique pending-admission-r13-focused-<fixture>-{update,check,both} labels. r13-focused-termination-evidence-sha256.json binds this report and the complete raw evidence set.

This is fresh R13 evidence. R12 and earlier main results retain their original identities; no historical receipt was relabeled.
