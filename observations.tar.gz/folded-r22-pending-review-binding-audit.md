# Folded layout fixture: pending package binding review

The pending choices represent incoming std binding migration, not a request for the folded-layout program to access the filesystem. The generated delta is suitable for ordinary managed test-package acceptance after reviewing these exact rows. No review decision, accepted lock, source file, or binary was changed by this investigation.

The fixture main.omg and build.omg are byte-identical to public source 2273a67852265ff8215d373b029f3be7532f275a. Its product body computes 275 and invokes Console::exit_process(70), with exit 71 only on an oracle mismatch. It contains no filesystem call, pathname, credential, network operation, or filesystem permission grant. Its Build still depends on std and binds the same four ProgramEntry targets.

## What changed

The review compares the same fixture source content 9b2067cb22d40bacf52848a08d5a39f7ce3a878c0139cc6e452f2eb2356d1674. Only std source content changes, from ff119edbd84f225ca83224d6d6d48cfa9c690144083c820eb98a613333a4447d to 99925f3e88b6f8c0cc483c8c68bf09ac7f26c3ac94548e15ce39d1e17e776bf0. Source associations and the macOS product occurrence are unchanged.

All 236 decisions are accounted for: 98 old forwarding-callable rows and their 98 external-supply rows disappear; 40 target-specific native-binding rows replace the macOS supplies. Removed supplies include 29 Linux x86-64, 29 Linux ARM64, and 40 macOS ARM64 declarations. This target review emits 40 macOS native rows; it is not evidence about executing another target.

The 40 macOS rows are 31 PosixFilesystemDarwin members, six PosixFilesystemDarwinByteViews members, and three PosixCanonicalLibc members. Each maps by exact member name to one removed macOS supply with the same install name and symbol. There are zero locator mismatches. All use /usr/lib/libSystem.B.dylib, with 35 distinct symbol coordinates because some requirements intentionally share a symbol. For example, c_create_dir_name remains _mkdir; c_write remains _write; canonical resolve remains _realpath; error_location remains ___error; copy_error remains _memcpy. No new library or external endpoint was found.

These changes come from main PRs #1617 (PosixCanonicalLibc), #1622 (Linux filesystem), and #1625 (Darwin filesystem), at eacdc311434, 54cb3e7dc11, and 6e5f21cbc68. std/build.omg adds three configuration routines using Build::bind. Old locator factories, satisfies-via forwarding declarations, and provider carriers are removed; checked adapter calls name the existing boundary requirements directly. PosixFilesystemHost publishes the raw-trait invokes edges used by those adapters. Those edges describe how existing filesystem services are implemented; they do not make this fixture invoke them.

The three affected macOS boundary-trait declarations are byte-identical to source 2273, including their signatures, service reach and other clauses. The three corresponding Linux trait declarations inspected are also byte-identical. Native rows retain the existing filesystem read/write/metadata/namespace/enumeration authority descriptions; none introduces a new service class. Those package findings are not grants to the compiler's running Build activation or new calls in the fixture.

## Governing rule and disposition

wiki/spec/build/foreign_bindings.md explains that Build records package-local, target-keyed binding intent and does not execute the designated product requirement or install a service into Build (lines 35–62). Locator construction and selection grant no runtime authority (lines 69 and 190–206). The requirement continues to own its complete public operational contract. wiki/spec/build/provider_selection.md likewise separates selection from runtime permission (lines 3–11 and 35–39).

tools/testing.md:142–146 authorizes the normal existing pass-fixture update/review/resume path: managed acceptance consists of the generated pending-row decisions, not a copied lock. On this exact delta I found no new external-authorization requirement: the bindings replace existing accepted supplies at identical native coordinates, and this fixture still exercises only its numeric/layout computation and Console exit. This conclusion is bounded to this generated review and these exact source inputs; it is not acceptance of unrelated future std changes or independent semantic approval of PR 1631.

The full pending review remains in place, and root has separately frozen the complete review, baseline and source output under guarded-crash-r22-layout-review-inputs/. The companion JSON records the complete concise member/locator roster, source declaration comparisons and original review digest. No builds or runtime executions were performed by this review.
