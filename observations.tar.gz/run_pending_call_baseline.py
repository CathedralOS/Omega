from pathlib import Path
import datetime, hashlib, json, os, platform, re, subprocess, sys
w=Path.cwd();h=Path(__file__).parent
manifest=h/'pending-call-authored-source-manifest.json';authored=json.loads(manifest.read_text());places=authored['places'];row=w/authored['production'];producer=json.loads((h/'closed-owner-r6-producer.json').read_text())
sys.path.insert(0,str(w/'tools'));import compiler_profile
assert compiler_profile.require_optimized(h/'closed-owner-r6-omega')==producer['executable']
manifest_digest=hashlib.sha256(manifest.read_bytes()).hexdigest()
def verify():
 assert hashlib.sha256(manifest.read_bytes()).hexdigest()==manifest_digest
 for name,digest in authored['files'].items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
verify()
summary={'state':'running','producer':producer,'producer_input_identity':'R6 source0f7da6f153281c0b10c2fe063ab3e0e29dfdd2d4, empty compiler patch, identical compiler/library/manifests to pre-edit ad538df71f383bb186744c76c84748fadff1e676. Current dirty implementation is not this producer.','frozen_manifest':str(manifest),'frozen_manifest_sha256':manifest_digest,'file_map_sha256':authored['file_map_sha256'],'host':{'system':platform.system(),'machine':platform.machine()},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observations':[],'lock_recoveries':[]}
p=h/'pending-call-baseline-summary.json'
def save():p.write_text(json.dumps(summary,indent=2)+'\n')
def call(project,label,args):
 verify();assert not (h/(label+'.json')).exists(),label
 env=dict(os.environ,VALIDATION_PRODUCER='closed-owner-r6',VALIDATION_PROJECT=str(project.relative_to(w)))
 wrapper=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (h/(label+'-wrapper.stdout')).write_bytes(wrapper.stdout);(h/(label+'-wrapper.stderr')).write_bytes(wrapper.stderr)
 assert wrapper.returncode==0,(label,wrapper.returncode,wrapper.stderr.decode())
 record=json.loads((h/(label+'.json')).read_text());assert record['producer']==producer['executable']
 assert set(record['inputs'])=={str(project/'main.omg'),str(project/'build.omg')}
 for name,digest in record['inputs'].items():assert digest==authored['files'][str(Path(name).relative_to(w))]
 stderr=Path(record['stderr']).read_text();stdout=Path(record['stdout']).read_text()
 item={'label':label,'project':str(project.relative_to(w)),'command':record['command'],'exit':record['exit'],'receipt':str(h/(label+'.json')),'wrapper_exit':wrapper.returncode}
 if '--both' in args:
  item['native_markers']=re.findall(r'native exit (-?\d+)',stderr+stdout);item['interpreter_markers']=re.findall(r'interp exit: (-?\d+)',stderr+stdout)
  item['actual_agreement_zero']=record['exit']==0 and item['native_markers']==['0'] and item['interpreter_markers']==['0']
 item['diagnostic_tail']=stderr[-1800:]
 summary['observations'].append(item);save();print(label,'compiler_exit',record['exit'],'both',item.get('actual_agreement_zero','n/a'),flush=True)
 if record['exit']!=0:print('DIAGNOSTIC',stderr[-1000:],flush=True)
 return item

def update(project,label):
 item=call(project,label,['update','--project',str(project),'--offline'])
 if item['exit'] and 'unsupported package lock version' in item['diagnostic_tail']:
  lock=project/'omega.lock';assert lock.exists();saved=h/(label+'-unsupported.omega.lock');saved.write_bytes(lock.read_bytes());lock.unlink()
  summary['lock_recoveries'].append({'project':str(project.relative_to(w)),'initial_receipt':item['receipt'],'preserved_lock':str(saved),'action':'Removed only incompatible ignored lock as directed by diagnostic, then normal offline update; no lock copied into project.'});save()
  return call(project,label+'-retry',['update','--project',str(project),'--offline'])
 return item

for place in places:
 project=row/place
 update(project,'pending-call-baseline-'+place+'-positive-update')
 call(project,'pending-call-baseline-'+place+'-positive-check',['--check',str(project/'main.omg')])
 call(project,'pending-call-baseline-'+place+'-positive-both',['run',str(project/'main.omg'),'--both','--keep'])
 project=row/place/'invalid'
 update(project,'pending-call-baseline-'+place+'-invalid-update')
 result=call(project,'pending-call-baseline-'+place+'-invalid-check',['--check',str(project/'main.omg')])
 if result['exit']==0:print('WRONG_ACCEPT',place,flush=True)
verify()
obs=summary['observations'];positives=[x for x in obs if x['label'].endswith('-positive-check')];invalid=[x for x in obs if x['label'].endswith('-invalid-check')];both=[x for x in obs if x['label'].endswith('-positive-both')];updates=[x for x in obs if '-update' in x['label']]
summary['counts']={'positive_checks':len(positives),'positive_checked':sum(x['exit']==0 for x in positives),'positive_refused':sum(x['exit']!=0 for x in positives),'both_requests':len(both),'actual_native_terminal_zero':sum(x['actual_agreement_zero'] for x in both),'invalid_checks':len(invalid),'invalid_wrongly_accepted':sum(x['exit']==0 for x in invalid),'invalid_rejected':sum(x['exit']!=0 for x in invalid),'normal_update_requests':len(updates),'update_failures':sum(x['exit']!=0 for x in updates)}
summary['state']='complete';summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();summary['frozen_inputs_unchanged']=True;save()
note=f"Frozen pending_call baseline with immutable optimized R6 source {producer['source']} (CLI {producer['executable']['sha256']}). Current implementation edits were not compiled or executed.\n\nAll nine positive source checks: {summary['counts']['positive_checked']} accepted, {summary['counts']['positive_refused']} refused. Actual native/Terminal zero agreements: {summary['counts']['actual_native_terminal_zero']} of nine requests. All nine negative checks: {summary['counts']['invalid_wrongly_accepted']} wrongly accepted, {summary['counts']['invalid_rejected']} rejected. These negative accepts demonstrate the pending-admission defect; they are not passing rejection controls.\n\nEvery project received ordinary offline update before checking, and receipts preserve locks and actual program inputs. The wrapper exit was inspected separately from compiler exits and both engine markers. Authored manifest bytes and all92 file hashes stayed unchanged. No compiler build, tracked edit, or commit was performed by this baseline chain. Raw receipts use pending-call-baseline-* labels; summary is pending-call-baseline-summary.json.\n"
(h/'pending-call-baseline-note.txt').write_text(note);print(json.dumps(summary['counts']),flush=True)
