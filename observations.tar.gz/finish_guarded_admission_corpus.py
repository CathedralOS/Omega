from pathlib import Path
import hashlib,json,os,subprocess,sys,time
h=Path(__file__).parent;w=Path.cwd();label=sys.argv[1];producer_label=sys.argv[2]
sys.path.insert(0,str(w/'tools'));import corpus_records as records;import compiler_profile
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();producer=json.loads((h/(producer_label+'-producer.json')).read_text());runner=h/(producer_label+'-omega');assert compiler_profile.require_optimized(runner)==producer['executable']
original=json.loads((h/'guarded-crash-r20-corpus-verdict.json').read_text());original_inputs=json.loads((h/'guarded-crash-r20-corpus-inputs.json').read_text());original_keys=set(original_inputs['fixtures']);counter='pass/comptime/const_recursive_counter_survives_unrelated_writes'
assert len(original_keys)==30 and not original['counts']['wrong_reason'] and not original['oracle_failures']
bad=[r for r in original['observations']if r['tier']!='fail'and r['status']!='checked'];assert len(bad)==1 and bad[0]['fixture']==counter and 'compiler identity changed' in '\n'.join(bad[0]['diagnostics'])
keys=sorted([counter,'pass/facts/provider_contract_endpoint_control_unrelated_pending_target_contract','fail/facts/provider_contract_endpoint_control_circular_endpoint_formation']);inputs={};locks={};overlay=h/(label+'-input-files');assert not overlay.exists();overlay.mkdir()
for key in keys:
 root=Path('tests/omega')/key
 for path in [*root.glob('*.omg'),*root.glob('expected*.txt')]:
  payload=path.read_bytes();inputs[str(path)]=hashlib.sha256(payload).hexdigest();target=overlay/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
 lock=root/'omega.lock';payload=lock.read_bytes()if lock.exists()else None;locks[str(lock)]={'present':payload is not None,'sha256':hashlib.sha256(payload).hexdigest()if payload is not None else None}
 if payload is not None:target=overlay/lock;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
source=Path('tests/omega/corpus_outcomes.txt');before=source.read_text();old={r['fixture']:r for r in records.parse(before)};stage=h/(label+'-staged.txt');assert not stage.exists();stage.write_text(before)
(h/(label+'-inputs.json')).write_text(json.dumps({'source':head,'producer':producer,'fresh_fixtures':keys,'files':inputs,'locks':locks,'retained_29_from':str(h/'guarded-crash-r20-corpus-verdict.json'),'reason':'The original counter observation stopped at a stale accepted compiler identity. Its normal update, source check and native/Terminal run have now passed. Two related pending-condition controls are also checked here; the other 29 completed observations keep their original receipts.'},indent=2)+'\n')
command=[sys.executable,'tools/corpus_gate.py','--runner',str(runner),'--filter',','.join(keys),'--golden',str(stage),'--record','--json',str(h/(label+'-verdict.json'))];t=time.monotonic()
with(h/(label+'.stdout')).open('wb')as out,(h/(label+'.stderr')).open('wb')as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL,env=dict(os.environ,OMEGA_CORPUS_HOST_PROVISIONS='1'))
(h/(label+'-command.json')).write_text(json.dumps({'command':command,'environment':{'OMEGA_CORPUS_HOST_PROVISIONS':'1'},'exit':r.returncode,'seconds':time.monotonic()-t},indent=2)+'\n')
verdict=json.loads((h/(label+'-verdict.json')).read_text());print('Fresh corpus completion exit',r.returncode,'counts',verdict['counts'],flush=True)
assert r.returncode==0 and verdict['counts']['fixtures']==3 and verdict['counts']['by_status']=={'checked':2,'rejected':1}
assert not verdict['counts']['wrong_reason'] and not verdict['oracle_failures']
for name,digest in {**original_inputs['files'],**inputs}.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
for name,state in locks.items():
 lock=Path(name);assert lock.exists()==state['present']
 if lock.exists():assert hashlib.sha256(lock.read_bytes()).hexdigest()==state['sha256'],name
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
policy=next(r for r in original['observations']if r['fixture']=='pass/build/terminal_calling_policy_execution');assert policy['facts']['terminal-runtime.retained_plan']=='match'and policy['facts']['terminal-inspections']=='match'
selected={r['fixture']:r for r in records.read(h/'guarded-crash-r20-corpus-staged.txt')if r['fixture']in original_keys and r['fixture']!=counter}
selected.update({r['fixture']:r for r in records.read(stage)if r['fixture']in keys});assert len(selected)==32
assert all(r['status']==('rejected'if key.startswith('fail/')else'checked')for key,r in selected.items())
fields=['status','expected_satisfied','facts','diagnostics','regressed_from'];timings=[]
for key,row in selected.items():
 prior=old.get(key)
 if prior is not None and all(row.get(field)==prior.get(field)for field in fields):timings.append({'fixture':key,'fresh_millis':row['millis'],'retained_millis':prior['millis']});row['millis']=prior['millis']
final=records.splice(before,list(selected.values()));new={r['fixture']:r for r in records.parse(final)}
assert set(old).issubset(new)and set(new)-set(old)==set(selected)-set(old)
def blocks(text):
 out={};key=None
 for line in text.splitlines(keepends=True):
  if not line.strip()or line.startswith('#'):continue
  if line.startswith('\t'):assert key;out[key]+=line
  else:key=line.split()[0];assert key not in out;out[key]=line
 return out
ob=blocks(before);nb=blocks(final);assert all(ob[key]==nb[key]for key in ob if key not in selected)
source.write_text(final)
summary={'state':'complete','source':head,'producer':producer,'counts':{'fixtures':32,'checked':16,'rejected':16,'retained_completed_observations':29,'fresh_completion_observations':3},'selected_fixtures':sorted(selected),'original_setup_refusal_preserved':str(h/'guarded-crash-r20-corpus-verdict.json'),'fresh_completion':str(h/(label+'-verdict.json')),'policy_runtime':policy['facts'],'golden_guard':{'keys_added':sorted(set(new)-set(old)),'no_keys_removed':True,'unselected_blocks_byte_identical':True,'timing_restorations':timings},'scope':'Source checking and intended rejects, plus the actual retained calling-policy runtime and inspection observations. Native program execution is recorded separately by the CLI witness receipts.'}
(h/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print('Combined corpus qualification: 16 checked and16 intended rejects; all other golden rows unchanged.',flush=True)
