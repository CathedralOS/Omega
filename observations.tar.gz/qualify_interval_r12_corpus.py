from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
subprocess.run([sys.executable,str(h/'prepare_interval_fixture_replay_r12.py')],check=True)
subprocess.run([sys.executable,str(h/'observe_interval_corpus.py'),'interval-window-r12-corpus','interval-window-r12-runner-link-retry','interval-window-r12-final-corpus-selection.json'],check=True)
