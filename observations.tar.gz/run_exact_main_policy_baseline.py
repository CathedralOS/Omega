from pathlib import Path
import json,subprocess,hashlib,os,time,sys
w=Path.cwd();h=Path(__file__).parent;frozen=json.loads((h/'guarded-crash-main-baseline-common-inputs.json').read_text());producer=json.loads((h/'guarded-crash-main-baseline-retry-runner-producer.json').read_text());assert producer['source']==frozen['baseline_source'];runner=h/'guarded-crash-main-baseline-retry-runner-omega'
for name,digest in frozen['files'].items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
label='guarded-crash-main-baseline-policy';command=[sys.executable,'tools/corpus_gate.py','--runner',str(runner),'--filter','pass/build/terminal_calling_policy_execution','--json',str(h/(label+'-verdict.json'))];t=time.monotonic()
with(h/(label+'.stdout')).open('wb')as out,(h/(label+'.stderr')).open('wb')as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL,env=dict(os.environ,OMEGA_CORPUS_HOST_PROVISIONS='1'))
for name,digest in frozen['files'].items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
receipt={'command':command,'exit':r.returncode,'seconds':time.monotonic()-t,'producer':producer,'input_manifest':str(h/'guarded-crash-main-baseline-common-inputs.json'),'environment':{'OMEGA_CORPUS_HOST_PROVISIONS':'1'},'source_attribution':'The producer is main at 5209eac451c. Fixture and library inputs use the same candidate-worktree paths as the integrated observation and are byte-identical to main at 5209eac451c. No golden recording or revision relabeling is requested.'};(h/(label+'-command.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if (h/(label+'-verdict.json')).exists():
 v=json.loads((h/(label+'-verdict.json')).read_text());print(json.dumps(v['observations'],indent=2),flush=True)
sys.exit(r.returncode)
