from pathlib import Path
import hashlib,json,shutil,subprocess,sys
h=Path(__file__).parent;label=sys.argv[1];overlay=h/(label+'-prior-project-locks');assert not overlay.exists();overlay.mkdir();projects=set()
for name in ['interval-window-r10-recast-selection.json','interval-window-shared-sources-selection.json','interval-window-r10-other-controls-selection.json','interval-window-r9-storage-selection.json']:
 projects.update(row['project']for row in json.loads((h/name).read_text())['projects'])
base=Path('samples/cli/facts/data_where_standing/write_only')
for place in json.loads((h/'interval-window-integrated-row-inputs.json').read_text())['places']:
 projects.update(str(base/place/suffix)for suffix in ['','invalid','invalid_window'])
projects.add(str(base/'controls/untouched_child_restoration'));rows=[]
for project in sorted(projects):
 p=Path(project)/'omega.lock'
 if not p.exists():continue
 assert subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0,str(p)
 q=overlay/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);digest=hashlib.sha256(p.read_bytes()).hexdigest();assert hashlib.sha256(q.read_bytes()).hexdigest()==digest
 rows.append({'file':str(p),'sha256':digest,'retained_copy':str(q)});p.unlink()
record={'purpose':'Prepare fresh root-project compilation before capturing restoration checks. Prior generated acceptance is retained byte for byte; authored source, project policy and compiler admission rules are unchanged. Each ordinary update must establish its own accepted result rather than reuse the earlier root checkpoint.','projects':sorted(projects),'files':rows};(h/(label+'-project-replay-preparation.json')).write_text(json.dumps(record,indent=2)+'\n');print('Prepared',len(projects),'projects; retained',len(rows),'prior generated locks',flush=True)
