The range-only artifact helper is ready at range_artifact_member.py. It writes no full ZIP to disk. Credentials and signed blob URLs stay in process memory and are omitted from receipts and error output. No compiler executable was downloaded or executed; only metadata, the summary and two small build-log members were retrieved.

The helper requires an exact workflow run, expected source revision and retained summary. It checks summary/artifact/producer source identity and run association, resolves the current attempt's exact compiler-pilot artifact, and derives the CLI member from the summary's retained path. Absent or ambiguous matches refuse.

Each request must return 206, the exact Content-Range and Content-Length, and unencoded bytes. The standard-library zipfile decoder uses a seekable block reader. Defaults: 1 MiB blocks, 4 MiB cache, 1,024 requests, 320 MiB transferred and 256 MiB selected output. Hard upper limits bound supplied settings, and individual reads are at most 8 MiB. Extraction streams to an exclusively created .partial; checks ZIP EOF/CRC and the summary's SHA; queries the embedded optimized profile; requires exact profile agreement; and streams a second SHA before publication. A same-directory hard link publishes without a second data copy or overwriting existing output. Extraction checks a 16 MiB free-disk reserve. Failure removes only its owned partial and retains a red receipt.

Focused evidence:

- range-artifact-helper-tests-r4.stderr: 18 tests pass. They cover selected-member/deflate extraction, seek/cache limits, invalid status/range/total/length/encoding/truncation, budgets, CRC/SHA cleanup, existing output/partial preservation, hard limits, data observations, compiler hash/profile requirements, profile-before-publication, exact run/member resolution, source mismatch before authentication and sanitized failures. An added test initially had incorrectly escaped fixture bytes; r3 remains retained and r4 fixes that test fixture.
- range-artifact-d644-summary-r2-receipt.json: the final helper resolves run 41769889885 and artifact 13295208773, extracts the 6,986-byte summary with CRC and independently retained SHA, using one 206 response and 35,176 transferred bytes.
- range-artifact-d644-build-stderr-r1.json: 17,005 log bytes, CRC and first-observed SHA, 166,248 transfer bytes.
- range-artifact-d644-build-jsonl-r1.json: 191,238 log bytes, CRC and first-observed SHA, 297,320 transfer bytes; cache peak 262,144 bytes.
- range-artifact-d644-wrong-sha-r1-receipt.json: deliberate wrong SHA refuses, leaves no output/owned partial and retains the failure. This is a tool test, not an Omega rejection.
- saved-loans-d644-download-failure.json and saved-loans-producer-download.stderr remain untouched. The original interrupted 199,229,440-byte extraction stays recorded and unusable.

The old summary reports 1,647.668 seconds (27m28s) preparing the optimized producer. The retained cli-build.stderr gives 24m40s, approximately 1,480 seconds, for Cargo's optimized dev CLI build. JSONL contains 213 compiler-artifact rows: 165 rebuilt and 48 fresh. Rebuilt units include libc, cfg_if, arena, numerics, semantic_vocabulary, typed_trees, validation, both typed checking stages and the compiler/CLI. This was substantial dependency code generation. The prior cargo check prepares metadata, which does not establish warm ordinary code-generation artifacts.

Approximately 167.668 seconds remain inside preparation for runner construction, copies and profile/identity checks; prepare_producer includes all those operations. That is not an individually measured runner duration. Logs provide no per-crate critical-path timings or proof of a specific cache-key failure. Profile 0 artifact rows include host/build work; the retained CLI's authenticated embedded profile is opt-level 1. No speedup or Cargo-default change is claimed.

The old ZIP is 449,612,136 bytes; its CLI is 208,736,880 bytes and separate runner 212,007,120 bytes, with Terminal artifacts and records also present. Only small members were extracted. No full ZIP was spooled or old CLI member retained.

After root reviews the new checking records and retains the summary, use this exact command:

    python3 /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/range_artifact_member.py \
      --run 41774629213 \
      --expected-source cd5340c6d0348e868e34d68ee85f250c431f79ba \
      --summary /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/saved-loans-hosted-41774629213/summary.json \
      --kind cli \
      --output /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/saved-loans-c6-omega \
      --receipt /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/saved-loans-c6-range-download-41774629213.json

Do not start before reviewing the recorded producer/source and checking outcomes. The command resolves the artifact and member automatically and publishes only after CRC, summary-bound SHA and optimized-profile agreement. Existing output or receipt paths refuse; retries need a new receipt label. A matching optimized binary is not source/execution acceptance.

range-artifact-helper-validation.json records final helper/test hashes, receipt hashes and measured build counts. All changes are local under build/scalar-continue-20261102; no tracked source, workflow, Cargo setting or expectation changed. No earlier CLI was fetched and no new-run CLI download has started.
