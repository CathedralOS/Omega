from pathlib import Path
import subprocess,hashlib,os,json,sys
h=Path(__file__).parent
sys.path.insert(0,str(Path.cwd()/'tools'))
import compiler_profile
label=sys.argv[1]
p=h/(label+'-omega')
profile=compiler_profile.require_optimized(p)
before=p.stat();digest=hashlib.sha256(p.read_bytes()).hexdigest()
temporary=p.with_name(p.name+'.compressed-copy')
subprocess.run(['ditto','--hfsCompression',str(p),str(temporary)],check=True)
after=temporary.stat()
assert (after.st_size,after.st_mtime_ns,after.st_mode)==(before.st_size,before.st_mtime_ns,before.st_mode)
assert hashlib.sha256(temporary.read_bytes()).hexdigest()==digest
os.replace(temporary,p)
assert compiler_profile.require_optimized(p)==profile
messages=[json.loads(s) for s in (h/(label+'-cargo.stdout')).read_text().splitlines() if s.startswith('{')]
artifact=next(m for m in reversed(messages) if m.get('reason')=='compiler-artifact' and m.get('executable'))
cache=Path(artifact['executable'])
removed=False
if cache.exists() and cache!=p:
 assert hashlib.sha256(cache.read_bytes()).hexdigest()==digest
 cache.unlink();removed=True
receipt={'file':str(p),'sha256':digest,'physical_bytes_before':before.st_blocks*512,'physical_bytes_after':p.stat().st_blocks*512,'mode_and_mtime_unchanged':True,'profile':profile,'identical_disposable_build_copy_removed':removed}
(h/(label+'-prepared-binary-storage.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
