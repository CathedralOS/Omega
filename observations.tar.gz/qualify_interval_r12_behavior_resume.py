from pathlib import Path
import subprocess,sys,json,time,os
h=Path(__file__).parent;rows=[];producer='interval-window-r12'
commands=[
 ('recast-row-oracle-audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r12-recast-row']),
 ('shared',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r12-shared',producer,'interval-window-shared-sources-selection.json']),
 ('shared-audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r12-shared']),
 ('row',[sys.executable,str(h/'run_interval_row_integrated.py'),'interval-window-r12-row',producer]),
 ('controls',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r12-controls',producer,'interval-window-r10-other-controls-selection.json']),
 ('storage',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r12-storage',producer,'interval-window-r9-storage-selection.json']),
 ('audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r12-shared','interval-window-r12-row','interval-window-r12-controls','interval-window-r12-storage','interval-window-r12-recast','interval-window-r12-recast-row']),
 ('archive',[sys.executable,str(h/'archive_completed_producer.py'),producer]),
]
for name,command in commands:
 t=time.monotonic()
 with (h/('interval-window-r12-'+name+'-phase.stdout')).open('wb') as out,(h/('interval-window-r12-'+name+'-phase.stderr')).open('wb') as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL,env=dict(os.environ,AUDIT_OUTPUT_LABEL='interval-window-r12-'+name))
 rows.append({'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-t});(h/'interval-window-r12-behavior-resume.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,'exit',r.returncode,'seconds',round(rows[-1]['seconds'],2),flush=True)
 if r.returncode:
  print((h/('interval-window-r12-'+name+'-phase.stdout')).read_text()[-5000:]);print((h/('interval-window-r12-'+name+'-phase.stderr')).read_text()[-3000:]);sys.exit(r.returncode)
