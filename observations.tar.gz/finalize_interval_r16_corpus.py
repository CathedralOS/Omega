from pathlib import Path
import hashlib,json,subprocess,sys
h=Path(__file__).parent
sys.path.insert(0,str(Path.cwd()/'tools'))
import corpus_records as c
v=json.loads((h/'interval-window-r16-corpus-verdict.json').read_text())
i=json.loads((h/'interval-window-r16-corpus-input-record.json').read_text())
assert json.loads((h/'interval-window-r16-corpus-command.json').read_text())['exit']==0
assert v['counts']['fixtures']==119 and v['counts']['by_status']=={'checked':36,'rejected':83}
assert not v['counts']['wrong_reason'] and not v['oracle_failures'] and not v['infrastructure_error']
for name,digest in i['files'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
selected={r['fixture'] for r in v['observations']}
changed=subprocess.check_output(['git','diff','--name-only','674184316eba783ba3d8324aa1cdf6053b3be0cb','--','tests/omega'],text=True).splitlines()
edited=set()
for name in changed:
 p=Path(name)
 if name=='tests/omega/corpus_outcomes.txt':continue
 parent=p.parent
 while parent!=Path('tests/omega'):
  if (parent/'main.omg').exists():edited.add(str(parent.relative_to('tests/omega')));break
  parent=parent.parent
assert edited<=selected,sorted(edited-selected)
original=(h/'interval-window-r12-golden-before.txt').read_text()
final=c.splice(original,v['observations'])
def blocks(text):
 result={}; key=None
 for line in text.splitlines(keepends=True):
  if not line.strip() or line.startswith('#'):continue
  if line.startswith('\t'):assert key;result[key]+=line
  else:key=line.split()[0];assert key not in result;result[key]=line
 return result
old,new=blocks(original),blocks(final)
assert set(old)<=set(new)
assert all(new[k]==block for k,block in old.items() if k not in selected)
Path('tests/omega/corpus_outcomes.txt').write_text(final)
receipt={'purpose':'Record fresh R16 observations for affected fixtures. Retain unselected original blocks byte for byte. Earlier runs keep their actual source identities.','producer_source':i['producer_build']['source'],'producer_sha256':i['producer']['sha256'],'fixtures':119,'checked':36,'rejected':83,'wrong_reason':0,'edited_fixture_keys':sorted(edited),'unselected_blocks_unchanged':True,'restoration_unverified_behind_earlier_loan_errors':['fail/facts/recast_parent_restoration_dirty_forward_rejected','fail/facts/recast_parent_restoration_forwarding_marker_rejected'],'records':v['observations']}
(h/'interval-window-r16-qualified-corpus.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['records','edited_fixture_keys']}));print('Edited fixtures covered:',len(edited))
