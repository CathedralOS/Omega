A helper can now update a bounded field through a saved reference and restore the bound before returning. The compiler previously forgot the field's location and failed while producing executable code.

The compiler retains the original object and field, read/write permission, and indices captured when the reference was formed. Constructing another reference follows that record to the same storage. Real stored pointers retain their required loads. Saved shared, mutable and write-only references use one location planner, replacing the old recognizer limited to three child references.

All 18 fact examples pass `omega run --both` on macOS ARM64, with native and Terminal exits of zero. Their 36 invalid counterparts reject when the bound is missing or restoration is unfinished. Eight existing borrow regressions also agree in both engines; two controls reject using a parent while a child borrow remains live. [Hosted checking](https://github.com/CathedralOS/Omega/actions/runs/41774629213) accepts 24 programs and correctly rejects 37 controls. Rust checking and repository rules pass. Final independent review is being completed on the submitted commit.

The parent **CANONICALIZE-SCALAR-RANGE-CONTRACTS** migration remains open. Other hosted targets are authored but unexecuted here; GUI qualification remains deferred as requested.

<details>
<summary>Source and validation records</summary>

- Submitted candidate: `d565dc2cf4432f522e97fc3243ce47c24f8d05a0`; fixed publication base: `0378c9bcf14f9e63f4c4dd67bc60a0ec06da6cd2`.
- Observed executable producer: `cd5340c6d0348e868e34d68ee85f250c431f79ba`; CLI SHA-256 `02777d19f59b383102c937ddc9cd930d47196332853a7ec7696de56724a8f9fd`, optimization level 1.
- The later compiler edit removes only a duplicate lowering check of a marker already guaranteed by the checked producers. Independent source review verified unchanged behavior for valid checked plans. Observations keep their actual cd534 identity.
- The frozen baseline `2713116252386e98ce5e87961aca764f8760b217` refuses eight saved-reference places; const-name and the nine write-only examples already check. The first repair `d6448cfae742e9142043bacd0a2be6a3891820b6` still fails the mutable-reference examples; its failed run is retained.
- A first local setup inherited the wrong library path and invoked neither engine. The successful retry explicitly uses the fixed worktree's library. The additional Console fixtures completed ordinary package acceptance before execution.
- The 54 sample programs and Build files exactly match their corpus copies. All 162 authored input hashes remain unchanged. Only the 54 edited fixture rows were recorded; every other corpus row is untouched.
- [Readable result report](https://github.com/CathedralOS/Omega/blob/d565dc2cf4432f522e97fc3243ce47c24f8d05a0/wiki/drafts/measurements/saved_field_reference_calls.md). Raw receipts and the compact ledger remain in local `build/scalar-continue-20261102/saved-loans-completed-evidence-ledger.json`.
- Claim: `9a9869fd8c524252a3959f1a24cc0d6e`. Codex implementation and a separate Codex semantic reviewer. Scoped C5 Clippy results are retained with their unchanged patch identity; the changed C6 source passes hosted Rust checking.

</details>
