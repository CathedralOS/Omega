A constant helper could use its unfinished result to justify a call made while calculating that result. This rejects that circular proof and preserves calls whose preconditions can be established independently.

For example, a helper calculating a bound of seven may call a function whose input must fit a separately calculated bound. That works. If the requirement instead depends on the helper's own unfinished bound, checking rejects it. An earlier call's completed result can still justify the next arithmetic operation.

The compiler records whether each deferred check is a prerequisite or a check of a completed result. The evaluator and interpreter enforce that distinction, and serialized programs carry it explicitly. The change also preserves the ordinary checker's storage information when proving recursive calls terminate; losing that information had rejected a valid library layout calculation.

Fresh validation is running after resolving actual conflicts in the evaluation code and serialized format. The earlier R12 results remain tied to their original source: 48 Rust tests passed, 30 positives ran with native/Terminal agreement, and 28 invalid updates reached their intended proof error. Those results are not being claimed for the newly integrated compiler. Crash-capable bound helper admission remains open.

[Earlier R12 results and their source](https://github.com/CathedralOS/Omega/blob/4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2/wiki/drafts/measurements/constant_call_admission_2026_11_02.md) · [Retained source snapshots and raw results](https://github.com/CathedralOS/Omega/blob/f7790912afea928f7a4fbbbd412ca51991159e9c/README.md)

<details>
<summary>Current validation status</summary>

- Candidate: `4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2`, integrated on fixed main `e3c4ae4fb406f0a40e8988e2b79100ceeeaff5b3` after GitHub reported a real conflict.
- Source review found no blocking conflict-resolution issue. Fresh optimized R13 build, affected source/runtime checks, lint and final review remain pending.
- Format 238 combines explicit scalar-check roles and public returned-borrow regions; both incompatible earlier 237 layouts reject.
- Claim: `9a9869fd8c524252a3959f1a24cc0d6e`, CANONICALIZE-SCALAR-RANGE-CONTRACTS.
- GUI qualification and execution on other hosted targets are not claimed. Work performed by Codex with native collaboration agents.

</details>
