from pathlib import Path
import json,os,re,subprocess,sys
h=Path(__file__).parent;w=Path.cwd();label=sys.argv[1];producer=sys.argv[2];project=w/'tests/omega/pass/comptime/const_recursive_counter_survives_unrelated_writes';rows=[]
for action,args in [('update',['update','--project',str(project),'--offline']),('check',['--check',str(project/'main.omg')]),('both',['run',str(project/'main.omg'),'--both','--keep'])]:
 name=label+'-'+action;assert not(h/(name+'.json')).exists()
 result=subprocess.run([sys.executable,str(h/'run_cli.py'),name,*args],env=dict(os.environ,VALIDATION_PRODUCER=producer,VALIDATION_PROJECT=str(project.relative_to(w))),capture_output=True)
 assert result.returncode==0,result.stderr.decode(errors='replace')[-3000:]
 r=json.loads((h/(name+'.json')).read_text());raw=Path(r['stdout']).read_text()+Path(r['stderr']).read_text();passed=r['exit']==0
 if action=='both':passed=passed and re.findall(r'native exit (-?\d+)',raw)==['0'] and re.findall(r'interp exit: (-?\d+)',raw)==['0']
 rows.append({'action':action,'receipt':str(h/(name+'.json')),'exit':r['exit'],'passed':passed});(h/(label+'-summary.json')).write_text(json.dumps({'state':'running'if passed else'stopped_on_failure','observations':rows},indent=2)+'\n');print(action,'actual exit',r['exit'],'passed',passed,flush=True)
 if not passed:print(raw[-6500:],flush=True);sys.exit(1)
(h/(label+'-summary.json')).write_text(json.dumps({'state':'complete','observations':rows},indent=2)+'\n')
