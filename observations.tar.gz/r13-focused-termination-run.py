"""Run only after the parent supplies the verified R13 producer and digest."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
parser=argparse.ArgumentParser()
parser.add_argument('--producer',required=True)
parser.add_argument('--sha256',required=True)
args=parser.parse_args()
h=Path(__file__).parent
w=Path.cwd()
assert args.producer.startswith('pending-admission-r13'), 'R13 producer required'
binary=h/(args.producer+'-omega')
actual=hashlib.sha256(binary.read_bytes()).hexdigest()
assert actual==args.sha256, 'producer digest mismatch'
manifest_path=h/'r13-focused-termination-inputs.json'
manifest=json.loads(manifest_path.read_text())
assert len(manifest['fixtures'])==11
assert manifest['producer'] is None, 'this prepared run already began; preserve receipts'
for item in manifest['fixtures']:
    root=w/'tests/omega'/item['fixture']
    for name,details in item['files'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==details['sha256'],(item['fixture'],name)
        assert (root/name).read_bytes()==Path(details['frozen']).read_bytes()
manifest['producer']={'binary':str(binary),'sha256':actual}
manifest['execution_status']='running under parent-authorized producer'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
results=[]
for item in manifest['fixtures']:
    relative=item['fixture'];root=w/'tests/omega'/relative
    env=dict(os.environ,VALIDATION_PRODUCER=args.producer,VALIDATION_PROJECT=str(root))
    actions=[('update',['update','--project',str(root),'--offline']),('check',['--check',str(root/'main.omg')])]
    if item['runtime_both']:actions.append(('both',['run',str(root/'main.omg'),'--both','--keep']))
    outcomes={}
    for phase,arguments in actions:
        label='pending-admission-r13-focused-'+relative.replace('/','-')+'-'+phase
        receipt_path=h/(label+'.json');log=h/(label+'-helper.log')
        assert not receipt_path.exists() and not log.exists(), 'preserve existing evidence'
        print('START',label,flush=True)
        with log.open('w') as output:
            run=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*arguments],env=env,stdout=output,stderr=subprocess.STDOUT)
        if not receipt_path.exists():
            outcomes[phase]={'helper_exit':run.returncode,'helper_log':str(log),'setup_error':'receipt helper did not produce an execution record'}
        else:
            receipt=json.loads(receipt_path.read_text())
            assert receipt['producer']['sha256']==actual
            raw=Path(receipt['stdout']).read_text(errors='replace')+Path(receipt['stderr']).read_text(errors='replace')
            lower=raw.lower()
            setup=None
            if any(token in lower for token in ['compiler identity','compiler-identity','compiler_identity','compiler executable identity']):setup='compiler identity setup fence'
            elif phase=='update' and 'build.omg' in raw and 'entity not found' in raw:setup='fixture has no build.omg'
            outcomes[phase]={'exit':receipt['exit'],'seconds':receipt['seconds'],'receipt':str(receipt_path),'setup_error':setup}
            if phase=='check' and relative.startswith('fail/'):
                fragments=[line.strip() for line in (root/'expected.txt').read_text().splitlines() if line.strip()]
                missing=[part for part in fragments if part not in raw]
                outcomes[phase].update(expected_fragments=fragments,missing_fragments=missing,fact_sensitive_rejection=receipt['exit']!=0 and not missing and setup is None,known_stale_expected_fragment=item['known_stale_expected_fragment'])
            if phase=='both':
                outcomes[phase]['observed_native_exit_zero']='native exit 0' in raw
                outcomes[phase]['observed_interpreter_exit_zero']='interp exit: 0' in raw
        print('END',label,json.dumps(outcomes[phase]),flush=True)
    for name,details in item['files'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==details['sha256'],(relative,name)
    results.append({'fixture':relative,'known_stale_expected_fragment':item['known_stale_expected_fragment'],'outcomes':outcomes})
    (h/'r13-focused-termination-outcomes.json').write_text(json.dumps(results,indent=2)+'\n')
manifest['execution_status']='finished; outcomes require assessment, mismatched rejections remain uncredited'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print('FINISHED',len(results),'fixtures',sum(len(row['outcomes']) for row in results),'commands',flush=True)
