from pathlib import Path
import subprocess,json,time,hashlib,sys
h=Path(__file__).parent;label=sys.argv[1];head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();patch=subprocess.check_output(['git','diff','HEAD','--','omega-rust']);rows=[]
for name,command in [('cli',['cargo','clippy','--locked','-p','omega','--bin','omega']),('corpus',['cargo','clippy','--locked','-p','compiler','--test','corpus_runner'])]:
 t=time.monotonic()
 with (h/(label+'-'+name+'.stdout')).open('wb') as out,(h/(label+'-'+name+'.stderr')).open('wb') as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
 assert subprocess.check_output(['git','diff','HEAD','--','omega-rust'])==patch
 rows.append({'command':command,'exit':r.returncode,'seconds':time.monotonic()-t,'head':head,'patch_sha256':hashlib.sha256(patch).hexdigest()});(h/(label+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(name,'exit',r.returncode,flush=True)
 if r.returncode: print((h/(label+'-'+name+'.stderr')).read_text()[-4000:]);sys.exit(r.returncode)
