from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
commands=[
 [sys.executable,str(h/'run_guarded_customer_continuation_r21.py'),'guarded-crash-r22-controls','guarded-crash-r22'],
 [sys.executable,str(h/'run_guarded_recursive_control.py'),'guarded-crash-r22-recursion','guarded-crash-r22'],
 [sys.executable,str(h/'run_guarded_plain_control.py'),'guarded-crash-r22-unrelated','guarded-crash-r22','tests/omega/pass/facts/provider_contract_endpoint_control_unrelated_pending_target_contract'],
 [sys.executable,str(h/'run_guarded_candidate_units.py'),'guarded-crash-r22-units'],
]
for command in commands:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
