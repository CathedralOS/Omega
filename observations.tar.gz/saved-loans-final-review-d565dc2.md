# Review of saved field-reference calls

The compiler now lets a helper update a bounded field through a saved local
reference, restore the field, and return. The caller then proves its addition
from the record’s bound. The reviewed programs check the changed field and
unchanged neighbors; their two match paths produce distinct results.

I reviewed exact candidate `d565dc2cf4432f522e97fc3243ce47c24f8d05a0`
against fixed base `0378c9bcf14f9e63f4c4dd67bc60a0ec06da6cd2`.
No semantic or runtime blocker was found. Final acceptance is held for one
required evidence-retention item below. This is a read-only review; I did not
build or execute a compiler.

The checked producer records a saved loan’s original storage, path, access and
formation-time selectors before omitting its local descriptor. Reference
construction now consumes that record through the ordinary borrowed-argument
owner. Access attenuation and cycle/selector checks remain; real inner pointer
loads remain. The old source-shape recognizer is removed. Its exact old source
shape was not established by the bounded source search; the existing parent-call
and shared-child examples establish their observed behavior instead.

Actual executable source is `cd5340c6d0348e868e34d68ee85f250c431f79ba`.
Its CLI SHA-256 is
`02777d19f59b383102c937ddc9cd930d47196332853a7ec7696de56724a8f9fd`,
with embedded optimization level 1. The only compiler change since that source
removes a redundant check of an already-recorded outer reference crossing.
I independently inspected both producers of nonzero crossing counts: each
supplies the corresponding leading markers. Mechanical consumption leaves the
same path for valid checked input. Original observations retain their actual
producer identity. The final candidate changes only three documentation files
since checkpoint `87f08734fad57e85a383c83eff4a9547ce8a806e`.

I inspected all 18 raw public `run --both` command receipts: every one reports
native exit 0 and interpreter exit 0. The downloaded CLI digest matches the
hosted producer. All 162 frozen authored-input hashes match current files.
All 54 sample/fixture pairs have identical program and Build bytes. Every one
of the 36 sample refusal requirements matches the corresponding captured hosted
diagnostic. Hosted run `41774629213` records 24 accepted programs and 37
intended refusals with no wrong reasons, unsafe acceptances, lost successes or
oracle failures. These are scoped observations, not a whole-corpus pass.

I also inspected all eight extra engine receipts and their input hashes.
Both engines report each authored result, including exit 70 for selector order
and nested-record restoration. Both additional live-child controls reject with
their required borrow errors. The first wrong-library setup invoked neither
engine. The later Console update exit 3 was pending package acceptance;
subsequent receipts demonstrate the actual executions. Neither setup refusal
is counted as runtime evidence.

The corpus diff changes exactly the selected 54 fixture blocks, preserves every
unselected block, and removes no keys. The new report and both fact READMEs
explain the program behavior plainly and distinguish the eight repaired baseline
refusals from already-checking const-name and write-only coverage. The missing
predicate twins and unfinished-restoration twins exercise distinct obligations.
Branch selection, extreme input results and nonzero neighbors provide runtime
falsifiers. Other hosted targets remain unexecuted, GUI qualification is deferred,
and the parent scalar-contract migration remains open.

One blocking closeout item remains: `tools/testing.md` requires publishing the
retained replay bundle with PR evidence when recorded corpus rows name source
outside published main history. The new report currently names ignored local
receipts and the hosted Actions run, but gives no published replay-bundle or
claim-note location for `cd5340c6d0348e868e34d68ee85f250c431f79ba`.
Neither ordinary `build/corpus-source` location contains its bundle at review
time. Publish and verify that source bundle with the retained receipts through
the existing evidence route, then link it from the short report. This needs no
new compiler run. Acceptance can close after this item is supplied and verified.
