from pathlib import Path
import subprocess,sys
h=Path(__file__).parent;label=sys.argv[1]
commands=[
 [sys.executable,str(h/'compress_workbench_cache_small_first.py'),label+'-before-build'],
 [sys.executable,str(h/'build_guarded_failure_chain_v2.py'),label],
 [sys.executable,str(h/'prepare_saved_producer.py'),label],
 [sys.executable,str(h/'run_guarded_admission_customers.py'),label+'-customers',label],
 [sys.executable,str(h/'run_guarded_crash_qualification.py'),label+'-row',label],
]
for command in commands:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
