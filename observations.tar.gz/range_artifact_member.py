#!/usr/bin/env python3
"""Retrieve one GHA ZIP member without storing the whole archive."""
import argparse
from collections import OrderedDict
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import zipfile


class DownloadFailure(Exception):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, newurl):
        return None


def safe_http(opener, request):
    # urllib errors can contain a signed URL; callers receive only a status.
    try:
        return opener.open(request, timeout=40)
    except urllib.error.HTTPError as error:
        raise DownloadFailure("HTTP request refused with status " + str(error.code)) from None
    except Exception as error:
        raise DownloadFailure("HTTP transport failed: " + type(error).__name__) from None


def auth_token():
    result = subprocess.run(
        ["gh", "auth", "token", "--hostname", "github.com"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20, check=False,
    )
    token = result.stdout.decode("utf-8", errors="strict").strip()
    if result.returncode or not token or "\n" in token:
        raise DownloadFailure("gh authentication was unavailable")
    return token


def api_json(route, token):
    request = urllib.request.Request(
        "https://api.github.com/" + route,
        headers={"Authorization": "Bearer " + token,
                 "Accept": "application/vnd.github+json",
                 "X-GitHub-Api-Version": "2022-11-28"},
    )
    with safe_http(urllib.request.build_opener(NoRedirect), request) as response:
        if response.status != 200:
            raise DownloadFailure("GitHub metadata response was not 200")
        content = response.read(2 * 1024 * 1024 + 1)
        if len(content) > 2 * 1024 * 1024:
            raise DownloadFailure("GitHub metadata exceeded its byte limit")
    try:
        return json.loads(content)
    except (ValueError, UnicodeError):
        raise DownloadFailure("GitHub metadata was not JSON") from None


def archive_location(repo, artifact, token):
    request = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/actions/artifacts/{artifact}/zip",
        headers={"Authorization": "Bearer " + token,
                 "Accept": "application/vnd.github+json",
                 "X-GitHub-Api-Version": "2022-11-28"},
    )
    # Do not forward GitHub authorization onto the signed blob host.
    try:
        response = urllib.request.build_opener(NoRedirect).open(request, timeout=40)
    except urllib.error.HTTPError as response:
        if response.code != 302:
            raise DownloadFailure("GitHub archive redirect refused: HTTP " + str(response.code)) from None
        location = response.headers.get("Location", "")
        response.close()
    except Exception as error:
        raise DownloadFailure("GitHub archive redirect failed: " + type(error).__name__) from None
    else:
        response.close()
        raise DownloadFailure("GitHub archive endpoint did not return 302")
    parsed = urllib.parse.urlsplit(location)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise DownloadFailure("GitHub archive redirect was not an HTTPS blob location")
    return location


class RangeReader(io.RawIOBase):
    """A seekable bounded view; only checked ranges enter the in-memory LRU."""
    def __init__(self, url, size, block_bytes=1024 * 1024, cache_bytes=4 * 1024 * 1024,
                 max_requests=1024, max_transfer_bytes=320 * 1024 * 1024, opener=None):
        super().__init__()
        if (size <= 0 or not 0 < block_bytes <= 4 * 1024 * 1024
                or cache_bytes < block_bytes or cache_bytes > 64 * 1024 * 1024):
            raise DownloadFailure("Invalid ranged-reader size or cache limits")
        if (not 0 < max_requests <= 8192
                or not 0 < max_transfer_bytes <= 1024 * 1024 * 1024):
            raise DownloadFailure("Invalid ranged-reader transfer limits")
        self._url = url
        self._size = size
        self._block_bytes = block_bytes
        self._cache_capacity = cache_bytes // block_bytes
        self._cache = OrderedDict()
        self._offset = 0
        self._opener = opener or urllib.request.build_opener(NoRedirect)
        self._max_requests = max_requests
        self._max_transfer_bytes = max_transfer_bytes
        self.requests = 0
        self.transferred_bytes = 0
        self.maximum_cached_bytes = 0
        self.cache_hits = 0

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self._offset

    def seek(self, offset, whence=io.SEEK_SET):
        position = offset if whence == io.SEEK_SET else (
            self._offset + offset if whence == io.SEEK_CUR else (
                self._size + offset if whence == io.SEEK_END else -1))
        if position < 0 or position > self._size:
            raise DownloadFailure("ZIP requested an out-of-bounds seek")
        self._offset = position
        return position

    def _block(self, number):
        if number in self._cache:
            self.cache_hits += 1
            self._cache.move_to_end(number)
            return self._cache[number]
        start = number * self._block_bytes
        end = min(self._size, start + self._block_bytes) - 1
        expected = end - start + 1
        if expected <= 0:
            raise DownloadFailure("ZIP requested an invalid range")
        if self.requests >= self._max_requests:
            raise DownloadFailure("HTTP range request budget exhausted")
        if self.transferred_bytes + expected > self._max_transfer_bytes:
            raise DownloadFailure("HTTP range transfer budget exhausted")
        request = urllib.request.Request(
            self._url, headers={"Range": f"bytes={start}-{end}", "Accept-Encoding": "identity"})
        self.requests += 1
        with safe_http(self._opener, request) as response:
            if response.status != 206:
                raise DownloadFailure("Blob server did not honor HTTP Range with status 206")
            expected_range = f"bytes {start}-{end}/{self._size}"
            if response.headers.get("Content-Range") != expected_range:
                raise DownloadFailure("Blob Content-Range did not match the requested archive slice")
            if response.headers.get("Content-Length") != str(expected):
                raise DownloadFailure("Blob Content-Length did not match its range")
            if response.headers.get("Content-Encoding", "identity") not in ("", "identity"):
                raise DownloadFailure("Blob range used an unexpected content encoding")
            content = response.read(expected + 1)
        self.transferred_bytes += len(content)
        if len(content) != expected:
            raise DownloadFailure("Blob range had a truncated or oversized body")
        while len(self._cache) >= self._cache_capacity:
            self._cache.popitem(last=False)
        self._cache[number] = content
        self.maximum_cached_bytes = max(
            self.maximum_cached_bytes, sum(len(value) for value in self._cache.values()))
        return content

    def read(self, size=-1):
        if self.closed:
            raise DownloadFailure("ZIP attempted to read a closed range reader")
        size = self._size - self._offset if size is None or size < 0 else size
        size = min(size, self._size - self._offset)
        # ZIP central-directory allocation is bounded independently of the archive.
        if size > 8 * 1024 * 1024:
            raise DownloadFailure("ZIP read exceeded the 8 MiB allocation bound")
        result = bytearray()
        while len(result) < size:
            number, within = divmod(self._offset, self._block_bytes)
            block = self._block(number)
            length = min(size - len(result), len(block) - within)
            if length <= 0:
                raise DownloadFailure("ZIP range made no progress")
            result.extend(block[within:within + length])
            self._offset += length
        return bytes(result)

    def stats(self):
        return dict(requests=self.requests, transferred_bytes=self.transferred_bytes,
                    maximum_cached_bytes=self.maximum_cached_bytes, cache_hits=self.cache_hits,
                    block_bytes=self._block_bytes, cache_capacity_blocks=self._cache_capacity)

    def close(self):
        self._cache.clear()
        self._url = ""
        super().close()


def file_sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def optimized_profile(path):
    with path.open("rb") as source:
        magic = source.read(4)
    if magic not in (b"\x7fELF", b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf",
                     b"\xce\xfa\xed\xfe", b"\xfe\xed\xfa\xce") and magic[:2] != b"MZ":
        raise DownloadFailure("Extracted compiler is not a recognized executable image")
    os.chmod(path, 0o700)
    try:
        result = subprocess.run([str(path), "--build-profile"], stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    except Exception as error:
        raise DownloadFailure("Compiler profile query failed: " + type(error).__name__) from None
    if result.returncode or len(result.stdout) > 65536:
        raise DownloadFailure("Compiler profile query did not complete successfully")
    try:
        profile = json.loads(result.stdout)
    except (ValueError, UnicodeError):
        raise DownloadFailure("Compiler profile query did not return JSON") from None
    check_profile(profile)
    return profile


def check_profile(profile):
    if (not isinstance(profile, dict)
            or profile.get("schema") != "omega-compiler-build-profile-v1"
            or str(profile.get("opt_level")) not in ("1", "2", "3", "s", "z")):
        raise DownloadFailure("Compiler has an unknown or unoptimized profile")


def extract_one(archive, member, output, expected_sha, max_member_bytes, kind,
                expected_profile=None):
    if kind in ("cli", "runner") and (not expected_sha or expected_profile is None):
        raise DownloadFailure("Compiler extraction requires its frozen hash and profile")
    matches = [entry for entry in archive.infolist() if entry.filename == member]
    if len(matches) != 1:
        raise DownloadFailure("Selected ZIP member is absent or duplicated")
    entry = matches[0]
    if (entry.is_dir() or entry.flag_bits & 1
            or stat.S_ISLNK(entry.external_attr >> 16)
            or entry.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)):
        raise DownloadFailure("Selected ZIP member is not a supported ordinary file")
    if entry.file_size > max_member_bytes:
        raise DownloadFailure("Selected ZIP member exceeds the output size limit")
    if output.exists() or output.is_symlink():
        raise DownloadFailure("Output already exists; refusing to replace evidence")
    if shutil.disk_usage(output.parent).free < entry.file_size + 16 * 1024 * 1024:
        raise DownloadFailure("Insufficient free disk for the selected member and 16 MiB reserve")
    partial = output.with_name(output.name + ".partial")
    owned_partial = False
    try:
        descriptor = os.open(partial, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        owned_partial = True
        digest = hashlib.sha256()
        written = 0
        with os.fdopen(descriptor, "wb") as destination, archive.open(entry, "r") as source:
            while chunk := source.read(1024 * 1024):
                written += len(chunk)
                if written > entry.file_size or written > max_member_bytes:
                    raise DownloadFailure("Selected ZIP member exceeded its declared output size")
                destination.write(chunk)
                digest.update(chunk)
            destination.flush()
            os.fsync(destination.fileno())
        # Reading through EOF above makes ZipExtFile verify the complete CRC.
        if written != entry.file_size:
            raise DownloadFailure("Selected ZIP member ended before its declared size")
        actual_sha = digest.hexdigest()
        if expected_sha is not None and actual_sha != expected_sha:
            raise DownloadFailure("Extracted ZIP member SHA-256 did not match the frozen expectation")
        profile = optimized_profile(partial) if kind in ("cli", "runner") else None
        if profile is not None and profile != expected_profile:
            raise DownloadFailure("Compiler profile differs from the frozen summary")
        if file_sha256(partial) != actual_sha:
            raise DownloadFailure("Extracted member changed during profile inspection")
        # A same-directory hard link is atomic, creates no second data copy,
        # and refuses a competing writer instead of replacing its output.
        os.link(partial, output)
        partial.unlink()
        owned_partial = False
        return dict(bytes=written, sha256=actual_sha, zip_crc32=f"{entry.CRC:08x}",
                    compressed_bytes=entry.compress_size, profile=profile)
    finally:
        if owned_partial:
            partial.unlink(missing_ok=True)


def run(args, receipt):
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", args.repo):
        raise DownloadFailure("Invalid GitHub repository name")
    if not re.fullmatch(r"[0-9a-f]{40}", args.expected_source):
        raise DownloadFailure("Expected source must be one exact forty-digit Git revision")
    summary_content = args.summary.read_bytes()
    summary = json.loads(summary_content)
    if summary.get("candidate") != args.expected_source:
        raise DownloadFailure("Retained summary differs from the expected source revision")
    expected = args.expected_sha256
    producer = summary.get("producer", {})
    recorded_path = PurePosixPath(str(producer.get(args.kind, "")).replace("\\", "/"))
    if args.member is None:
        args.member = (str(PurePosixPath(recorded_path.parent.name) / recorded_path.name)
                       if args.kind in ("cli", "runner") else "summary.json")
    receipt["member"] = args.member
    if args.kind in ("cli", "runner"):
        producer = summary.get("producer", {})
        recorded = producer.get(args.kind + "_profile", {})
        if expected and expected != recorded.get("sha256"):
            raise DownloadFailure("Explicit SHA-256 differs from the summary producer")
        expected = recorded.get("sha256")
        check_profile(recorded.get("profile"))
        if recorded_path.name != PurePosixPath(args.member).name:
            raise DownloadFailure("Member basename differs from the summary producer")
    if args.observe_data and (args.kind != "data" or expected):
        raise DownloadFailure("First-observation mode is only for data without an expected SHA-256")
    if (not args.list and not args.observe_data
            and (not expected or not re.fullmatch(r"[0-9a-f]{64}", expected))):
        raise DownloadFailure("A frozen SHA-256 is required before extraction")
    receipt["summary_sha256"] = hashlib.sha256(summary_content).hexdigest()
    receipt["expected_sha256"] = expected
    token = auth_token()
    if args.artifact is None:
        run_record = api_json(f"repos/{args.repo}/actions/runs/{args.run}", token)
        if run_record.get("head_sha") != summary.get("candidate"):
            raise DownloadFailure("Workflow source differs from the frozen summary")
        name = (args.artifact_name or
                f"compiler-pilot-{summary.get('target')}-{summary.get('candidate')}-{run_record.get('run_attempt')}")
        listing = api_json(f"repos/{args.repo}/actions/runs/{args.run}/artifacts?per_page=100", token)
        if listing.get("total_count", 0) > 100:
            raise DownloadFailure("Run artifact listing is too large; supply an explicit artifact ID")
        matches = [artifact for artifact in listing.get("artifacts", [])
                   if artifact.get("name") == name and not artifact.get("expired")]
        if len(matches) != 1:
            raise DownloadFailure("Named producer artifact is absent or ambiguous")
        args.artifact = matches[0]["id"]
        receipt["artifact"] = args.artifact
    metadata = api_json(f"repos/{args.repo}/actions/artifacts/{args.artifact}", token)
    if args.artifact_name and metadata.get("name") != args.artifact_name:
        raise DownloadFailure("Artifact name differs from the expected named artifact")
    if metadata.get("id") != args.artifact or metadata.get("expired"):
        raise DownloadFailure("Artifact identity is wrong or expired")
    workflow = metadata.get("workflow_run", {})
    if workflow.get("id") != args.run:
        raise DownloadFailure("Artifact belongs to a different workflow run")
    if workflow.get("head_sha") != summary.get("candidate"):
        raise DownloadFailure("Artifact source differs from the frozen summary candidate")
    if args.kind in ("cli", "runner") and summary.get("producer", {}).get("revision") != workflow.get("head_sha"):
        raise DownloadFailure("Producer revision differs from the artifact source")
    size = metadata.get("size_in_bytes")
    if not isinstance(size, int) or size <= 0:
        raise DownloadFailure("Artifact metadata has no positive ZIP byte size")
    receipt["artifact_metadata"] = dict(id=metadata["id"], name=metadata["name"],
                                       zip_bytes=size, run=workflow["id"],
                                       source=workflow["head_sha"])
    location = archive_location(args.repo, args.artifact, token)
    token = ""  # Never write either credential or signed location to a receipt.
    reader = RangeReader(location, size, args.block_bytes, args.cache_bytes,
                         args.max_requests, args.max_transfer_bytes)
    location = ""
    try:
        with zipfile.ZipFile(reader) as archive:
            if args.list:
                receipt["members"] = [dict(name=entry.filename, bytes=entry.file_size,
                                            compressed_bytes=entry.compress_size)
                                      for entry in archive.infolist()]
            else:
                if args.output is None:
                    raise DownloadFailure("Extraction requires an output path")
                if args.member == "summary.json" and args.kind != "data":
                    raise DownloadFailure("A summary member must be extracted as data")
                receipt["extracted"] = extract_one(archive, args.member, args.output, expected,
                                                   args.max_member_bytes, args.kind,
                                                   recorded["profile"] if args.kind in ("cli", "runner") else None)
    finally:
        receipt["range_reader"] = reader.stats()
        reader.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default="CathedralOS/Omega")
    parser.add_argument("--run", type=int, required=True)
    parser.add_argument("--expected-source", required=True)
    parser.add_argument("--artifact", type=int)
    parser.add_argument("--artifact-name",
                        help="exact name when resolving the artifact from its workflow run")
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--member",
                        help="exact ZIP member; defaults to the summary's producer path, or summary.json")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--kind", choices=["data", "cli", "runner"], default="data")
    parser.add_argument("--expected-sha256")
    parser.add_argument("--observe-data", action="store_true",
                        help="retain first-observed data under ZIP CRC; never permits compiler extraction")
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--block-bytes", type=int, default=1024 * 1024)
    parser.add_argument("--cache-bytes", type=int, default=4 * 1024 * 1024)
    parser.add_argument("--max-requests", type=int, default=1024)
    parser.add_argument("--max-transfer-bytes", type=int, default=320 * 1024 * 1024)
    parser.add_argument("--max-member-bytes", type=int, default=256 * 1024 * 1024)
    args = parser.parse_args(argv)
    # Failure records are evidence too. Never replace an earlier one.
    if args.receipt.exists():
        parser.error("receipt already exists")
    receipt = dict(schema="omega-range-member-download-v1",
                   utc=datetime.now(timezone.utc).isoformat(), repo=args.repo,
                   run=args.run, expected_source=args.expected_source, artifact=args.artifact, member=args.member,
                   kind=args.kind, output=str(args.output) if args.output else None,
                   passed=False)
    try:
        run(args, receipt)
        receipt["passed"] = True
    except BaseException as error:
        # Do not stringify arbitrary urllib/zip errors: they may expose URLs.
        receipt["error"] = (str(error) if isinstance(error, DownloadFailure)
                            else type(error).__name__)
        if isinstance(error, OSError):
            receipt["errno"] = error.errno
    with args.receipt.open("x") as destination:
        destination.write(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ("passed", "artifact", "member")}
                     | {"receipt": str(args.receipt)}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
