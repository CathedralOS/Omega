from pathlib import Path
import json,subprocess,sys,time
h=Path(__file__).parent;rows=[]
commands=[
 ('row',[sys.executable,str(h/'run_interval_row_integrated.py'),'interval-window-r6-row-retry','interval-window-r6-integrated-link-retry']),
 ('controls',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r6-controls','interval-window-r6-integrated-link-retry','interval-window-integrated-controls.json']),
 ('storage',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r6-storage','interval-window-r6-integrated-link-retry','interval-window-storage-controls.json']),
 ('unit-tests',['cargo','nextest','run','--locked','-p','validation','-p','package-source','--lib','-E','test(declaration_predicates)']),
 ('compress-before-runner',[sys.executable,str(h/'compress_interval_cache.py'),'interval-window-r6-before-runner']),
 ('build-runner',[sys.executable,str(h/'build_corpus.py'),'interval-window-r6-runner']),
 ('prepare-runner',[sys.executable,str(h/'prepare_saved_producer.py'),'interval-window-r6-runner']),
]
for name,command in commands:
 t=time.monotonic()
 with (h/('interval-window-r6-retry-'+name+'.stdout')).open('wb') as out,(h/('interval-window-r6-retry-'+name+'.stderr')).open('wb') as err:
  r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
 row={'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-t};rows.append(row)
 (h/'interval-window-r6-retry-qualification-chain.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,'exit',r.returncode,'seconds',round(row['seconds'],2),flush=True)
 if r.returncode:
  print((h/('interval-window-r6-retry-'+name+'.stderr')).read_text()[-5000:]);sys.exit(r.returncode)
