from pathlib import Path
import json,sys
h=Path(__file__).parent;errors=[];counts={'positive_both':0,'negative':0,'negative_with_authored_fragments':0}
for label in sys.argv[1:]:
 data=json.loads((h/(label+'-summary.json')).read_text())
 for r in data['observations']:
  project=Path(r['project'])
  if r['positive']:
   counts['positive_both']+=1
   if r['update_exit']!=0 or r.get('runtime_exit')!=0:errors.append({'project':str(project),'failure':'acceptance or runtime exit','row':r});continue
   receipt=json.loads(Path(r['runtime_receipt']).read_text());text=Path(receipt['stderr']).read_text()
   if 'native exit 0' not in text or 'interp exit: 0' not in text:errors.append({'project':str(project),'failure':'missing engine observation','stderr':text})
  else:
   counts['negative']+=1
   receipt=json.loads(Path(r['update_receipt']).read_text());text=Path(receipt['stderr']).read_text()+Path(receipt['stdout']).read_text()
   metadata=project/'sample.json';oracle=project/'expected.txt';fragments=[]
   if metadata.exists():fragments=json.loads(metadata.read_text()).get('rejection_contains',[])
   elif oracle.exists():fragments=[s.strip() for s in oracle.read_text().splitlines() if s.strip() and not s.startswith('#')]
   if fragments:counts['negative_with_authored_fragments']+=1
   if r['update_exit']==0 or any(fragment not in text for fragment in fragments):errors.append({'project':str(project),'failure':'rejection or diagnostic mismatch','fragments':fragments,'exit':r['update_exit'],'diagnostic':text})
result={'counts':counts,'errors':errors};(h/'interval-window-r6-observation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(bool(errors))
