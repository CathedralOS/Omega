from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

records = Path(__file__).parent
source = 'f78c2623a68cf93044b0b38befd42e627a98667a'
base = '674184316eba783ba3d8324aa1cdf6053b3be0cb'
qualified = json.loads((records / 'interval-window-r16-qualified-corpus.json').read_text())
assert (qualified['fixtures'], qualified['checked'], qualified['rejected'], qualified['wrong_reason']) == (119, 36, 83, 0)
assert qualified['unselected_blocks_unchanged']
audit = json.loads((records / 'interval-window-r16-audit-observation-audit.json').read_text())
assert audit['counts']['positive_both'] == 37 and audit['counts']['negative'] == 44 and not audit['errors']
assert all(row['matched'] for row in json.loads((records / 'interval-window-r16-additional-rejection-fragments.json').read_text())['observations'])
for name in ['interval-window-r16-unit-tests.json', 'interval-window-r16-lint.json', 'interval-window-r16-rustfmt.json']:
    assert json.loads((records / name).read_text())['exit'] == 0
assert not json.loads((records / 'interval-window-r16-added-line-lint-review.json').read_text())['added_line_diagnostics']
assert not subprocess.check_output(['git', 'diff', source, '--', 'omega-rust', 'source/library', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'])

payload = records / 'interval-restoration-evidence-v2-payload'
assert not payload.exists()
payload.mkdir()
allowed = {'.json', '.stdout', '.stderr', '.patch', '.md', '.txt', '.lock', '.omg', '.py'}
files = set()
def add(path):
    if path.is_file() and path.suffix in allowed and path.stat().st_size < 100 * 1024 ** 2:
        files.add(path)
for path in records.glob('interval-window-*'):
    if path.is_dir():
        for child in path.rglob('*'):
            add(child)
    else:
        add(path)
for pattern in ['*interval*.py', 'pending-integer-formation-focused-selection-r13.*', 'returned-recast-marker-bound-scout-r12.md']:
    for path in records.glob(pattern):
        add(path)
for name in ['build_producer.py', 'build_corpus.py', 'run_cli.py', 'prepare_saved_producer.py', 'archive_completed_producer.py', 'archive_completed_producer_xz.py', 'remove_private_producer_aliases.py']:
    add(records / name)
# Retain the archival recipes for baseline binaries too.
for pattern in ['guarded-crash-r22-*-archived-producer.json', 'guarded-crash-r23-runner-*-archived-producer.json', 'guarded-crash-main-baseline-retry-runner-*-archived-producer.json']:
    for path in records.glob(pattern):
        add(path)
index = {str(path.relative_to(records)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)}
(payload / 'receipt-files.json').write_text(json.dumps(index, indent=2) + '\n')
archive = payload / 'observations.tar.gz'
with tarfile.open(archive, 'w:gz') as output:
    for path in sorted(files):
        output.add(path, arcname=str(path.relative_to(records)), recursive=False)

bundles = []
for name in ['interval-window-preintegration.bundle', 'interval-window-integrated-source.bundle', 'interval-window-qualified-source-' + source + '.bundle']:
    original = records / name
    target = payload / name
    shutil.copy2(original, target)
    header = []
    with target.open('rb') as input_file:
        for line in input_file:
            if line == b'\n':
                break
            header.append(line.decode().strip())
    bundles.append({'file': name, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'prerequisites': [line[1:].split()[0] for line in header if line.startswith('-')]})
manifest = {
    'qualified_compiler_source': source,
    'publication_base': base,
    'baseline_source': 'c5cc3d8749224ed1a76fa7abad1707dfd9f5dd1d',
    'baseline_accepted_source': '3bcdc2d9e3b81ab4af705b8c14d04a6f4021a8dd',
    'previous_evidence': ['3a3a4d53e122c3508075d50bb73ef3633055e13e', 'c03441063d2c5488948a77f61ef41660565288bb', '024779c6ffe4db42ec4ce3d9771f35b5377e36cd'],
    'execution_host': 'macos_arm64',
    'positive_both': 37,
    'negative_controls': 44,
    'corpus': {'fixtures': 119, 'checked': 36, 'rejected': 83, 'wrong_reason': 0, 'unsafe_acceptances': 0, 'lost_successes': 0, 'edited_fixture_keys': len(qualified['edited_fixture_keys']), 'unselected_blocks_unchanged': True},
    'rust_tests': 10,
    'rust_format_files': 36,
    'added_line_lint_diagnostics': 0,
    'source_bundles': bundles,
    'observations': {'file': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size, 'receipt_files': len(files)},
    'limits': 'Native and Terminal execution is observed on macOS ARM64. Two restoration controls reject at an earlier field-loan gate, and two stronger-predicate neighbors stop during layout preparation. Their later obligations remain unverified. The original baseline comparison remains exactly 40 fixtures. Parent migration and GUI qualification remain open or deferred as documented.',
    'preserved_attempts': 'Earlier semantic refusals, disk-full links, unsuccessful runner retries and the cleanup-helper failure remain recorded with their actual sources and results. Completed producer bytes are retained locally in verified lossless archives; their original digests, profiles and archival records are included.',
}
(payload / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(payload / '.gitattributes').write_text('*.bundle -text\n*.gz -text\n')
(payload / 'README.md').write_text('''# Record updates that restore their bounds

The compiler rejected helpers that temporarily exceeded a record's bound and
restored it before use or return. The qualified repair accepts those updates,
keeps requirements on untouched fields, and rejects unfinished restoration.
Atomic cells still check every write against their resident bound.

On macOS ARM64, 37 programs run with native and Terminal Psi exits of zero.
All 44 negative controls reject with their relevant diagnostic fragments.
The focused corpus checks 36 valid fixtures and rejects 83 invalid fixtures,
with no unsafe acceptance, wrong-reason refusal or lost success. Ten Rust tests
pass. Lint passes with no diagnostic on an added Rust line; 36 changed Rust files
pass formatting. Every edited fixture has a fresh record, and unselected
original corpus blocks remain unchanged.

The match test leaves a separate marker at 17 on one path and changes it to 29
on the forwarding path. It checks both outcomes and nonzero neighboring fields.
This exposed missing storage-aware arithmetic proof, missing associations from
viewed fields to original storage, and a preserved-checkpoint error after joins.
The frozen program stays unchanged through those repairs.

The manifest identifies the source, baseline and producer records. The source
bundles retain the qualified source and earlier checkpoints, with published Git
prerequisites. receipt-files.json hashes every file in observations.tar.gz.
Rebuild producers from those sources with the pinned optimized toolchain, and
replay the recorded commands with their authored project policy and inputs.
Original producer hashes, profiles and lossless archival records remain retained.

Two controls stop at an earlier field-loan restriction; two stronger-predicate
neighbors stop during layout preparation. Their later obligations remain
unverified. The parent scalar-range migration remains open. GUI qualification
is deferred at the user's request. Failed attempts retain their actual status.
This parentless evidence commit stays separate from feature and main history.
''')
index_path = records / 'interval-restoration-evidence-v2.index'
assert not index_path.exists()
environment = dict(os.environ, GIT_INDEX_FILE=str(index_path))
subprocess.run(['git', 'read-tree', '--empty'], env=environment, check=True)
for path in sorted(payload.iterdir()):
    blob = subprocess.check_output(['git', 'hash-object', '-w', '--no-filters', str(path)], text=True).strip()
    subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644,' + blob + ',' + path.name], env=environment, check=True)
tree = subprocess.check_output(['git', 'write-tree'], env=environment, text=True).strip()
index_path.unlink()
commit = subprocess.check_output(['git', 'commit-tree', tree], input='tests: retain record restoration observations\n\nKeep qualified programs, invalid controls and replay inputs with their actual producers.\nRetain failed attempts separately from successful results.\n', text=True).strip()
reference = 'refs/evidence/record-restoration-20261103/' + commit
subprocess.run(['git', 'update-ref', reference, commit], check=True)
receipt = {'commit': commit, 'ref': reference, 'payload': str(payload), **manifest}
(records / 'interval-restoration-evidence-v2-prepared.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'commit': commit, 'ref': reference, 'receipt_files': len(files), 'archive_bytes': archive.stat().st_size, 'bundles': len(bundles)}))
