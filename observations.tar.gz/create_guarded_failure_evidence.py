from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
h=Path(__file__).parent
source='2273a67852265ff8215d373b029f3be7532f275a'
assert json.loads((h/'guarded-crash-r20-executable-qualification-summary.json').read_text())['state']=='complete_for_executed_witnesses'
assert json.loads((h/'guarded-crash-r20-corpus-completion-summary.json').read_text())['counts']['fixtures']==32
assert all(row['exit']==0 for row in json.loads((h/'guarded-crash-r20-clippy.json').read_text()))
payload=h/'constant-crash-evidence-payload';assert not payload.exists();payload.mkdir()
allowed={'.json','.stdout','.stderr','.patch','.md','.omg','.txt','.lock','.py'};files=set()
def add(path):
 if path.is_file() and path.suffix in allowed and path.stat().st_size<30*1024**2 and 'next-witness' not in path.name and 'staged' not in path.name:files.add(path)
for pattern in ['guarded-*','r16-*','*guarded*.py']:
 for path in h.glob(pattern):
  if path.is_dir():
   for child in path.rglob('*'):add(child)
  else:add(path)
for name in ['build_producer.py','build_corpus.py','run_cli.py','run_prerequisite_lint.py','prepare_saved_producer.py','compress_workbench_cache_small_first.py','pending-admission-r13-producer.json','pending-admission-r13-build.json','pending-admission-r13-source.patch','pending-admission-r13-cargo.stdout','pending-admission-r13-cargo.stderr','pending-admission-r13-omega.compiler-profile.json']:
 add(h/name)
for path in h.glob('pending-admission-r13-next-gap-crashing-endpoint-*'):add(path)
queue=list(files);seen=set()
while queue:
 path=queue.pop()
 if path in seen:continue
 seen.add(path)
 if path.suffix!='.json':continue
 try:data=json.loads(path.read_text())
 except(ValueError,UnicodeDecodeError):continue
 def walk(value):
  if isinstance(value,dict):
   for child in value.values():walk(child)
  elif isinstance(value,list):
   for child in value:walk(child)
  elif isinstance(value,str)and value.startswith(str(h)+'/')and len(value)<1024 and '\n'not in value:
   candidate=Path(value);before=len(files);add(candidate)
   if len(files)>before:queue.append(candidate)
 walk(data)
for path in list(files):
 if path.suffix=='.json':
  stem=path.with_suffix('')
  for suffix in ['.stdout','.stderr','-input.omega.lock','-output.omega.lock']:add(Path(str(stem)+suffix))
file_hashes={str(path.relative_to(h)):hashlib.sha256(path.read_bytes()).hexdigest()for path in sorted(files)}
(payload/'receipt-files.json').write_text(json.dumps(file_hashes,indent=2)+'\n')
archive=payload/'observations.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for path in sorted(files):tar.add(path,arcname=str(path.relative_to(h)))
original=Path.cwd()/'build/corpus-source'/(source+'.bundle');assert original.exists();bundle=payload/original.name;shutil.copy2(original,bundle);assert bundle.read_bytes()==original.read_bytes()
header=[]
with bundle.open('rb')as stream:
 while True:
  line=stream.readline()
  if line in(b'\n',b''):break
  header.append(line.decode().strip())
prerequisites=[line[1:].split()[0]for line in header if line.startswith('-')]
metadata={'source':source,'source_bundle':{'file':bundle.name,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'exported_ref':'refs/corpus-observations/'+source,'prerequisites':prerequisites},'observations':{'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'receipt_files':len(files)},'producer':'R20 CLI and runner were built from exact source2273a67852265ff8215d373b029f3be7532f275a with empty compiler-input patches; both verified opt-level1. Their original receipts preserve exact binary digests.','source_boundary':'The source bundle retains code history. The archive includes the twelve-file oracle working-tree patch, exact fixture/oracle copies, lock replay inputs and original +wt stamps. Working-tree observations are not relabeled as clean source.','history':'Intermediate build/test failures, the deliberately canceled slow prototype, the corrected CLI exit70 classification and the initial stale-lock corpus refusal remain explicit and uncredited. The qualified corpus combines29 completed observations with3 fresh completion observations, totaling16 checks and16 intended rejects.','scope':'Raw evidence only. This parentless evidence commit is outside the feature branch and main history.'}
(payload/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
(payload/'.gitattributes').write_text('*.bundle -text\n*.gz -text\n')
(payload/'README.md').write_text('''# Constant calls must be safe before execution

A helper used to calculate a range limit must not run into a trap before the
compiler rejects it. These records show that the repaired compiler admits safe
calls and refuses unsafe calls first.

All nine guarded examples run with native and Terminal exit zero on macOS ARM64.
Their nine twins reject the Trap route through limit before execution. The
ordinary runtime control still traps, and the layout customers retain exits zero
and 70. Five source admission tests and eight unchanged saved-program tests pass.
The focused corpus qualifies 32 fixtures: 16 checks and 16 intended rejects,
including actual execution and inspection of the saved calling policy.

The initial 30-fixture attempt includes one stale accepted compiler lock; that
setup refusal receives no semantic credit. Normal update and native/Terminal
execution of that recursion control pass, followed by three fresh corpus checks.
The other 29 completed observations retain their original records. The initial
wrapper also misclassified the correct CLI exit 70; its correction uses the
completed engine observations without repeating them.

The manifest binds the source bundle and archive. receipt-files.json binds every
archived file. Producer receipts give actual revisions, patches, optimized
profiles and binary digests. Intermediate failures remain unchanged and labeled.
The +wt oracle patch, exact fixture inputs and accepted-lock replay inputs are
included; a clean-source stamp is not substituted for a dirty observation.

The bundle exports the measured source under refs/corpus-observations. Restore
its listed published prerequisites before fetching that bundle. Raw data is kept
in this separate evidence commit; the feature PR carries only a readable summary.
''')
index=h/'constant-crash-evidence.index';assert not index.exists();environment=dict(os.environ,GIT_INDEX_FILE=str(index))
subprocess.run(['git','read-tree','--empty'],env=environment,check=True)
for path in sorted(payload.iterdir()):
 blob=subprocess.check_output(['git','hash-object','-w','--no-filters',str(path)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644,'+blob+','+path.name],env=environment,check=True)
tree=subprocess.check_output(['git','write-tree'],env=environment,text=True).strip();index.unlink()
message='tests: retain constant-call failure admission evidence\n\nPreserve exact source, execution observations and replay inputs separately\nfrom code history. Safe bound helpers run and unsafe calls refuse before\nexecution; intermediate failures remain explicit.\n'
commit=subprocess.check_output(['git','commit-tree',tree],input=message,text=True).strip();ref='refs/evidence/constant-crash-admission-20261102/'+commit
subprocess.run(['git','update-ref',ref,commit],check=True)
record={'commit':commit,'tree':tree,'ref':ref,'payload':str(payload),**metadata};(h/'constant-crash-evidence-prepared.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'commit':commit,'ref':ref,'receipt_files':len(files),'archive_bytes':archive.stat().st_size,'bundle_bytes':bundle.stat().st_size}))
