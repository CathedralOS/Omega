# Prepared only: execute after the parent confirms R13 producer readiness and
# the folded customer's successful ordinary update. This helper performs no build.
from pathlib import Path
import datetime,hashlib,json,os,platform,re,subprocess,sys
w=Path.cwd();h=Path(__file__).parent;root=w/'samples/cli/facts/provider_contract_endpoint';producer=json.loads((h/'pending-admission-r13-producer.json').read_text());revision='4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2'
assert producer['source']==revision and producer['patch_sha256']==hashlib.sha256(b'').hexdigest() and producer['exit']==0
assert Path(producer['executable']['binary']).resolve()==(h/'pending-admission-r13-omega').resolve()
assert re.fullmatch(r'[0-9a-f]{64}',producer['executable']['sha256'])
sys.path.insert(0,str(w/'tools'));import compiler_profile;assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable']
assert not subprocess.check_output(['git','diff','--name-only',revision,'--','omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml'])
places=['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body'];jobs=[];files={}
for row in ['original','closed_owner','pending_call']:
 for place in places:
  for invalid in [False,True]:
   base=root if row=='original' else root/row;project=base/place/('invalid' if invalid else '');prefix='provider_contract_endpoint'+('' if row=='original' else '_'+row)+'_through_'+place;pin=w/('tests/omega/fail/facts' if invalid else 'tests/omega/pass/facts')/(prefix+('_rejected' if invalid else '_exit'));jobs.append({'name':row+'-'+place+('-invalid' if invalid else '-positive'),'group':row,'project':project,'pin':pin,'invalid':invalid})
for name,fixture in [('earlier_operand','earlier_operand_exit'),('dormant_target_endpoint_positive','dormant_target_endpoint_positive'),('unrelated_pending_target_contract','unrelated_pending_target_contract')]:
 jobs.append({'name':name+'-positive','group':'positive_controls','project':root/'controls'/name,'pin':w/'tests/omega/pass/facts'/('provider_contract_endpoint_control_'+fixture),'invalid':False})
jobs.append({'name':'original-circular-invalid','group':'original_circular','project':root/'controls/circular_endpoint_formation','pin':w/'tests/omega/fail/facts/provider_contract_endpoint_control_circular_endpoint_formation','invalid':True})
for job in jobs:
 for name in ['main.omg','build.omg']:
  assert (job['project']/name).read_bytes()==(job['pin']/name).read_bytes(),str(job['pin']/name)
  for p in [job['project']/name,job['pin']/name]:files[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 oracle=job['pin']/('expected.txt' if job['invalid'] else 'expected_native_exit.txt');files[str(oracle)]=hashlib.sha256(oracle.read_bytes()).hexdigest();job['fragments']=[s for s in oracle.read_text().splitlines() if s.strip()] if job['invalid'] else []
 if not job['invalid']:assert oracle.read_text().strip()=='0' and '// Expected exit: 0' in (job['project']/'main.omg').read_text()
assert len(jobs)==58 and len(files)==290
r12_inputs=h/'pending-admission-r12-integrated-qualification-inputs.json';r12_manifest=json.loads(r12_inputs.read_text());assert files==r12_manifest['files'], 'A program, Build file or oracle changed since frozen R12 qualification'
assert jobs[-1]['fragments']==['constant invocation cannot establish its own pending target condition','requires contract for call need from limit']
manifest={'kind':'R13 integrated qualification frozen source inputs','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':producer,'files':files,'integration_reason':'Actual merge conflicts required targeted integration with main e3c4ae4fb406f0a40e8988e2b79100ceeeaff5b3. These are fresh R13 observations from exact integrated source 4b50, not relabeled R12 outcomes.','compiler_patch_sha256':hashlib.sha256(b'').hexdigest(),'previous_R12_input_manifest':str(r12_inputs),'previous_R12_input_manifest_sha256':hashlib.sha256(r12_inputs.read_bytes()).hexdigest(),'source_equivalence':'All 290 program, Build and oracle hashes equal the frozen R12 inputs.','jobs':[dict(name=j['name'],group=j['group'],project=str(j['project']),pin=str(j['pin']),invalid=j['invalid'],expected_fragments=j['fragments']) for j in jobs]};mp=h/'pending-admission-r13-integrated-qualification-inputs.json';assert not mp.exists();mp.write_text(json.dumps(manifest,indent=2)+'\n')
summary={'state':'running','producer':producer,'input_manifest':str(mp),'input_manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'host':platform.system()+'/'+platform.machine(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observations':[],'failure':None};sp=h/'pending-admission-r13-integrated-qualification-summary.json'
def save():
 temporary=sp.with_suffix('.json.tmp');temporary.write_text(json.dumps(summary,indent=2)+'\n');temporary.replace(sp)
def verify():
 for name,digest in files.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
try:
 save()
 for job in jobs:
  project=job['project'];invalid=job['invalid'];actions=[('update',['update','--project',str(project),'--offline']),('check',['--check',str(project/'main.omg')])]
  if not invalid:actions.append(('both',['run',str(project/'main.omg'),'--both','--keep']))
  for action,args in actions:
   verify();label='pending-admission-r13-integrated-'+job['name']+'-'+action;assert not (h/(label+'.json')).exists()
   wrapper=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],cwd=w,env=dict(os.environ,VALIDATION_PRODUCER='pending-admission-r13',VALIDATION_PROJECT=str(project.relative_to(w))),capture_output=True)
   if wrapper.returncode!=0:raise RuntimeError(label+': wrapper failed: '+wrapper.stderr.decode(errors='replace')[-2500:])
   d=json.loads((h/(label+'.json')).read_text());assert d['producer']==producer['executable'];assert set(d['inputs'])=={str(project/'main.omg'),str(project/'build.omg')}
   for name,digest in d['inputs'].items():assert files[name]==digest
   raw=Path(d['stdout']).read_text()+Path(d['stderr']).read_text();item={'name':job['name'],'group':job['group'],'invalid':invalid,'action':action,'exit':d['exit'],'wrapper_exit':wrapper.returncode,'receipt':str(h/(label+'.json')),'diagnostic_tail':raw[-2800:]}
   if invalid:
    item['expected_fragments']=job['fragments'];item['expected_fragments_present']=all(f in raw for f in job['fragments']);item['setup_refusal']=action=='check' and d['exit']!=0 and not item['expected_fragments_present'] and 'compiler identity changed; run `omega update` for fresh review before compiling' in raw
   if action=='both':item['native_exits']=re.findall(r'native exit (-?\d+)',raw);item['terminal_exits']=re.findall(r'interp exit: (-?\d+)',raw);item['actual_agreement_zero']=d['exit']==0 and item['native_exits']==['0'] and item['terminal_exits']==['0']
   summary['observations'].append(item);save();print(job['name'],action,'actual exit',d['exit'],'engine agreement',item.get('actual_agreement_zero','n/a'),'proof fragments',item.get('expected_fragments_present','n/a'),'setup fence',item.get('setup_refusal',False),flush=True)
   if not invalid and (d['exit']!=0 or (action=='both' and not item['actual_agreement_zero'])):raise RuntimeError(label+': positive failed: '+raw[-2300:])
   if invalid and action=='update' and (d['exit']==0 or not item['expected_fragments_present']):raise RuntimeError(label+': negative accepted or update refused for unrelated reason: '+raw[-2300:])
   if invalid and action=='check' and (d['exit']==0 or (not item['expected_fragments_present'] and not item['setup_refusal'])):raise RuntimeError(label+': negative accepted or check refused for unrelated reason: '+raw[-2300:])
 verify();assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable'];summary['state']='complete';summary['frozen_inputs_unchanged']=True
except BaseException as error:
 summary['state']='stopped_on_failure';summary['failure']=repr(error);print('STOP',repr(error),flush=True);raise
finally:
 obs=summary['observations'];summary['counts']={}
 for group in ['original','closed_owner','pending_call','positive_controls','original_circular']:
  rows=[x for x in obs if x['group']==group];summary['counts'][group]={'positive_source_checks':sum(not x['invalid'] and x['action']=='check' and x['exit']==0 for x in rows),'actual_native_terminal_zero_agreements':sum(x.get('actual_agreement_zero',False) for x in rows),'negative_update_proof_refusals':sum(x['invalid'] and x['action']=='update' and x['exit']!=0 and x['expected_fragments_present'] for x in rows),'negative_check_proof_refusals':sum(x['invalid'] and x['action']=='check' and x['exit']!=0 and x['expected_fragments_present'] for x in rows),'negative_check_setup_refusals':sum(x.get('setup_refusal',False) for x in rows),'wrong_accepts':sum(x['invalid'] and x['exit']==0 for x in rows)}
 summary['finished_or_yielded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(summary['counts']),flush=True)
