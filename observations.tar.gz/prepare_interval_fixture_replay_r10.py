from pathlib import Path
import json,subprocess,hashlib,shutil
h=Path(__file__).parent;selection=json.loads((h/'interval-window-r10-final-corpus-selection.json').read_text());overlay=h/'interval-window-r10-prior-fixture-acceptance';overlay.mkdir();rows=[]
for key in selection['fixtures']:
 if not key.startswith('pass/'):continue
 p=Path('tests/omega')/key/'omega.lock'
 if not p.exists():continue
 assert subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0,str(p)
 q=overlay/key/'omega.lock';q.parent.mkdir(parents=True);shutil.copy2(p,q);rows.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'retained_copy':str(q)});p.unlink()
record={'purpose':'Prepare selected fixture projects without stale generated review state, before capture. The ordinary fixture discovery and repository test-consent path still runs; no compiler admission rule or authored acceptance file is changed. Prior ignored locks are retained byte for byte.','files':rows};(h/'interval-window-r10-fixture-replay-preparation.json').write_text(json.dumps(record,indent=2)+'\n');print('Retained and removed',len(rows),'stale or prior generated fixture locks')
