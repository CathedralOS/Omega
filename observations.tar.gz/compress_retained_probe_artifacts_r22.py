from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
h=Path(__file__).parent;roots=set();rows=[];scanned=0
for log in [*h.glob('*.stdout'),*h.glob('*.stderr')]:
 receipt=log.with_suffix('.json')
 if not receipt.exists():continue
 for name in re.findall(r'^build dir kept: (/.+)$',log.read_text(errors='replace'),re.M):
  root=Path(name)
  if root.name.startswith('omega-probe-') and root.is_dir() and '/T/' in str(root):roots.add(root)
for root in sorted(roots):
 for p in root.rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  before=p.stat();scanned+=1
  if before.st_size<512*1024 or before.st_blocks*512<before.st_size//2:continue
  digest=hashlib.sha256(p.read_bytes()).hexdigest();temporary=p.with_name(p.name+'.lossless-storage-copy')
  r=subprocess.run(['ditto','--hfsCompression',str(p),str(temporary)],capture_output=True)
  assert r.returncode==0,(str(p),r.stderr)
  after=temporary.stat();assert (before.st_size,before.st_mtime_ns,before.st_mode)==(after.st_size,after.st_mtime_ns,after.st_mode)
  assert hashlib.sha256(temporary.read_bytes()).hexdigest()==digest
  saved=max(0,(before.st_blocks-after.st_blocks)*512)
  if saved:os.replace(temporary,p)
  else:temporary.unlink()
  rows.append({'file':str(p),'sha256':digest,'saved_bytes':saved})
record={'purpose':'Lossless transparent compression of completed probe artifacts named by this session receipts. No artifacts removed. Bytes, mode and modification time verified unchanged; current Cargo output untouched.','completed_probe_directories':len(roots),'files_scanned':scanned,'files':rows,'saved_bytes':sum(r['saved_bytes'] for r in rows),'free_bytes':shutil.disk_usage(h).free}
(h/'guarded-crash-retained-probe-storage-r22.json').write_text(json.dumps(record,indent=2)+'\n');print('Retained artifacts unchanged; freed',record['saved_bytes']//1024**2,'MiB; available',record['free_bytes']//1024**2,'MiB.',flush=True)
