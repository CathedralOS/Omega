from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
for command in [[sys.executable,str(h/'prepare_saved_producer.py'),'guarded-crash-main-baseline-retry-runner'],[sys.executable,str(h/'run_exact_main_policy_baseline.py')]]:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
