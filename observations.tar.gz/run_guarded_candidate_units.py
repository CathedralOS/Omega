from pathlib import Path
import subprocess,json,time,hashlib,sys
h=Path(__file__).parent;label=sys.argv[1];head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();patch=subprocess.check_output(['git','diff','HEAD','--','omega-rust']);(h/(label+'-source.patch')).write_bytes(patch)
command=['cargo','nextest','run','--locked','--lib','-p','build-time-evaluation','-p','terminal-installation','-p','package-source','-E','test(source_admission) | test(source_failure_summary) | test(source_empty_failure_summary) | test(compiler_evaluation::failures)']
t=time.monotonic()
with (h/(label+'.stdout')).open('wb') as out,(h/(label+'.stderr')).open('wb') as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
assert subprocess.check_output(['git','diff','HEAD','--','omega-rust'])==patch
receipt={'command':command,'exit':r.returncode,'seconds':time.monotonic()-t,'head':head,'patch_sha256':hashlib.sha256(patch).hexdigest()};(h/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((h/(label+'.stderr')).read_text()[-5000:]);sys.exit(r.returncode)
