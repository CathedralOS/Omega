from pathlib import Path
import hashlib,json,os,subprocess,sys,time
h=Path(__file__).parent;label=sys.argv[1];producer_label=sys.argv[2]
sys.path.insert(0,str(Path.cwd()/'tools'));import corpus_records as records;import compiler_profile
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
producer=json.loads((h/(producer_label+'-producer.json')).read_text());runner=h/(producer_label+'-omega')
assert compiler_profile.require_optimized(runner)==producer['executable']
keys=sorted(set(json.loads((h/'guarded-crash-focused-selection.json').read_text())['fixtures']) | {'pass/facts/provider_contract_endpoint_control_unrelated_pending_target_contract','fail/facts/provider_contract_endpoint_control_circular_endpoint_formation'});assert len(keys)==32
inputs={};locks={};overlay=h/(label+'-input-files');assert not overlay.exists();overlay.mkdir()
(h/(label+'-working-tree.patch')).write_bytes(subprocess.check_output(['git','diff','HEAD']))
for key in keys:
 root=Path('tests/omega')/key
 for path in [*root.glob('*.omg'),*root.glob('expected*.txt')]:
  payload=path.read_bytes();inputs[str(path)]=hashlib.sha256(payload).hexdigest();target=overlay/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
 lock=root/'omega.lock';payload=lock.read_bytes()if lock.exists()else None;locks[str(lock)]={'present':payload is not None,'sha256':hashlib.sha256(payload).hexdigest()if payload is not None else None}
 if payload is not None:target=overlay/lock;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
source=Path('tests/omega/corpus_outcomes.txt');before=source.read_text();old_rows={row['fixture']:row for row in records.parse(before)}
stage=h/(label+'-staged.txt');assert not stage.exists();stage.write_text(before)
(h/(label+'-inputs.json')).write_text(json.dumps({'source':revision,'producer':producer,'fixtures':keys,'files':inputs,'locks':locks,'host_provisions':True},indent=2)+'\n')
command=[sys.executable,'tools/corpus_gate.py','--runner',str(runner),'--filter',','.join(keys),'--golden',str(stage),'--record','--json',str(h/(label+'-verdict.json'))];t=time.monotonic()
with(h/(label+'.stdout')).open('wb')as out,(h/(label+'.stderr')).open('wb')as err:
 result=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL,env=dict(os.environ,OMEGA_CORPUS_HOST_PROVISIONS='1'))
(h/(label+'-command.json')).write_text(json.dumps({'command':command,'environment':{'OMEGA_CORPUS_HOST_PROVISIONS':'1'},'exit':result.returncode,'seconds':time.monotonic()-t},indent=2)+'\n')
verdict=json.loads((h/(label+'-verdict.json')).read_text());print('Corpus actual exit',result.returncode,'counts',verdict['counts'],flush=True)
assert result.returncode==0
assert verdict['counts']['fixtures']==32 and verdict['counts']['by_status']=={'checked':16,'rejected':16}
assert not verdict['counts']['wrong_reason'] and not verdict['oracle_failures']
policy=next(row for row in verdict['observations']if row['fixture']=='pass/build/terminal_calling_policy_execution')
assert policy['facts']['terminal-runtime.retained_plan']=='match' and policy['facts']['terminal-inspections']=='match'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==revision
for name,digest in inputs.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
adjusted=[];timings=[];fields=['status','expected_satisfied','facts','diagnostics','regressed_from']
for row in records.read(stage):
 if row['fixture']not in keys:continue
 old=old_rows.get(row['fixture'])
 if old is not None and all(row.get(field)==old.get(field)for field in fields):
  timings.append({'fixture':row['fixture'],'fresh_millis':row['millis'],'retained_millis':old['millis']});row['millis']=old['millis'];adjusted.append(row)
final=records.splice(stage.read_text(),adjusted);new_rows={row['fixture']:row for row in records.parse(final)}
assert set(old_rows).issubset(new_rows)
assert set(new_rows)-set(old_rows)==set(keys)-set(old_rows)
def blocks(text):
 result={};key=None
 for line in text.splitlines(keepends=True):
  if not line.strip()or line.startswith('#'):continue
  if line.startswith('\t'):assert key;result[key]+=line
  else:key=line.split()[0];assert key not in result;result[key]=line
 return result
old_blocks=blocks(before);new_blocks=blocks(final)
assert all(old_blocks[key]==new_blocks[key]for key in old_blocks if key not in keys)
source.write_text(final)
(h/(label+'-golden-guard.json')).write_text(json.dumps({'source':revision,'selected_fixture_count':len(keys),'keys_added':sorted(set(new_rows)-set(old_rows)),'no_keys_removed':True,'unselected_blocks_byte_identical':True,'timing_restorations':timings,'policy_runtime':policy['facts'],'raw_measurement_preserved':str(h/(label+'-verdict.json'))},indent=2)+'\n')
