from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
for command in [
 [sys.executable,str(h/'finish_guarded_admission_corpus.py'),'guarded-crash-r20-corpus-completion','guarded-crash-r20-runner'],
 [sys.executable,str(h/'run_prerequisite_lint.py'),'guarded-crash-r20-clippy'],
]:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
