# R12 focused termination execution

Executed exactly the nine fixtures assigned after the parent took the folded wrapper. No optional fixture expansion, Rust edits, source/golden edits, HEAD changes, or builds were performed. The parent separately reported the wrapper update passed; its runtime result is outside this report.

Producer: pending-admission-r12-omega, SHA256 a8c921d8ce448cf36da92e35442b00e04d342ab576e318e7ba2f24d7420174ce, verified opt-level 1 by run_cli.py before and after each invocation. Every command used VALIDATION_PRODUCER=pending-admission-r12 and the exact fixture as VALIDATION_PROJECT. The receipt helper retained command, binary profile, source hashes, elapsed time, stdout, stderr, and input/output locks when present.

The 20 invocations comprised nine offline update attempts, nine source checks, and two run --both commands. All four positive source checks passed. Both runtime-positive controls observed native exit 0 and interpreter exit 0. All five negative checks rejected, but only three matched all retained expected.txt fragments. Two diagnostic mismatches remain uncounted as golden-matched controls. No compiler-identity setup fence occurred.

| Fixture | Offline update | Source check | Execution / retained diagnostic |
| --- | --- | --- | --- |
| pass/comptime/const_joint_ranked_call_component | 0 | 0 | --both exit 0; observed native 0 / interpreter 0 |
| pass/termination/runtime_joint_rank_computed_copy_exit | 0 | 0 | --both exit 0; observed native 0 / interpreter 0 |
| pass/termination/proof_non_tail_joint_machine_cycle_compile | 1: no build.omg | 0 | Checking only |
| pass/proofs/nested_machine_rank_forwarding | 1: no build.omg | 0 | Checking only |
| fail/termination/joint_machine_call_cycle_stalled | 1: no build.omg | 1: matched expected fragments | Expected: `preserving cycle has no strict measure DECREASE` |
| fail/termination/proof_joint_machine_cycle_unmeasured | 1: no build.omg | 1: expected fragment mismatch | Expected: `unmeasured proof machine` |
| fail/termination/runtime_non_tail_joint_machine_cycle | 1: no build.omg | 1: expected fragment mismatch | Expected: `non-tail call` |
| fail/proofs/nested_machine_rank_bypassed | 1: no build.omg | 1: matched expected fragments | Expected: `helper-only cycle can avoid every ranked entry` |
| fail/termination/saved_field_predicate_overwritten | 1: no build.omg | 1: matched expected fragments | Expected: `construction of `Countdown` field `remaining` may overflow `u64`` |

The seven update failures are missing-project-input setup outcomes: those checking fixtures do not contain build.omg. Their subsequent source checks reached ordinary checking. These update failures are not language rejections and are not counted as negative controls.

The two unmatched diagnostics are:

- proof_joint_machine_cycle_unmeasured actually reports: `proof-only machine call cycle: left, right -- no complete structural ranking establishes strict descent on every cycle ... computed ranking: the proof component has no authored ranking entry`. Its retained fragment is `unmeasured proof machine`.
- runtime_non_tail_joint_machine_cycle actually reports: `an internal call occurrence lacks a classified tail edge; runtime calls must be tail; a termination promise additionally requires strict descent on every complete cycle`. Its retained fragment is `non-tail call`.

Both messages enforce the intended obligation. The exact R11 follow-up below demonstrates that both mismatches already existed before R12. They remain uncredited as matched rejects. No golden was changed.

Evidence:

- r12-focused-termination-inputs.json records all authored source/oracle SHA256 hashes and points to frozen copies under r12-focused-termination-frozen-inputs/. Each original was verified unchanged after its fixture commands.
- r12-focused-termination-outcomes.json indexes each exact receipt and records expected/missing fragments separately.
- pending-admission-r12-focused-<pass/fail-category-name>-{update,check,both}.{json,stdout,stderr} retains raw commands and actual outcomes. The matching -helper.log contains the helper transcript.
- r12-focused-termination-evidence-sha256.json binds this report and retained raw receipts/output hashes.

## Exact R11 attribution follow-up

Executed exactly two additional source checks, without updates or builds, using pending-admission-r11-omega, verified opt-level 1, SHA256 042b88e21ce719faf5577f10fa9ab7f0dc1a911d6bd8e3a5efc36a7ca16b8ed2. The fixture .omg and expected files matched the frozen R12 copies byte for byte before execution and retained their recorded SHA256 values afterward. Each command used the fixture as VALIDATION_PROJECT and run_cli.py with unique pending-admission-r11-focused-attribution-<fixture>-check labels.

Both R11 checks reject at exit 1. Each full stdout-plus-stderr is byte-for-byte identical to its R12 counterpart. Thus the two mismatches are existing stale expected.txt fragments, not diagnostic changes introduced by R12. Neither is credited as a matched rejection. Exact expected fragments, full actual text, receipt paths, binary digest, and equality checks are recorded in r11-r12-termination-diagnostic-attribution.json. No compiler-identity fence occurred.

## Raw-log verification of the three matched rejects

The following retained expected.txt fragments were checked directly against the R12 stderr files; all are literal substrings of actual semantic rejection messages, not setup failures:

- joint_machine_call_cycle_stalled: `preserving cycle has no strict measure DECREASE`. Actual: `machine call cycle: Main::scan_a, Main::scan_b -- a preserving cycle has no strict measure DECREASE; runtime calls must be tail; a termination promise additionally requires strict descent on every complete cycle`. Raw file: pending-admission-r12-focused-fail-termination-joint_machine_call_cycle_stalled-check.stderr.
- nested_machine_rank_bypassed: `helper-only cycle can avoid every ranked entry`. Actual complete-component diagnosis ends `computed ranking: a helper-only cycle can avoid every ranked entry`; a second diagnostic also says recursive proof machine forward needs a single structural measure. Raw file: pending-admission-r12-focused-fail-proofs-nested_machine_rank_bypassed-check.stderr.
- saved_field_predicate_overwritten: ``construction of `Countdown` field `remaining` may overflow `u64` ``. Actual begins ``error: exact arithmetic in construction of `Countdown` field `remaining` may overflow `u64`: the operands are not provably in range``; another message identifies overflow in the transition argument. Raw file: pending-admission-r12-focused-fail-termination-saved_field_predicate_overwritten-check.stderr.

The full requested chain is now 22 invocations: the original 20 R12 commands plus two R11 attribution checks. The original nine-fixture selection and its execution counts are unchanged.
