from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
for command in [[sys.executable,str(h/'record_guarded_admission_corpus_r21.py'),'guarded-crash-r23-corpus','guarded-crash-r23-runner'],[sys.executable,str(h/'run_prerequisite_lint.py'),'guarded-crash-r23-clippy']]:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
