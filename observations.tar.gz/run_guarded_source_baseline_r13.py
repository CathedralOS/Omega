from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
w=Path.cwd();h=Path(__file__).parent
sys.path.insert(0,str(w/'tools'));import compiler_profile
producer=json.loads((h/'pending-admission-r13-producer.json').read_text())
assert producer['source']=='4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2'
assert producer['patch_sha256']==hashlib.sha256(b'').hexdigest()
assert producer['executable']['sha256']=='0420b257867901596eec8c2fb1bca87d547932d304fd107db2adb2b49c7b4bc7'
assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable']
assert not subprocess.check_output(['git','diff','--name-only',producer['source'],'--','source/library'])
jobs=[('runtime-const-array','pass/comptime/runtime_const_array_call_arguments_exit',True),('folded-range-custody','pass/generics/folded_range_endpoint_selection_custody',True),('demanded-crashing-helper','fail/constants/target_layout_derived_demanded_crashing_helper_reject',False),('crashing-helper','fail/constants/target_layout_derived_crashing_helper_reject',False),('typed-trapping-extent','fail/generics/typed_const_probe_trapping_extent',False)]
files={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for _,project,_ in jobs for f in (w/'tests/omega'/project).iterdir() if f.suffix=='.omg' or f.name.startswith('expected')}
manifest={'producer':producer,'files':files,'scope':'Unchanged authored fixtures; raw source-stage observations only, without oracle credit.'}
mp=h/'guarded-source-baseline-r13-inputs.json';assert not mp.exists();mp.write_text(json.dumps(manifest,indent=2)+'\n')
summary={'state':'running','producer':producer,'manifest':str(mp),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observations':[]};sp=h/'guarded-source-baseline-r13-summary.json'
def save():sp.write_text(json.dumps(summary,indent=2)+'\n')
def verify():
 for name,digest in files.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
try:
 save()
 for name,relative,check in jobs:
  project=w/'tests/omega'/relative
  actions=[('update',['update','--project',str(project),'--offline'])]
  if check:actions.append(('check',['--check',str(project/'main.omg')]))
  for action,args in actions:
   verify();label='guarded-source-baseline-r13-'+name+'-'+action;assert not (h/(label+'.json')).exists()
   result=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],cwd=w,env=dict(os.environ,VALIDATION_PRODUCER='pending-admission-r13',VALIDATION_PROJECT=str(project.relative_to(w))),capture_output=True)
   if result.returncode:raise RuntimeError(label+': wrapper failure: '+result.stderr.decode(errors='replace'))
   receipt=json.loads((h/(label+'.json')).read_text());assert receipt['producer']==producer['executable']
   raw=Path(receipt['stdout']).read_text()+Path(receipt['stderr']).read_text()
   item={'fixture':str(project.relative_to(w)),'action':action,'actual_exit':receipt['exit'],'seconds':receipt['seconds'],'receipt':str(h/(label+'.json')),'stdout':receipt['stdout'],'stderr':receipt['stderr'],'diagnostic':raw,'compiler_identity_fence':'compiler identity changed; run `omega update` for fresh review before compiling' in raw}
   summary['observations'].append(item);save();print(name,action,'actual exit',receipt['exit'],'seconds',round(receipt['seconds'],2),flush=True);print(raw[-2600:],flush=True)
   if any(s in raw for s in ['No such file or directory','does not contain a build.omg','could not locate build.omg','requires a build.omg','no Build companion','compiler identity changed; run `omega update` for fresh review before compiling']):raise RuntimeError(label+': setup refusal; see preserved receipt')
 verify();assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable'];summary['state']='complete';summary['frozen_inputs_unchanged']=True
except BaseException as error:
 summary['state']='stopped_on_failure';summary['failure']=repr(error);raise
finally:
 summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
