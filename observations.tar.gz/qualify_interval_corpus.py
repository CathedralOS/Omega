from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
for command in [[sys.executable,str(h/'prepare_saved_producer.py'),'interval-window-r7-runner-link-retry'],[sys.executable,str(h/'observe_interval_corpus.py'),'interval-window-r7-corpus-first','interval-window-r7-runner-link-retry','interval-window-final-corpus-selection.json']]:
 r=subprocess.run(command)
 if r.returncode:sys.exit(r.returncode)
