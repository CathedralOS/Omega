from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,sys
w=Path.cwd();h=Path(__file__).parent;sys.path.insert(0,str(w/'tools'));import compiler_profile
producer=json.loads((h/'pending-admission-r13-producer.json').read_text());assert producer['source']=='4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2' and producer['patch_sha256']==hashlib.sha256(b'').hexdigest()
assert producer['executable']['sha256']=='0420b257867901596eec8c2fb1bca87d547932d304fd107db2adb2b49c7b4bc7'
assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable']
assert not subprocess.check_output(['git','diff','--name-only',producer['source'],'--','source/library'])
project=w/'samples/cli/facts/provider_contract_endpoint/guarded_crash/controls/runtime_zero_divisor';pin=w/'tests/omega/pass/facts/provider_contract_endpoint_guarded_crash_runtime_zero_divisor_traps'
files={}
for name in ['main.omg','build.omg']:
 assert (project/name).read_bytes()==(pin/name).read_bytes(),name
 for f in [project/name,pin/name]:files[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
oracle=pin/'expected_native_exit.txt';files[str(oracle)]=hashlib.sha256(oracle.read_bytes()).hexdigest()
manifest={'producer':producer,'files':files,'expected_native_exit_text':oracle.read_text(),'scope':'Ordinary runtime crash control only; no scalar admission credit.'}
mp=h/'guarded-runtime-trap-baseline-r13-inputs.json';assert not mp.exists();mp.write_text(json.dumps(manifest,indent=2)+'\n')
summary={'state':'running','producer':producer,'manifest':str(mp),'observations':[]};sp=h/'guarded-runtime-trap-baseline-r13-summary.json'
def verify():
 for name,digest in files.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
try:
 for action,args in [('update',['update','--project',str(project),'--offline']),('both',['run',str(project/'main.omg'),'--both','--keep'])]:
  verify();label='guarded-runtime-trap-baseline-r13-'+action;assert not (h/(label+'.json')).exists()
  result=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],cwd=w,env=dict(os.environ,VALIDATION_PRODUCER='pending-admission-r13',VALIDATION_PROJECT=str(project.relative_to(w))),capture_output=True)
  if result.returncode:raise RuntimeError('wrapper failed: '+result.stderr.decode(errors='replace'))
  receipt=json.loads((h/(label+'.json')).read_text());assert receipt['producer']==producer['executable'];raw=Path(receipt['stdout']).read_text()+Path(receipt['stderr']).read_text();item={'action':action,'actual_exit':receipt['exit'],'seconds':receipt['seconds'],'receipt':str(h/(label+'.json')),'diagnostic':raw,'native_exits':re.findall(r'native exit (-?\d+)',raw),'terminal_exits':re.findall(r'interp exit: (-?\d+)',raw),'terminal_crash_causes':re.findall(r'cause: (\w+)',raw),'terminal_crash_sites':re.findall(r'site: ([^,}]+)',raw)};summary['observations'].append(item);sp.write_text(json.dumps(summary,indent=2)+'\n');print(action,'actual exit',receipt['exit'],'seconds',round(receipt['seconds'],2),flush=True);print(raw,flush=True)
  if action=='update' and receipt['exit']!=0:raise RuntimeError('ordinary update refused; preserved actual diagnostic')
 verify();assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable'];summary['frozen_inputs_unchanged']=True;summary['state']='complete'
except BaseException as error:
 summary['state']='stopped_on_failure';summary['failure']=repr(error);raise
finally:
 summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();sp.write_text(json.dumps(summary,indent=2)+'\n')
