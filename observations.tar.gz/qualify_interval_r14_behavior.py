from pathlib import Path
import subprocess,sys,json,time,os
h=Path(__file__).parent;rows=[];producer='interval-window-r14'
commands=[
 ('match',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r14-match',producer,'interval-window-r14-match-selection.json']),
 ('match-audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r14-match']),
 ('recast',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r14-recast',producer,'interval-window-r12-recast-selection.json']),
 ('recast-audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r14-recast']),
 ('recast-row',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r14-recast-row',producer,'interval-window-r14-recast-row-selection.json']),
 ('recast-row-audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r14-recast-row']),
 ('shared',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r14-shared',producer,'interval-window-shared-sources-selection.json']),
 ('shared-audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r14-shared']),
 ('row',[sys.executable,str(h/'run_interval_row_integrated.py'),'interval-window-r14-row',producer]),
 ('controls',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r14-controls',producer,'interval-window-r10-other-controls-selection.json']),
 ('storage',[sys.executable,str(h/'run_interval_controls.py'),'interval-window-r14-storage',producer,'interval-window-r9-storage-selection.json']),
 ('audit',[sys.executable,str(h/'check_interval_observations_current.py'),'interval-window-r14-shared','interval-window-r14-row','interval-window-r14-controls','interval-window-r14-storage','interval-window-r14-recast','interval-window-r14-recast-row','interval-window-r14-match']),
 ('archive',[sys.executable,str(h/'archive_completed_producer.py'),producer]),
]
for name,command in commands:
 t=time.monotonic()
 with (h/('interval-window-r14-'+name+'-phase.stdout')).open('wb') as out,(h/('interval-window-r14-'+name+'-phase.stderr')).open('wb') as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL,env=dict(os.environ,AUDIT_OUTPUT_LABEL='interval-window-r14-'+name))
 rows.append({'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-t});(h/'interval-window-r14-behavior-chain.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,'exit',r.returncode,'seconds',round(rows[-1]['seconds'],2),flush=True)
 if r.returncode:
  print((h/('interval-window-r14-'+name+'-phase.stdout')).read_text()[-5000:]);print((h/('interval-window-r14-'+name+'-phase.stderr')).read_text()[-3000:]);sys.exit(r.returncode)
