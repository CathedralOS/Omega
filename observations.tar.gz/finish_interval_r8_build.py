from pathlib import Path
import subprocess,json,time,sys,hashlib
h=Path(__file__).parent;label='interval-window-r8-tail-retry';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();patch=subprocess.check_output(['git','diff','HEAD','--','omega-rust','source/library','Cargo.toml','Cargo.lock']);command=['cargo','build','--locked','-p','omega','--lib','-p','package-source','--message-format=json'];t=time.monotonic()
with (h/(label+'-cargo.stdout')).open('wb') as out,(h/(label+'-cargo.stderr')).open('wb') as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and subprocess.check_output(['git','diff','HEAD','--','omega-rust','source/library','Cargo.toml','Cargo.lock'])==patch
(h/(label+'-build.json')).write_text(json.dumps({'command':command,'source':head,'patch_sha256':hashlib.sha256(patch).hexdigest(),'exit':r.returncode,'seconds':time.monotonic()-t},indent=2)+'\n');print('remaining libraries exit',r.returncode,flush=True)
if r.returncode:print((h/(label+'-cargo.stderr')).read_text()[-4000:]);sys.exit(r.returncode)
subprocess.run([sys.executable,str(h/'compress_interval_cache.py'),label],check=True)
sys.exit(subprocess.run([sys.executable,str(h/'build_producer.py'),'interval-window-r8']).returncode)
