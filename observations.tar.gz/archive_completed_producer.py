from pathlib import Path
import gzip,hashlib,json,os,shutil,sys
h=Path(__file__).parent;label=sys.argv[1];p=h/(label+'-omega');archive=h/(label+'-omega.gz');assert not archive.exists();sys.path.insert(0,str(Path.cwd()/'tools'));import compiler_profile
profile=compiler_profile.require_optimized(p);before=p.stat();digest=hashlib.sha256(p.read_bytes()).hexdigest()
with p.open('rb') as source,gzip.open(archive,'wb',compresslevel=3) as out:shutil.copyfileobj(source,out)
with gzip.open(archive,'rb') as source:
 check=hashlib.sha256()
 for chunk in iter(lambda:source.read(1024*1024),b''):check.update(chunk)
assert check.hexdigest()==digest
record={'purpose':'Retain a completed producer losslessly while freeing its uncompressed workspace file. Replay restores its exact bytes, permissions and mtime, then verifies its original profile. No producer bytes or observations are replaced by a newer build.','original_file':str(p),'sha256':digest,'size':before.st_size,'mode':before.st_mode,'atime_ns':before.st_atime_ns,'mtime_ns':before.st_mtime_ns,'profile':profile,'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size}
(h/(label+'-archived-producer.json')).write_text(json.dumps(record,indent=2)+'\n');p.unlink();record['free_after']=shutil.disk_usage(h).free;(h/(label+'-archived-producer.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
