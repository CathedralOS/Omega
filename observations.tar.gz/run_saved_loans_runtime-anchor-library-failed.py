from pathlib import Path
import sys, os, json, hashlib, subprocess, threading, time
h=Path(__file__).parent; w=Path.cwd(); sys.path.insert(0,str(w/'tools'))
import sample_native_gate as gate
from compiler_profile import require_optimized
binary=h/'saved-loans-c6-omega'; profile=require_optimized(binary)
frozen=json.loads((h/'saved-loans-final-authored-inputs.json').read_text())
def validate():
 for name,digest in frozen['files'].items(): assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
 assert require_optimized(binary)==profile
validate()
# Keep the public gate's commands and raw engine observations for review.
original=gate.run; guard=threading.Lock(); calls=[]
def recorded_run(command,timeout,stdin=subprocess.DEVNULL,cwd=None):
 with guard: ordinal=len(calls); row={'command':command,'cwd':str(cwd) if cwd else None,'timeout':timeout}; calls.append(row)
 updates={}; lock=None
 if 'run' in command and '--both' in command:
  lock=Path(command[-1]).parent/'omega.lock'
  if lock.is_file():
   saved=h/f'saved-loans-runtime-command-{ordinal:03d}-input.omega.lock'; saved.write_bytes(lock.read_bytes()); updates['input_lock']=str(saved); updates['input_lock_sha256']=hashlib.sha256(saved.read_bytes()).hexdigest()
 t=time.monotonic(); result=original(command,timeout,stdin=stdin,cwd=cwd)
 if lock is not None and lock.is_file(): updates['output_lock_sha256']=hashlib.sha256(lock.read_bytes()).hexdigest()
 updates.update(seconds=time.monotonic()-t,exit=None if result is None else result.returncode)
 if result is not None:
  for channel in ['stdout','stderr']:
   path=h/f'saved-loans-runtime-command-{ordinal:03d}.{channel}'; path.write_text(getattr(result,channel)); updates[channel]=str(path)
 with guard:
  row.update(updates)
  (h/'saved-loans-runtime-raw-commands.json').write_text(json.dumps(calls,indent=2)+'\n')
 return result
gate.run=recorded_run
command=json.loads((h/'saved-loans-runtime-command.json').read_text()); sys.argv=command[1:]
status=gate.main(); validate(); print('Public sample gate exit',status,flush=True)
if status: sys.exit(status)
# These existing programs also exercise parent use after child references end.
extra=[('tests/omega/pass/borrows/runtime_scalar_field_local_loan_handback_exit',True),('tests/omega/pass/calls/runtime_explicit_reference_alias_argument_exit',True),('tests/omega/pass/borrows/runtime_reference_initializer_selector_before_later_write_exit',True),('tests/omega/pass/borrows/runtime_selected_reference_reborrow_restoration_exit',True),('tests/omega/pass/borrows/suspension_saved_reference_view_shared_cohort_call_restore_exit',True),('tests/omega/fail/borrows/suspension_saved_reference_view_shared_cohort_early_write_rejected',False),('tests/omega/pass/borrows/local_subslice_parent_lent_after_last_use_exit',True),('tests/omega/fail/borrows/local_subslice_live_parent_mutable_argument',False),('tests/omega/pass/borrows/runtime_nested_reference_partition_exit',True),('tests/omega/pass/borrows/runtime_nested_reference_record_direct_payload_restoration_exit',True)]
rows=[]
for ordinal,(relative,positive) in enumerate(extra):
 label=f'saved-loans-runtime-extra-{ordinal:02d}'; project=w/relative; env=dict(os.environ,VALIDATION_PRODUCER='saved-loans-c6',VALIDATION_PROJECT=relative)
 if positive:
  setup=label+'-update'; subprocess.run([sys.executable,str(h/'run_cli.py'),setup,'update','--project',str(project),'--offline'],check=True,env=env,stdout=subprocess.DEVNULL)
  update=json.loads((h/(setup+'.json')).read_text()); assert update['exit']==0,update
  args=['run','--both',str(project/'main.omg')]
 else: args=['--check',str(project/'main.omg')]
 subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],check=True,env=env,stdout=subprocess.DEVNULL)
 receipt=json.loads((h/(label+'.json')).read_text()); stderr=Path(receipt['stderr']).read_text(); row={'project':relative,'positive':positive,'receipt':str(h/(label+'.json')),'exit':receipt['exit']}
 if positive:
  expectation=int((project/'expected_native_exit.txt').read_text().strip()); observation=gate.both_execution_observation(stderr); row.update(execution=observation,expected_exit=expectation); assert receipt['exit']==expectation and observation=={'native_exit':expectation,'interpreter_exit':expectation},row
 else:
  fragments=[s for s in (project/'expected.txt').read_text().splitlines() if s.strip()]; row['fragments']=fragments; row['fragments_matched']=all(fragment in stderr for fragment in fragments); assert receipt['exit']!=0 and row['fragments_matched'],row
 rows.append(row); (h/'saved-loans-runtime-extra-summary.json').write_text(json.dumps(rows,indent=2)+'\n'); print(relative,'exit',receipt['exit'],flush=True)
validate()
