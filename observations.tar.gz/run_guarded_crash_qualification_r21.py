from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
w=Path.cwd();h=Path(__file__).parent;label=sys.argv[1];producer_label=sys.argv[2]
m=json.loads((h/'guarded-crash-row-v2-frozen-inputs.json').read_text())
producer=json.loads((h/(producer_label+'-producer.json')).read_text())
root=w/'samples/cli/facts/provider_contract_endpoint/guarded_crash'
summary={'kind':'Guarded bound helpers: rejection before execution','producer':producer,'observations':[],'state':'running'}
sp=h/(label+'-summary.json');assert not sp.exists()
def verify():
 for name,digest in m['files'].items():
  assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
 for place in m['places']:
  for status in ['pass','fail']:
   source=root/place if status=='pass' else root/place/'invalid'
   pin=w/'tests/omega'/status/'facts'/('provider_contract_endpoint_guarded_crash_through_'+place+('_exit' if status=='pass' else '_rejected'))
   for name in ['main.omg','build.omg']:assert (source/name).read_bytes()==(pin/name).read_bytes()
def save():sp.write_text(json.dumps(summary,indent=2)+'\n')
try:
 verify();save()
 for place in m['places']:
  for invalid in [False,True]:
   project=root/place/('invalid' if invalid else '')
   actions=[('update',['update','--project',str(project),'--offline'])]
   if not invalid:actions += [('check',['--check',str(project/'main.omg')]),('both',['run',str(project/'main.omg'),'--both','--keep'])]
   for action,args in actions:
    verify();name=label+'-'+place+('-invalid-' if invalid else '-positive-')+action
    assert not (h/(name+'.json')).exists()
    wrapper=subprocess.run([sys.executable,str(h/'run_cli.py'),name,*args],env=dict(os.environ,VALIDATION_PRODUCER=producer_label,VALIDATION_PROJECT=str(project.relative_to(w))),capture_output=True)
    assert wrapper.returncode==0,wrapper.stderr.decode(errors='replace')[-3000:]
    receipt=json.loads((h/(name+'.json')).read_text());assert receipt['producer']==producer['executable']
    raw=Path(receipt['stdout']).read_text()+Path(receipt['stderr']).read_text()
    row={'place':place,'invalid':invalid,'action':action,'receipt':str(h/(name+'.json')),'exit':receipt['exit']}
    if invalid:
     row['admission_refusal']=receipt['exit']!=0 and ('constant evaluation requires proof that no crash route can occur before execution' in raw or ('constant expression' in raw and 'can crash with [Trap]' in raw))
     row['interpreted_trap']='Crashed(' in raw
     success=row['admission_refusal'] and not row['interpreted_trap']
    elif action=='both':
     row['native_exits']=re.findall(r'native exit (-?\d+)',raw);row['terminal_exits']=re.findall(r'interp exit: (-?\d+)',raw)
     success=receipt['exit']==0 and row['native_exits']==['0'] and row['terminal_exits']==['0']
    else:success=receipt['exit']==0
    row['passed']=success;summary['observations'].append(row);save()
    print(place,'invalid' if invalid else 'positive',action,'exit',receipt['exit'],'passed',success,flush=True)
    if not success:raise RuntimeError(name+': '+raw[-5000:])
 verify();summary['state']='complete';summary['frozen_inputs_and_pins_unchanged']=True
except BaseException as error:
 summary['state']='stopped_on_failure';summary['failure']=repr(error);raise
finally:save()
