R13 accepts both unchanged positive fixtures during ordinary offline update and direct source checking. The two target-layout crashing-helper updates refuse only after constant interpretation reaches Trap. These are historical wrong-stage failures, not evidence of pre-execution crash admission.

The fifth fixture, typed_const_probe_trapping_extent, has no build.omg. Its ordinary update stops at a file-operation setup error, so no source result is credited. The chain performed no further actions and did not author a Build file.

The saved optimized producer is from source 4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2 with an empty patch. Its SHA-256 is 0420b257867901596eec8c2fb1bca87d547932d304fd107db2adb2b49c7b4bc7. The actual saved binary profile and digest were independently verified before and after the chain; the runtime SDK diff against that source was empty. All frozen source and oracle hashes remained unchanged.

Receipts:
- tests/omega/pass/comptime/runtime_const_array_call_arguments_exit update: exit 0. /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-runtime-const-array-update.json
- tests/omega/pass/comptime/runtime_const_array_call_arguments_exit check: exit 0. /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-runtime-const-array-check.json
- tests/omega/pass/generics/folded_range_endpoint_selection_custody update: exit 0. /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-folded-range-custody-update.json
- tests/omega/pass/generics/folded_range_endpoint_selection_custody check: exit 0. /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-folded-range-custody-check.json
- tests/omega/fail/constants/target_layout_derived_demanded_crashing_helper_reject update: exit 1. /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-demanded-crashing-helper-update.json
- tests/omega/fail/constants/target_layout_derived_crashing_helper_reject update: exit 1. /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-crashing-helper-update.json
- tests/omega/fail/generics/typed_const_probe_trapping_extent update: exit 1. /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-typed-trapping-extent-update.json

Machine-readable summary: /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-summary.json
Initial unclassified mechanical summary retained at: /Users/zcanann/Documents/Projects/Omega/build/scalar-continue-20261102/guarded-source-baseline-r13-summary-initial.json
