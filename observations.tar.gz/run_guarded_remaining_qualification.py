from pathlib import Path
import subprocess,sys
h=Path(__file__).parent;label=sys.argv[1];producer=sys.argv[2]
for command in [
 [sys.executable,str(h/'run_guarded_customer_continuation.py'),label+'-customer-controls',producer],
 [sys.executable,str(h/'run_guarded_crash_qualification.py'),label+'-row',producer],
]:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
