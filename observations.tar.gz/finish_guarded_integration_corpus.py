from pathlib import Path
import json,subprocess,hashlib,sys
h=Path(__file__).parent;sys.path.insert(0,str(Path.cwd()/'tools'));import corpus_records as records
attribution=json.loads((h/'guarded-crash-r23-policy-baseline-attribution.json').read_text());assert attribution['same_diagnostics_and_status_and_facts']
inputs=json.loads((h/'guarded-crash-r23-corpus-inputs.json').read_text());verdict=json.loads((h/'guarded-crash-r23-corpus-verdict.json').read_text());assert not verdict['counts']['wrong_reason']and not verdict['oracle_failures'];excluded='pass/build/terminal_calling_policy_execution';keys=set(inputs['fixtures'])-{excluded};assert len(keys)==31
for name,digest in inputs['files'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
path=Path('tests/omega/corpus_outcomes.txt');before=path.read_text();old={r['fixture']:r for r in records.parse(before)};selected={r['fixture']:r for r in records.read(h/'guarded-crash-r23-corpus-staged.txt')if r['fixture']in keys};assert len(selected)==31
assert sum(r['status']=='checked'for r in selected.values())==15 and sum(r['status']=='rejected'for r in selected.values())==16
assert all(r['status']==('rejected'if k.startswith('fail/')else'checked')for k,r in selected.items())
fields=['status','expected_satisfied','facts','diagnostics','regressed_from'];timings=[]
for key,row in selected.items():
 prior=old.get(key)
 if prior and all(row.get(f)==prior.get(f)for f in fields):timings.append({'fixture':key,'fresh_millis':row['millis'],'retained_millis':prior['millis']});row['millis']=prior['millis']
main=subprocess.check_output(['git','show','5209eac451c:tests/omega/corpus_outcomes.txt'],text=True);historical=next(r for r in records.parse(main)if r['fixture']==excluded);final=records.splice(before,[*selected.values(),historical])
def blocks(text):
 out={};key=None
 for line in text.splitlines(keepends=True):
  if not line.strip()or line.startswith('#'):continue
  if line.startswith('\t'):out[key]+=line
  else:key=line.split()[0];assert key not in out;out[key]=line
 return out
ob=blocks(before);nb=blocks(final);mb=blocks(main);assert set(ob)==set(nb);assert nb[excluded]==mb[excluded];assert all(ob[k]==nb[k]for k in ob if k not in keys and k!=excluded)
path.write_text(final)
r={'state':'Complete for the 31 scoped checks; one unrelated baseline failure is retained explicitly.','source':inputs['source'],'producer':inputs['producer'],'observed_fixtures':32,'qualified_fixtures':31,'qualified_counts':{'checked':15,'rejected':16},'selected_fixtures':sorted(keys),'baseline_failure':excluded,'baseline_attribution':str(h/'guarded-crash-r23-policy-baseline-attribution.json'),'excluded_historical_row_restored_from':'5209eac451caf43591135c2b453033e60b4df917','no_keys_removed':True,'all_other_blocks_byte_identical':True,'timing_restorations':timings,'raw_verdict':str(h/'guarded-crash-r23-corpus-verdict.json'),'limitation':'The saved-policy positive still fails transport on both main and candidate. It is not credited as current runtime success or converted into an expected reject.'};(h/'guarded-crash-r23-corpus-qualified-summary.json').write_text(json.dumps(r,indent=2)+'\n');print('Recorded 15 checked positives and 16 intended rejects. Preserved main historical policy row and raw baseline failure; no keys removed.')
