from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
commands=[
 [sys.executable,str(h/'prepare_saved_producer.py'),'guarded-crash-r22'],
 [sys.executable,str(h/'run_guarded_crash_qualification_r21.py'),'guarded-crash-r22-row','guarded-crash-r22'],
 [sys.executable,str(h/'run_guarded_admission_customers_r21.py'),'guarded-crash-r22-customers','guarded-crash-r22'],
 [sys.executable,str(h/'run_guarded_candidate_units.py'),'guarded-crash-r22-units'],
]
for command in commands:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
