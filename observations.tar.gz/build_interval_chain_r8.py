from pathlib import Path
import hashlib,json,os,subprocess,sys,time
h=Path(__file__).parent;label=sys.argv[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
patch=subprocess.check_output(['git','diff','HEAD','--','omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml'])
(h/(label+'-prebuild-source.patch')).write_bytes(patch)
rows=[]
subprocess.run([sys.executable,str(h/'compress_interval_cache.py'),label+'-before'],check=True)
# Reclaim only disposable cache storage between dependency builds. This keeps
# compilation below the host's available disk space without changing bytes.
for package in ['validation','typed-trees-to-checked-trees','build-time-evaluation','checked-trees-to-lowered-psi','omega']:
 name=label+'-dependency-'+package;command=['cargo','build','--locked','-p',package,'-p','package-source'];t=time.monotonic()
 if package=='omega':command.append('--lib')
 with (h/(name+'.stdout')).open('wb') as out,(h/(name+'.stderr')).open('wb') as err:
  result=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 assert subprocess.check_output(['git','diff','HEAD','--','omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml'])==patch
 row={'command':command,'exit':result.returncode,'seconds':time.monotonic()-t,'source':head,'patch_sha256':hashlib.sha256(patch).hexdigest()};rows.append(row)
 (h/(label+'-dependency-builds.json')).write_text(json.dumps(rows,indent=2)+'\n')
 print(package,'build exit',result.returncode,'seconds',round(row['seconds'],2),flush=True)
 if result.returncode:
  print((h/(name+'.stderr')).read_text()[-7000:],flush=True);sys.exit(result.returncode)
 subprocess.run([sys.executable,str(h/'compress_interval_cache.py'),name],check=True)
result=subprocess.run([sys.executable,str(h/'build_producer.py'),label]);sys.exit(result.returncode)
