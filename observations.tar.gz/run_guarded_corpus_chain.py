from pathlib import Path
import subprocess,sys
h=Path(__file__).parent;label=sys.argv[1]
for command in [
 [sys.executable,str(h/'compress_workbench_cache_small_first.py'),label+'-before-runner'],
 [sys.executable,str(h/'build_corpus.py'),label+'-runner'],
 [sys.executable,str(h/'prepare_saved_producer.py'),label+'-runner'],
 [sys.executable,str(h/'record_guarded_admission_corpus.py'),label+'-corpus',label+'-runner'],
 [sys.executable,str(h/'run_prerequisite_lint.py'),label+'-clippy'],
]:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
