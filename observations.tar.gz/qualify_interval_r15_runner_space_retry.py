from pathlib import Path
import json
import shutil
import subprocess
import sys
import threading
import time

records = Path(__file__).parent
label = 'interval-window-r15-runner-space-retry'
available = shutil.disk_usage(records).free
assert available >= 500 * 1024 ** 2, available
samples = []
done = threading.Event()
def observe_space():
    while not done.is_set():
        samples.append({'seconds': time.monotonic() - started, 'free_bytes': shutil.disk_usage(records).free})
        done.wait(0.1)
started = time.monotonic()
observer = threading.Thread(target=observe_space, daemon=True)
observer.start()
command = [sys.executable, str(records / 'build_corpus.py'), label]
try:
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
finally:
    done.set()
    observer.join()
record = {'command': command, 'exit': result.returncode, 'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'initial_free_bytes': available, 'minimum_free_bytes': min(item['free_bytes'] for item in samples), 'seconds': time.monotonic() - started, 'samples': samples}
(records / (label + '-disk-observation.json')).write_text(json.dumps(record, indent=2) + '\n')
if result.returncode:
    sys.exit(result.returncode)
for command in [
    [sys.executable, str(records / 'prepare_interval_fixture_replay_r15.py')],
    [sys.executable, str(records / 'observe_interval_corpus.py'), 'interval-window-r15-corpus', label, 'interval-window-r15-corpus-selection.json'],
]:
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    if result.returncode:
        sys.exit(result.returncode)
