from pathlib import Path
import subprocess,json,hashlib
h=Path(__file__).parent;before='a169d6a3794f53c3aa731d3da2ae4b9a76fd7255';after=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();paths=subprocess.check_output(['git','diff','--name-only',before,after,'--','omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml'],text=True).splitlines();rows=[]
for name in paths:
 old=subprocess.check_output(['git','show',before+':'+name],text=True);new=Path(name).read_text()
 if name.endswith('/declaration_predicates/tests/own_fact_reuse.rs'):
  parent=Path(name).parents[1].with_suffix('.rs').read_text();assert '#[cfg(test)]\nmod tests;' in parent
  rows.append({'file':name,'reason':'Changes are in a test-only module.'});continue
 if name.endswith('/declaration_predicates/field_carriers.rs'):
  marker='#[cfg(test)]\nmod tests {';assert old.count(marker)==new.count(marker)==1;old=old.split(marker)[0];new=new.split(marker)[0]
 def executable_lines(source):return '\n'.join(line for line in source.splitlines() if line.strip() and not line.lstrip().startswith('//'))
 assert executable_lines(old)==executable_lines(new),name
 rows.append({'file':name,'production_code_sha256':hashlib.sha256(executable_lines(new).encode()).hexdigest(),'reason':'The production portion differs only in line comments and blank lines; the field-carrier test changes are inside cfg(test).'} )
record={'tested_producer_source':before,'inspected_source':after,'files':rows,'reason_for_reuse':'The compiler and library inputs outside these files are unchanged. The changed production text consists only of comments; executable changes are test-only. The recorded native and Terminal observations remain observations of the R6 binary, with its original source and digest. R7 builds and exercises the corrected tests separately.'}
(h/'interval-window-r7-runtime-evidence-applicability.json').write_text(json.dumps(record,indent=2)+'\n');print('Verified production equivalence across',len(rows),'changed input files')
