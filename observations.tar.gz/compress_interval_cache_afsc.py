from pathlib import Path
import subprocess,hashlib,os,json,shutil,sys
root=Path('/Users/zcanann/Documents/Projects/Omega/build/gate-cli-reuse-current/debug');h=Path(__file__).parent;label=sys.argv[1];rows=[]
files=sorted((p for p in root.rglob('*') if p.is_file() and p.suffix in ['.rlib','.rmeta'] and p.stat().st_size>1024**2),key=lambda p:p.stat().st_size)
for source in files:
 before=source.stat()
 if before.st_blocks*512<before.st_size//2:continue
 digest=hashlib.sha256(source.read_bytes()).hexdigest();command=['/opt/homebrew/bin/afsctool','-c',str(source)];result=subprocess.run(command,capture_output=True,text=True);assert result.returncode==0,result.stderr
 assert source.stat().st_size==before.st_size and source.stat().st_mode==before.st_mode and hashlib.sha256(source.read_bytes()).hexdigest()==digest
 os.utime(source,ns=(before.st_atime_ns,before.st_mtime_ns));assert source.stat().st_mtime_ns==before.st_mtime_ns
 rows.append({'file':str(source),'sha256':digest,'command':command,'saved_bytes':max(0,(before.st_blocks-source.stat().st_blocks)*512),'mtime_preserved':True})
(h/(label+'-cache-compression.json')).write_text(json.dumps({'purpose':'Compress completed private Cargo libraries and metadata in place. Bytes, permissions and modification times are verified unchanged. Retained producers and run artifacts are untouched.','files':rows,'saved_bytes':sum(r['saved_bytes'] for r in rows),'free_bytes':shutil.disk_usage(root).free},indent=2)+'\n')
print('Cache bytes unchanged; freed',round(sum(r['saved_bytes'] for r in rows)/1024**2),'MiB; available',round(shutil.disk_usage(root).free/1024**2),'MiB.',flush=True)
