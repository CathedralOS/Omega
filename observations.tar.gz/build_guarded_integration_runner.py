from pathlib import Path
import subprocess,sys
h=Path(__file__).parent
for command in [[sys.executable,str(h/'compress_workbench_cache_small_first.py'),'guarded-crash-r22-before-runner'],[sys.executable,str(h/'build_corpus.py'),'guarded-crash-r22-runner'],[sys.executable,str(h/'prepare_saved_producer.py'),'guarded-crash-r22-runner']]:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
