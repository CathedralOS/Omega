from pathlib import Path
import datetime,hashlib,json,os,platform,re,subprocess,sys
w=Path.cwd();h=Path(__file__).parent;mp=h/'guarded-crash-row-v2-frozen-inputs.json';m=json.loads(mp.read_text());manifest_sha=hashlib.sha256(mp.read_bytes()).hexdigest();root=w/'samples/cli/facts/provider_contract_endpoint/guarded_crash';producer=json.loads((h/'pending-admission-r13-producer.json').read_text());assert producer['source']=='4b50ded92ae9cb9f5216e8e8ed6115f9054d7cc2' and producer['executable']['sha256']=='0420b257867901596eec8c2fb1bca87d547932d304fd107db2adb2b49c7b4bc7'
sys.path.insert(0,str(w/'tools'));import compiler_profile;assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable']
assert not subprocess.check_output(['git','diff','--name-only',producer['source'],'--','source/library'])
summary={'state':'running','kind':'Frozen guarded-crash V2 baseline, not repair acceptance','producer':producer,'authoring_source':m['author_head'],'producer_identity_boundary':'Actual retained compiler source is4b50 with an empty patch. Later Rust edits in the worktree are not this producer. Runtime SDK is unchanged.','frozen_manifest':str(mp),'frozen_manifest_sha256':manifest_sha,'host':platform.system()+'/'+platform.machine(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observations':[],'failure':None};sp=h/'guarded-crash-row-v2-r13-baseline-summary.json';assert not sp.exists()
def save():
 temporary=sp.with_suffix('.json.tmp');temporary.write_text(json.dumps(summary,indent=2)+'\n');temporary.replace(sp)
def verify():
 assert hashlib.sha256(mp.read_bytes()).hexdigest()==manifest_sha
 for name,digest in m['files'].items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
def classify(exit_code,raw):
 if exit_code==0:return 'accepted'
 if 'Crashed(' in raw and 'Trap' in raw:return 'interpreted_trap_not_admission'
 if 'has no executable body' in raw or 'call count agreement' in raw:return 'missing_body_not_admission'
 if 'compiler identity changed; run `omega update`' in raw:return 'compiler_identity_setup_fence'
 return 'other_refusal_not_credited'
def observe(label,place,invalid,action,reused=False):
 path=h/(label+'.json');d=json.loads(path.read_text());assert d['producer']==producer['executable'];project=root/place/('invalid' if invalid else '');assert set(d['inputs'])=={str(project/'main.omg'),str(project/'build.omg')}
 for name,digest in d['inputs'].items():assert m['files'][str(Path(name).relative_to(w))]==digest
 raw=Path(d['stdout']).read_text()+Path(d['stderr']).read_text();item={'place':place,'invalid':invalid,'action':action,'receipt':str(path),'exit':d['exit'],'reused_local_receipt':reused,'observed_stage':classify(d['exit'],raw),'diagnostic_tail':raw[-2300:]}
 if action=='both':item['native_exits']=re.findall(r'native exit (-?\d+)',raw);item['terminal_exits']=re.findall(r'interp exit: (-?\d+)',raw);item['actual_agreement_zero']=d['exit']==0 and item['native_exits']==['0'] and item['terminal_exits']==['0']
 summary['observations'].append(item);save();print(place,'invalid' if invalid else 'positive',action,'actual exit',d['exit'],'stage',item['observed_stage'],'actual agreement',item.get('actual_agreement_zero','n/a'),'reused',reused,flush=True)
 if (not invalid and d['exit']!=0) or (invalid and item['observed_stage']!='interpreted_trap_not_admission'):print('BASELINE DETAIL:',raw[-1800:],flush=True)
 return item
try:
 verify();save()
 for suffix,action,invalid in [('positive-update','update',False),('positive-check','check',False),('positive-both','both',False),('invalid-update','update',True)]:observe('guarded-crash-v2-r13-'+suffix,'local',invalid,action,True)
 summary['local_missing_observations']='No completed local invalid source-check receipt exists; not rerun or credited.';save()
 for place in m['places']:
  if place=='local':continue
  for invalid in [False,True]:
   project=root/place/('invalid' if invalid else '');actions=[('update',['update','--project',str(project),'--offline']),('check',['--check',str(project/'main.omg')])]
   if not invalid:actions.append(('both',['run',str(project/'main.omg'),'--both','--keep']))
   for action,args in actions:
    verify();label='guarded-crash-row-v2-r13-'+place+('-invalid-' if invalid else '-positive-')+action;assert not (h/(label+'.json')).exists()
    wrapper=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],cwd=w,env=dict(os.environ,VALIDATION_PRODUCER='pending-admission-r13',VALIDATION_PROJECT=str(project.relative_to(w))),capture_output=True)
    if wrapper.returncode!=0:raise RuntimeError(label+': receipt wrapper failed: '+wrapper.stderr.decode(errors='replace')[-2500:])
    observe(label,place,invalid,action)
 verify();assert compiler_profile.require_optimized(h/'pending-admission-r13-omega')==producer['executable'];assert not subprocess.check_output(['git','diff','--name-only',producer['source'],'--','source/library']);summary['state']='complete';summary['frozen_inputs_unchanged']=True
except BaseException as error:
 summary['state']='stopped_on_failure';summary['failure']=repr(error);print('STOP',repr(error),flush=True);raise
finally:
 obs=summary['observations'];summary['counts']={'fresh_command_receipts':sum(not x['reused_local_receipt'] for x in obs),'reused_local_receipts':sum(x['reused_local_receipt'] for x in obs),'positive_source_checks_passed':sum(not x['invalid'] and x['action']=='check' and x['exit']==0 for x in obs),'actual_native_terminal_zero_agreements':sum(x.get('actual_agreement_zero',False) for x in obs),'negative_updates_interpreted_trap':sum(x['invalid'] and x['action']=='update' and x['observed_stage']=='interpreted_trap_not_admission' for x in obs),'negative_checks_interpreted_trap':sum(x['invalid'] and x['action']=='check' and x['observed_stage']=='interpreted_trap_not_admission' for x in obs),'negative_updates_wrongly_accepted':sum(x['invalid'] and x['action']=='update' and x['exit']==0 for x in obs),'positive_failures':sum(not x['invalid'] and x['exit']!=0 for x in obs),'missing_body_refusals':sum(x['observed_stage']=='missing_body_not_admission' for x in obs),'setup_fences':sum(x['observed_stage']=='compiler_identity_setup_fence' for x in obs)};summary['finished_or_yielded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(summary['counts']),flush=True)
