from pathlib import Path
import hashlib,json,os,subprocess,sys,time
h=Path(__file__).parent
w=Path.cwd()
rows=[('pass/comptime/const_joint_ranked_call_component',True),('pass/termination/runtime_joint_rank_computed_copy_exit',True),('pass/termination/proof_non_tail_joint_machine_cycle_compile',False),('pass/proofs/nested_machine_rank_forwarding',False),('fail/termination/joint_machine_call_cycle_stalled',False),('fail/termination/proof_joint_machine_cycle_unmeasured',False),('fail/termination/runtime_non_tail_joint_machine_cycle',False),('fail/proofs/nested_machine_rank_bypassed',False),('fail/termination/saved_field_predicate_overwritten',False)]
binary=h/'pending-admission-r12-omega'
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='a8c921d8ce448cf36da92e35442b00e04d342ab576e318e7ba2f24d7420174ce'
freeze=h/'r12-focused-termination-frozen-inputs'
freeze.mkdir(exist_ok=False)
inventory=[]
for relative,both in rows:
    root=w/'tests/omega'/relative
    files={}
    for f in sorted(root.iterdir()):
        if not f.is_file() or not (f.suffix=='.omg' or f.name.startswith('expected')): continue
        dest=freeze/relative/f.name
        dest.parent.mkdir(parents=True,exist_ok=True)
        data=f.read_bytes();dest.write_bytes(data)
        files[f.name]={'sha256':hashlib.sha256(data).hexdigest(),'frozen':str(dest)}
    inventory.append({'fixture':relative,'runtime_both':both,'files':files})
(h/'r12-focused-termination-inputs.json').write_text(json.dumps({'producer_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'fixture_count':len(rows),'fixtures':inventory},indent=2)+'\n')
results=[]
for item in inventory:
    relative=item['fixture'];root=w/'tests/omega'/relative
    slug=relative.replace('/','-')
    env=dict(os.environ,VALIDATION_PRODUCER='pending-admission-r12',VALIDATION_PROJECT=str(root))
    actions=[('update',['update','--project',str(root),'--offline']),('check',['--check',str(root/'main.omg')])]
    if item['runtime_both']: actions.append(('both',['run',str(root/'main.omg'),'--both','--keep']))
    outcomes={}
    for phase,args in actions:
        label='pending-admission-r12-focused-'+slug+'-'+phase
        print('START',label,flush=True)
        log=h/(label+'-helper.log')
        with log.open('w') as output:
            run=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],env=env,stdout=output,stderr=subprocess.STDOUT)
        record=h/(label+'.json')
        if not record.exists():
            outcomes[phase]={'helper_exit':run.returncode,'helper_log':str(log)}
        else:
            receipt=json.loads(record.read_text())
            raw=Path(receipt['stdout']).read_text(errors='replace')+Path(receipt['stderr']).read_text(errors='replace')
            outcomes[phase]={'exit':receipt['exit'],'seconds':receipt['seconds'],'receipt':str(record),'identity_setup_fence':any(term in raw.lower() for term in ['compiler identity','compiler-identity','compiler_identity'])}
            if phase=='check' and relative.startswith('fail/'):
                fragments=[line.strip() for line in (root/'expected.txt').read_text().splitlines() if line.strip()]
                outcomes[phase]['expected_fragments']=fragments
                outcomes[phase]['missing_fragments']=[part for part in fragments if part not in raw]
                outcomes[phase]['fact_sensitive_rejection']=receipt['exit']!=0 and not outcomes[phase]['missing_fragments'] and not outcomes[phase]['identity_setup_fence']
        print('END',label,json.dumps(outcomes[phase]),flush=True)
    for name,details in item['files'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==details['sha256'],(relative,name)
    results.append({'fixture':relative,'outcomes':outcomes})
    (h/'r12-focused-termination-outcomes.json').write_text(json.dumps(results,indent=2)+'\n')
print('FINISHED',len(results),flush=True)
