from pathlib import Path
import json,os,re,subprocess,sys
w=Path.cwd();h=Path(__file__).parent;label=sys.argv[1];producer=sys.argv[2]
summary={'state':'running','observations':[]};sp=h/(label+'-summary.json');assert not sp.exists()
projects=[
 ('original-crash','samples/cli/facts/provider_contract_endpoint/controls/crashing_endpoint','refuse',None),
 ('layout-demanded-crash','tests/omega/fail/constants/target_layout_derived_demanded_crashing_helper_reject','refuse',None),
 ('layout-derived-crash','tests/omega/fail/constants/target_layout_derived_crashing_helper_reject','refuse',None),
 ('runtime-trap','samples/cli/facts/provider_contract_endpoint/guarded_crash/controls/runtime_zero_divisor','trap',None),
]
def save():sp.write_text(json.dumps(summary,indent=2)+'\n')
try:
 for name,relative,kind,expected in projects:
  project=w/relative;actions=[('update',['update','--project',str(project),'--offline'])]
  if kind!='refuse':actions.append(('both',['run',str(project/'main.omg'),'--both','--keep']))
  for action,args in actions:
   runlabel=label+'-'+name+'-'+action;assert not (h/(runlabel+'.json')).exists()
   wrapper=subprocess.run([sys.executable,str(h/'run_cli.py'),runlabel,*args],env=dict(os.environ,VALIDATION_PRODUCER=producer,VALIDATION_PROJECT=relative),capture_output=True)
   assert wrapper.returncode==0,wrapper.stderr.decode(errors='replace')[-3000:]
   r=json.loads((h/(runlabel+'.json')).read_text());raw=Path(r['stdout']).read_text()+Path(r['stderr']).read_text()
   row={'project':relative,'kind':kind,'action':action,'receipt':str(h/(runlabel+'.json')),'exit':r['exit']}
   if kind=='refuse':
    row['before_execution_refusal']='constant evaluation requires proof that no crash route can occur before execution' in raw
    row['interpreted_trap']='Crashed(' in raw
    success=r['exit']!=0 and row['before_execution_refusal'] and not row['interpreted_trap']
   elif action=='update':success=r['exit']==0
   elif kind=='trap':
    row['native_signals']=re.findall(r'native signal (\d+)',raw);row['terminal_trap']='interp crash: Trap (host presentation agrees)' in raw
    success=r['exit']==255 and bool(row['native_signals']) and row['terminal_trap']
   else:
    row['native_exits']=re.findall(r'native exit (-?\d+)',raw);row['terminal_exits']=re.findall(r'interp exit: (-?\d+)',raw)
    success=r['exit']==expected and row['native_exits']==[str(expected)] and row['terminal_exits']==[str(expected)]
   row['passed']=success;summary['observations'].append(row);save();print(name,action,'actual exit',r['exit'],'passed',success,flush=True)
   if not success:raise RuntimeError(runlabel+': '+raw[-5500:])
 summary['state']='complete'
except BaseException as error:summary['state']='stopped_on_failure';summary['failure']=repr(error);raise
finally:save()
