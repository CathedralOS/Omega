Use five rejection controls for the pending exact-arithmetic path. Two existing positives are useful counterparts. This is source inspection only: no compiler was run and no fixture, expectation or build input was changed. Every fixture below is a key relative to tests/omega; main.omg is its source. The companion JSON records file hashes and exact expected fragments.

The current producer defers only an unresolved runtime ResultRepresentable judgment: the ordinary occurrence walk must be enabled, there must be no specification-fact context or storage graph, and no target-dependent recipe may have handled the obligation already. It immediately refuses when the whole computed interval is outside the carrier. Division/remainder definedness, static constant evaluation, receiving-domain membership and rank formation are different obligations. The five selected runtime operations have possible in-carrier and out-of-carrier results, rather than an interval wholly outside. They therefore exercise the pending path by source inspection; this is not a claim that a trace has observed their pending rows.

1. fail/arithmetic/zero_product_operand_overflow_rejected/main.omg:1:
   `machine product(value: u64) -> u64 { (value + 1) * 0 }`
   The unknown u64 input makes value+1 unsafe at MAX. Its range begins at 1 and has no finite upper endpoint in the interval representation, so it intersects u64. The parent product is zero, but it must not discharge or drop the child’s pending formation. expected.txt requires “may overflow `u64`”.

2. fail/facts/unsigned_exact_addition_bound_through_local_rejected/main.omg:6–12:
   `requires lhs >= 15 && lhs <= 40 && rhs >= 25 && rhs <= 51`
   `let sum: u64 = lhs + rhs; let s: u64 = sum;`
   `let headroom: u64 = 90u64 - s; let margin: u64 = s - 40u64; 0i32`
   The sum is safe from 40 through 91. The unused headroom local ranges from -1 through 50, so its failure is unresolved rather than definitely outside. Returning zero and never using headroom must not erase its mandatory pending occurrence. expected.txt requires “may overflow `u64`”. This gives unused-operation coverage independently of the cancelled child in control 1.

3. fail/expressions/match_operand_anonymous_operation_overflow/main.omg:5–12:
   `match flag { true -> 200 _ -> 1 } + match flag { true -> 100 _ -> 1 }`
   Both operands fit their u8 receiving carrier individually. The outer operation ranges from 2 through 300; the true arm computes 300 and the false arm computes 2. The safe arm cannot justify the unsafe arm, and this is not an out-of-range literal rejection before the operation. expected.txt requires “may overflow `u8`”.

4. fail/facts/nested_machine_wrapping_index_exact_child_formation_rejected/main.omg:5–7:
   `window.index = ((window.offset as u64) + 17) as u64 in Wrapping;`
   `transition enabled && window.index < 512 { true -> read(window) false -> 0 }`
   The plain u64 child computes before the outer wrapping policy and before the later guard. Its unknown input permits safe and overflowing results, so the child is deferred. Neither receiving policy nor later narrowing can establish that earlier occurrence. expected.txt requires exactly: “exact arithmetic in machine `probe` state `entry` cast expression may overflow `u64`”.

5. fail/arithmetic/match_subject_write_changes_operand_version/main.omg:1–5:
   `machine change(cell: &mut Cell) -> bool { cell.value = 2; true }`
   `cell.value - (match change(cell) { true -> cell.value, false -> cell.value })`
   The left operand snapshots the arbitrary incoming u32 value. The right operand observes post-write value 2. The possible difference spans safe and unsafe values, so it is not wholly outside the carrier. Deferring must preserve those distinct versions through the match and overlapping write. expected.txt requires “may overflow `u32`”.

Useful positive counterparts:

- pass/arithmetic/runtime_unbounded_zero_product_exit/main.omg:1–15 contains value*0, 0*value, and value*factor under factor == 0. These have no unsafe computed child and should remain admitted. Both expected_native_exit.txt and expected_interpreter_exit.txt contain 0. This distinguishes dropping a genuine child obligation from valid zero-product reasoning; it need not itself use the new pending path.
- pass/arithmetic/call_argument_snapshot_survives_write_exit/main.omg:12–15 saves before, calls capture(before,&mut cell), then subtracts captured-before. Main verifies that both saved values remain 1 while the live cell becomes 2. Source checking should succeed and expected_native_exit.txt contains 0. This guards preserved scalar snapshots; it may already be discharged before deferral. No Terminal execution is claimed by this inspection.

Do not credit these tempting alternatives as demonstrations of the new pending path:

- fail/arithmetic/call_argument_snapshot_not_current_field has concrete 1 minus 2. If the ordinary interval analysis retains both singletons, definitely_outside rejects it immediately. It remains a useful semantic rejection, but its source alone cannot establish that a pending row was consumed.
- fail/facts/exact_integer_narrowing_unsafe_exact_intermediate_rejected has a guarded positive value plus u32::MAX. Its whole computed interval is outside u32, so the new immediate-refusal branch is sufficient; it is not the primary pending-child canary.
- fail/generics/open_const_unused_const_overflow fails static constant arithmetic before this runtime path. fail/generics/runtime_value_recipe_unused_overflow is declaration/index formation, not an executable occurrence. fail/providers/applied_binding_unused_const_overflow is a constant carrier-fit failure.
- fail/arithmetic/zero_product_operand_division_rejected and divide_by_zero_rejected check division definedness; require_representable_result explicitly leaves division/remainder to that owner.
- fail/domains/computed_qualification_requires_operand_facts and dispatch_cast_wrong_arm fail qualification or narrowing, so they do not replace a deferred binary representability control.

The strengthened mutable_recast/match_join positive and its fact-sensitive twin remain the direct acceptance for the new behavior. This selection adds no new baseline or fixture family. R13 observations, including whether every intended pending path is actually reached, must be recorded separately from this source-based expectation.
