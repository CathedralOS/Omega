from pathlib import Path
import subprocess, sys, json, time
records = Path(__file__).parent
steps = [
    ('runner-build', [sys.executable, str(records / 'build_corpus.py'), 'interval-window-r15-runner-link-retry']),
    ('prepare-fixtures', [sys.executable, str(records / 'prepare_interval_fixture_replay_r15.py')]),
    ('corpus', [sys.executable, str(records / 'observe_interval_corpus.py'), 'interval-window-r15-corpus', 'interval-window-r15-runner-link-retry', 'interval-window-r15-corpus-selection.json']),
]
observations = []
for name, command in steps:
    started = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    observations.append({'name': name, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - started})
    (records / 'interval-window-r15-runner-retry-chain.json').write_text(json.dumps(observations, indent=2) + '\n')
    print(name, 'exit', result.returncode, 'seconds', round(observations[-1]['seconds'], 2), flush=True)
    if result.returncode:
        sys.exit(result.returncode)
