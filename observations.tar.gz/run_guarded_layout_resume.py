from pathlib import Path
import subprocess,sys,os,json,re
h=Path(__file__).parent;w=Path.cwd();relative='tests/omega/pass/generics/folded_range_endpoint_selection_custody';project=w/relative;rows=[]
for action,args in [('resume',['update','--project',str(project),'--offline','--resume']),('both',['run',str(project/'main.omg'),'--both','--keep'])]:
 label='guarded-crash-r22-folded-'+action;assert not(h/(label+'.json')).exists()
 result=subprocess.run([sys.executable,str(h/'run_cli.py'),label,*args],env=dict(os.environ,VALIDATION_PRODUCER='guarded-crash-r22',VALIDATION_PROJECT=relative),capture_output=True)
 assert result.returncode==0,result.stderr.decode(errors='replace')[-2000:]
 r=json.loads((h/(label+'.json')).read_text());raw=Path(r['stdout']).read_text()+Path(r['stderr']).read_text();passed=r['exit']==(70 if action=='both'else 0)
 if action=='both':passed=passed and re.findall(r'native exit (-?\d+)',raw)==['70']and re.findall(r'interp exit: (-?\d+)',raw)==['70']
 rows.append({'action':action,'receipt':str(h/(label+'.json')),'exit':r['exit'],'seconds':r['seconds'],'passed':passed});(h/'guarded-crash-r22-folded-resume-summary.json').write_text(json.dumps({'state':'complete'if passed and action=='both'else'running'if passed else'stopped_on_failure','observations':rows},indent=2)+'\n');print(action,'actual exit',r['exit'],'passed',passed,flush=True)
 if not passed:print(raw[-4500:],flush=True);sys.exit(1)
