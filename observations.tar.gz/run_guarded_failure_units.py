from pathlib import Path
import subprocess,json,time,hashlib,sys
h=Path(__file__).parent;label=sys.argv[1];head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();patch=subprocess.check_output(['git','diff','HEAD','--','omega-rust']);(h/(label+'-source.patch')).write_bytes(patch)
command=['cargo','nextest','run','--locked','-p','terminal-codec','-p','terminal-installation','-p','build-time-evaluation','-p','terminal-interpreter','-p','checked-trees','-p','checked-trees-to-lowered-psi','-E','test(scalar_condition) | test(scalar_predicate) | test(scalar_application) | test(entry_results) | test(constant_recipe) | test(constant_predicate) | test(integer_range_obligation) | test(compiler_failure) | test(compiler_evaluation::failures) | test(invocation_failure) | test(source_admission) | test(source_failure_summary)']
t=time.monotonic()
with (h/(label+'.stdout')).open('wb') as out,(h/(label+'.stderr')).open('wb') as err:r=subprocess.run(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL)
assert subprocess.check_output(['git','diff','HEAD','--','omega-rust'])==patch
receipt={'command':command,'exit':r.returncode,'seconds':time.monotonic()-t,'head':head,'patch_sha256':hashlib.sha256(patch).hexdigest()};(h/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((h/(label+'.stderr')).read_text()[-5000:]);sys.exit(r.returncode)
