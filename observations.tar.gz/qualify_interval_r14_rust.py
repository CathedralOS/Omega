from pathlib import Path
import subprocess,sys,json,time
h=Path(__file__).parent;rows=[]
commands=[('unit-tests',[sys.executable,str(h/'run_interval_r14_unit_tests.py')]),('unit-cache',[sys.executable,str(h/'compress_interval_cache.py'),'interval-window-r14-unit-tests']),('lint',[sys.executable,str(h/'run_interval_r14_lint.py')]),('lint-cache',[sys.executable,str(h/'compress_interval_cache.py'),'interval-window-r14-lint']),('runner-build',[sys.executable,str(h/'build_corpus.py'),'interval-window-r14-runner'])]
for name,command in commands:
 t=time.monotonic();r=subprocess.run(command,stdin=subprocess.DEVNULL);rows.append({'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-t});(h/'interval-window-r14-rust-chain.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,'exit',r.returncode,'seconds',round(rows[-1]['seconds'],2),flush=True)
 if r.returncode:sys.exit(r.returncode)
