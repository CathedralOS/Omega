from pathlib import Path
import subprocess,hashlib,os,json,shutil,sys
root=Path('/Users/zcanann/Documents/Projects/Omega/build/gate-cli-reuse-current/debug');h=Path(__file__).parent;label=sys.argv[1];rows=[]
files=sorted((p for p in root.rglob('*') if p.is_file() and p.suffix in ['.rlib','.rmeta'] and p.stat().st_size>1024**2),key=lambda p:p.stat().st_size,reverse=False)
for source in files:
 before=source.stat()
 if before.st_blocks*512<before.st_size//2:continue
 temporary=source.with_name(source.name+'.compressed-copy');digest=hashlib.sha256(source.read_bytes()).hexdigest();result=subprocess.run(['ditto','--hfsCompression',str(source),str(temporary)],capture_output=True,text=True);assert result.returncode==0,result.stderr
 after=temporary.stat();assert after.st_size==before.st_size and after.st_mtime_ns==before.st_mtime_ns and hashlib.sha256(temporary.read_bytes()).hexdigest()==digest
 saved=(before.st_blocks-after.st_blocks)*512
 if saved>0:os.replace(temporary,source)
 else:temporary.unlink()
 rows.append({'file':str(source),'sha256':digest,'saved_bytes':max(0,saved),'mtime_preserved':True})
(h/(label+'-cache-compression.json')).write_text(json.dumps({'purpose':'Transparent compression of disposable compiler cache only. Contents and modification times verified unchanged. Saved compilers and run artifacts untouched.','files':rows,'saved_bytes':sum(r['saved_bytes'] for r in rows),'free_bytes':shutil.disk_usage(root).free},indent=2)+'\n')
print('Cache bytes unchanged; freed',round(sum(r['saved_bytes'] for r in rows)/1024**2),'MiB; available',round(shutil.disk_usage(root).free/1024**2),'MiB.',flush=True)
