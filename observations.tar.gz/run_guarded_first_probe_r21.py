from pathlib import Path
import hashlib,json,os,re,subprocess,sys
h=Path(__file__).parent;w=Path.cwd();label=sys.argv[1];producer=sys.argv[2]
root=w/'samples/cli/facts/provider_contract_endpoint/guarded_crash/local';rows=[]
for invalid in [False,True]:
 project=root/('invalid' if invalid else '');actions=[('update',['update','--project',str(project),'--offline'])]
 if not invalid:actions.append(('both',['run',str(project/'main.omg'),'--both','--keep']))
 for action,args in actions:
  name=label+('-invalid-' if invalid else '-positive-')+action;assert not(h/(name+'.json')).exists()
  wrapper=subprocess.run([sys.executable,str(h/'run_cli.py'),name,*args],env=dict(os.environ,VALIDATION_PRODUCER=producer,VALIDATION_PROJECT=str(project.relative_to(w))),capture_output=True)
  assert wrapper.returncode==0,wrapper.stderr.decode(errors='replace')[-2500:]
  r=json.loads((h/(name+'.json')).read_text());raw=Path(r['stdout']).read_text()+Path(r['stderr']).read_text()
  success=r['exit']!=0 and ('constant evaluation requires proof that no crash route can occur before execution' in raw or ('constant expression' in raw and 'can crash with [Trap]' in raw)) and 'Crashed(' not in raw if invalid else r['exit']==0
  if action=='both':success=success and re.findall(r'native exit (-?\d+)',raw)==['0'] and re.findall(r'interp exit: (-?\d+)',raw)==['0']
  rows.append({'invalid':invalid,'action':action,'receipt':str(h/(name+'.json')),'exit':r['exit'],'passed':success})
  (h/(label+'-summary.json')).write_text(json.dumps({'observations':rows,'state':'running' if success else 'stopped_on_failure'},indent=2)+'\n')
  print('invalid' if invalid else 'positive',action,'exit',r['exit'],'passed',success,flush=True)
  if not success:print(raw[-6500:],flush=True);sys.exit(1)
(h/(label+'-summary.json')).write_text(json.dumps({'observations':rows,'state':'complete'},indent=2)+'\n')
