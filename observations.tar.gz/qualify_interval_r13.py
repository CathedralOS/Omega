from pathlib import Path
import subprocess,sys,json,time,hashlib
h=Path(__file__).parent;rows=[]
frozen=json.loads((h/'interval-window-r12-match-authored-inputs.json').read_text())
for item in frozen['files']:
 name=item['file'];assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==item['new_sha256'],name
commands=[
 ('aliases',[sys.executable,str(h/'remove_private_producer_aliases.py'),'interval-window-r13']),
 ('behavior',[sys.executable,str(h/'qualify_interval_r13_behavior.py')]),
 ('archive-prior-runner',[sys.executable,str(h/'archive_completed_producer_xz.py'),'interval-window-r12-runner-link-retry']),
 ('rust',[sys.executable,str(h/'qualify_interval_r13_rust.py')]),
 ('prepare-fixtures',[sys.executable,str(h/'prepare_interval_fixture_replay_r13.py')]),
 ('corpus',[sys.executable,str(h/'observe_interval_corpus.py'),'interval-window-r13-corpus','interval-window-r13-runner','interval-window-r13-corpus-selection.json']),
]
for name,command in commands:
 t=time.monotonic();r=subprocess.run(command,stdin=subprocess.DEVNULL)
 rows.append({'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-t})
 (h/'interval-window-r13-qualification-chain.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,'exit',r.returncode,'seconds',round(rows[-1]['seconds'],2),flush=True)
 if r.returncode:sys.exit(r.returncode)
