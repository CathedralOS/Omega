from pathlib import Path
import sys,json,hashlib,copy
h=Path(__file__).parent; sys.path.insert(0,str(Path.cwd()/'tools')); import corpus_records as records
root=h/'saved-loans-hosted-41774629213'; summary=json.loads((root/'summary.json').read_text()); verdict=json.loads((root/'checking.json').read_text()); source='cd5340c6d0348e868e34d68ee85f250c431f79ba'
assert summary['candidate']==summary['producer']['revision']==verdict['revision']==source
assert verdict['counts']['fixtures']==61 and verdict['counts']['by_status']=={'checked':24,'rejected':37},verdict['counts']
for key in ['wrong_reason','fail_not_rejected','lost_successes','pinned_off_target']: assert verdict['counts'][key]==0,(key,verdict['counts'])
assert not verdict['oracle_failures'] and not verdict['infrastructure_error']
controls=json.loads((h/'saved-loans-negative-sample-applicability-plan.json').read_text())['controls']; observed={row['fixture']:row for row in verdict['observations']}
for control in controls:
 row=observed[control['fixture']]; assert row['status']=='rejected' and row['expected_satisfied'] is True
 diagnostics='\n'.join(row['diagnostics']); assert all(fragment in diagnostics for fragment in control['required_fragments']),(control,row['diagnostics'])
(h/'saved-loans-negative-sample-applicability.json').write_text(json.dumps({'purpose':'The same source and Build files were checked by the fresh hosted producer; each sample’s own diagnostic fragments also match the actual captured refusal. No negative compiler execution is repeated locally.','source':source,'hosted_run':41774629213,'controls':controls,'all_sample_diagnostic_requirements_matched':True},indent=2)+'\n')
selection=json.loads((h/'saved-loans-hosted-checking-selection.json').read_text())['fixtures']; selected=set(selection[:54]); assert len(selected)==54
rows=[copy.deepcopy(row) for row in verdict['observations'] if row['fixture'] in selected]; assert len(rows)==54
assert sum(row['status']=='checked' for row in rows)==18 and sum(row['status']=='rejected' for row in rows)==36
for row in rows:
 assert row['status']==('checked' if row['fixture'].startswith('pass/') else 'rejected')
 if row['status']=='rejected': assert row['expected_satisfied'] is True and row['diagnostics']
 row['recorded_at']=source
path=Path('tests/omega/corpus_outcomes.txt'); before=path.read_text(); after=records.splice(before,rows)
def blocks(text):
 out={}; key=None
 for line in text.splitlines(keepends=True):
  if not line.strip() or line.startswith('#'):continue
  if line.startswith('\t'):out[key]+=line
  else:key=line.split()[0]; assert key not in out; out[key]=line
 return out
old=blocks(before); new=blocks(after); assert set(old)<=set(new); assert all(new[key]==block for key,block in old.items() if key not in selected)
(h/'saved-loans-corpus-before.txt').write_text(before); path.write_text(after)
receipt={'purpose':'Record actual source-checking outcomes for the 54 edited fixtures. Runtime observations remain in the separate public-CLI record.','source':source,'hosted_run':41774629213,'producer':summary['producer'],'checked':18,'rejected':36,'selected':sorted(selected),'old_sha256':hashlib.sha256(before.encode()).hexdigest(),'new_sha256':hashlib.sha256(after.encode()).hexdigest(),'all_unselected_blocks_byte_identical':True,'removed_keys':[],'new_keys':sorted(set(new)-set(old))}
(h/'saved-loans-corpus-recording.json').write_text(json.dumps(receipt,indent=2)+'\n'); print('Recorded 18 checked positives and 36 intended rejections; all other rows unchanged.')
