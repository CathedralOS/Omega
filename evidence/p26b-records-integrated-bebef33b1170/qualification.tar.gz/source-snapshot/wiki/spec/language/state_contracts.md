# Invocation contracts and live facts

These are source-language obligations, not a list of patterns recognized by the
Rust compiler. [Mathematical proof contracts](../proofs/contracts.md) owns theorem
meaning, assumptions, bundles, and evidence; [Terminal fact validity](../terminal-psi/fact_validity.md)
governs which premises the emitted product's obligations may use.

## Bindings and arrivals

A machine enters its own executable body; there is no separately authored entry
member. Trailing nested declarations scope helper names, not runtime data.
[Nested machines](machines.md#nested-machines-and-identity) defines visibility,
declaration order and flattening. Both ordinary and terminal calls invoke the
selected machine with ordinary explicit parameters. Context records and their
borrows are supplied like other arguments; no receiver or enclosing activation
is retained or rebound implicitly.
An ordinary terminal value, explicit return, or permitted implicit Unit
completion ends the invocation and owes its declared result/return contract.

A transition explicitly supplies the target machine's arguments. Executable uses
name the exact invocation's parameters or preceding local bindings; arrival
contracts use the target's parameters. Enclosing and sibling runtime bindings cannot be
recovered by matching spelling. Nominal member and case selection retains the
declared owner, including payload projections rooted at an explicit context argument.

Machine `requires` applies at every invocation, including terminal and recursive
calls. Every arrival establishes the target's requirements and declared domains
under actual argument substitution. Nesting does not assume the parent's entry
requirements again, import its return guarantees, or supply facts invalidated
by mutation. Live caller facts can discharge a nested helper's requirements;
body inference must justify any inferred private requirements on every arrival,
not grant them from lexical ancestry. Every invocation retains both sides of
its own contract. A recursive contract is not its own proof; induction follows
the well-founded obligations in [termination](termination.md).

Arrival substitution is simultaneous and identity-based. Scalar arguments retain
their evaluation snapshots; facts about referenced storage must survive writes
from later arguments. A same-named formal cannot alias an unrelated caller value.
Every reachable predecessor participates in a join. Unknown input cannot be
omitted to preserve a convenient invariant. A minimum collection length is not
an exact extent, and declaration initializers are not recurring loop invariants.

## Terminal calls in transition arms

Resolve every called target as a machine, nested or otherwise. A terminal call
is an invocation whose normal result completes the current machine, including Unit completion.
Argument admission, result compatibility, machine postconditions, cleanup,
crash and no-normal-return behavior are the ordinary call-and-completion rules.
Only the selected arm executes, with ordinary once-only operand evaluation.

Terminal machine calls accept the same exact operational acknowledgements as
other calls:

```omega
// Assuming Storage::read permits both suspension and blocking:
transition {
    _ -> suspend block Storage::read(storage)
}
```

This invokes `Storage::read` in the current activation and forwards its normal
result; it does not start or detach a task. If the call parks, completion of the
enclosing machine remains pending. No return, cleanup or storage reclamation
occurs merely because the call is syntactically final or becomes suspended.
Ordinary cleanup-bearing completion edges still discharge their obligations.
Tail-call lowering may remove unnecessary control state only while preserving
all live backing, loans, custody and completion obligations. Recursive runtime
calls still obey the no-accumulated-frames rule.

Nested machine calls have no marker exemption. Their exact call envelope
determines `suspend` and `block`, including in terminal position, even when
lowering later implements the call with a jump. Markers do not redirect name
resolution. Missing, partial or redundant call markers reject under
[effects](effects.md#call-site-acknowledgements). The same
[borrow/carry requirements](../resources/carry.md#borrows-across-suspension)
apply in a terminal arm as at any other suspending call.

## Mutation and subject identity

Facts apply to their exact subjects and program points. Assignments first
[capture their destination place](expressions.md#evaluation-schedule), including
its selectors and bounds at that program point. They then evaluate the
right-hand side and its effects, capture transferable evidence, and finally
invalidate overlapping destination facts and establish the new value at the
captured place. Right-hand-side mutations invalidate their own overlapping facts
when they occur; the captured selector is not a fact that the selector's live
binding still has its earlier value. Uninitialized storage
has no assumed zero. Copies transport facts about the captured value, not source
expressions to be reevaluated after mutation.

A reference identifies live storage, not its former contents. Replacing a local
reference binding changes that binding without redirecting aliases made from its
previous value. A write through the reference changes the referent, not the
binding. Stored reference leaves retain their captured origins until replacement
or exposure invalidates that relation. Type or lifetime correspondence alone
does not establish a returned reference's storage origin.

Caller-visible mutation summaries include operand evaluation and callee writes.
A complete empty summary preserves facts; an unknown summary proves no
non-interference. Fact invalidation uses storage footprints, while borrow
authorization uses the access route. Neither may-write summaries nor origin
recovery grant loans, permit moves, or discharge linear claims.

## Returns and proof use

Normal returns owe applicable postconditions for both value and Unit results.
An implicit return occurs after the executable portion's final statement, not
after executing trailing declarations. A selected returning arm uses that arm's
facts. A terminal call owes both the callee's result and the caller's completion
contract; lexical ancestry adds no further return targets. Crash edges are not
normal returns. Synthetic `result` denotes the exact returned value; output-reference
parameters retain their actual reference origins.

Exit proof consumes live facts, not the conclusion being proved. Reference-subject
transport across calls or loop edges does not transport the truth of an expired
entry assumption. Declaration contexts cannot receive a sibling invocation's facts.
Outcome-specific guarantees follow the matching nominal result case and remain
separate from unconditional guarantees, as specified in
[proof availability](../proofs/contracts.md#identity-availability-and-erasure).

A call used as a total predicate term requires termination and absence of crash
routes. Equality conditional on normal runtime return does not establish total
denotation. Repeated calls need effect- and observation-free semantics plus exact
targets and inputs; an empty write summary alone does not prove repeatability.

Source proof search may be incomplete. Failure to infer an invariant, normalize
a term, or prove a supported implication grants no fact and is not a refutation.
Current algorithms and support limits belong beside
[checking](../../../omega-rust/psi/compilation/pipeline/04_typed-trees-to-checked-trees/README.md)
and [validation](../../../omega-rust/psi/compilation/checking/README.md).
