//! Bounded-value obligation checks for assignments, initializers, state
//! returns, call arguments and transition arguments.

use crate::checker::AssignmentRangeContext;
use crate::checker::assignment_stability::{
    collect_read_place_paths, member_paths_may_alias, written_place_path,
};
use crate::checker::certificate::{
    CertificateVerdict, bounded_integer_value_verdict, guarded_transition_integer_verdict_measured,
    state_return_integer_verdict,
};
use crate::checker::dependent_bounds::{
    dependent_call_field_floor, dependent_field_floor, guard_proves_dependent_upper,
    guard_proves_sibling_len_upper, incoming_guard_proves_dependent_call_upper,
    sibling_len_from_constraints, state_preserves_field, symbolic_max_from_constraints,
};
use crate::checker::derivation_cache::DerivationConsultation;
use crate::checker::diagnostics::{
    cannot_prove_bounded_assignment_float, cannot_prove_bounded_assignment_integer,
    cannot_prove_bounded_call_float, cannot_prove_bounded_call_integer,
    cannot_prove_bounded_initializer_float, cannot_prove_bounded_initializer_integer,
    cannot_prove_bounded_return_float, cannot_prove_bounded_return_integer,
    cannot_prove_bounded_transition_float, cannot_prove_bounded_transition_integer,
    cannot_prove_dependent_call_bound, cannot_prove_dependent_transition_bound,
    expression_display_name,
};
use crate::checker::float_ranges::{
    float_range_for_assignment, float_range_for_call_argument, float_range_for_initializer,
    float_range_for_return_value, float_range_from_constraints,
    guarded_float_range_for_transition_argument,
};
use crate::checker::integer_ranges::{
    guarded_integer_range_for_assignment_with_context,
    guarded_integer_range_for_transition_argument, integer_range_for_call_argument,
    integer_range_for_initializer, integer_range_for_state_return, integer_range_from_constraints,
    type_constraints,
};
use crate::checker::measurement::ProofPlanMeasurements;
use crate::checker::named_constraints::{
    check_assignment_named_constraints, check_call_named_constraints,
    check_initializer_named_constraints, check_return_named_constraints,
    check_transition_named_constraints,
};
use crate::checker::return_arrival;
use crate::obligations::{
    BoundedAssignmentObligation, BoundedCallArgumentObligation, BoundedInitializerObligation,
    BoundedStateReturnObligation, BoundedTransitionArgumentObligation, ProofPlan,
};
use crate::obligations::{FloatRange, IntegerRange, ProofConstraint, RecipeRangeBound};
use diagnostics::Diagnostic;
use numerics::bignum::BigInt;
use typed_trees::expression::ExpressionNode;
use typed_trees::statement::StatementNode;

pub(crate) fn check_bounded_assignment<'program>(
    proof_plan: &ProofPlan<'program>,
    obligation: &BoundedAssignmentObligation,
    context: &AssignmentRangeContext<'program>,
    seed: u64,
    diagnostics: &mut Vec<Diagnostic>,
    recipe_obligations: &mut Vec<checked_trees::ConstantRecipeObligation>,
    measurements: &mut ProofPlanMeasurements,
    derivations: Option<&mut DerivationConsultation<'_>>,
) -> Option<crate::obligations::IntegerRange> {
    // Chapter 11 invariant windows: an intermediate store need not itself
    // satisfy the place's constraints when a later store repairs the EXACT
    // place before anything can observe it.  The repairing assignment keeps
    // its own ordinary obligation; this only suppresses proof debt for a
    // value that is provably dead before the next consumption point.
    if assignment_is_overwritten_before_consumption(proof_plan, obligation) {
        return None;
    }

    let diagnostics_before = diagnostics.len();
    let mut checked_range = None;
    check_assignment_named_constraints(proof_plan, obligation, diagnostics);
    discharge_recipe_range(
        proof_plan,
        obligation.machine_symbol,
        obligation.constraints,
        guarded_integer_range_for_assignment_with_context(proof_plan, obligation, context),
        obligation.value,
        format!(
            "assignment to `{}` in `{}.{}`",
            proof_plan
                .program
                .expression_table
                .display_name(obligation.target),
            obligation.machine,
            obligation.state
        ),
        diagnostics,
        recipe_obligations,
    );

    if let Some(target_range) =
        integer_range_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        checked_range = Some(target_range.clone());
        // The certificate route decides the covered shapes on independently
        // checked evidence; everything else keeps the ordinary derivation.
        match bounded_integer_value_verdict(
            proof_plan,
            obligation.value,
            obligation.value_constraints,
            obligation.base_type,
            &target_range,
            seed,
            false,
            measurements,
            derivations,
        ) {
            CertificateVerdict::Certified => {}
            CertificateVerdict::Rejected => {
                diagnostics.push(cannot_prove_bounded_assignment_integer(
                    proof_plan,
                    obligation,
                    target_range,
                ));
            }
            CertificateVerdict::Uncovered => {
                let interval_fits = guarded_integer_range_for_assignment_with_context(
                    proof_plan, obligation, context,
                )
                .is_some_and(|range| {
                    range.minimum >= target_range.minimum && range.maximum <= target_range.maximum
                });
                // Independent intervals can lose correlations between operands.
                // Ask the arithmetic owner about this exact pre-store occurrence;
                // the promised destination range is a goal, never a premise.
                if !interval_fits
                    && !validation::occurrence_integer_expression_fits_range(
                        proof_plan.program,
                        obligation.machine_symbol,
                        obligation.state_symbol,
                        obligation.statement_index,
                        obligation.value,
                        &target_range.minimum,
                        &target_range.maximum,
                    )
                {
                    diagnostics.push(cannot_prove_bounded_assignment_integer(
                        proof_plan,
                        obligation,
                        target_range,
                    ));
                }
            }
        }
    }

    if discharge_declared_float_range(
        proof_plan,
        obligation,
        obligation.constraints,
        diagnostics,
        float_range_for_assignment,
        cannot_prove_bounded_assignment_float,
    ) {
        return None;
    }

    if diagnostics.len() == diagnostics_before {
        checked_range
    } else {
        None
    }
}

/// Whether this assignment's value is overwritten before it can be observed.
///
/// Calls and transitions are unconditional consumption points. Reads of the
/// place and writes that may alias it also close the window. Pure work over
/// disjoint places may occur between the opening write and its repair.
/// The shared atom leg of the dependent-bound discharge: the argument's
/// symbolic maximum must restate this field at a tighter-or-equal floor and
/// the state must preserve the field.
fn dependent_atom_proves(
    proof_plan: &ProofPlan,
    argument_constraints: arena::HandleSpan<crate::obligations::ProofConstraint>,
    machine: &str,
    state: &str,
    max_field: &typed_trees::name::Identifier,
    minimum: i64,
    max_offset: i64,
) -> bool {
    symbolic_max_from_constraints(type_constraints(proof_plan, argument_constraints)).is_some_and(
        |(arg_min, arg_field, arg_offset)| {
            arg_field.as_str() == max_field.as_str()
                && arg_offset <= max_offset
                && arg_min >= minimum
        },
    ) && state_preserves_field(proof_plan, machine, state, max_field)
}

fn assignment_is_overwritten_before_consumption(
    proof_plan: &ProofPlan,
    obligation: &BoundedAssignmentObligation,
) -> bool {
    let program = proof_plan.program;
    let Some(state) = program.machines().iter().find_map(|machine| {
        typed_trees::state::state_by_symbol(
            program.machine_states(machine),
            obligation.state_symbol,
        )
    }) else {
        return false;
    };
    let Some(window_path) = written_place_path(proof_plan, obligation.target) else {
        return false;
    };
    // Indexed places intentionally stay strict for now: the path helper
    // collapses an element to its collection, so equal paths would not prove
    // that two dynamic indexes denote the same location.
    if matches!(
        program.expression_table.expression(obligation.target),
        ExpressionNode::Indexed(_)
    ) {
        return false;
    }
    let target_name = program.expression_table.display_name(obligation.target);
    let mut reached_assignment = false;

    for statement in program.statement_table.statements(state.statement_nodes) {
        if !reached_assignment {
            if let Some(assignment) = statement.as_assignment()
                && assignment.target == obligation.target
                && assignment.value == obligation.value
            {
                reached_assignment = true;
            }
            continue;
        }

        match statement {
            StatementNode::Assembly(_) => {}
            // A proof assertion is a semantic consumption point: an open
            // invariant window may not flow through it.
            StatementNode::AssemblyFact(_) => return false,
            StatementNode::Assignment(assignment) => {
                if crate::typed_expressions::expression_contains_call_node(
                    proof_plan.program,
                    assignment.value,
                ) {
                    return false;
                }
                let mut reads = Vec::new();
                collect_read_place_paths(proof_plan, assignment.value, &mut reads);
                if reads
                    .iter()
                    .any(|read| member_paths_may_alias(read, &window_path))
                {
                    return false;
                }

                let Some(written) = written_place_path(proof_plan, assignment.target) else {
                    return false;
                };
                if program.expression_table.display_name(assignment.target) == target_name {
                    return true;
                }
                if member_paths_may_alias(&written, &window_path) {
                    return false;
                }
            }
            StatementNode::LocalData(local) => {
                if local.initial_value.is_valid() {
                    if crate::typed_expressions::expression_contains_call_node(
                        proof_plan.program,
                        local.initial_value,
                    ) {
                        return false;
                    }
                    let mut reads = Vec::new();
                    collect_read_place_paths(proof_plan, local.initial_value, &mut reads);
                    if reads
                        .iter()
                        .any(|read| member_paths_may_alias(read, &window_path))
                    {
                        return false;
                    }
                }
            }
            StatementNode::Expression(expression) => {
                if crate::typed_expressions::expression_contains_call_node(
                    proof_plan.program,
                    *expression,
                ) {
                    return false;
                }
                let mut reads = Vec::new();
                collect_read_place_paths(proof_plan, *expression, &mut reads);
                if reads
                    .iter()
                    .any(|read| member_paths_may_alias(read, &window_path))
                {
                    return false;
                }
            }
            StatementNode::Call(_) | StatementNode::Transition(_) => return false,
        }
    }

    false
}

pub(crate) fn check_bounded_initializer(
    proof_plan: &ProofPlan,
    obligation: &BoundedInitializerObligation,
    seed: u64,
    diagnostics: &mut Vec<Diagnostic>,
    recipe_obligations: &mut Vec<checked_trees::ConstantRecipeObligation>,
    measurements: &mut ProofPlanMeasurements,
    derivations: Option<&mut DerivationConsultation<'_>>,
) {
    check_initializer_named_constraints(proof_plan, obligation, diagnostics);
    discharge_recipe_range(
        proof_plan,
        obligation.owner.machine_symbol().unwrap_or_default(),
        obligation.constraints,
        integer_range_for_initializer(proof_plan, obligation),
        obligation.value,
        "initializer".to_owned(),
        diagnostics,
        recipe_obligations,
    );

    if let Some(target_range) =
        integer_range_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        // The certificate route covers the literal and declared legs; every
        // other shape stays uncovered.
        match bounded_integer_value_verdict(
            proof_plan,
            obligation.value,
            obligation.value_constraints,
            obligation.base_type,
            &target_range,
            seed,
            false,
            measurements,
            derivations,
        ) {
            CertificateVerdict::Certified => {}
            CertificateVerdict::Rejected => {
                diagnostics.push(cannot_prove_bounded_initializer_integer(
                    proof_plan,
                    obligation,
                    target_range,
                ));
            }
            CertificateVerdict::Uncovered => {
                let value_range = integer_range_for_initializer(proof_plan, obligation);
                let interval_fits = value_range.as_ref().is_some_and(|range| {
                    range.minimum >= target_range.minimum && range.maximum <= target_range.maximum
                });
                // A state local's initializer is evaluated at its declaring
                // statement: ask the arithmetic owner about that occurrence,
                // as an assignment does.
                let occurrence_fits = !interval_fits
                    && obligation.owner.state_statement().is_some_and(
                        |(machine_symbol, state_symbol, statement_index)| {
                            validation::occurrence_integer_expression_fits_range(
                                proof_plan.program,
                                machine_symbol,
                                state_symbol,
                                statement_index,
                                obligation.value,
                                &target_range.minimum,
                                &target_range.maximum,
                            )
                        },
                    );
                if !interval_fits && !occurrence_fits {
                    diagnostics.push(cannot_prove_bounded_initializer_integer(
                        proof_plan,
                        obligation,
                        target_range,
                    ));
                    if value_range.is_none() {
                        return;
                    }
                }
            }
        }
    }

    if discharge_declared_float_range(
        proof_plan,
        obligation,
        obligation.constraints,
        diagnostics,
        float_range_for_initializer,
        cannot_prove_bounded_initializer_float,
    ) {
        return;
    }
}

pub(crate) fn check_bounded_state_return<'program>(
    proof_plan: &ProofPlan<'program>,
    obligation: &BoundedStateReturnObligation,
    context: &AssignmentRangeContext<'program>,
    seed: u64,
    diagnostics: &mut Vec<Diagnostic>,
    recipe_obligations: &mut Vec<checked_trees::ConstantRecipeObligation>,
    measurements: &mut ProofPlanMeasurements,
    derivations: Option<&mut DerivationConsultation<'_>>,
) {
    check_return_named_constraints(proof_plan, obligation, diagnostics);
    discharge_recipe_range(
        proof_plan,
        obligation.machine_symbol,
        obligation.constraints,
        integer_range_for_state_return(proof_plan, obligation),
        obligation.value,
        format!("return from `{}.{}`", obligation.machine, obligation.state),
        diagnostics,
        recipe_obligations,
    );

    if let Some(target_range) =
        integer_range_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        // The certificate route covers the declared-or-literal legs the
        // arrival machinery would reach anyway, the arrival bound itself,
        // and the Requires-contract refinement; malformed obligations and
        // the operand-level folds stay uncovered.
        match state_return_integer_verdict(
            proof_plan,
            obligation,
            context,
            &target_range,
            seed,
            measurements,
            derivations,
        ) {
            CertificateVerdict::Certified => {}
            CertificateVerdict::Rejected => {
                diagnostics.push(cannot_prove_bounded_return_integer(
                    proof_plan,
                    obligation,
                    target_range,
                ));
            }
            CertificateVerdict::Uncovered => {
                let Some(value_range) =
                    return_arrival::integer_range(proof_plan, obligation, context)
                else {
                    diagnostics.push(cannot_prove_bounded_return_integer(
                        proof_plan,
                        obligation,
                        target_range,
                    ));
                    return;
                };

                if value_range.minimum < target_range.minimum
                    || value_range.maximum > target_range.maximum
                {
                    diagnostics.push(cannot_prove_bounded_return_integer(
                        proof_plan,
                        obligation,
                        target_range,
                    ));
                }
            }
        }
    }

    if discharge_declared_float_range(
        proof_plan,
        obligation,
        obligation.constraints,
        diagnostics,
        float_range_for_return_value,
        cannot_prove_bounded_return_float,
    ) {
        return;
    }
}

pub(crate) fn check_bounded_call_argument(
    proof_plan: &ProofPlan,
    obligation: &BoundedCallArgumentObligation,
    seed: u64,
    diagnostics: &mut Vec<Diagnostic>,
    recipe_obligations: &mut Vec<checked_trees::ConstantRecipeObligation>,
    measurements: &mut ProofPlanMeasurements,
    derivations: Option<&mut DerivationConsultation<'_>>,
) {
    check_call_named_constraints(proof_plan, obligation, diagnostics);
    discharge_recipe_range(
        proof_plan,
        obligation.machine_symbol,
        obligation.constraints,
        integer_range_for_call_argument(proof_plan, obligation),
        obligation.argument,
        format!(
            "call argument for parameter `{}` of `{}`",
            obligation.parameter, obligation.target
        ),
        diagnostics,
        recipe_obligations,
    );

    if let Some(target_range) =
        integer_range_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        // The certificate route covers the anonymous, literal and declared
        // legs in the same order the ordinary derivation tries them.
        match bounded_integer_value_verdict(
            proof_plan,
            obligation.argument,
            obligation.argument_constraints,
            obligation.base_type,
            &target_range,
            seed,
            true,
            measurements,
            derivations,
        ) {
            CertificateVerdict::Certified => {}
            CertificateVerdict::Rejected => {
                diagnostics.push(cannot_prove_bounded_call_integer(
                    proof_plan,
                    obligation,
                    target_range,
                ));
            }
            CertificateVerdict::Uncovered => {
                let argument_range = integer_range_for_call_argument(proof_plan, obligation);
                let interval_fits = argument_range.as_ref().is_some_and(|range| {
                    range.minimum >= target_range.minimum && range.maximum <= target_range.maximum
                });
                // The argument's own interval loses the facts of its
                // evaluation point (guards, earlier stores). Ask the arithmetic
                // owner about this exact occurrence, as an assignment does.
                if !interval_fits
                    && !validation::occurrence_integer_expression_fits_range(
                        proof_plan.program,
                        obligation.machine_symbol,
                        obligation.state_symbol,
                        obligation.statement_index,
                        obligation.argument,
                        &target_range.minimum,
                        &target_range.maximum,
                    )
                {
                    diagnostics.push(cannot_prove_bounded_call_integer(
                        proof_plan,
                        obligation,
                        target_range,
                    ));
                    if argument_range.is_none() {
                        return;
                    }
                }
            }
        }
    }

    // R1 dependent maximum on a CALL argument: no co-located guard exists on
    // a call statement, so the rung-A discharges are the worst case through
    // the field's OWN enforced minimum, or the caller state's dominating
    // incoming-guard/arrival-contract fact -- and only for SELF-receiver
    // calls (the recognizer's `self.<field>` names the callee's data, which
    // for a self-call IS this machine's; cross-machine dependent params are
    // the R4 boundary-witness rung). Anything else refuses loudly.
    if let Some((minimum, max_field, max_offset)) =
        symbolic_max_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        let self_receiver = obligation
            .receiver
            .as_ref()
            .is_none_or(|receiver| receiver.is_self_receiver());
        let argument_range = integer_range_for_call_argument(proof_plan, obligation);
        // Route (c), as on transitions: a same-field tighter-or-equal
        // dependent argument forwards (self-receiver keeps `self.<field>`
        // the same place).
        let atom_proves = dependent_atom_proves(
            proof_plan,
            obligation.argument_constraints,
            obligation.machine.as_str(),
            obligation.state.as_str(),
            max_field,
            minimum,
            max_offset,
        );
        let proven = self_receiver
            && (atom_proves
                || incoming_guard_proves_dependent_call_upper(
                    proof_plan, obligation, max_field, max_offset,
                )
                || argument_range.is_some_and(|range| {
                    range.minimum >= BigInt::from_i64(minimum)
                        && dependent_call_field_floor(proof_plan, obligation, max_field)
                            .and_then(|floor| floor.checked_add(max_offset))
                            .is_some_and(|cap| range.maximum <= BigInt::from_i64(cap))
                }));
        if !proven {
            diagnostics.push(cannot_prove_dependent_call_bound(
                proof_plan, obligation, minimum, max_field, max_offset,
            ));
        }
    }

    // Sibling-length params on CALL arguments: a call has no co-located
    // guard and a slice length has no static floor, so no rung-A discharge
    // exists -- refuse with the route hint.
    if let Some((_, max_offset)) =
        sibling_len_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        let _ = max_offset;
        diagnostics.push(Diagnostic::error(format!(
            "cannot prove call argument `{}` satisfies sibling-length parameter `{}` for `{}` in `{}.{}`; route the call through a transition whose arm guards `{} < <items>.len`",
            expression_display_name(proof_plan, obligation.argument),
            obligation.parameter,
            obligation.target,
            obligation.machine,
            obligation.state,
            expression_display_name(proof_plan, obligation.argument),
        )));
    }

    if discharge_declared_float_range(
        proof_plan,
        obligation,
        obligation.constraints,
        diagnostics,
        float_range_for_call_argument,
        cannot_prove_bounded_call_float,
    ) {
        return;
    }
}

pub(crate) fn check_bounded_transition_argument(
    proof_plan: &ProofPlan,
    obligation: &BoundedTransitionArgumentObligation,
    seed: u64,
    diagnostics: &mut Vec<Diagnostic>,
    recipe_obligations: &mut Vec<checked_trees::ConstantRecipeObligation>,
    measurements: &mut ProofPlanMeasurements,
    mut derivations: Option<&mut DerivationConsultation<'_>>,
) {
    check_transition_named_constraints(proof_plan, obligation, diagnostics);
    discharge_recipe_range(
        proof_plan,
        obligation.machine_symbol,
        obligation.constraints,
        Some(guarded_integer_range_for_transition_argument(
            proof_plan, obligation,
        )),
        obligation.argument,
        "transition argument".to_owned(),
        diagnostics,
        recipe_obligations,
    );

    if let Some(target_range) =
        integer_range_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        // The certificate route covers the anonymous, literal and declared
        // legs in the same order the ordinary derivation tries them, then the
        // guard-narrowed legs (direct and `place +- K` refold) and the
        // arrival rescue; point exclusions stay on the uncovered path.
        match bounded_integer_value_verdict(
            proof_plan,
            obligation.argument,
            obligation.argument_constraints,
            obligation.base_type,
            &target_range,
            seed,
            true,
            measurements,
            derivations.as_deref_mut(),
        ) {
            CertificateVerdict::Certified => {}
            CertificateVerdict::Rejected => {
                diagnostics.push(cannot_prove_bounded_transition_integer(
                    proof_plan,
                    obligation,
                    target_range,
                ));
            }
            CertificateVerdict::Uncovered => {
                // The guard-narrowed leg cites the arm's guard and refuted
                // exit guards as explicit premises on the argument's atom;
                // shapes it cannot certify keep the trusted narrowing below.
                match guarded_transition_integer_verdict_measured(
                    proof_plan,
                    obligation,
                    &target_range,
                    seed,
                    measurements,
                    derivations,
                ) {
                    CertificateVerdict::Certified => {}
                    CertificateVerdict::Rejected => {
                        diagnostics.push(cannot_prove_bounded_transition_integer(
                            proof_plan,
                            obligation,
                            target_range,
                        ));
                    }
                    CertificateVerdict::Uncovered => {
                        let argument_range =
                            guarded_integer_range_for_transition_argument(proof_plan, obligation);

                        if argument_range.minimum < target_range.minimum
                            || argument_range.maximum > target_range.maximum
                        {
                            // Use the shared arithmetic owner for this exact occurrence.
                            // Named/dependent constraints remain independent checks below.
                            let arrival_fits = validation::arrival_integer_expression_bounds(
                                proof_plan.program,
                                obligation.machine_symbol,
                                obligation.state_symbol,
                                obligation.statement_index,
                                obligation.argument,
                            )
                            .is_some_and(|(minimum, maximum)| {
                                BigInt::from_i64(minimum) >= target_range.minimum
                                    && BigInt::from_i64(maximum) <= target_range.maximum
                            });
                            if !arrival_fits {
                                diagnostics.push(cannot_prove_bounded_transition_integer(
                                    proof_plan,
                                    obligation,
                                    target_range,
                                ));
                            }
                        }
                    }
                }
            }
        }
    }

    // R1 dependent maximum (`i: u32 [0..=self.count]`): the upper half is a
    // RELATIONAL obligation -- `arg <= self.count + offset` at the transition
    // point. Discharge routes, in order: (a) the arm's own guard relates the
    // argument to the SAME field (`arg < self.count`; co-located, so no
    // stability gate -- same rationale as the literal path above); (b) worst
    // case through the field's OWN enforced literal range (`arg_max <=
    // min(count) + offset` holds for every runtime count). The lower half is
    // the literal minimum, checked against the guarded argument range.
    if let Some((minimum, max_field, max_offset)) =
        symbolic_max_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        let argument_range = guarded_integer_range_for_transition_argument(proof_plan, obligation);
        // Route (c): the ARGUMENT is itself dependent-ranged on the SAME
        // field with a tighter-or-equal bound (`i: [0..=self.count]`
        // forwarded into `k: [0..=self.count]`; the exclusive sugar's -1
        // offset forwards into the inclusive form). Transitions stay within
        // one machine, so the field is the same place.
        let atom_proves = dependent_atom_proves(
            proof_plan,
            obligation.argument_constraints,
            obligation.machine.as_str(),
            obligation.state.as_str(),
            max_field,
            minimum,
            max_offset,
        );
        let lower_proven = atom_proves || argument_range.minimum >= BigInt::from_i64(minimum);
        let upper_proven = atom_proves
            || guard_proves_dependent_upper(proof_plan, obligation, max_field, max_offset)
            || dependent_field_floor(proof_plan, obligation, max_field)
                .and_then(|floor| floor.checked_add(max_offset))
                .is_some_and(|cap| argument_range.maximum <= BigInt::from_i64(cap));
        if !lower_proven || !upper_proven {
            diagnostics.push(cannot_prove_dependent_transition_bound(
                proof_plan, obligation, minimum, max_field, max_offset,
            ));
        }
    }

    // R1 sibling-length maximum (`index: u64 [0..items.len]`): the argument
    // must sit under the SIBLING ARGUMENT's length at this call -- and slice
    // lengths have no static floor, so the only discharge is the co-located
    // guard relating the argument to `<sibling-arg>.len` tightly enough.
    if let Some((minimum, max_offset)) =
        sibling_len_from_constraints(type_constraints(proof_plan, obligation.constraints))
    {
        let argument_range = guarded_integer_range_for_transition_argument(proof_plan, obligation);
        let lower_proven = argument_range.minimum >= BigInt::from_i64(minimum);
        let upper_proven = obligation.sibling_argument.is_valid()
            && guard_proves_sibling_len_upper(
                proof_plan,
                obligation.argument,
                &obligation.guard,
                obligation.sibling_argument,
                max_offset,
            );
        if !lower_proven || !upper_proven {
            diagnostics.push(Diagnostic::error(format!(
                "cannot prove transition argument `{}` satisfies sibling-length parameter `{}` in `{}.{}`; expected {minimum}..=<sibling>.len{} -- relate them on the arm (`{} < {}.len`)",
                expression_display_name(proof_plan, obligation.argument),
                obligation.parameter,
                obligation.machine,
                obligation.state,
                if max_offset == 0 { String::new() } else { format!(" {:+}", max_offset) },
                expression_display_name(proof_plan, obligation.argument),
                if obligation.sibling_argument.is_valid() {
                    expression_display_name(proof_plan, obligation.sibling_argument)
                } else {
                    "<sibling>".to_string()
                },
            )));
        }
    }

    // The declared range is the goal. A co-located comparison of this
    // argument and surviving refuted exits constrain its ordered values.
    // Unlike integer complements, false IEEE comparisons retain NaN;
    // guard effects must also preserve the consumed observation.
    if discharge_declared_float_range(
        proof_plan,
        obligation,
        obligation.constraints,
        diagnostics,
        guarded_float_range_for_transition_argument,
        cannot_prove_bounded_transition_float,
    ) {
        return;
    }
}

/// Discharge one obligation's declared float range: a value range that
/// cannot be produced refuses and aborts the obligation, and a range
/// outside the declared one refuses while the caller's remaining checks
/// continue. `range` names the obligation's own range owner and `refuse`
/// its own diagnostic, so each obligation keeps its exact refusal text.
/// Returns `true` when the caller must abort.
fn discharge_declared_float_range<O>(
    proof_plan: &ProofPlan,
    obligation: &O,
    constraints: arena::HandleSpan<ProofConstraint>,
    diagnostics: &mut Vec<Diagnostic>,
    range: fn(&ProofPlan, &O) -> Option<FloatRange>,
    refuse: fn(&ProofPlan, &O, FloatRange) -> Diagnostic,
) -> bool {
    let Some(target_range) =
        float_range_from_constraints(type_constraints(proof_plan, constraints))
    else {
        return false;
    };
    let Some(value_range) = range(proof_plan, obligation) else {
        diagnostics.push(refuse(proof_plan, obligation, target_range));
        return true;
    };
    if !target_range.contains_range(&value_range) {
        diagnostics.push(refuse(proof_plan, obligation, target_range));
    }
    false
}

/// Decide a declared range with a retained constant recipe at an endpoint.
/// The value's own range is the judgment's evidence: a closed endpoint is
/// compared here, a recipe endpoint becomes a recorded comparison the target
/// closure discharges against the closed value. A value without a bounded
/// range has nothing to compare and refuses now.
fn discharge_recipe_range(
    proof_plan: &ProofPlan,
    owner: symbols::SymbolHandle,
    constraints: arena::HandleSpan<crate::obligations::ProofConstraint>,
    value_range: Option<IntegerRange>,
    value: typed_trees::expression::ExpressionHandle,
    description: String,
    diagnostics: &mut Vec<Diagnostic>,
    recipe_obligations: &mut Vec<checked_trees::ConstantRecipeObligation>,
) {
    for constraint in type_constraints(proof_plan, constraints) {
        let crate::obligations::ProofConstraint::IntegerRangeRecipe { minimum, maximum } =
            constraint
        else {
            continue;
        };
        let source_span = proof_plan.program.expression_table.source_span(value);
        let Some(value_range) = value_range.as_ref() else {
            diagnostics.push(
                Diagnostic::error(format!(
                    "cannot prove {description} has a bounded value to compare with its declared range fixed at target closure"
                ))
                .with_source_span(source_span),
            );
            return;
        };
        match minimum {
            RecipeRangeBound::Closed(bound) => {
                if value_range.minimum < *bound {
                    diagnostics.push(
                        Diagnostic::error(format!(
                            "cannot prove {description} is at least {bound}; its value may be as low as {}",
                            value_range.minimum
                        ))
                        .with_source_span(source_span),
                    );
                }
            }
            RecipeRangeBound::Recipe { recipe, offset } => {
                recipe_obligations.push(checked_trees::ConstantRecipeObligation::retain(
                    owner,
                    *recipe,
                    checked_trees::ConstantRecipeRequirement::AtMost(
                        value_range.minimum.sub(&BigInt::from_i64(*offset)),
                    ),
                    source_span,
                    format!("{description} (declared minimum)"),
                ));
            }
        }
        match maximum {
            RecipeRangeBound::Closed(bound) => {
                if value_range.maximum > *bound {
                    diagnostics.push(
                        Diagnostic::error(format!(
                            "cannot prove {description} is at most {bound}; its value may be as high as {}",
                            value_range.maximum
                        ))
                        .with_source_span(source_span),
                    );
                }
            }
            RecipeRangeBound::Recipe { recipe, offset } => {
                recipe_obligations.push(checked_trees::ConstantRecipeObligation::retain(
                    owner,
                    *recipe,
                    checked_trees::ConstantRecipeRequirement::AtLeast(
                        value_range.maximum.sub(&BigInt::from_i64(*offset)),
                    ),
                    source_span,
                    format!("{description} (declared maximum)"),
                ));
            }
        }
    }
}
