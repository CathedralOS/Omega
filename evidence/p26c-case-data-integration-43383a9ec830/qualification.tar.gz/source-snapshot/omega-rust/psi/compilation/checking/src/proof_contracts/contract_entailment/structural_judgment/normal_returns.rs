//! Selected guarantees for captured normal-return values.
//!
//! A runtime result is one occurrence, not a replayable mathematical call.
//! Capture operands before substituting the selected public signature, prove
//! its entry requirements, then import its unconditional normal guarantees.
//! This environment belongs to one executed normal-return path; it is neither
//! a loop invariant nor permission to replay mutable storage observations.

mod array_elements;
mod body_completion;
mod collection_extents;
mod match_captures;
mod operand_types;
mod owned_arguments;

use super::super::specification_calls::{
    AppliedProofBindings, SelectedCallContract, owner_contracts, owner_leading_operands,
    owner_return_type, owner_symbol, selected_call_contract,
};
use super::selected_contracts::bound_term;
use super::value_predicates::boolean_term;
use super::{MembershipGuarantee, StructuralJudge, StructuralJudgment, StructuralTerm};
use crate::expression_traversal::children;
use crate::machine_calls::contract_dependencies::independent_call_application;
use facts::NormalizedWriteFrame;
use language_semantics::declaration_selection::CollectionMeasure;
use symbols::SymbolHandle;
use typed_trees::domain::ProofFact;
use typed_trees::expression::{BinaryOperator, ExpressionHandle, ExpressionNode, MatchPattern};
use typed_trees::signature::SignatureContractKind;
use typed_trees::types::TypeReferenceHandle;

pub(in crate::proof_contracts::contract_entailment) struct NormalReturnPath<'program> {
    pub value: StructuralTerm,
    pub judge: StructuralJudge<'program>,
    observation: NormalValueObservation,
}

/// Completing an address/effect traversal does not observe its stored value.
/// This scratch status travels with the operand, independently of its demand.
#[derive(Clone, Copy, PartialEq, Eq)]
enum NormalValueObservation {
    Observed,
    NotObserved,
}

#[derive(Clone)]
struct NormalOperandResult {
    value: StructuralTerm,
    observation: NormalValueObservation,
}

impl NormalOperandResult {
    fn observed_value(&self) -> Option<&StructuralTerm> {
        (self.observation == NormalValueObservation::Observed).then_some(&self.value)
    }
}

pub(in crate::proof_contracts::contract_entailment) struct NormalOperationEntry<'program> {
    pub expression: ExpressionHandle,
    pub arguments: Vec<Option<StructuralTerm>>,
    pub judge: StructuralJudge<'program>,
}

impl NormalOperationEntry<'_> {
    /// Complete actuals require every operand observation. Selected-field
    /// observers instead inspect only their requested positional slots.
    pub(in crate::proof_contracts::contract_entailment) fn observed_arguments(
        &self,
    ) -> Option<Vec<StructuralTerm>> {
        self.arguments.iter().cloned().collect()
    }
}

/// An entry query needs operand values, not the operation's own result.
/// Unrequested operands retain their ordered effects and positional slots.
#[derive(Clone, Copy)]
pub(in crate::proof_contracts::contract_entailment) enum OperationOperandDemand<'query> {
    All,
    Selected(&'query [ExpressionHandle]),
}

pub(in crate::proof_contracts::contract_entailment) struct CompletedNormalObservations<'program> {
    pub paths: Vec<StructuralJudge<'program>>,
    pub operations: Vec<NormalOperationEntry<'program>>,
}

/// A premise query stops before its operation; a batch observer retains the
/// same incoming snapshot and continues to observe later operands. Neither
/// snapshot contains the operation's own result or normal guarantees.
#[derive(Clone, Copy, PartialEq, Eq)]
enum ObservationStop {
    None,
    BeforeOperation(ExpressionHandle),
    AfterValue(ExpressionHandle),
}

#[derive(Clone, Copy)]
struct OperationObservations<'query> {
    stop: ObservationStop,
    expressions: &'query [ExpressionHandle],
    operands: OperationOperandDemand<'query>,
}

impl OperationObservations<'_> {
    fn none() -> Self {
        Self {
            stop: ObservationStop::None,
            expressions: &[],
            operands: OperationOperandDemand::All,
        }
    }
}

/// A consumer may demand completed fields without using its enclosing value.
/// Required values still use the same strict normal-return operation.
#[derive(Clone, Copy)]
enum NormalValueDemand<'query> {
    Value,
    // Complete the operation and its effects without demanding a result carrier.
    Completion,
    // Evaluate a checked storage coordinate without observing aggregate contents.
    Location,
    Observe(&'query [ExpressionHandle]),
}

#[derive(Clone, Copy)]
struct NormalOperand<'query> {
    expression: ExpressionHandle,
    reference: TypeReferenceHandle,
    demand: NormalValueDemand<'query>,
}

type ValueScope<'scope> = (
    &'scope typed_trees::machine::Machine,
    &'scope typed_trees::state::State,
    TypeReferenceHandle,
);

impl<'program> StructuralJudge<'program> {
    pub(in crate::proof_contracts::contract_entailment) fn completed_expression_values(
        &self,
    ) -> &[(ExpressionHandle, StructuralTerm)] {
        self.normal_results.as_slice()
    }

    /// Authenticate a whole scalar before descriptive equations replace it.
    /// Captured values are minted only by normal completion; raw arithmetic
    /// descriptions qualify only when retained in this occurrence's completed
    /// result roster. Reference descriptors never authenticate stored contents.
    pub(in crate::proof_contracts::contract_entailment) fn completed_scalar_observation(
        &self,
        value: &StructuralTerm,
        primitive: typed_trees::types::PrimitiveType,
    ) -> Option<(StructuralTerm, numerics::arithmetic::ArithmeticDomain)> {
        if !self.runtime_body_values || self.case_facts_only {
            return None;
        }
        let mut identity = value.clone();
        for _ in 0..32 {
            match &identity {
                StructuralTerm::ObservedValue {
                    observed_type,
                    value,
                    descriptor,
                } => {
                    if descriptor.is_some()
                        || crate::reference_shell(self.program, *observed_type).is_some()
                        || self.program.primitive_type_reference(*observed_type) != Some(primitive)
                    {
                        return None;
                    }
                    identity = value.as_ref().clone();
                }
                StructuralTerm::Variable(name) => {
                    identity = self
                        .substitutions
                        .iter()
                        .find(|(variable, _)| variable == name)?
                        .1
                        .clone();
                }
                StructuralTerm::CapturedValue { result_type, .. } => {
                    let policy = self
                        .program
                        .arithmetic_domain_for_type_reference(*result_type);
                    return (crate::reference_shell(self.program, *result_type).is_none()
                        && self.program.primitive_type_reference(*result_type) == Some(primitive))
                    .then_some((identity, policy));
                }
                StructuralTerm::ScalarBinary {
                    operator, meaning, ..
                } if typed_trees::operator::builtin_integer_result_carrier(
                    *operator,
                    meaning.map(|(primitive, _)| primitive),
                ) == Some(primitive) =>
                {
                    let policy =
                        super::super::arithmetic_judgment::Engine::integer_operation_policy(
                            *operator, *meaning,
                        )?;
                    return self
                        .normal_results
                        .iter()
                        .any(|(_, observed)| {
                            let observed = match observed {
                                StructuralTerm::ObservedValue {
                                    observed_type,
                                    value,
                                    descriptor,
                                } if descriptor.is_none()
                                    && crate::reference_shell(self.program, *observed_type)
                                        .is_none()
                                    && self.program.primitive_type_reference(*observed_type)
                                        == Some(primitive) =>
                                {
                                    value.as_ref()
                                }
                                StructuralTerm::ScalarBinary { .. } => observed,
                                _ => return false,
                            };
                            observed == &identity
                        })
                        .then_some((identity, policy));
                }
                _ => return None,
            }
        }
        None
    }

    /// Projection demands carried by this exact completed result's public
    /// equations. The consumer authenticates each field against its declared
    /// type; unrelated captures, hypotheses and private bodies contribute none.
    pub(in crate::proof_contracts::contract_entailment) fn completed_value_projection_paths(
        &self,
        value: &StructuralTerm,
    ) -> Vec<String> {
        let (root, prefix) = match value.semantic_value() {
            StructuralTerm::Projection { subject, path } => (subject.as_ref(), Some(path.as_str())),
            _ => (value, None),
        };
        let mut paths = Vec::new();
        for (left, right) in self.captured_result_equations.iter() {
            for term in [left, right] {
                let StructuralTerm::Projection { subject, path } = term else {
                    continue;
                };
                if subject.as_ref() != root {
                    continue;
                }
                let path = if let Some(prefix) = prefix {
                    let Some(suffix) = path
                        .strip_prefix(prefix)
                        .and_then(|suffix| suffix.strip_prefix('.'))
                    else {
                        continue;
                    };
                    suffix
                } else {
                    path.as_str()
                };
                if !paths.iter().any(|previous| previous == path) {
                    paths.push(path.to_owned());
                }
            }
        }
        paths
    }

    fn term_max_captured_occurrence(term: &StructuralTerm) -> Option<usize> {
        match term.semantic_value() {
            StructuralTerm::CapturedValue { occurrence, .. } => Some(*occurrence),
            _ => {
                let mut max = None;
                term.for_each_child(|child| {
                    if let Some(child_occ) = Self::term_max_captured_occurrence(child) {
                        max = Some(max.map_or(child_occ, |curr: usize| curr.max(child_occ)));
                    }
                });
                max
            }
        }
    }

    /// Resolve captured value identities without folding arithmetic or using
    /// caller hypotheses. Discovery needs the producing operand structure;
    /// ring equality cannot replace its intermediate formation obligations.
    pub(in crate::proof_contracts::contract_entailment) fn completed_value_identity(
        &self,
        value: StructuralTerm,
    ) -> StructuralTerm {
        if self.captured_result_equations.is_empty() {
            return value;
        }
        self.completed_value_identity_at(value, 0)
    }

    fn completed_value_identity_at(&self, value: StructuralTerm, depth: usize) -> StructuralTerm {
        if depth >= 64 {
            return value;
        }
        let value = match value {
            StructuralTerm::Projection { subject, path } => {
                let subject = self.completed_value_identity_at(*subject, depth + 1);
                path.split('.')
                    .try_fold(subject.clone(), |value, field| {
                        super::super::observed_projections::project_declared_field(
                            self.program,
                            value,
                            field,
                        )
                    })
                    .unwrap_or(StructuralTerm::Projection {
                        subject: Box::new(subject),
                        path,
                    })
            }
            other => other.map_children(|child| self.completed_value_identity_at(child, depth + 1)),
        };
        if !matches!(
            value.semantic_value(),
            StructuralTerm::CapturedValue { .. }
                | StructuralTerm::Projection { .. }
                | StructuralTerm::CollectionMeasure { .. }
        ) {
            return value;
        }
        for (left, right) in self.captured_result_equations.iter() {
            // Orient captured results toward earlier source observations:
            // normalize a later captured call result toward an earlier
            // observation or input parameter, avoiding circular flips.
            let (pattern, replacement) = match (
                Self::term_max_captured_occurrence(left),
                Self::term_max_captured_occurrence(right),
            ) {
                (Some(left_occ), Some(right_occ)) => {
                    if left_occ > right_occ {
                        (left, right)
                    } else if right_occ > left_occ {
                        (right, left)
                    } else {
                        continue;
                    }
                }
                (Some(_), None) => (left, right),
                (None, Some(_)) => (right, left),
                (None, None) => continue,
            };
            if pattern == &value
                && replacement != &value
                && !super::super::structural_terms::term_contains(replacement, &value)
            {
                return self.completed_value_identity_at(replacement.clone(), depth + 1);
            }
        }
        value
    }

    /// Project normal outcomes under their own invocation facts. Every eager
    /// operand executes in order; selective operands fork the same path owner.
    /// No branch's hypotheses are donated to a different normal outcome.
    pub(in crate::proof_contracts::contract_entailment) fn normal_return_paths(
        &self,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<Vec<NormalReturnPath<'program>>> {
        self.clone().evaluate_normal_paths(
            expression,
            environment,
            scope,
            0,
            OperationObservations::none(),
            &mut Vec::new(),
            NormalValueDemand::Value,
        )
    }

    /// A complete statement retains its normal effects and parameter guarantees,
    /// not a result value. Unit and discarded value statements share this owner;
    /// their eager operands still require their actual values in invocation order.
    pub(in crate::proof_contracts::contract_entailment) fn normal_completion_paths(
        &self,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<Vec<StructuralJudge<'program>>> {
        let mut paths: Vec<StructuralJudge<'program>> = self
            .clone()
            .evaluate_normal_paths(
                expression,
                environment,
                scope,
                0,
                OperationObservations::none(),
                &mut Vec::new(),
                NormalValueDemand::Completion,
            )?
            .into_iter()
            .map(|path| path.judge)
            .collect();
        if paths.len() > 1
            && paths
                .iter()
                .all(|judge| judge.has_no_new_effects_or_guarantees_since(self))
        {
            let judge_refs: Vec<&Self> = paths.iter().collect();
            paths = vec![self.rejoin_pure_outcomes(&judge_refs, Some(expression))];
        }
        Some(paths)
    }

    /// Observe an operation after its operands complete, including preceding
    /// statement roots such as named-transition arguments. The snapshot is
    /// before the operation itself: a call cannot donate its own guarantee,
    /// and a cast cannot supply its own destination range.
    pub(in crate::proof_contracts::contract_entailment) fn normal_operation_entries(
        &self,
        statement_index: usize,
        call: ExpressionHandle,
        operand_demand: OperationOperandDemand<'_>,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<Vec<NormalOperationEntry<'program>>> {
        // Earlier siblings still execute in order, but their unused aggregate
        // values need not be retained to observe this operation's operands.
        // The requested operation and every effectful child keep value demand.
        let observations = [call];
        let operands = self.statement_observation_operands(
            statement_index,
            call,
            scope,
            NormalValueDemand::Observe(&observations),
        )?;
        let mut entries = Vec::new();
        self.clone().evaluate_normal_operands(
            &operands,
            environment,
            scope,
            0,
            OperationObservations {
                stop: ObservationStop::BeforeOperation(call),
                expressions: &[],
                operands: operand_demand,
            },
            &mut entries,
            None,
        )?;
        (!entries.is_empty()).then_some(entries)
    }

    /// Capture one anonymous value as it completes, before any enclosing
    /// invocation or later sibling executes. A landing consumes its bare
    /// mathematical value; the receiving carrier is not evidence of fit.
    pub(in crate::proof_contracts::contract_entailment) fn normal_value_entries(
        &self,
        statement_index: usize,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<Vec<NormalOperationEntry<'program>>> {
        let operands = self.statement_observation_operands(
            statement_index,
            expression,
            scope,
            NormalValueDemand::Value,
        )?;
        let mut entries = Vec::new();
        self.clone().evaluate_normal_operands(
            &operands,
            environment,
            scope,
            0,
            OperationObservations {
                stop: ObservationStop::AfterValue(expression),
                expressions: &[],
                operands: OperationOperandDemand::All,
            },
            &mut entries,
            None,
        )?;
        (!entries.is_empty()).then_some(entries)
    }

    /// Completed value observers use the same ordered statement operands as
    /// call-premise observers. Select the recorded occurrence after evaluation;
    /// no standalone replay can omit an earlier sibling's effects.
    pub(in crate::proof_contracts::contract_entailment) fn completed_statement_paths(
        &self,
        statement_index: usize,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<Vec<NormalReturnPath<'program>>> {
        let requested = [expression];
        let operands = self.statement_observation_operands(
            statement_index,
            expression,
            scope,
            NormalValueDemand::Observe(&requested),
        )?;
        let mut completed = Vec::new();
        self.clone().evaluate_normal_operands(
            &operands,
            environment,
            scope,
            0,
            OperationObservations {
                stop: ObservationStop::AfterValue(expression),
                expressions: &[],
                operands: OperationOperandDemand::All,
            },
            &mut completed,
            None,
        )?;
        let paths = completed
            .into_iter()
            .map(|entry| {
                let [Some(value)] = entry.arguments.as_slice() else {
                    return None;
                };
                Some(NormalReturnPath::observed(value.clone(), entry.judge))
            })
            .collect::<Option<Vec<_>>>()?;
        (!paths.is_empty()).then_some(paths)
    }

    /// Observe requested field operands through normal evaluation without
    /// requiring an unrelated enclosing result to have a mathematical term.
    pub(in crate::proof_contracts::contract_entailment) fn completed_observations(
        &self,
        statement_index: usize,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
        observations: &[ExpressionHandle],
        operations: &[ExpressionHandle],
    ) -> Option<CompletedNormalObservations<'program>> {
        let operands = self.statement_observation_operands(
            statement_index,
            expression,
            scope,
            NormalValueDemand::Observe(observations),
        )?;
        let mut entries = Vec::new();
        let paths = self
            .clone()
            .evaluate_normal_operands(
                &operands,
                environment,
                scope,
                0,
                OperationObservations {
                    stop: ObservationStop::None,
                    expressions: operations,
                    operands: OperationOperandDemand::All,
                },
                &mut entries,
                None,
            )?
            .into_iter()
            .map(|(judge, _)| judge)
            .collect();
        Some(CompletedNormalObservations {
            paths,
            operations: entries,
        })
    }

    fn statement_observation_operands<'query>(
        &self,
        statement_index: usize,
        expression: ExpressionHandle,
        scope: ValueScope<'_>,
        demand: NormalValueDemand<'query>,
    ) -> Option<Vec<NormalOperand<'query>>> {
        let roots = super::super::structural_prefix::expression_prefix_roots(
            self.program,
            scope.1,
            statement_index,
            expression,
        )?;
        Some(
            roots
                .into_iter()
                .map(|root| {
                    let reference = crate::expression_result_type_reference(
                        self.program,
                        scope.0,
                        scope.1,
                        root,
                    )
                    .unwrap_or(scope.2);
                    NormalOperand {
                        expression: root,
                        reference,
                        demand: if self
                            .program
                            .statement_table
                            .statements(scope.1.statement_nodes)
                            .get(statement_index)
                            .and_then(|statement| statement.as_assignment())
                            .is_some_and(|assignment| assignment.target == root)
                        {
                            NormalValueDemand::Location
                        } else {
                            demand
                        },
                    }
                })
                .collect(),
        )
    }

    /// A store captures its destination before evaluating the replacement.
    /// The location demand completes selectors without reading or moving the
    /// old destination. Its captured backing and selector values then survive
    /// RHS effects; the final write retires current contents before installation.
    pub(in crate::proof_contracts::contract_entailment) fn normal_assignment_paths(
        &self,
        statement: &typed_trees::statement::StatementNode,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<Vec<NormalReturnPath<'program>>> {
        let assignment = statement.as_assignment()?;
        let reference =
            crate::assignment_stored_value_type(self.program, scope.0, scope.1, assignment)?;
        let scope = (scope.0, scope.1, reference);
        let destinations = self.clone().evaluate_normal_paths(
            assignment.target,
            environment,
            scope,
            0,
            OperationObservations::none(),
            &mut Vec::new(),
            NormalValueDemand::Location,
        )?;
        if let Some(event) = crate::value_custody::atomic_operations::atomic_assignment_carrier(
            self.program,
            assignment,
        ) {
            // An atomic event evaluates its authored operands, never the
            // synthetic resident-update expression. Its write retires storage
            // observations but establishes no stable ordinary-store equation.
            let frame = self
                .frame_resolver()?
                .assignment_write_frame(scope.0, statement);
            let mut paths = destinations;
            for operand in event.operands {
                let mut next = Vec::new();
                for path in paths {
                    next.extend(path.judge.evaluate_normal_paths(
                        operand,
                        environment,
                        scope,
                        0,
                        OperationObservations::none(),
                        &mut Vec::new(),
                        NormalValueDemand::Value,
                    )?);
                }
                paths = next;
            }
            for path in &mut paths {
                path.judge
                    .observe_storage_effects(scope.1, frame.complete_paths())?;
            }
            // Statement assignment consumers discard the last operand value;
            // an observed prior is owned separately by the event result carrier.
            return Some(paths);
        }
        let mut paths = Vec::new();
        for destination in destinations {
            let captured = destination
                .judge
                .capture_store_destination(scope.0, scope.1, statement)?;
            for mut result in destination.judge.evaluate_normal_paths(
                assignment.value,
                environment,
                scope,
                0,
                OperationObservations::none(),
                &mut Vec::new(),
                NormalValueDemand::Value,
            )? {
                result.judge.observe_captured_store(
                    scope.1,
                    captured.clone(),
                    result.value.clone(),
                )?;
                paths.push(result);
            }
        }
        Some(paths)
    }

    /// Complete a declaration's actuals in source order before checking its
    /// receiving contract. Named transitions and expression calls share the
    /// same operand scheduler; the destination's ensures are never available.
    pub(in crate::proof_contracts::contract_entailment) fn normal_argument_entries(
        &self,
        arguments: &[ExpressionHandle],
        parameters: &[typed_trees::signature::StateParameter],
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
        invocation: Option<crate::CallSite<'_>>,
    ) -> Option<Vec<NormalOperationEntry<'program>>> {
        if arguments.len() != parameters.len() {
            return None;
        }
        let operands = arguments
            .iter()
            .zip(parameters)
            .map(|(expression, parameter)| NormalOperand {
                expression: *expression,
                reference: parameter.type_reference,
                demand: NormalValueDemand::Value,
            })
            .collect::<Vec<_>>();
        Some(
            self.clone()
                .evaluate_normal_operands(
                    &operands,
                    environment,
                    scope,
                    0,
                    OperationObservations::none(),
                    &mut Vec::new(),
                    invocation,
                )?
                .into_iter()
                .map(|(judge, values)| {
                    let arguments = values
                        .into_iter()
                        .map(|(_, result)| result.observed_value().cloned())
                        .collect::<Option<Vec<_>>>()?;
                    Some(NormalOperationEntry {
                        expression: ExpressionHandle::invalid(),
                        arguments: arguments.into_iter().map(Some).collect(),
                        judge,
                    })
                })
                .collect::<Option<Vec<_>>>()?,
        )
    }

    fn evaluate_normal_operands(
        mut self,
        operands: &[NormalOperand<'_>],
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
        depth: usize,
        requested_operations: OperationObservations<'_>,
        entries: &mut Vec<NormalOperationEntry<'program>>,
        invocation: Option<crate::CallSite<'_>>,
    ) -> Option<Vec<(Self, Vec<(ExpressionHandle, NormalOperandResult)>)>> {
        let mut aliases = Vec::new();
        if let Some(site) = invocation {
            let mut visited = Vec::new();
            for operand in operands {
                crate::expression_traversal::collect_expression_tree(
                    self.program,
                    operand.expression,
                    &mut visited,
                );
            }
            for expression in visited {
                if let ExpressionNode::SavedSubject(saved) =
                    self.program.expression_table.expression(expression)
                    && let Some(position) =
                        owned_arguments::capture_position_at_site(self.program, saved, site)
                {
                    aliases.push((
                        expression,
                        position,
                        self.program.saved_value_source(saved)?,
                    ));
                }
            }
            if !aliases.is_empty() {
                let authored = crate::call_site_argument_expressions(self.program, &site);
                if !authored
                    .iter()
                    .copied()
                    .eq(operands.iter().map(|operand| operand.expression))
                {
                    return None;
                }
                // A loop iteration cannot borrow a previous invocation's alias.
                std::sync::Arc::make_mut(&mut self.normal_results).retain(|(expression, _)| {
                    !aliases.iter().any(|(alias, _, _)| alias == expression)
                });
            }
        }
        let mut contexts = vec![(self, Vec::<(ExpressionHandle, NormalOperandResult)>::new())];
        for &NormalOperand {
            expression: child,
            reference,
            demand,
        } in operands
        {
            let mut next = Vec::new();
            for (mut context, mut inputs) in contexts {
                for &(alias, position, source) in &aliases {
                    if let Some((completed_source, value)) = inputs.get(position) {
                        if *completed_source != source {
                            return None;
                        }
                        let results = std::sync::Arc::make_mut(&mut context.normal_results);
                        results.retain(|(expression, _)| *expression != alias);
                        results.push((alias, value.observed_value()?.clone()));
                    }
                }
                let paths = context.evaluate_normal_paths(
                    child,
                    environment,
                    (scope.0, scope.1, reference),
                    depth + 1,
                    requested_operations,
                    entries,
                    demand,
                )?;
                let mut paths = paths.into_iter().peekable();
                while let Some(path) = paths.next() {
                    // Only distinct outcomes need independent histories. Move
                    // the existing prefix into the final (usually sole) path.
                    let mut branch_inputs = if paths.peek().is_some() {
                        inputs.clone()
                    } else {
                        std::mem::take(&mut inputs)
                    };
                    branch_inputs.push((
                        child,
                        NormalOperandResult {
                            value: path.value,
                            observation: path.observation,
                        },
                    ));
                    next.push((path.judge, branch_inputs));
                }
            }
            contexts = next;
        }
        Some(contexts)
    }

    /// A completion observation retains both result and proof context at the
    /// same semantic cut, including match/short-circuit recursive returns.
    /// Later siblings cannot donate facts to this completed value.
    fn evaluate_normal_paths(
        self,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
        depth: usize,
        requested_operations: OperationObservations<'_>,
        entries: &mut Vec<NormalOperationEntry<'program>>,
        demand: NormalValueDemand<'_>,
    ) -> Option<Vec<NormalReturnPath<'program>>> {
        let paths = self.evaluate_normal_value_paths(
            expression,
            environment,
            scope,
            depth,
            requested_operations,
            entries,
            demand,
        )?;
        if requested_operations.stop == ObservationStop::AfterValue(expression) {
            for path in paths {
                let value = path.observed_value()?.clone();
                entries.push(NormalOperationEntry {
                    expression,
                    arguments: vec![Some(value)],
                    judge: path.judge,
                });
            }
            return Some(Vec::new());
        }
        Some(paths)
    }

    fn evaluate_normal_value_paths(
        mut self,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
        depth: usize,
        requested_operations: OperationObservations<'_>,
        entries: &mut Vec<NormalOperationEntry<'program>>,
        demand: NormalValueDemand<'_>,
    ) -> Option<Vec<NormalReturnPath<'program>>> {
        if depth >= 64 || !program_expression_is_live(self.program, expression) {
            return None;
        }
        let program = self.program;
        let node = program.expression_table.expression(expression);
        if let ExpressionNode::SavedSubject(saved) = node
            && program
                .expression_table
                .contains_value_capture(saved.capture)
            && matches!(
                program.expression_table.value_capture(saved.capture).owner,
                typed_trees::expression::ValueCaptureOwner::Match
            )
        {
            let value = self.completed_match_subject(saved)?;
            return Some(vec![
                NormalReturnPath::observed(value, self).at_expression(expression, demand),
            ]);
        }
        if program.saved_argument_source(expression).is_some() {
            // The argument scheduler has completed this exact predecessor.
            // Missing completion is absence of evidence, never source replay.
            let value = self
                .normal_results
                .iter()
                .rev()
                .find(|(candidate, _)| *candidate == expression)?
                .1
                .clone();
            return Some(vec![
                NormalReturnPath::observed(value, self).at_expression(expression, demand),
            ]);
        }
        let before_operation =
            requested_operations.stop == ObservationStop::BeforeOperation(expression);
        let demand = match demand {
            NormalValueDemand::Location => {
                let is_location = match node {
                    ExpressionNode::Name(_) => true,
                    ExpressionNode::Member(_) => {
                        discarded_value_has_no_own_effects(program, scope, expression)
                    }
                    ExpressionNode::Indexed(_) => {
                        crate::value_custody::places::place_has_builtin_coordinates(
                            program,
                            scope.0,
                            Some(scope.1),
                            expression,
                        )
                    }
                    _ => false,
                };
                if is_location {
                    NormalValueDemand::Location
                } else {
                    NormalValueDemand::Value
                }
            }
            NormalValueDemand::Observe(observations)
                if !before_operation
                    && (observations.contains(&expression)
                        || requested_operations.expressions.contains(&expression)
                        || !discarded_value_has_no_own_effects(program, scope, expression)) =>
            {
                NormalValueDemand::Value
            }
            demand => demand,
        };
        // An implementation selector constructs code identity, not a value
        // obtained by evaluating the implementation name. The declaration
        // owner separately validates its exact conformance/application. Keep
        // only a fresh opaque value here: no implementation-body facts escape.
        if self.runtime_body_values
            && let ExpressionNode::Cast(cast) = node
            && !cast.form.is_recast()
            && cast.domain == numerics::arithmetic::ArithmeticDomain::Exact
            && cast.semantic_domain.is_empty()
            && cast.semantic_domain_arguments.is_empty()
            && matches!(
                program
                    .type_reference_table
                    .type_reference(cast.target_type),
                typed_trees::types::TypeReferenceNode::DynamicTrait { .. }
            )
            && let ExpressionNode::Name(name) = program.expression_table.expression(cast.value)
            && name.symbol.is_valid()
            && program.symbols.get(name.symbol).kind == symbols::SymbolKind::Conformance
        {
            let value = self.capture_unknown_value(expression, scope)?;
            return Some(vec![
                NormalReturnPath::observed(value, self).at_expression(expression, demand),
            ]);
        }

        // A wholly anonymous calculation has exact rational meaning before
        // its first carrier landing. Reuse that owner; an expected Addr or
        // fixed integer cannot turn its inner operators into typed arithmetic.
        // Requested descendant observations still traverse the normal scheduler;
        // folding cannot erase an operation-entry or child-completion snapshot.
        let contains_observation =
            |observed| crate::expression_owners::expression_contains(program, expression, observed);
        let observes_inner_operation = || {
            requested_operations
                .expressions
                .iter()
                .copied()
                .any(contains_observation)
                || match requested_operations.stop {
                    ObservationStop::BeforeOperation(observed) => contains_observation(observed),
                    ObservationStop::AfterValue(observed) => {
                        observed != expression && contains_observation(observed)
                    }
                    ObservationStop::None => false,
                }
        };
        // Containment is needed only when this value could actually fold.
        // Other operands keep their ordinary scheduler without subtree walks.
        if matches!(demand, NormalValueDemand::Value)
            && crate::value_custody::literals::has_anonymous_numeric_results(program, expression)
            && !observes_inner_operation()
            && let Some(value) =
                crate::value_custody::literals::evaluate_anonymous_numeric_expression(
                    program,
                    expression,
                    &[],
                    |operation| {
                        crate::value_custody::literals::has_anonymous_operator_meaning(
                            program, operation,
                        )
                    },
                )
                .and_then(|value| value.to_integer_exact())
        {
            return Some(vec![
                NormalReturnPath::observed(StructuralTerm::Integer(value), self)
                    .at_expression(expression, demand),
            ]);
        }

        // A classifier observes a tag and returns Bool; its case head is not
        // evaluated as a partial constructor. Unknown tags retain both paths.
        if let ExpressionNode::Binary(binary) = node
            && let Some((source_definition, source_variant)) =
                super::super::structural_terms::case_guard_classifier(
                    program,
                    scope.0,
                    Some(scope.1),
                    expression,
                )
        {
            let subject_type = self.normal_value_type_reference(binary.left, scope)?;
            let definition =
                program.data_constructor_definition(subject_type, source_definition.symbol)?;
            let variant = program.data_constructor_case(
                subject_type,
                source_definition.symbol,
                source_variant.symbol,
            )?;
            let mut outcomes = Vec::new();
            for subject in self.evaluate_normal_paths(
                binary.left,
                environment,
                scope,
                depth + 1,
                requested_operations,
                entries,
                NormalValueDemand::Value,
            )? {
                let judgment = subject.judge.judge_case(
                    subject.value.clone(),
                    definition.symbol,
                    variant.symbol,
                );
                for truth in [false, true] {
                    if (truth && matches!(judgment, StructuralJudgment::Refuted))
                        || (!truth && matches!(judgment, StructuralJudgment::Proven))
                    {
                        continue;
                    }
                    let mut selected = subject.judge.clone();
                    if truth {
                        selected.intake_case_guarantee(&super::CaseGuarantee {
                            subject: subject.value.clone(),
                            data: definition.symbol,
                            case: variant.symbol,
                        });
                        selected.intake_completed_match_case(
                            expression,
                            binary.left,
                            &subject.value,
                            subject_type,
                            scope.0,
                            scope.1,
                            environment,
                        );
                    }
                    outcomes.push(
                        NormalReturnPath::observed(boolean_term(truth), selected)
                            .at_expression(expression, demand),
                    );
                }
            }
            return Some(outcomes);
        }

        if let ExpressionNode::Binary(binary) = node
            && matches!(binary.operator, BinaryOperator::And | BinaryOperator::Or)
            && crate::has_builtin_binary_expression_meaning(
                program,
                scope.0,
                Some(scope.1),
                expression,
            )
        {
            let pre_binary_judge = self.clone();
            let evaluate_right = binary.operator == BinaryOperator::And;
            let mut short_circuit_steps_pure = true;
            let mut outcomes = Vec::new();
            for left in self.evaluate_normal_paths(
                binary.left,
                environment,
                scope,
                depth + 1,
                requested_operations,
                entries,
                NormalValueDemand::Value,
            )? {
                for truth in [false, true] {
                    let mut selected = left.judge.clone();
                    let guard_value = boolean_term(truth);
                    if matches!(
                        selected.judge_equation(
                            selected.resolve(left.value.clone()),
                            guard_value.clone(),
                            0
                        ),
                        StructuralJudgment::Refuted
                    ) {
                        continue;
                    }
                    selected.assume_normal_equation(left.value.clone(), guard_value);
                    if truth == evaluate_right {
                        for right in selected.evaluate_normal_paths(
                            binary.right,
                            environment,
                            scope,
                            depth + 1,
                            requested_operations,
                            entries,
                            demand,
                        )? {
                            outcomes.push(right.at_expression(expression, demand));
                        }
                    } else {
                        if !selected.has_no_new_effects_or_guarantees_since(&left.judge)
                            || !selected.has_no_new_non_boolean_facts_since(&left.judge)
                        {
                            short_circuit_steps_pure = false;
                        }
                        outcomes.push(
                            NormalReturnPath::observed(boolean_term(truth), selected)
                                .at_expression(expression, demand),
                        );
                    }
                }
            }
            if outcomes.len() > 1
                && (matches!(demand, NormalValueDemand::Location)
                    || matches!(
                        demand,
                        NormalValueDemand::Observe(obs)
                            if !obs.iter().any(|&observed| {
                                crate::expression_owners::expression_contains(
                                    program,
                                    expression,
                                    observed,
                                )
                            })
                    ))
                && outcomes.iter().all(|path| {
                    path.judge
                        .has_no_new_effects_or_guarantees_since(&pre_binary_judge)
                })
            {
                let judge_refs: Vec<&Self> = outcomes.iter().map(|path| &path.judge).collect();
                let rejoined = pre_binary_judge.rejoin_pure_outcomes(&judge_refs, Some(expression));
                return Some(vec![
                    NormalReturnPath::unobserved(rejoined).at_expression(expression, demand),
                ]);
            }
            let short_circuit_value = boolean_term(!evaluate_right);
            if short_circuit_steps_pure && outcomes.len() > 1 {
                let sc_indices: Vec<usize> = outcomes
                    .iter()
                    .enumerate()
                    .filter_map(|(idx, path)| {
                        (path.observation == NormalValueObservation::Observed
                            && path.value == short_circuit_value
                            && path
                                .judge
                                .has_no_new_effects_or_guarantees_since(&pre_binary_judge))
                        .then_some(idx)
                    })
                    .collect();
                let can_merge_sc = sc_indices.len() >= 2
                    && sc_indices.iter().all(|&idx| {
                        outcomes[idx]
                            .judge
                            .has_no_new_non_boolean_facts_since(&pre_binary_judge)
                    });
                if can_merge_sc {
                    let sc_judges: Vec<&Self> =
                        sc_indices.iter().map(|&idx| &outcomes[idx].judge).collect();
                    let rejoined_sc =
                        pre_binary_judge.rejoin_pure_outcomes(&sc_judges, Some(expression));
                    let mut merged_sc = Some(
                        NormalReturnPath::observed(short_circuit_value, rejoined_sc)
                            .at_expression(expression, demand),
                    );
                    let first_sc = sc_indices[0];
                    let mut merged_outcomes =
                        Vec::with_capacity(outcomes.len() - sc_indices.len() + 1);
                    for (idx, outcome) in outcomes.into_iter().enumerate() {
                        if idx == first_sc {
                            if let Some(merged) = merged_sc.take() {
                                merged_outcomes.push(merged);
                            }
                        } else if !sc_indices.contains(&idx) {
                            merged_outcomes.push(outcome);
                        }
                    }
                    outcomes = merged_outcomes;
                }
            }
            return Some(outcomes);
        }
        if let ExpressionNode::Match(dispatch) = node {
            let mut outcomes = Vec::new();
            let mut remaining = self.evaluate_normal_paths(
                dispatch.subject,
                environment,
                scope,
                depth + 1,
                requested_operations,
                entries,
                NormalValueDemand::Value,
            )?;
            for subject in &mut remaining {
                subject.value = subject.judge.complete_match_subject(
                    expression,
                    dispatch,
                    subject.value.clone(),
                    scope,
                )?;
            }
            for arm in program.expression_table.match_arms(dispatch.arms) {
                let mut next_remaining = Vec::new();
                for subject in remaining {
                    let pattern = match arm.pattern {
                        MatchPattern::Value(pattern) => Some((pattern, false)),
                        MatchPattern::Destructure(pattern) => Some((pattern.condition, true)),
                        MatchPattern::Wildcard => None,
                    };
                    if let Some((pattern, predicate)) = pattern {
                        // Patterns execute only after every preceding pattern
                        // failed. Keep their guarantees in that remaining path.
                        for tested in subject.judge.evaluate_normal_paths(
                            pattern,
                            environment,
                            scope,
                            depth + 1,
                            requested_operations,
                            entries,
                            NormalValueDemand::Value,
                        )? {
                            let primitive = if predicate {
                                Some(typed_trees::types::PrimitiveType::Bool)
                            } else {
                                crate::match_subject_primitive_type(program, dispatch)
                            };
                            let equation_meaning = primitive.is_some_and(|primitive| {
                                primitive == typed_trees::types::PrimitiveType::Bool
                                    || primitive.is_integer()
                            });
                            let comparison = if equation_meaning {
                                tested.judge.judge_equation(
                                    tested.judge.resolve(if predicate {
                                        tested.value.clone()
                                    } else {
                                        subject.value.clone()
                                    }),
                                    if predicate {
                                        boolean_term(true)
                                    } else {
                                        tested.judge.resolve(tested.value.clone())
                                    },
                                    0,
                                )
                            } else {
                                StructuralJudgment::Unknown
                            };
                            if !matches!(comparison, StructuralJudgment::Proven) {
                                let mut skipped = tested.judge.clone();
                                if predicate {
                                    skipped.assume_normal_equation(
                                        tested.value.clone(),
                                        boolean_term(false),
                                    );
                                } else if primitive == Some(typed_trees::types::PrimitiveType::Bool)
                                {
                                    let pattern = skipped.resolve(tested.value.clone());
                                    for truth in [false, true] {
                                        if matches!(
                                            skipped.judge_equation(
                                                pattern.clone(),
                                                boolean_term(truth),
                                                0
                                            ),
                                            StructuralJudgment::Proven
                                        ) {
                                            skipped.assume_normal_equation(
                                                subject.value.clone(),
                                                boolean_term(!truth),
                                            );
                                            break;
                                        }
                                    }
                                }
                                next_remaining.push(NormalReturnPath {
                                    value: subject.value.clone(),
                                    judge: skipped,
                                    observation: subject.observation,
                                });
                            }
                            if matches!(comparison, StructuralJudgment::Refuted) {
                                continue;
                            }
                            let mut selected = tested.judge;
                            if predicate {
                                selected.assume_normal_equation(tested.value, boolean_term(true));
                            } else if equation_meaning {
                                selected
                                    .assume_normal_equation(subject.value.clone(), tested.value);
                            }
                            for value in selected.evaluate_normal_paths(
                                arm.value,
                                environment,
                                scope,
                                depth + 1,
                                requested_operations,
                                entries,
                                demand,
                            )? {
                                outcomes.push(value.at_expression(expression, demand));
                            }
                        }
                    } else {
                        for value in subject.judge.evaluate_normal_paths(
                            arm.value,
                            environment,
                            scope,
                            depth + 1,
                            requested_operations,
                            entries,
                            demand,
                        )? {
                            outcomes.push(value.at_expression(expression, demand));
                        }
                    }
                }
                remaining = next_remaining;
                if matches!(arm.pattern, MatchPattern::Wildcard) {
                    break;
                }
            }
            for outcome in &mut outcomes {
                outcome.judge.retire_match_subject(dispatch);
            }
            return Some(outcomes);
        }
        let has_own_effect = match node {
            ExpressionNode::Call(call) => {
                !call_has_mathematical_denotation(program, scope.0.symbol, call)
            }
            ExpressionNode::Atomic(_) => {
                crate::value_custody::atomic_operations::atomic_once_carrier(program, expression)
                    .is_some()
            }
            _ => false,
        };
        let writes = if has_own_effect {
            let machine = program.machine(scope.0.symbol)?;
            let writes = self
                .frame_resolver()?
                .operation_write_frame(machine, expression);
            if super::super::struct_trace() {
                eprintln!(
                    "STRUCT normal-write-frame caller={} expression={expression:?} writes={writes:?}",
                    scope.0.name
                );
            }
            if !writes.is_complete() && !self.requires_value_preservation() {
                return None;
            }
            // Mathematical body substitution has no runtime storage epochs.
            // It cannot unfold effectful calls as repeatable applications.
            // Case-only paths separately establish tag preservation.
            if !writes.paths().is_empty() && !self.runtime_body_values && !self.case_facts_only {
                return None;
            }
            writes
        } else {
            NormalizedWriteFrame::complete(Vec::new())
        };
        // Retire a prior evaluation of this static node. Repeated edges are
        // distinct invocations; saved earlier values already retain their own
        // capture sequence and equations in the caller environment.
        std::sync::Arc::make_mut(&mut self.normal_results)
            .retain(|(source, _)| *source != expression);
        let scalar_storage_read = self.requires_value_preservation()
            && super::super::observed_projections::scalar_storage_read(
                program, scope.0, scope.1, expression,
            )
            .is_some();
        let scalar_field_read = scalar_storage_read && matches!(node, ExpressionNode::Member(_));
        let mut children_to_evaluate = Vec::new();
        let child_references =
            operand_types::receiving_types(program, scope.0, expression, node, scope.2);
        let namespace_receiver = program
            .expression_table
            .call_node(expression)
            .filter(|call| {
                super::super::structural_terms::static_call_receiver(program, scope.0.symbol, call)
            })
            .map(|call| call.receiver);
        if let ExpressionNode::Indexed(indexed) = node
            && let Some(range) = program.expression_table.range_node(indexed.index)
        {
            // A window operation consumes its collection and each authored
            // bound, not a first-class Range value. Keep the same operand
            // roster as runtime lowering and capture each bound in order.
            // Completion needs this roster too: a standalone selector has no
            // value carrier and would discard the later state's entire prefix.
            children_to_evaluate.extend(
                [indexed.collection, range.start, range.end]
                    .into_iter()
                    .filter(|child| child.is_valid())
                    .map(|child| (child, scope.2)),
            );
        } else {
            let mut position = 0;
            children(program, node, |child| {
                // Keep the shared roster's positions, including an absent
                // receiver and repeated edges, before pruning non-values.
                let reference = child_references
                    .as_ref()
                    .and_then(|references| references.get(position))
                    .copied()
                    .filter(|reference| reference.is_valid())
                    .unwrap_or(scope.2);
                position += 1;
                if child.is_valid() && Some(child) != namespace_receiver {
                    children_to_evaluate.push((child, reference));
                }
            });
        }
        let operands = children_to_evaluate
            .into_iter()
            .map(|(child, child_reference)| {
                let operand_demand = if before_operation {
                    match requested_operations.operands {
                        OperationOperandDemand::All => NormalValueDemand::Value,
                        OperationOperandDemand::Selected(values) if values.contains(&child) => {
                            NormalValueDemand::Value
                        }
                        OperationOperandDemand::Selected(values) => {
                            NormalValueDemand::Observe(values)
                        }
                    }
                } else if matches!(demand, NormalValueDemand::Completion) {
                    NormalValueDemand::Value
                } else {
                    demand
                };
                let child_demand = match node {
                    // An operation-entry query explicitly owns operand demand.
                    // Location-only receiver traversal is for evaluating an
                    // unrequested result, never for discarding a requested input.
                    _ if before_operation => operand_demand,
                    ExpressionNode::Member(member)
                        if (scalar_field_read || matches!(demand, NormalValueDemand::Location))
                            && child == member.receiver =>
                    {
                        NormalValueDemand::Location
                    }
                    ExpressionNode::Indexed(indexed)
                        if scalar_storage_read
                            || matches!(demand, NormalValueDemand::Location)
                            || program.expression_table.range_node(indexed.index).is_some() =>
                    {
                        // A view's pointer/count descriptor is evaluated before
                        // its selector. Fixed-array geometry needs only a place,
                        // not a read of possibly uninitialized element storage.
                        if child == indexed.collection
                            && crate::expression_result_type_reference(
                                program, scope.0, scope.1, child,
                            )
                            .and_then(|reference| crate::slice_view_shell(program, reference, &[]))
                            .is_none()
                        {
                            NormalValueDemand::Location
                        } else {
                            NormalValueDemand::Value
                        }
                    }
                    _ => operand_demand,
                };
                NormalOperand {
                    expression: child,
                    reference: child_reference,
                    demand: child_demand,
                }
            })
            .collect::<Vec<_>>();
        let receiver_write_sequence = self.storage_write_sequence;
        let pre_call_judge = if matches!(node, ExpressionNode::Call(_)) {
            Some(self.clone())
        } else {
            None
        };
        let contexts = self.evaluate_normal_operands(
            &operands,
            environment,
            scope,
            depth,
            requested_operations,
            entries,
            if let ExpressionNode::Call(call) = node {
                Some(crate::CallSite::Expression { expression, call })
            } else {
                None
            },
        )?;
        let mut outcomes: Vec<NormalReturnPath<'program>> = contexts
            .into_iter()
            .map(|(mut judge, inputs)| {
                let call_inputs = if let Some(call) = program.expression_table.call_node(expression)
                {
                    let mut cursor = 0;
                    Some(
                        program
                            .expression_table
                            .expression_handles(call.arguments)
                            .iter()
                            .map(|source| {
                                let offset = inputs[cursor..]
                                    .iter()
                                    .position(|(input, _)| input == source)?;
                                cursor += offset + 1;
                                Some(inputs[cursor - 1].1.clone())
                            })
                            .collect::<Option<Vec<_>>>()?,
                    )
                } else {
                    None
                };
                if requested_operations.stop == ObservationStop::BeforeOperation(expression)
                    || requested_operations.expressions.contains(&expression)
                {
                    entries.push(NormalOperationEntry {
                        expression,
                        arguments: call_inputs.as_ref().map_or_else(
                            || inputs.iter().map(|(_, result)| result.observed_value().cloned()).collect(),
                            |arguments| arguments.iter().map(|result| result.observed_value().cloned()).collect(),
                        ),
                        judge: judge.clone(),
                    });
                    // Nothing after this operation is part of its incoming
                    // proof context. A stopped path is not an executed result.
                    if requested_operations.stop == ObservationStop::BeforeOperation(expression) {
                        return Some(Vec::new());
                    }
                }
                if matches!(
                    demand,
                    NormalValueDemand::Observe(_) | NormalValueDemand::Location
                ) {
                    // Entry capture above needs operand snapshots only. Stop
                    // before the operation can publish its own invariant, and
                    // do not reconstruct an unrelated enclosing aggregate.
                    return Some(vec![NormalReturnPath::unobserved(judge)]);
                }
                // Entry observers above may keep positional placeholders.
                // Executing the call's result/guarantees needs every actual value.
                let call_values = match call_inputs {
                    Some(arguments) => Some(arguments.iter()
                        .map(|argument| argument.observed_value().cloned())
                        .collect::<Option<Vec<_>>>()?),
                    None => None,
                };
                if let Some(paths) = judge.completed_body_paths(
                    expression, call_values.as_deref(), environment, scope, &writes,
                ) {
                    return Some(paths.into_iter().map(|mut path| {
                        if matches!(demand, NormalValueDemand::Completion) {
                            path.observation = NormalValueObservation::NotObserved;
                        }
                        path.at_expression(expression, demand)
                    }).collect());
                }
                judge.complete_normal_call(
                    expression,
                    call_values.as_deref(),
                    environment,
                    scope,
                    &writes,
                )?;
                if matches!(demand, NormalValueDemand::Completion) {
                    return Some(vec![
                        NormalReturnPath::unobserved(judge).at_expression(expression, demand),
                    ]);
                }
                let receiver_changed =
                    scalar_storage_read && judge.storage_write_sequence != receiver_write_sequence;
                let completed_field = if let ExpressionNode::Member(member) = node {
                    let receiver_type = crate::expression_result_type_reference(
                        program,
                        scope.0,
                        scope.1,
                        member.receiver,
                    )?;
                    // An owned receiver has already completed at this operand.
                    // Project that captured value without replaying its former
                    // source home. Reference descriptors still cannot supply
                    // observations of their referent's fields.
                    if crate::reference_shell(program, receiver_type).is_none() {
                        inputs
                            .iter()
                            .find(|(source, _)| *source == member.receiver)
                            .and_then(|(_, value)| {
                                judge.observed_field_term(value.observed_value()?.clone(), member.member.as_str(), 0)
                            })
                    } else {
                        None
                    }
                } else {
                    None
                };
                // Metadata observes the descriptor child that just completed,
                // not a replay of its source place. A backing write may retire
                // content observations without replacing this descriptor.
                let completed_measure = if let ExpressionNode::Member(member) = node {
                    crate::expression_result_type_reference(
                        program,
                        scope.0,
                        scope.1,
                        member.receiver,
                    )
                    .and_then(|reference| {
                        super::super::structural_terms::collection_measure_term(
                            program,
                            member,
                            reference,
                            || {
                                inputs
                                    .iter()
                                    .find(|(source, _)| *source == member.receiver)
                                    .and_then(|(_, value)| value.observed_value().cloned())
                            },
                        )
                    })
                } else {
                    None
                };
                let mut value = if receiver_changed {
                    // The receiver selected its base before a later operand
                    // wrote storage. Reconstructing it from the live place now
                    // could silently select a replacement descriptor.
                    match completed_field.filter(|value| value.observation_identity_key().is_some()) {
                        Some(value) => value,
                        None => judge.capture_unknown_value(expression, scope)?,
                    }
                } else if let Some(value) = completed_measure.or(completed_field) {
                    value
                } else if matches!(node, ExpressionNode::Atomic(_)) {
                    // The atomic owner distinguishes an observed load from
                    // update carriers. Its value is a fresh event, not the
                    // place's prior initializer or the modeled new resident.
                    if crate::value_custody::atomic_operations::atomic_load_carrier(program, expression).is_none()
                        && crate::value_custody::atomic_operations::atomic_once_carrier(program, expression).is_none()
                    { return None; }
                    judge.capture_unknown_value(expression, scope)?
                } else if let Some(value) =
                    judge.callee_term_in_scope(Some(scope), expression, environment, 0)
                {
                    value
                } else if judge.runtime_body_values
                    && (matches!(node, ExpressionNode::Call(_))
                        || matches!(node, ExpressionNode::Indexed(indexed)
                            if program.expression_table.range_node(indexed.index).is_some()
                                && judge.completed_builtin_coordinates(expression, scope))
                        || judge.storage_observation_invalidated(expression)
                        || discarded_value_has_no_own_effects(program, scope, expression)
                        || matches!(node, ExpressionNode::Cast(cast)
                            if !cast.form.is_recast()
                                && program.primitive_type_reference(cast.target_type).is_some()))
                {
                    // Completion does not require a mathematical denotation.
                    // Every child has already run, and the own-effect owner
                    // above handled calls/atomics. Pure construction and
                    // primitive conversion may therefore retain a fresh value
                    // with no equations. In particular an earlier address cast
                    // must not erase unrelated premises for a later cast.
                    judge.capture_unknown_value(expression, scope)?
                } else {
                    return None;
                };
                if let (StructuralTerm::Application { arguments, .. }, Some(inputs)) =
                    (&mut value, call_values)
                {
                    *arguments = inputs;
                }
                if let ExpressionNode::StructLiteral(literal) = node {
                    let fields = program.expression_table.struct_fields(literal.fields);
                    let constructed = super::super::structural_terms::constructor_literal_term(
                        program,
                        expression,
                        literal,
                        |declared, supplied| {
                            if let Some(field) = supplied {
                                let position = fields
                                    .iter()
                                    .position(|source| source.field_symbol == field.field_symbol)?;
                                return inputs.get(position).and_then(|(_, value)| value.observed_value().cloned());
                            }
                            if !judge.runtime_body_values
                                || !crate::has_contents(
                                    program,
                                    declared.type_reference,
                                    &[],
                                    crate::value_custody::storage_contents::ContentsRequirement::BorrowFree,
                                )
                            {
                                return None;
                            }
                            // Default-domain admission is not a loan origin.
                            // Only finite borrow-free runtime zeros receive an
                            // opaque identity; erased terms and reference-bearing
                            // defaults still need their independent producers.
                            judge.capture_sequence += 1;
                            Some(StructuralTerm::CapturedValue {
                                expression,
                                callable: SymbolHandle::invalid(),
                                occurrence: judge.capture_sequence,
                                result_type: declared.type_reference,
                            })
                        },
                    );
                    value = match constructed {
                        Some(constructed) => constructed,
                        None if judge.runtime_body_values => {
                            // A completed construction can contain an omitted
                            // established value with no mathematical denotation.
                            // Preserve its executed effects and a fresh result;
                            // an unrelated later predicate still sees its prefix.
                            judge.capture_unknown_value(expression, scope)?
                        }
                        None => return None,
                    };
                }
                if let ExpressionNode::ArrayLiteral(elements) = node {
                    judge.intake_completed_array_elements(&value, elements.count(), &inputs);
                }
                if let ExpressionNode::Binary(_) = node {
                    let [(_, left), (_, right)] = inputs.as_slice() else {
                        return None;
                    };
                    value = super::super::structural_terms::binary_term_in_scope(
                        program,
                        Some(scope),
                        None,
                        expression,
                        left.observed_value()?.clone(),
                        right.observed_value()?.clone(),
                    )?;
                }
                if let ExpressionNode::Unary(_) = node {
                    let [(_, operand)] = inputs.as_slice() else {
                        return None;
                    };
                    if let Some(negated) =
                        super::super::structural_terms::logical_not_term_in_scope(
                            program,
                            Some(scope),
                            None,
                            expression,
                            operand.observed_value()?.clone(),
                        )
                    {
                        value = negated;
                    }
                }
                if let ExpressionNode::Indexed(indexed) = node
                    && program.expression_table.range_node(indexed.index).is_none()
                {
                    let [(_, collection), (_, index)] = inputs.as_slice() else {
                        return None;
                    };
                    if let (Some(collection), Some(index)) = (collection.observed_value(), index.observed_value())
                        && let Some(observed) =
                        super::super::structural_terms::indexed_term_in_scope(
                            program,
                            Some(scope),
                            None,
                            expression,
                            collection.clone(),
                            index.clone(),
                        )
                        .filter(|value| value.observation_identity_key().is_some())
                    {
                        value = observed;
                    } else if !judge.runtime_body_values {
                        return None;
                    }
                    // A completed runtime read still has its captured scalar
                    // value when its collection's contents have no structural
                    // denotation. A stable descriptor alone cannot reconstruct
                    // an element identity from an earlier storage epoch.
                    // A location-only collection is an evaluation placeholder,
                    // not a replacement for that captured scalar.
                    if let Some(reference) = crate::expression_result_type_reference(
                        program,
                        scope.0,
                        scope.1,
                        expression,
                    ) {
                        judge.intake_admitted_value_predicates(reference, value.clone());
                    }
                }
                judge.observe_completed_window(expression, &inputs, scope, &value)?;
                if let ExpressionNode::Borrow(borrow) = node {
                    // A checked borrow selects its referent; it does not create
                    // a new case-bearing value. The referent's completed term
                    // keeps the same descriptor identity the mathematical
                    // `callee_term` walk would have produced, so later `len`
                    // and field observations name this exact view.
                    if let Some((_, referent)) =
                        inputs.iter().find(|(input, _)| *input == borrow.target)
                    {
                        if let Some(observed) = referent.observed_value() {
                            value = crate::expression_result_type_reference(
                                program, scope.0, scope.1, expression,
                            )
                            .and_then(|declared| {
                                super::super::structural_terms::shared_inline_observation(
                                    program, declared, observed.clone(),
                                )
                            })
                            .unwrap_or_else(|| observed.clone());
                        }
                    }
                }
                if scalar_storage_read {
                    // Completing a typed read observes its actual value even
                    // when no mathematical entry value is known. Integers,
                    // addresses, and IEEE floats share that coordinate, so an
                    // exclusive loan retires the read only when it overlaps.
                    // Source text is never its identity.
                    if value.observation_identity_key().is_none() {
                        value = judge.capture_unknown_value(expression, scope)?;
                    }
                    if !receiver_changed {
                        judge.observe_completed_storage_read(
                            scope.0,
                            scope.1,
                            expression,
                            value.clone(),
                        );
                    }
                }
                // A whole owned-value read captures its revision before a
                // named state can inspect its fields. A reference descriptor
                // does not capture the contents of its referent.
                if matches!(node, ExpressionNode::Name(_) | ExpressionNode::Member(_))
                    && let Some(reference) = crate::expression_result_type_reference(program, scope.0, scope.1, expression)
                    && program.primitive_type_reference(reference).is_none()
                    && crate::reference_shell(program, reference).is_none()
                {
                    judge.observe_completed_storage_read(scope.0, scope.1, expression, value.clone());
                }
                if let Some(actual_type) = crate::expression_result_type_reference(
                    program, scope.0, scope.1, expression,
                ) && crate::fixed_array_type_extent(program, actual_type).is_some()
                    && let Some(extent) = super::super::structural_terms::observed_collection_measure(
                        program,
                        actual_type,
                        CollectionMeasure::Length,
                        || None,
                    )
                {
                    // Capture immutable geometry on the completed actual before
                    // a receiving slice formal attenuates its declared carrier.
                    // This exact descriptor identity supplies no element facts,
                    // initializer replay, or additional reference authority.
                    let descriptor = value.clone().into_collection_descriptor();
                    if descriptor.observation_identity_key().is_some() {
                        judge.assume_normal_equation(
                            StructuralTerm::CollectionMeasure {
                                measure: CollectionMeasure::Length,
                                collection: Box::new(descriptor),
                            },
                            extent,
                        );
                    }
                }
                Some(vec![
                    NormalReturnPath::observed(value, judge).at_expression(expression, demand),
                ])
            })
            .collect::<Option<Vec<_>>>()?
            .into_iter()
            .flatten()
            .collect();
        if outcomes.len() > 1
            && let Some(pre_call_judge) = &pre_call_judge
            && outcomes.iter().all(|path| {
                path.judge
                    .has_no_new_effects_or_guarantees_since(pre_call_judge)
            })
        {
            if outcomes
                .iter()
                .all(|path| path.observation == NormalValueObservation::NotObserved)
            {
                let judge_refs: Vec<&Self> = outcomes.iter().map(|path| &path.judge).collect();
                let rejoined = pre_call_judge.rejoin_pure_outcomes(&judge_refs, Some(expression));
                return Some(vec![
                    NormalReturnPath::unobserved(rejoined).at_expression(expression, demand),
                ]);
            }
            if let StructuralTerm::CapturedValue {
                expression: expr,
                callable,
                result_type,
                ..
            } = outcomes[0].value
                && expr == expression
                && outcomes.iter().all(|path| {
                    path.observation == NormalValueObservation::Observed
                        && path.judge.normal_guarantees.len()
                            == pre_call_judge.normal_guarantees.len()
                        && matches!(
                            path.value,
                            StructuralTerm::CapturedValue {
                                expression: other_expr,
                                callable: other_callable,
                                result_type: other_type,
                                ..
                            } if other_expr == expr
                                && other_callable == callable
                                && other_type == result_type
                        )
                })
            {
                let judge_refs: Vec<&Self> = outcomes.iter().map(|path| &path.judge).collect();
                let mut rejoined =
                    pre_call_judge.rejoin_pure_outcomes(&judge_refs, Some(expression));
                rejoined.capture_sequence += 1;
                let captured = StructuralTerm::CapturedValue {
                    expression,
                    callable,
                    occurrence: rejoined.capture_sequence,
                    result_type,
                };
                return Some(vec![
                    NormalReturnPath::observed(captured, rejoined)
                        .at_expression(expression, demand),
                ]);
            }
        }
        Some(outcomes)
    }

    /// Operand completion retains the actual contextual carrier. Receiving
    /// types alone cannot authenticate an indexed source or its geometry.
    fn completed_collection_type(
        &self,
        expression: ExpressionHandle,
        scope: ValueScope<'_>,
    ) -> Option<TypeReferenceHandle> {
        crate::expression_result_type_reference(self.program, scope.0, scope.1, expression).or_else(
            || {
                let (_, value) = self
                    .normal_results
                    .iter()
                    .rev()
                    .find(|(source, _)| *source == expression)?;
                match value {
                    StructuralTerm::CapturedValue { result_type, .. }
                    | StructuralTerm::Application { result_type, .. } => Some(*result_type),
                    StructuralTerm::ObservedValue { observed_type, .. } => Some(*observed_type),
                    _ => None,
                }
                .filter(|reference| reference.is_valid())
            },
        )
    }

    fn completed_builtin_coordinates(
        &self,
        expression: ExpressionHandle,
        scope: ValueScope<'_>,
    ) -> bool {
        crate::value_custody::places::value_has_builtin_coordinates_with_types(
            self.program,
            scope.0,
            scope.1,
            expression,
            |source| self.completed_collection_type(source, scope),
        )
    }

    fn normal_value_type_reference(
        &self,
        expression: ExpressionHandle,
        scope: ValueScope<'_>,
    ) -> Option<TypeReferenceHandle> {
        let program = self.program;
        crate::expression_result_type_reference(program, scope.0, scope.1, expression).or_else(
            || {
                let indexed = program.expression_table.indexed_node(expression)?;
                program.expression_table.range_node(indexed.index)?;
                crate::slice_view_shell(program, scope.2, &[])?;
                if !self.completed_builtin_coordinates(expression, scope) {
                    return None;
                }
                let source = self.completed_collection_type(indexed.collection, scope)?;
                let source_element =
                    crate::value_custody::places::collection_element_type_reference(
                        program, source,
                    )?;
                let receiving_element =
                    crate::value_custody::places::collection_element_type_reference(
                        program, scope.2,
                    )?;
                (program.normalized_type_identity(source_element)
                    == program.normalized_type_identity(receiving_element))
                .then_some(scope.2)
            },
        )
    }

    fn capture_unknown_value(
        &mut self,
        expression: ExpressionHandle,
        scope: ValueScope<'_>,
    ) -> Option<StructuralTerm> {
        self.capture_sequence += 1;
        let value = StructuralTerm::CapturedValue {
            expression,
            callable: SymbolHandle::invalid(),
            occurrence: self.capture_sequence,
            result_type: self
                .normal_value_type_reference(expression, scope)
                .or_else(|| {
                    // Collection literals have contextual storage types, not one
                    // context-free result reference. Constructor operands already
                    // carry the selected field type; retain that receiving carrier
                    // without claiming anything about its contents.
                    matches!(
                        self.program.expression_table.expression(expression),
                        ExpressionNode::String(_) | ExpressionNode::ArrayLiteral(_)
                    )
                    .then(|| {
                        crate::value_custody::places::collection_element_type_reference(
                            self.program,
                            scope.2,
                        )
                    })
                    .flatten()
                    .filter(|element| {
                        matches!(
                            self.program.expression_table.expression(expression),
                            ExpressionNode::ArrayLiteral(_)
                        ) || self.program.primitive_type_reference(*element)
                            == Some(typed_trees::types::PrimitiveType::U8)
                    })
                    .map(|_| scope.2)
                })?,
        };
        self.intake_current_storage_fields(scope.0, scope.1, expression, &value);
        if let StructuralTerm::CapturedValue { result_type, .. } = &value {
            self.intake_admitted_scalar_bounds(*result_type, &value);
            self.intake_atomic_observation_bounds(
                scope.0,
                scope.1,
                expression,
                *result_type,
                &value,
            );
        }
        if let ExpressionNode::String(bytes) = self.program.expression_table.expression(expression)
            && let StructuralTerm::CapturedValue { result_type, .. } = &value
        {
            // The completed quoted-byte view has exact descriptor geometry.
            // Its contents remain opaque: a byte count supplies neither an
            // encoding predicate nor authority to observe another referent.
            let extent = StructuralTerm::Integer(numerics::bignum::BigInt::from_u64(
                u64::try_from(bytes.len()).ok()?,
            ));
            for measure in [
                language_semantics::declaration_selection::CollectionMeasure::Length,
                language_semantics::declaration_selection::CollectionMeasure::Capacity,
            ] {
                if let Some(observation) =
                    super::super::structural_terms::observed_collection_measure(
                        self.program,
                        *result_type,
                        measure,
                        || Some(value.clone()),
                    )
                {
                    self.assume_normal_equation(observation, extent.clone());
                }
            }
        }
        Some(value)
    }

    pub(super) fn assume_normal_equation(&mut self, left: StructuralTerm, right: StructuralTerm) {
        std::sync::Arc::make_mut(&mut self.normal_guarantees).push((left.clone(), right.clone()));
        self.intake_equation(left, right, 0);
    }

    pub(in crate::proof_contracts::contract_entailment) fn reference_subject_term(
        &self,
        subject: &crate::machine_calls::calls::InvocationEntrySubject,
        actual: &StructuralTerm,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<StructuralTerm> {
        let program = self.program;
        let [source] = subject.sources.as_slice() else {
            // Origin authority quantifies over the complete join. Its actual
            // value was selected by this path's ordered operand evaluation.
            // Later sibling writes retire that observation; a produced
            // descriptor never supplies referent contents by type alone.
            if subject.sources.is_empty()
                || self.storage_observation_invalidated(subject.argument)
                || subject
                    .sources
                    .iter()
                    .any(|source| self.storage_binding_invalidated(source.root))
            {
                return None;
            }
            // Resolution may replace the outer carrier. Check authority on
            // both sides so an equation cannot launder a raw descriptor.
            if !super::super::structural_terms::scalar_operand_is_observed(
                program,
                subject.parameter_type,
                actual,
            ) {
                return None;
            }
            let value = self.resolve(actual.clone());
            if !super::super::structural_terms::scalar_operand_is_observed(
                program,
                subject.parameter_type,
                &value,
            ) {
                return None;
            }
            return Some(
                if program
                    .primitive_type_reference(subject.type_reference)
                    .is_some()
                {
                    StructuralTerm::ObservedValue {
                        observed_type: subject.type_reference,
                        descriptor: None,
                        value: Box::new(value),
                    }
                } else {
                    value
                },
            );
        };
        if let Some(value) = self
            .captured_reference_subject(subject)
            .and_then(|coordinate| self.current_storage_value(&coordinate))
        {
            return Some(
                if program
                    .primitive_type_reference(subject.type_reference)
                    .is_some()
                {
                    StructuralTerm::ObservedValue {
                        observed_type: subject.type_reference,
                        descriptor: None,
                        value: Box::new(value),
                    }
                } else {
                    value
                },
            );
        }
        if self.storage_binding_invalidated(source.root) {
            return None;
        }
        // The frame publishes a checked exact declaration path. Scope lookup
        // only locates that root's current observation; no initializer replay
        // or similarly spelled declaration may stand in for it.
        let is_parameter = program
            .state_parameter_by_symbol(scope.1, source.root)
            .is_some();
        let is_local = program
            .state_local_declaration(scope.1, source.root)
            .is_some();
        if !(is_parameter || is_local) || !subject.type_reference.is_valid() {
            return None;
        }
        let mut current_type = crate::state_root_type(program, scope.1, source.root)?;
        let name = program.symbols.name(source.root);
        let mut roots = environment.iter().filter(|(binding, _)| binding == name);
        let mut value = roots.next()?.1.clone();
        if roots.next().is_some() {
            return None;
        }
        for segment in &source.segments {
            match segment {
                facts::PlaceSegment::Field { symbol } => {
                    value = self.observed_field_term(value, program.symbols.name(*symbol), 0)?;
                    current_type =
                        crate::value_custody::places::project_type_reference_from_segments(
                            program,
                            current_type,
                            std::slice::from_ref(segment),
                        )?;
                }
                facts::PlaceSegment::FixedIndex { index } => {
                    let index_u64 = u64::try_from(*index).ok()?;
                    let index_term =
                        StructuralTerm::Integer(numerics::bignum::BigInt::from_u64(index_u64));
                    value = super::super::observed_projections::project_index(
                        program,
                        current_type,
                        value,
                        index_term,
                    )?;
                    current_type =
                        crate::value_custody::places::project_type_reference_from_segments(
                            program,
                            current_type,
                            std::slice::from_ref(segment),
                        )?;
                }
                // The current structural term owner has no dynamic indexed or case
                // projection observation. Exact origin/type alone cannot
                // manufacture its value or erase an active-case obligation.
                _ => return None,
            }
        }
        if program
            .primitive_type_reference(subject.type_reference)
            .is_some()
        {
            Some(StructuralTerm::ObservedValue {
                observed_type: subject.type_reference,
                descriptor: None,
                value: Box::new(value),
            })
        } else {
            Some(value)
        }
    }

    /// Observe this operation's own normal result immediately after its
    /// captured operands. The entry traversal stops before later siblings;
    /// completing the call here does not evaluate its operands a second time.
    pub(in crate::proof_contracts::contract_entailment) fn normal_operation_results(
        &self,
        statement_index: usize,
        expression: ExpressionHandle,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
    ) -> Option<Vec<NormalReturnPath<'program>>> {
        let entries = self.normal_operation_entries(
            statement_index,
            expression,
            OperationOperandDemand::All,
            environment,
            scope,
        )?;
        let mut results = Vec::with_capacity(entries.len());
        for entry in entries {
            let arguments = entry.observed_arguments()?;
            let mut judge = entry.judge;
            let writes = judge
                .frame_resolver()?
                .operation_write_frame(scope.0, expression);
            if !writes.is_complete() && !judge.requires_value_preservation() {
                return None;
            }
            judge.complete_normal_call(
                expression,
                Some(&arguments),
                environment,
                scope,
                &writes,
            )?;
            let value = judge
                .normal_results
                .iter()
                .find(|(source, _)| *source == expression)?
                .1
                .clone();
            results.push(NormalReturnPath::observed(value, judge));
        }
        (!results.is_empty()).then_some(results)
    }

    fn complete_normal_call(
        &mut self,
        expression: ExpressionHandle,
        actuals: Option<&[StructuralTerm]>,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
        writes: &NormalizedWriteFrame,
    ) -> Option<()> {
        let post_storage =
            self.capture_normal_call(expression, actuals, environment, scope, writes);
        self.observe_storage_effects(scope.1, writes.complete_paths())?;
        for (coordinate, value) in post_storage.into_iter().flatten() {
            self.retain_storage_value(coordinate, value, false);
        }
        Some(())
    }

    fn capture_normal_call(
        &mut self,
        expression: ExpressionHandle,
        actuals: Option<&[StructuralTerm]>,
        environment: &[(String, StructuralTerm)],
        scope: ValueScope<'_>,
        writes: &NormalizedWriteFrame,
    ) -> Option<
        Vec<(
            super::storage_effects::CapturedStorageCoordinate,
            StructuralTerm,
        )>,
    > {
        let program = self.program;
        let node = program.expression_table.expression(expression);
        let ExpressionNode::Call(call) = node else {
            return None;
        };
        let Some(owner) = selected_call_contract(program, scope.0.symbol, call) else {
            return None;
        };
        // Computed proof machines are erased mathematical applications. Their
        // definitions and induction remain with the existing term owner;
        // replacing them with opaque runtime occurrences loses that denotation.
        if call_has_mathematical_denotation(program, scope.0.symbol, call) {
            return None;
        }
        if !call.evidence_arguments.is_empty() || call.quotient_operation.is_some() {
            return None;
        }
        let site = crate::CallSite::Expression { expression, call };
        let application =
            AppliedProofBindings::for_call_site(program, scope.0.symbol, &owner, site)?;
        // The shared application intake authenticates the complete static
        // telescope. This observer imports only its selected public contract;
        // it never interprets a callback body. The exact call's callback
        // dependencies still pass independent_call_application below before
        // any normal guarantee is imported.
        let parameter_scope = super::super::specification_calls::call_parameter_scope(
            program,
            scope.0.symbol,
            &owner,
            crate::CallSite::Expression { expression, call },
        )?;
        let parameters = parameter_scope.as_ref();
        if super::super::struct_trace() {
            eprintln!(
                "STRUCT normal-capture entry expression={expression:?} owner={:?} arguments={actuals:?}",
                owner_symbol(&owner)
            );
        }
        // References are live subjects. Only the frame owner can publish their
        // exact prefix origins and preservation through this normal return.
        // A written subject or replaced formal binding needs post-state facts,
        // not the detached child term captured during operand evaluation.
        let Some(machine) = program.machine(scope.0.symbol) else {
            return None;
        };
        let frames = self.frame_resolver();
        // An opaque frame establishes no preservation or post-call reference
        // correspondence. Isolated operand snapshots and independent result
        // guarantees remain usable, but no live referent is reintroduced.
        let subjects = frames.filter(|_| writes.is_complete()).and_then(|frames| {
            frames.expression_call_reference_subjects(machine, expression, parameters)
        });
        if !independent_call_application(
            program,
            self.machine_symbol,
            owner_symbol(&owner),
            typed_trees::references::StaticArgumentCall::Expression(expression, call),
        ) {
            return None;
        }
        let leading_operands = owner_leading_operands(&owner);
        let Some(arguments) = program
            .expression_table
            .expression_handles(call.arguments)
            .get(leading_operands..)
        else {
            return None;
        };
        if arguments.len() != parameters.len() {
            return None;
        }
        // The checked local-name gate rejects parameter/local collisions and
        // duplicate locals in each state; state forwarding creates a fresh
        // environment. Names here locate values only in that validated scope;
        // exact symbols still own the public formal/result substitution.
        // All actual values belong to the caller environment. Installing a
        // formal map before this capture would reinterpret another actual in
        // the callee's telescope.
        let completed_arguments = actuals?;
        let Some(actuals) = completed_arguments
            .get(leading_operands..)
            .filter(|actuals| actuals.len() == arguments.len())
        else {
            return None;
        };
        // Entry requirements observe the arguments before this call's writes.
        // Guarantees may use only formals whose observations survive return.
        // Keep both substitutions: dropping a mutable input's post-state
        // observation must not erase a proven entry requirement or an
        // independent guarantee about the captured result.
        let mut entry_bindings = parameters
            .iter()
            .zip(actuals)
            .filter_map(|(parameter, value)| {
                let subject = subjects
                    .as_ref()
                    .and_then(|subjects| {
                        subjects
                            .iter()
                            .find(|subject| subject.entry.parameter == parameter.symbol)
                    })
                    .map(|subject| &subject.entry);
                self.entry_argument_value(parameter, value, subject, environment, scope)
                    .map(|value| (parameter.symbol, value))
            })
            .collect::<Vec<_>>();
        // One authenticated telescope supplies closed constants and completed
        // runtime operands. Executable formals already captured above retain
        // their own ordered value; header subjects never replay their storage.
        let static_bindings = super::super::specification_calls::call_contract_scalar_substitution(
            program,
            scope.0.symbol,
            &owner,
            site,
            |subject| {
                self.completed_scalar_subject(subject, site, completed_arguments, scope.0, scope.1)
            },
        )?;
        for (parameter, value) in static_bindings {
            if !entry_bindings
                .iter()
                .any(|(symbol, _)| *symbol == parameter.symbol)
            {
                entry_bindings.push((parameter.symbol, value));
            }
        }
        let mut bindings = entry_bindings
            .iter()
            .filter_map(|(symbol, value)| {
                let Some(parameter) = parameters
                    .iter()
                    .find(|parameter| parameter.symbol == *symbol)
                else {
                    return application
                        .constants
                        .iter()
                        .any(|constant| constant.symbol == *symbol)
                        .then(|| (*symbol, value.clone()))
                        .or_else(|| {
                            application
                                .runtime_parameters
                                .iter()
                                .any(|runtime| runtime.symbol == *symbol)
                                .then(|| (*symbol, value.clone()))
                        });
                };
                let observed =
                    if crate::reference_shell(program, parameter.type_reference).is_none() {
                        (!parameter.is_mutable).then(|| value.clone())?
                    } else if subjects.as_ref().is_some_and(|subjects| {
                        subjects.iter().any(|subject| {
                            subject.entry.parameter == *symbol && subject.preserved_on_return
                        })
                    }) {
                        value.clone()
                    } else if !parameter.is_mutable
                        && crate::slice_view_shell(program, parameter.type_reference, &[]).is_some()
                    {
                        // The passed descriptor can survive without preserved
                        // referent contents. Retain only its metadata identity;
                        // a pre-call contents observation is not a post-call fact.
                        super::super::structural_terms::descriptor_only_observation(
                            parameter.type_reference,
                            value.clone(),
                        )
                    } else {
                        return None;
                    };
                Some((*symbol, observed))
            })
            .collect::<Vec<_>>();
        // A stable reference binding can designate changed contents. Capture
        // those contents as a fresh post-call value, never as the entry value.
        // The frame owns the exact referent coordinate; selected public
        // guarantees own its equations. Install it only after retiring writes.
        let mut post_storage = Vec::new();
        for subject in subjects.as_ref().into_iter().flatten() {
            if subject.preserved_on_return || !subject.stable_on_return {
                continue;
            }
            let Some(coordinate) = self.captured_reference_subject(&subject.entry) else {
                continue;
            };
            self.capture_sequence += 1;
            let value = StructuralTerm::CapturedValue {
                expression,
                callable: owner_symbol(&owner),
                occurrence: self.capture_sequence,
                result_type: subject.entry.type_reference,
            };
            let mut observed = if program
                .primitive_type_reference(subject.entry.type_reference)
                .is_some()
            {
                StructuralTerm::ObservedValue {
                    observed_type: subject.entry.type_reference,
                    descriptor: None,
                    value: Box::new(value.clone()),
                }
            } else {
                value.clone()
            };
            // The normal boundary restores declared predicates on these fresh
            // returned contents; retired pre-call observations supply none.
            self.intake_admitted_value_predicates(subject.entry.type_reference, value.clone());
            if let Some(parameter) = parameters.iter().find(|parameter| {
                parameter.symbol == subject.entry.parameter
                    && !parameter.is_mutable
                    && crate::slice_view_shell(program, parameter.type_reference, &[]).is_some()
            }) && let Some((_, descriptor)) = entry_bindings
                .iter()
                .find(|(symbol, _)| *symbol == subject.entry.parameter)
            {
                observed = super::super::structural_terms::reference_argument_observation(
                    program,
                    parameter.type_reference,
                    descriptor,
                    Some(observed),
                )?;
            }
            // Exact formal substitution selects the first binding. Replace
            // its metadata-only row rather than shadowing this authenticated
            // post-call observation with an earlier same-symbol entry value.
            if let Some((_, current)) = bindings
                .iter_mut()
                .find(|(symbol, _)| *symbol == subject.entry.parameter)
            {
                *current = observed;
            } else {
                bindings.push((subject.entry.parameter, observed));
            }
            post_storage.push((coordinate, value));
        }
        let callable = match owner {
            SelectedCallContract::Concrete(machine, _) => machine.symbol,
            _ => owner_symbol(&owner),
        };
        // Carrier equality is checked under the exact public application.
        // A policy adapter still cannot donate a raw declaration's equation.
        // Share constructed_results' exact public/applied result telescope.
        // This immutable type correspondence never re-observes actual values.
        let applied_result_parameters = site.parameters(program, scope.0.symbol);
        let result_presentation = if matches!(
            program
                .type_reference_table
                .type_reference(owner_return_type(&owner)),
            typed_trees::types::TypeReferenceNode::Unit
        ) {
            None
        } else {
            let observed_type =
                crate::expression_result_type_reference(program, scope.0, scope.1, expression)?;
            Some(application.runtime_result_presentation(
                program,
                &owner,
                call,
                observed_type,
                applied_result_parameters,
                callable,
                parameters,
                &bindings,
            )?)
        };
        let contracts = owner_contracts(program, &owner).collect::<Vec<_>>();
        let captured = result_presentation.as_ref().map(|presentation| {
            self.capture_sequence += 1;
            StructuralTerm::CapturedValue {
                expression,
                occurrence: self.capture_sequence,
                callable,
                result_type: presentation.type_reference,
            }
        });
        if super::super::struct_trace() {
            eprintln!(
                "STRUCT normal-capture bindings expression={expression:?} entry={entry_bindings:?} post={bindings:?}"
            );
        }
        // An overwritten referent supplies no stable input observation, but
        // does not erase independent guarantees about this returned value.
        // Equations requiring an omitted formal fail exact substitution.
        let Some(guarantees) =
            self.selected_guarantees(&owner, &entry_bindings, &bindings, captured.as_ref(), 0)
        else {
            return None;
        };
        let mut equations = guarantees.equations;
        std::sync::Arc::make_mut(&mut self.normal_content_guarantees).extend(guarantees.content);
        // A saved local now resolves to this occurrence, so the callee's case
        // tags must classify it here; the citation route's saved-binding tags
        // never meet that environment term. Tags never become value equations.
        let tag_callee = match owner {
            SelectedCallContract::Concrete(machine, _)
                if parameters.iter().all(|parameter| {
                    bindings
                        .iter()
                        .any(|(symbol, _)| *symbol == parameter.symbol)
                }) =>
            {
                Some(machine)
            }
            _ => None,
        };
        let tag_map = parameters
            .iter()
            .filter_map(|parameter| {
                bindings
                    .iter()
                    .find(|(symbol, _)| *symbol == parameter.symbol)
                    .map(|(_, value)| (parameter.name.as_str().to_owned(), value.clone()))
            })
            .chain(captured.as_ref().map(|captured| {
                (
                    crate::proof_contracts::contract_entailment::RESULT_BINDER.to_owned(),
                    captured.clone(),
                )
            }))
            .collect::<Vec<_>>();
        let mut case_guarantees = Vec::new();
        let selected_signature = match owner {
            SelectedCallContract::Signature(signature)
            | SelectedCallContract::DynamicSlot { signature, .. } => Some(signature),
            _ => None,
        };
        let qualification_contract = crate::CallQualificationContract::prepare(
            program,
            call.target_symbol,
            selected_signature,
        );
        for contract in contracts
            .iter()
            .filter(|contract| contract.kind == SignatureContractKind::Ensures)
        {
            for fact in program.proof_facts.span_or_empty(contract.facts) {
                if let ProofFact::Membership(guarantee) = fact {
                    if qualification_contract
                        .fact_source(contract.kind.clone(), fact)
                        .is_none()
                    {
                        // A checked adapter's inherited issuer obligation is
                        // not an ordinary-call guarantee. Use the same actual
                        // declaration gate as flow's call-contract evidence.
                        continue;
                    }
                    // A result qualification stated in `ensures` carries the
                    // same admission as one stated on the result type. Retain
                    // its exact detached occurrence, never a live caller name
                    // or the result's borrowed referent. Later writes change
                    // the observed subject and cannot reuse this snapshot.
                    if let Some(subject) = bound_term(
                        program,
                        guarantee.value,
                        callable,
                        parameters,
                        callable,
                        &bindings,
                        captured.as_ref(),
                        0,
                    ) {
                        let mut root = &subject;
                        while let StructuralTerm::Projection { subject, .. } = root {
                            root = subject;
                        }
                        if Some(root) == captured.as_ref() && guarantee.semantic_domain.is_valid() {
                            std::sync::Arc::make_mut(&mut self.normal_memberships).push(
                                MembershipGuarantee {
                                    subject,
                                    domain: guarantee.domain_symbol,
                                    semantic_domain: guarantee.semantic_domain,
                                },
                            );
                        }
                    }
                }
                let ProofFact::Expression(guarantee) = fact else {
                    continue;
                };
                if let Some(callee) = tag_callee {
                    self.instantiated_case_guarantees(
                        callee,
                        *guarantee,
                        &tag_map,
                        &mut case_guarantees,
                    );
                }
            }
        }
        if super::super::struct_trace() {
            eprintln!(
                "STRUCT normal-call expression={expression:?} public_owner={:?} result={captured:?} equations={equations:?}",
                owner_symbol(&owner),
            );
        }
        if let (Some(captured), Some(result_presentation)) = (&captured, &result_presentation)
            && let SelectedCallContract::Concrete(callee, selected_state) = &owner
        {
            equations.extend(self.returned_field_equations(
                callee,
                selected_state,
                parameters,
                actuals,
                captured,
            ));
        }
        for (left, right) in equations {
            let max_premise_occ = self.rewrites.max_premise_occurrence();
            let pattern_occ = match (
                Self::term_max_captured_occurrence(&left),
                Self::term_max_captured_occurrence(&right),
            ) {
                (Some(l), Some(r)) => {
                    if l > r {
                        Some(l)
                    } else if r > l {
                        Some(r)
                    } else {
                        None
                    }
                }
                (Some(l), None) => Some(l),
                (None, Some(r)) => Some(r),
                (None, None) => None,
            };
            if let Some(occ) = pattern_occ
                && occ <= max_premise_occ
            {
                std::sync::Arc::make_mut(&mut self.rewrites)
                    .bump_integer_premise_revision_for_occurrences(occ);
            }
            std::sync::Arc::make_mut(&mut self.captured_result_equations)
                .push((left.clone(), right.clone()));
            std::sync::Arc::make_mut(&mut self.normal_guarantees)
                .push((left.clone(), right.clone()));
            self.intake_equation(left, right, 0);
        }
        if let (Some(captured), Some(result_presentation)) = (captured, result_presentation) {
            let result_type = result_presentation.type_reference;
            self.intake_admitted_value_predicates(result_type, captured.clone());
            // A dependent result recipe keeps the same formal presentation used
            // by admission. Its operands are these completed invocation bindings;
            // neither slot alpha-renaming nor later writes can replay their source.
            self.intake_admitted_value_indices(
                result_type,
                &captured,
                result_presentation.parameter_owner,
                result_presentation.parameters,
                &result_presentation.bindings,
            );
            // A construction describes payload, never the identity or admission of
            // this call's result. Equal field geometry cannot merge linear roots.
            std::sync::Arc::make_mut(&mut self.normal_results).push((expression, captured));
        }
        for guarantee in &case_guarantees {
            self.intake_case_guarantee(guarantee);
        }
        Some(post_storage)
    }
}

/// Discarding a value never discards an operation's own effects. Calls,
/// atomics, executable conversions and non-builtin operators keep their complete
/// owner. Representation recasts, construction and projection have only their
/// ordered children's effects; the recast checker owns compatibility and loans.
fn discarded_value_has_no_own_effects(
    program: &dyn crate::CheckingInput,
    scope: ValueScope<'_>,
    expression: ExpressionHandle,
) -> bool {
    match program.expression_table.expression(expression) {
        ExpressionNode::Call(_) | ExpressionNode::Atomic(_) | ExpressionNode::Unary(_) => false,
        // A recast borrows existing backing; it does not execute a conversion.
        // Its completed reference may remain opaque without discarding the
        // prefix's independent premises or claiming new referent contents.
        ExpressionNode::Cast(cast) => cast.form.is_recast(),
        ExpressionNode::Binary(_) => crate::has_builtin_binary_expression_meaning(
            program,
            scope.0,
            Some(scope.1),
            expression,
        ),
        ExpressionNode::Indexed(indexed) => {
            crate::has_builtin_subslice_meaning(program, scope.0, Some(scope.1), expression)
                || crate::expression_result_type_reference(
                    program,
                    scope.0,
                    scope.1,
                    indexed.collection,
                )
                .is_some_and(|collection| {
                    crate::value_custody::places::value_element_has_builtin_coordinate(
                        program,
                        scope.0,
                        Some(scope.1),
                        expression,
                        collection,
                    )
                })
        }
        ExpressionNode::Member(member) => {
            let Some(reference) =
                crate::expression_result_type_reference(program, scope.0, scope.1, member.receiver)
            else {
                return false;
            };
            if crate::value_custody::places::collection_operations::collection_measure_member(
                program,
                member,
                crate::value_custody::places::collection_operations::MeasureReceiver::Declared(
                    reference,
                ),
            )
            .is_some()
            {
                return true;
            }
            crate::value_custody::places::data_definition_for_type(program, reference)
                .and_then(|data| {
                    crate::value_custody::places::exact_data_member_field(
                        program,
                        data,
                        member.member_symbol,
                        member.member.as_str(),
                        member.case_variant.as_ref().map(|case| case.as_str()),
                    )
                })
                .is_some()
        }
        ExpressionNode::Match(_)
        | ExpressionNode::ArrayLiteral(_)
        | ExpressionNode::Boolean(_)
        | ExpressionNode::Float(_)
        | ExpressionNode::Integer(_)
        | ExpressionNode::Borrow(_)
        | ExpressionNode::Name(_)
        | ExpressionNode::Range(_)
        | ExpressionNode::StructLiteral(_)
        | ExpressionNode::String(_) => true,
        ExpressionNode::SavedSubject(_)
        | ExpressionNode::UndeterminedNaN(_)
        | ExpressionNode::ZeroValue(_) => false,
    }
}

impl<'program> NormalReturnPath<'program> {
    fn observed(value: StructuralTerm, judge: StructuralJudge<'program>) -> Self {
        Self {
            value,
            judge,
            observation: NormalValueObservation::Observed,
        }
    }

    fn unobserved(judge: StructuralJudge<'program>) -> Self {
        Self {
            // This private traversal token is never published as a value.
            // Operation entries carry its absence explicitly as None.
            value: StructuralTerm::Opaque("unobserved traversal".to_owned()),
            judge,
            observation: NormalValueObservation::NotObserved,
        }
    }

    fn observed_value(&self) -> Option<&StructuralTerm> {
        (self.observation == NormalValueObservation::Observed).then_some(&self.value)
    }

    fn at_expression(
        mut self,
        expression: ExpressionHandle,
        demand: NormalValueDemand<'_>,
    ) -> Self {
        // Every evaluation retires this static node's prior occurrence, even
        // when its current value is discarded. Only demanded values enter the
        // completed-result roster; ordered traversal still keeps child effects.
        std::sync::Arc::make_mut(&mut self.judge.normal_results)
            .retain(|(source, _)| *source != expression);
        if matches!(demand, NormalValueDemand::Value)
            && self.observation == NormalValueObservation::Observed
        {
            std::sync::Arc::make_mut(&mut self.judge.normal_results)
                .push((expression, self.value.clone()));
        }
        self
    }
}

/// Authored mathematical definitions have no runtime invocation, including
/// definitions with ordinary scalar results. Other calls need the shared
/// proof-only classification; runtime calls still require complete write frames.
pub(in crate::proof_contracts::contract_entailment) fn call_has_mathematical_denotation(
    program: &dyn crate::CheckingInput,
    caller: SymbolHandle,
    call: &typed_trees::expression::TableCallExpression,
) -> bool {
    if crate::mathematical_applications::selected_definition(program, call).is_some() {
        return true;
    }
    if let Some(signature) = crate::machine_calls::denotational_calls::abstract_value_call_signature(
        program,
        call.target_symbol,
    ) {
        return crate::proof_only_classification(program)
            .proof_only_mention(program, signature.return_type)
            .is_some();
    }
    match selected_call_contract(program, caller, call) {
        Some(SelectedCallContract::Concrete(machine, _)) => {
            crate::proof_only_classification(program).is_proof_machine(program, machine)
        }
        Some(SelectedCallContract::Operator(operator)) => {
            // A sealed total proof-value operator has the same erased
            // denotation as a computed proof machine. Retain its selected
            // identity; an unresolved or ordinary runtime operator must still
            // establish its write frame and capture its own result occurrence.
            crate::proof_only_classification(program)
                .proof_only_mention(program, operator.return_type)
                .is_some()
                && crate::machine_calls::denotational_calls::selected_operator_has_closed_value_denotation(program, operator)
        }
        _ => false,
    }
}

fn program_expression_is_live(
    program: &dyn crate::CheckingInput,
    expression: ExpressionHandle,
) -> bool {
    expression.is_valid() && program.expression_table.expression_is_valid(expression)
}
