use super::lower_expression_handle_from_table_with_symbol_substitution;
use crate::lowerer::name::lower_name;
use diagnostics::Diagnostic;
use symbol_resolved_trees as resolved;
use typed_trees as typed;

/// `value in Type::Case` is the tag test (frozen decision 11): it lowers to
/// a tag-equality compare against the case name. The lowered form is the
/// SAME binary-equality shape a payload-less `==` produces, on purpose --
/// the guard tag clamp, value-position enum-constant folding, and the
/// interpreter's tag-only enum equality all consume it unchanged. The
/// user-facing bare-case `==` error cannot re-flag it because that check
/// runs on the RESOLVED trees, before this lowering (see `crate::expressions::equality`).
///
/// Returns `None` when the membership domain does not name a case of a data
/// definition, so the caller falls back to declared-domain lowering.
pub(super) fn lower_case_membership_expression(
    program: &resolved::SymbolResolvedTrees,
    source: &resolved::expression::ExpressionTable,
    target: &mut typed::TypedTrees,
    value: typed::expression::ExpressionHandle,
    domain: arena::HandleSpan<resolved::name::DiagnosticName>,
    type_symbol: symbols::SymbolHandle,
    case_symbol: symbols::SymbolHandle,
) -> Option<typed::expression::ExpressionHandle> {
    lower_case_membership_expression_from_members(
        program,
        target,
        value,
        source.name_path_members(domain),
        type_symbol,
        case_symbol,
    )
}

fn lower_case_membership_expression_from_members(
    program: &resolved::SymbolResolvedTrees,
    target: &mut typed::TypedTrees,
    value: typed::expression::ExpressionHandle,
    domain_members: &[resolved::name::DiagnosticName],
    type_symbol: symbols::SymbolHandle,
    case_symbol: symbols::SymbolHandle,
) -> Option<typed::expression::ExpressionHandle> {
    case_membership_test(
        program,
        target,
        value,
        domain_members,
        type_symbol,
        case_symbol,
        typed::expression::BinaryOperator::Equal,
    )
}

/// A declared-domain fact replayed into an executable membership is a
/// generated tag observation, not an authored equality use: the fact's tokens
/// belong to the domain declaration, and the consumer's authored `in`
/// selection lands on whatever node this replay returns. Keeping the
/// `CaseMembership` operation explicit -- the same contract structural
/// equality synthesis uses for its generated tag guards -- lets validation
/// rejoin the exact subject and carrier without demanding an authored
/// membership roster, and without letting an attached domain-membership
/// occurrence reinterpret the node as value equality.
fn replayed_case_membership_test(
    program: &resolved::SymbolResolvedTrees,
    target: &mut typed::TypedTrees,
    value: typed::expression::ExpressionHandle,
    domain_members: &[resolved::name::DiagnosticName],
    type_symbol: symbols::SymbolHandle,
    case_symbol: symbols::SymbolHandle,
) -> Option<typed::expression::ExpressionHandle> {
    case_membership_test(
        program,
        target,
        value,
        domain_members,
        type_symbol,
        case_symbol,
        typed::expression::BinaryOperator::CaseMembership,
    )
}

fn case_membership_test(
    program: &resolved::SymbolResolvedTrees,
    target: &mut typed::TypedTrees,
    value: typed::expression::ExpressionHandle,
    domain_members: &[resolved::name::DiagnosticName],
    type_symbol: symbols::SymbolHandle,
    case_symbol: symbols::SymbolHandle,
    operator: typed::expression::BinaryOperator,
) -> Option<typed::expression::ExpressionHandle> {
    let [.., type_name, case_name] = domain_members else {
        return None;
    };
    if !type_symbol.is_valid() || !case_symbol.is_valid() {
        return None;
    }

    let data_definition = program.data_definition_by_symbol(type_symbol)?;
    let exact_case_belongs_to_type = program
        .data_members(data_definition.members)
        .iter()
        .any(|member| matches!(member, resolved::data::DataMember::Variant(variant) if variant.symbol == case_symbol));
    if !exact_case_belongs_to_type {
        return None;
    }

    // The case reference must carry its symbols: the backend's guard tag
    // clamp keys the tag-only compare off a symbol-stamped `Type::Case` path.
    let mut members = arena::HandleSpan::empty();
    // The authored selection ledger keeps the full source path. This generated
    // tag operand has exactly two semantic owners: the selected data and case.
    // Namespace/package spellings must not become extra runtime path segments.
    for member in [type_name, case_name] {
        target
            .expression_table
            .push_name_path_member(&mut members, lower_name(member));
    }
    let mut member_symbols = arena::HandleSpan::empty();
    target
        .expression_table
        .push_name_path_member_symbol(&mut member_symbols, type_symbol);
    target
        .expression_table
        .push_name_path_member_symbol(&mut member_symbols, case_symbol);
    let case_reference = target
        .expression_table
        .insert(typed::expression::ExpressionNode::Name(
            typed::expression::TableNamePath::new(
                members,
                member_symbols,
                type_symbol,
                case_symbol,
            ),
        ));

    Some(
        target
            .expression_table
            .insert(typed::expression::ExpressionNode::Binary(
                typed::expression::TableBinaryExpression {
                    left: value,
                    operator,
                    right: case_reference,
                },
            )),
    )
}

fn domain_definition<'p>(
    program: &'p resolved::SymbolResolvedTrees,
    domain_symbol: symbols::SymbolHandle,
) -> Result<&'p resolved::domain::DomainDefinition, Diagnostic> {
    program
        .domain_definition_by_symbol(domain_symbol)
        .ok_or_else(|| {
            Diagnostic::error(format!(
                "cannot lower executable membership for unknown domain symbol {}",
                domain_symbol.arena_index()
            ))
        })
}

/// Domain refinement consumes an admitted carrier. A data declaration's
/// compiler-owned logical subject still owes that very default domain. Preserve
/// its formation refusal before predicate expansion can erase an unused value.
fn is_pending_data_subject(
    program: &resolved::SymbolResolvedTrees,
    target: &typed::TypedTrees,
    mut value: typed::expression::ExpressionHandle,
) -> bool {
    let mut visited = Vec::new();
    while value.is_valid() && !visited.contains(&value) {
        visited.push(value);
        match target.expression_table.expression(value) {
            typed::expression::ExpressionNode::Name(path) => {
                return path.symbol.is_valid()
                    && program
                        .data_definition_by_symbol(program.symbols.get(path.symbol).parent)
                        .is_some_and(|definition| {
                            definition.predicate_subject_symbol == path.symbol
                                && !definition.where_facts.is_empty()
                        });
            }
            // This private lowering capture may still be under construction.
            // Its source is dependency/type custody, never permission to read
            // or execute it. Refusal must survive before expansion can erase it.
            typed::expression::ExpressionNode::SavedSubject(saved) => {
                if !target
                    .expression_table
                    .contains_value_capture(saved.capture)
                {
                    return true;
                }
                value = target.expression_table.value_capture(saved.capture).subject;
            }
            typed::expression::ExpressionNode::Borrow(borrow) => value = borrow.target,
            typed::expression::ExpressionNode::Cast(cast) => value = cast.value,
            _ => return false,
        }
    }
    value.is_valid()
}

pub(super) fn lower_domain_membership_expression(
    program: &resolved::SymbolResolvedTrees,
    target: &mut typed::TypedTrees,
    value: typed::expression::ExpressionHandle,
    domain_symbol: symbols::SymbolHandle,
) -> Result<typed::expression::ExpressionHandle, Diagnostic> {
    let domain_definition = domain_definition(program, domain_symbol)?;
    if is_pending_data_subject(program, target, value) {
        return Err(Diagnostic::error(
            "cannot form named-domain membership: the logical data subject's own default domain is still pending admission",
        ).with_source_span(target.expression_table.source_span(value)));
    }
    let expanded = crate::type_reference::domain_aliases::expand_domain_reference(
        program,
        domain_symbol,
        vec![domain_definition.name.clone()],
    )?;
    let mut lowered = Vec::with_capacity(expanded.len());
    for atom in expanded {
        lowered.push(lower_atomic_domain_membership_expression(
            program,
            target,
            value,
            atom.symbol,
        )?);
    }
    combine_conjunction(target, lowered)
}

fn lower_atomic_domain_membership_expression(
    program: &resolved::SymbolResolvedTrees,
    target: &mut typed::TypedTrees,
    value: typed::expression::ExpressionHandle,
    domain_symbol: symbols::SymbolHandle,
) -> Result<typed::expression::ExpressionHandle, Diagnostic> {
    let domain_definition = domain_definition(program, domain_symbol)?;
    let source = &program.tables.bodies.expressions;
    let mut lowered_facts = Vec::new();

    for fact in program.proof_facts(domain_definition.facts) {
        let lowered = match fact {
            resolved::domain::ProofFact::Expression(expression) => {
                // A normalized case-membership fact replays as a generated
                // tag test, not the authored `==` form: the authored roster
                // on the domain-site membership stays bound to the domain's
                // own lowered fact, while the consumer's `in` selection lands
                // on this replay root.
                match source.expression(*expression) {
                    resolved::expression::ExpressionNode::Membership(membership)
                        if membership.case_type_symbol.is_valid()
                            && membership.case_symbol.is_valid() =>
                    {
                        let nested_value =
                            lower_expression_handle_from_table_with_symbol_substitution(
                                Some(program),
                                source,
                                target,
                                membership.value,
                                Some((domain_definition.subject_symbol, value)),
                            )?;
                        let generated = replayed_case_membership_test(
                            program,
                            target,
                            nested_value,
                            source.name_path_members(membership.domain),
                            membership.case_type_symbol,
                            membership.case_symbol,
                        )
                        .ok_or_else(|| {
                            Diagnostic::error(
                                "replayed domain case membership lost its selected owner or case",
                            )
                        })?;
                        target
                            .expression_table
                            .set_source_span(generated, source.source_span(*expression));
                        target
                            .expression_table
                            .attach_authored_selection_occurrences(
                                generated,
                                source
                                    .authored_selection_occurrences(*expression)
                                    .collect::<Vec<_>>(),
                            );
                        generated
                    }
                    _ => lower_expression_handle_from_table_with_symbol_substitution(
                        Some(program),
                        source,
                        target,
                        *expression,
                        Some((domain_definition.subject_symbol, value)),
                    )?,
                }
            }
            resolved::domain::ProofFact::Membership(membership) => {
                let nested_value = lower_expression_handle_from_table_with_symbol_substitution(
                    Some(program),
                    source,
                    target,
                    membership.value,
                    Some((domain_definition.subject_symbol, value)),
                )?;
                let (case_type_symbol, case_symbol) =
                    case_symbols_for_domain_fact(program, membership.domain);
                if let Some(case_membership) = replayed_case_membership_test(
                    program,
                    target,
                    nested_value,
                    program.domain_path_members(membership.domain),
                    case_type_symbol,
                    case_symbol,
                ) {
                    case_membership
                } else {
                    lower_domain_membership_expression(
                        program,
                        target,
                        nested_value,
                        membership.domain_symbol,
                    )?
                }
            }
        };
        lowered_facts.push(lowered);
    }

    let predicate = combine_conjunction(target, lowered_facts)?;
    target.expression_table.retain_executable_domain_test(
        predicate,
        typed::expression::ExecutableDomainTest {
            subject: value,
            domain: domain_symbol,
        },
    );
    Ok(predicate)
}

fn case_symbols_for_domain_fact(
    program: &resolved::SymbolResolvedTrees,
    domain: arena::HandleSpan<resolved::name::DiagnosticName>,
) -> (symbols::SymbolHandle, symbols::SymbolHandle) {
    let [type_name, case_name] = program.domain_path_members(domain) else {
        return (
            symbols::SymbolHandle::invalid(),
            symbols::SymbolHandle::invalid(),
        );
    };
    let Some(data_index) =
        crate::expressions::exhaustiveness::data_definition_index(program, type_name)
    else {
        return (
            symbols::SymbolHandle::invalid(),
            symbols::SymbolHandle::invalid(),
        );
    };
    let data = &program.data_definitions[data_index];
    let case_symbol = program
        .data_members(data.members)
        .iter()
        .find_map(|member| match member {
            resolved::data::DataMember::Variant(variant)
                if variant.name.as_str() == case_name.as_str() =>
            {
                Some(variant.symbol)
            }
            _ => None,
        })
        .unwrap_or_else(symbols::SymbolHandle::invalid);
    (data.symbol, case_symbol)
}

fn combine_conjunction(
    target: &mut typed::TypedTrees,
    lowered_facts: Vec<typed::expression::ExpressionHandle>,
) -> Result<typed::expression::ExpressionHandle, Diagnostic> {
    let mut lowered_facts = lowered_facts.into_iter();
    let Some(mut combined) = lowered_facts.next() else {
        return Ok(target
            .expression_table
            .insert(typed::expression::ExpressionNode::Boolean(true)));
    };

    for fact in lowered_facts {
        combined = target
            .expression_table
            .insert(typed::expression::ExpressionNode::Binary(
                typed::expression::TableBinaryExpression {
                    left: combined,
                    operator: typed::expression::BinaryOperator::And,
                    right: fact,
                },
            ));
    }

    Ok(combined)
}
