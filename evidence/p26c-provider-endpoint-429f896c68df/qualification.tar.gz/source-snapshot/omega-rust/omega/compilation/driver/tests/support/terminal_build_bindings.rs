//! The complete source Build entry, with real host binding effects and helper
//! writeback. Product bodies stay inert; fuel pauses resume the same activation.
#[path = "terminal_provision.rs"]
mod terminal_provision;

use build_evaluation::terminal_bindings::TerminalBuildBindingHost;
use build_evaluation::terminal_requests::TerminalBuildRequestHost;
use terminal_fuel::TerminalFuelMeter;
use terminal_interpreter::{
    TerminalEffectHandler, TerminalEntryStorageError, TerminalEntryStorageValue,
    TerminalExecutionResult, TerminalExecutionStatus, TerminalProgram, TerminalStructuralInputs,
    TerminalStructuralValue,
};

pub(super) fn observe(
    artifact: &terminal_codec::CanonicalTerminalArtifact,
    bindings: &psi_compiler::TerminalBuildBindings,
    requests: &psi_compiler::TerminalBuildRequests,
    slots: &str,
    entry: &str,
    identifier: &str,
) -> Result<(), String> {
    terminal_provision::result(
        || {
            exercise(
                artifact,
                bindings,
                requests,
                &slots.split(',').collect::<Vec<_>>(),
                entry,
                if identifier == "-" { "" } else { identifier },
            )
        },
        "full Build binding provision failed",
    )
}

fn exercise(
    artifact: &terminal_codec::CanonicalTerminalArtifact,
    bindings: &psi_compiler::TerminalBuildBindings,
    requests: &psi_compiler::TerminalBuildRequests,
    slots: &[&str],
    entry: &str,
    expected_identifier: &str,
) {
    let identifier = [super::mutable_boundary::field(artifact, "identifier")];
    let loaded = TerminalProgram::load_envelope(&artifact.to_bytes()).expect("external artifact");
    for program in [TerminalProgram::borrow(artifact.view()), loaded] {
        let original = TerminalStructuralValue::minted(
            951,
            program.entry().unwrap().structural_parameters[0].structural_type,
            Vec::new(),
        );
        for foreign in [false, true] {
            let host =
                TerminalBuildBindingHost::new(artifact.view().into(), bindings, original.clone())
                    .unwrap();
            let project = TerminalBuildRequestHost::new(
                artifact.view().into(),
                requests,
                original.clone(),
                None,
            )
            .unwrap();
            let request_calls = requests.calls_for(artifact.view().into()).unwrap();
            let binding_calls = bindings.calls_for(artifact.view().into()).unwrap();
            let mut receiver = original.clone();
            if foreign {
                receiver.opaque_identity += 1;
            }
            let mut instance = program
                .instantiate(terminal_interpreter::TerminalInstantiation {
                    scalar_arguments: &[],
                    structural_inputs: TerminalStructuralInputs {
                        arguments: std::slice::from_ref(&receiver),
                        zero_initialized_arguments: &[0],
                        ..Default::default()
                    },
                    ..Default::default()
                })
                .unwrap();
            let imports = instance.unbound_imports().collect::<Vec<_>>();
            let mut expected_imports = binding_calls
                .iter()
                .map(|call| call.boundary)
                .chain(request_calls.iter().map(|call| call.boundary))
                .collect::<Vec<_>>();
            expected_imports.sort();
            expected_imports.dedup();
            let mut actual_imports = imports.clone();
            actual_imports.sort();
            assert_eq!(
                actual_imports, expected_imports,
                "only source-issued project requests and binding effects, not product execution"
            );
            for boundary in &imports {
                let declaration = artifact
                    .semantic_module()
                    .boundary_machines
                    .iter()
                    .find(|item| item.id == *boundary)
                    .unwrap();
                if request_calls.iter().any(|call| call.boundary == *boundary) {
                    instance
                        .bind_import(*boundary, project.adapter(declaration.into()))
                        .unwrap();
                } else {
                    instance
                        .bind_import(*boundary, host.adapter(declaration.into()))
                        .unwrap();
                }
            }
            if foreign {
                let error = instance
                    .invoke(&mut TerminalFuelMeter::unbounded())
                    .unwrap_err();
                assert!(format!("{error:?}").contains("original compiler-issued Build"));
                assert_eq!(
                    instance.observe_borrowed_entry(0, &identifier),
                    Err(TerminalEntryStorageError::NormalReturnRequired)
                );
                drop(instance);
                assert!(host.into_executed().unwrap().is_empty());
                assert!(project.drain_requests().unwrap().is_empty());
                continue;
            }
            let mut fuel = TerminalFuelMeter::with_allowance(0);
            let mut paused_after_effect = false;
            for _ in 0..1_000 {
                match instance.invoke(&mut fuel).unwrap() {
                    TerminalExecutionStatus::SponsorExhausted(_) => {
                        paused_after_effect |= !instance.effects().is_empty();
                        fuel.replenish(1).unwrap();
                    }
                    TerminalExecutionStatus::Complete(TerminalExecutionResult::Unit) => break,
                    status => panic!("unexpected full Build result: {status:?}"),
                }
            }
            assert!(instance.result().is_some());
            assert!(paused_after_effect);
            let TerminalEntryStorageValue::Bytes(bytes) =
                instance.observe_borrowed_entry(0, &identifier).unwrap()
            else {
                panic!("identifier byte readback");
            };
            let mut identifier_bytes = vec![0; bytes.len()];
            bytes.copy_to(&mut identifier_bytes).unwrap();
            assert_eq!(identifier_bytes, expected_identifier.as_bytes());
            let project_requests = project.drain_requests().unwrap();
            let executed_project_calls = instance.effects().iter().filter(|effect| {
                matches!(effect, terminal_interpreter::TerminalEffect::BoundaryCall { operation, boundary, .. }
                    if request_calls.iter().any(|call| call.operation == *operation && call.boundary == *boundary))
            }).count();
            assert_eq!(
                project_requests.len(),
                executed_project_calls,
                "each executed project operation issues one request"
            );
            assert_eq!(
                instance.effects().len(),
                slots.len() * 2 + project_requests.len(),
                "one preparation and commit per binding plus the executed project requests"
            );
            let commit = instance.effects().iter().find(|effect| matches!(effect, terminal_interpreter::TerminalEffect::BoundaryCall { structural_arguments, .. } if structural_arguments.is_empty())).unwrap().clone();
            drop(instance);
            let terminal_interpreter::TerminalEffect::BoundaryCall { boundary, .. } = &commit
            else {
                panic!("boundary")
            };
            let declaration = artifact
                .semantic_module()
                .boundary_machines
                .iter()
                .find(|item| item.id == *boundary)
                .unwrap();
            let rejection = host
                .adapter(declaration.into())
                .handle_effect_result(&commit)
                .unwrap_err();
            assert!(
                rejection.reason.contains("consumed"),
                "a replayed ticket must refuse"
            );
            let mut fabricated = commit;
            let terminal_interpreter::TerminalEffect::BoundaryCall { operation, .. } =
                &mut fabricated
            else {
                panic!("boundary")
            };
            *operation = semantic_vocabulary::OperationId::new(u64::MAX).unwrap();
            let rejection = host
                .adapter(declaration.into())
                .handle_effect_result(&fabricated)
                .unwrap_err();
            assert!(rejection.reason.contains("no source-issued"));
            let executed = host.into_executed().unwrap();
            let requests = executed
                .iter()
                .map(|selection| {
                    let language_semantics::declaration_selection::ExecutedBuildSelection::Entry(
                        binding,
                    ) = selection
                    else {
                        panic!(
                            "root-binding fixture emitted an unexpected Product declaration choice"
                        );
                    };
                    binding
                })
                .collect::<Vec<_>>();
            assert_eq!(
                requests
                    .iter()
                    .map(|request| request.slot.as_str())
                    .collect::<Vec<_>>(),
                slots
            );
            assert!(requests.iter().all(|request| matches!(&request.implementation, language_semantics::declaration_selection::RootBindingSelection::AuthoredPath(path) if path == entry)));
            eprintln!(
                "Terminal full Build: {} bindings once, identifier={expected_identifier}, original-receiver and ticket controls enforced",
                slots.len()
            );
        }
    }
}
