use crate::interpreter::evaluator::{
    BTreeMap, BuildEvaluationSponsor, CALL_DEPTH_BUDGET, Cell, CellMeter, CheckedTrees,
    DataDefinition, DataMember, EvalResult, EvaluatedArgument, EvaluationUsage, Evaluator,
    FilesystemLogicalHandles, FilesystemMetadataLayout, Frame, FrameLocal, Halt, Machine,
    PrimitiveType, State, StatementNode, SymbolHandle, TextByteMeter, TransitionDecision,
    TypeReferenceNode, TypedTrees, Value, ambient_step_budget, trap, unsupported, wrap_to_width,
};
impl<'program> Evaluator<'program> {
    pub(in crate::interpreter) fn new_build(
        program: crate::interpreter::BuildMachineProgram<'program>,
    ) -> Self {
        match program {
            crate::interpreter::BuildMachineProgram::Typed(typed) => Self::new(typed, &[]),
            crate::interpreter::BuildMachineProgram::Checked(checked) => {
                let mut evaluator = Self::new(&checked.typed, &[]);
                evaluator.checked = Some(checked);
                evaluator.operator_facts = Some(&checked.facts.operators);
                // Runtime dispatch can carry relationships admitted for the
                // product, not this activation. Host authority still enters
                // only through the Build owner's explicit execution grants.
                evaluator
            }
            crate::interpreter::BuildMachineProgram::CheckedClosure {
                execution,
                product_declarations,
            } => {
                let mut evaluator =
                    Self::new_build(crate::interpreter::BuildMachineProgram::Checked(execution));
                evaluator.product_declarations = product_declarations;
                evaluator
            }
        }
    }

    pub(in crate::interpreter) fn new(
        program: &'program TypedTrees,
        stdin: &'program [u8],
    ) -> Self {
        let step_budget = ambient_step_budget();
        Self {
            program,
            product_declarations: program,
            checked: None,
            operator_facts: None,
            boundary_adapter_dispatch: &[],
            selected_product_float_comparisons: None,
            selected_build_time_operators: &[],
            selected_build_time_machine_bodies: &[],
            x86_flags: None,
            semantic_float_evaluation: false,
            stdout: Vec::new(),
            stderr: Vec::new(),
            build_log: Vec::new(),
            root_build: None,
            executed_source_selections: Vec::new(),
            pending_build_selections: Vec::new(),
            executed_behavior_exclusions: Vec::new(),
            executed_build_selections: Vec::new(),
            executed_wire_demands: Vec::new(),
            product_entry_descriptions: Vec::new(),
            product_entry_compatibility: None,
            product_schema_descriptions: Vec::new(),
            product_provider_descriptions: Vec::new(),
            stdin,
            stdin_cursor: 0,
            virtual_ticks: 0,
            virtual_clock_bindings: Vec::new(),
            virtual_live_windows: std::collections::HashSet::new(),
            virtual_window_next: 0,
            virtual_files: BTreeMap::new(),
            virtual_fds: BTreeMap::new(),
            virtual_next_fd: 3,
            virtual_dirs: std::collections::BTreeSet::new(),
            filesystem_metadata_layout: FilesystemMetadataLayout::default(),
            virtual_finds: BTreeMap::new(),
            virtual_next_find: 1,
            virtual_perms: BTreeMap::new(),
            virtual_symlinks: BTreeMap::new(),
            virtual_times: BTreeMap::new(),
            virtual_flocks: BTreeMap::new(),
            virtual_char_devices: [b"/dev/null".to_vec(), b"/dev/zero".to_vec()]
                .into_iter()
                .collect(),
            virtual_errno: 0,
            real_fs: None,
            rooted_build_paths_required: false,
            build_included_sources: Vec::new(),
            output_obligations: Vec::new(),
            output_receipts: Vec::new(),
            output_obligation_paths: BTreeMap::new(),
            output_seal_states: BTreeMap::new(),
            output_open_writers: BTreeMap::new(),
            host_boundary_touched: false,
            non_fs_host_boundary_touched: false,
            filesystem_operation_attempts: Vec::new(),
            filesystem_logical_handles: FilesystemLogicalHandles::default(),
            filesystem_live_handle_leases: BTreeMap::new(),
            filesystem_observation_path_bytes: 0,
            filesystem_observation_evidence_bytes: 0,
            filesystem_observation_resource_halt: None,
            filesystem_operation_attempt_stack: Vec::new(),
            private_layout_placements: Vec::new(),
            usage: EvaluationUsage::empty(step_budget),
            cell_meter: CellMeter::new(None),
            text_byte_meter: TextByteMeter::new(None),
            build_evaluation_sponsor: None,
            // OMEGA_INTERP_STEP_BUDGET overrides the default for
            // measurement / long-running sample runs (dev knob, same
            // convention as the OMEGA_DEBUG_* flags); unset = the default.
            step_budget,
            call_depth: 0,
            guard_depth: 0,
        }
    }

    pub(in crate::interpreter) fn new_checked(
        checked: &'program CheckedTrees,
        stdin: &'program [u8],
    ) -> Self {
        let mut evaluator = Self::new(&checked.typed, stdin);
        evaluator.checked = Some(checked);
        evaluator.operator_facts = Some(&checked.facts.operators);
        evaluator
    }

    pub(in crate::interpreter::evaluator) fn tick(&mut self) -> EvalResult<()> {
        self.usage
            .charge_step()
            .ok_or_else(|| Halt::Trap("evaluator usage overflowed".to_owned()))?;
        if self.usage.fuel_units() > self.step_budget {
            return trap("step budget exceeded");
        }
        if let Some(sponsor) = &self.build_evaluation_sponsor {
            sponsor.charge_fuel_unit().map_err(Halt::Resource)?;
        }
        Ok(())
    }

    pub(in crate::interpreter) fn configure_build_evaluation(
        &mut self,
        fuel_ceiling: u64,
        sponsor: Option<BuildEvaluationSponsor>,
    ) {
        debug_assert_eq!(self.cell_meter.peak(), 0);
        debug_assert_eq!(self.text_byte_meter.peak(), 0);
        self.step_budget = fuel_ceiling;
        self.semantic_float_evaluation = true;
        self.usage.set_fuel_ceiling(fuel_ceiling);
        self.cell_meter = CellMeter::new(sponsor.clone());
        self.text_byte_meter = TextByteMeter::new(sponsor.clone());
        self.build_evaluation_sponsor = sponsor;
    }

    pub(in crate::interpreter::evaluator) fn allocate_cell(
        &self,
        value: Value,
    ) -> EvalResult<Cell> {
        self.cell_meter.allocate(value).map_err(Halt::Resource)
    }

    pub(in crate::interpreter::evaluator) fn allocate_text(
        &self,
        bytes: Vec<u8>,
    ) -> EvalResult<Value> {
        self.text_byte_meter.allocate(bytes).map_err(Halt::Resource)
    }

    pub(in crate::interpreter) fn finish_cell_usage(&mut self) {
        self.usage.record_peak_live_cells(self.cell_meter.peak());
        self.usage
            .record_peak_live_text_bytes(self.text_byte_meter.peak());
    }

    pub(in crate::interpreter::evaluator) fn charge_build_log_bytes(
        &mut self,
        bytes: usize,
    ) -> EvalResult<()> {
        let bytes = u64::try_from(bytes)
            .map_err(|_| Halt::Resource("BuildLog byte count overflowed".to_owned()))?;
        if let Some(sponsor) = &self.build_evaluation_sponsor {
            sponsor
                .charge_build_log_bytes(bytes)
                .map_err(Halt::Resource)?;
        }
        self.usage
            .charge_build_log_bytes(bytes)
            .ok_or_else(|| Halt::Resource("BuildLog byte accounting overflowed".to_owned()))
    }

    pub(in crate::interpreter::evaluator) fn charge_filesystem_operation_attempt(
        &mut self,
    ) -> EvalResult<()> {
        if let Some(sponsor) = &self.build_evaluation_sponsor {
            sponsor
                .charge_filesystem_operation_attempt()
                .map_err(Halt::Resource)?;
        }
        self.usage
            .charge_filesystem_operation_attempt()
            .ok_or_else(|| {
                Halt::Resource("filesystem operation-attempt accounting overflowed".to_owned())
            })
    }

    // ---- entry --------------------------------------------------------------

    pub(in crate::interpreter) fn run_entry(&mut self, entry_machine_name: &str) -> EvalResult<()> {
        let entry_machine = self
            .find_machine_by_name(entry_machine_name)
            .ok_or_else(|| Halt::Unsupported(format!("no entry machine `{entry_machine_name}`")))?;
        self.run_resolved_entry(entry_machine)
    }

    /// Entry dispatch on the selected machine's exact symbol. Root-slot
    /// bindings already carried identity as a symbol; dispatching on the
    /// spelling could reach a same-named machine from another module.
    pub(in crate::interpreter) fn run_entry_symbol(
        &mut self,
        entry_machine_symbol: SymbolHandle,
    ) -> EvalResult<()> {
        let entry_machine = self
            .find_machine_by_symbol(entry_machine_symbol)
            .ok_or_else(|| {
                Halt::Unsupported(
                    "the selected program entry is not a machine in the checked program".to_owned(),
                )
            })?;
        self.run_resolved_entry(entry_machine)
    }

    fn run_resolved_entry(&mut self, entry_machine: &'program Machine) -> EvalResult<()> {
        let entry_machine_name = entry_machine.name.as_str();
        let entry_state = self.machine_entry_state(entry_machine).ok_or_else(|| {
            Halt::Unsupported(format!(
                "entry machine `{entry_machine_name}` has no executable state"
            ))
        })?;

        let arguments = self.entry_arrival_arguments(entry_machine, entry_state)?;
        // The entry machine's value (its terminal `Value` transition / final expression)
        // becomes the process exit code when it has no explicit `exit_process`. Mirrors the
        // backend: `machine Main::main(...) -> i32` returns the exit status.
        let returned = self.run_state_collect(entry_machine, entry_state, arguments)?;
        if let Some(value) = returned
            && let Some(code) = value.as_int()
        {
            return Err(Halt::Exit(code as i32));
        }
        Ok(())
    }

    /// This evaluator has no installed argument source. A parameter requires
    /// an ordinary explicit caller; its type cannot manufacture backing.
    fn entry_arrival_arguments(
        &mut self,
        entry_machine: &Machine,
        entry_state: &'program State,
    ) -> EvalResult<Vec<EvaluatedArgument>> {
        if let Some(parameter) = self.program.state_parameters(entry_state).first() {
            return unsupported(format!(
                "entry machine `{}` parameter `{}` has no installed arrival value",
                entry_machine.name.as_str(),
                parameter.name.as_str()
            ));
        }
        Ok(Vec::new())
    }

    /// CONST EVALUATION: run `machine_name` (zero arguments, fresh default
    /// instance) to its terminal value. The machine's declared integer return
    /// type fixes the result's width semantics via `wrap_to_width` (target
    /// widths, never host widths). Non-integer terminal values are errors.
    pub(in crate::interpreter) fn run_const_machine(
        &mut self,
        machine_name: &str,
    ) -> EvalResult<i64> {
        let machine = self
            .find_machine_by_name(machine_name)
            .ok_or_else(|| Halt::Trap(format!("no machine named `{machine_name}` exists")))?;
        let entry_state = self.machine_entry_state(machine).ok_or_else(|| {
            Halt::Trap(format!(
                "machine `{machine_name}` has no states to evaluate"
            ))
        })?;
        // The declared INTEGER return type fixes the result's width semantics
        // (checked before running so the diagnostic names the type, not
        // whatever value the body happened to produce).
        let return_primitive = match self
            .program
            .primitive_type_reference(entry_state.return_type)
        {
            Some(primitive)
                if primitive != PrimitiveType::Bool
                    && primitive != PrimitiveType::F32
                    && primitive != PrimitiveType::F64 =>
            {
                primitive
            }
            Some(primitive) => {
                return Err(Halt::Trap(format!(
                    "machine `{machine_name}` returns `{}`, not an integer type",
                    primitive.name()
                )));
            }
            None => {
                return Err(Halt::Trap(format!(
                    "machine `{machine_name}` does not declare an integer return type"
                )));
            }
        };

        let returned = self.run_state_collect(machine, entry_state, Vec::new())?;
        let value = returned.ok_or_else(|| {
            Halt::Trap(format!(
                "machine `{machine_name}` terminated without producing a value"
            ))
        })?;
        let raw = value.as_int().ok_or_else(|| {
            Halt::Trap(format!(
                "machine `{machine_name}` produced a non-integer value"
            ))
        })?;

        Ok(wrap_to_width(raw, return_primitive))
    }

    /// STRUCTURED build-time evaluation: bind compiler-built arguments to the
    /// machine's entry-state parameters positionally, run to the terminal
    /// value, and deep-read it back out. Argument-count mismatch is a clear
    /// error here (the position's diagnostic names the machine); the caller
    /// owns the purity gate.
    pub(in crate::interpreter) fn run_build_time_machine(
        &mut self,
        machine_name: &str,
        arguments: Vec<build_time_values::BuildTimeValue>,
    ) -> EvalResult<build_time_values::BuildTimeValue> {
        let machine = self
            .find_machine_by_name(machine_name)
            .ok_or_else(|| Halt::Trap(format!("no machine named `{machine_name}` exists")))?;
        self.run_resolved_build_time_machine(machine, arguments)
    }

    /// Exact-symbol form of [`Self::run_build_time_machine`]. The selected
    /// declaration must exist under this identity; spelling is never consulted
    /// as a fallback.
    pub(in crate::interpreter) fn run_build_time_machine_symbol(
        &mut self,
        machine_symbol: SymbolHandle,
        arguments: Vec<build_time_values::BuildTimeValue>,
    ) -> EvalResult<build_time_values::BuildTimeValue> {
        let machine = self.find_machine_by_symbol(machine_symbol).ok_or_else(|| {
            Halt::Trap(format!(
                "no machine with exact symbol {machine_symbol:?} exists in the evaluated program"
            ))
        })?;
        self.run_resolved_build_time_machine(machine, arguments)
    }

    fn build_time_entry_state(
        &mut self,
        machine: &'program Machine,
        argument_count: usize,
    ) -> EvalResult<&'program State> {
        let machine_name = machine.name.as_str();
        let entry_state = self.machine_entry_state(machine).ok_or_else(|| {
            Halt::Trap(format!(
                "machine `{machine_name}` has no states to evaluate"
            ))
        })?;
        let parameter_count = self.program.state_parameters(entry_state).len();
        if parameter_count != argument_count {
            return Err(Halt::Trap(format!(
                "machine `{machine_name}` takes {parameter_count} argument(s); the build-time                  position supplied {}",
                argument_count
            )));
        }
        Ok(entry_state)
    }

    fn run_resolved_build_time_machine(
        &mut self,
        machine: &'program Machine,
        arguments: Vec<build_time_values::BuildTimeValue>,
    ) -> EvalResult<build_time_values::BuildTimeValue> {
        let machine_name = machine.name.as_str();
        let entry_state = self.build_time_entry_state(machine, arguments.len())?;

        let argument_cells = arguments
            .into_iter()
            .map(|argument| {
                let value = crate::build_time::materialize_build_time_value(
                    argument,
                    &|value| self.allocate_cell(value),
                    &|bytes| self.allocate_text(bytes),
                )?;
                Ok(EvaluatedArgument::plain(self.allocate_cell(value)?))
            })
            .collect::<EvalResult<Vec<_>>>()?;
        let returned = self.run_state_collect(machine, entry_state, argument_cells)?;
        let value = returned.ok_or_else(|| {
            Halt::Trap(format!(
                "machine `{machine_name}` terminated without producing a value"
            ))
        })?;
        // The dynamic purity backstop: the static effect surface does not yet
        // fold host-authority audit facts (boundary-trait calls), so any run
        // that actually touched the host is rejected here.
        if self.host_boundary_touched {
            return Err(Halt::Trap(format!(
                "machine `{machine_name}` is not effect-free: it drove a host-boundary call \
                 during build-time evaluation"
            )));
        }
        crate::build_time::observe_build_time_value(&value, &|reference| {
            self.read_reference(reference)
        })
    }

    /// The augmenting-machine variant: run and read back the FINAL argument
    /// values (a `&mut` parameter aliases its argument cell, so mutations land
    /// there). A unit terminal is accepted -- the machine's OUTPUT is its
    /// arguments.
    pub(in crate::interpreter) fn run_build_time_machine_arguments(
        &mut self,
        machine_name: &str,
        arguments: Vec<build_time_values::BuildTimeValue>,
    ) -> EvalResult<Vec<build_time_values::BuildTimeValue>> {
        self.run_build_machine_arguments_with_policy(machine_name, arguments, false)
    }

    /// Exact-symbol form of [`Self::run_build_time_machine_arguments`]. The
    /// selected declaration must exist in this program; spelling is never
    /// consulted as a fallback.
    pub(in crate::interpreter) fn run_build_time_machine_symbol_arguments(
        &mut self,
        machine_symbol: SymbolHandle,
        arguments: Vec<build_time_values::BuildTimeValue>,
    ) -> EvalResult<Vec<build_time_values::BuildTimeValue>> {
        self.run_build_machine_symbol_arguments_with_policy(machine_symbol, arguments, false)
    }

    /// The shared augmenting-machine runner. `allow_filesystem` selects the
    /// dynamic backstop: `false` = the PURE build-time entry (any host touch
    /// rejects -- decision 12's discipline); `true` = the GRANTED build entry
    /// (filesystem ops are the point; every OTHER host boundary rejects).
    pub(in crate::interpreter) fn run_build_machine_arguments_with_policy(
        &mut self,
        machine_name: &str,
        arguments: Vec<build_time_values::BuildTimeValue>,
        allow_filesystem: bool,
    ) -> EvalResult<Vec<build_time_values::BuildTimeValue>> {
        self.enable_rooted_build_paths_from_arguments(&arguments);
        let machine = self
            .find_machine_by_name(machine_name)
            .ok_or_else(|| Halt::Trap(format!("no machine named `{machine_name}` exists")))?;
        self.run_resolved_build_machine_arguments(machine, arguments, allow_filesystem)
    }

    /// Exact-symbol form of [`Self::run_build_machine_arguments_with_policy`].
    /// This is the execution seam used by admitted prepared build entries.
    pub(in crate::interpreter) fn run_build_machine_symbol_arguments_with_policy(
        &mut self,
        machine_symbol: SymbolHandle,
        arguments: Vec<build_time_values::BuildTimeValue>,
        allow_filesystem: bool,
    ) -> EvalResult<Vec<build_time_values::BuildTimeValue>> {
        self.enable_rooted_build_paths_from_arguments(&arguments);
        let machine = self.find_machine_by_symbol(machine_symbol).ok_or_else(|| {
            Halt::Trap(format!(
                "no machine with exact symbol {machine_symbol:?} exists in the evaluated program"
            ))
        })?;
        self.run_resolved_build_machine_arguments(machine, arguments, allow_filesystem)
    }

    fn run_resolved_build_machine_arguments(
        &mut self,
        machine: &'program Machine,
        arguments: Vec<build_time_values::BuildTimeValue>,
        allow_filesystem: bool,
    ) -> EvalResult<Vec<build_time_values::BuildTimeValue>> {
        let machine_name = machine.name.as_str();
        let entry_state = self.build_time_entry_state(machine, arguments.len())?;

        let argument_cells: Vec<Cell> = arguments
            .into_iter()
            .map(|argument| {
                let value = crate::build_time::materialize_build_time_value(
                    argument,
                    &|value| self.allocate_cell(value),
                    &|bytes| self.allocate_text(bytes),
                )?;
                self.allocate_cell(value)
            })
            .collect::<EvalResult<_>>()?;
        // Keep the cells: a `&mut` parameter aliases its cell, so the run's
        // mutations are visible here afterward.
        let kept: Vec<Cell> = argument_cells.clone();
        self.retain_root_build(entry_state, &argument_cells)?;
        let evaluated_arguments = argument_cells
            .into_iter()
            .zip(self.program.state_parameters(entry_state).iter())
            .map(|(cell, parameter)| {
                // Snapshot arguments supply referent values. Reference parameters
                // need the same wrapper used by ordinary calls, or forwarding a
                // bare parameter copies the record at the first helper call.
                let cell = if matches!(
                    self.program
                        .type_reference_table
                        .type_reference(parameter.type_reference),
                    TypeReferenceNode::Reference { .. }
                ) {
                    self.allocate_cell(Value::reference(cell))?
                } else {
                    cell
                };
                Ok(EvaluatedArgument::plain(cell))
            })
            .collect::<EvalResult<_>>()?;
        let _terminal = self.run_state_collect(machine, entry_state, evaluated_arguments)?;
        let impure = if allow_filesystem {
            self.non_fs_host_boundary_touched
        } else {
            self.host_boundary_touched
        };
        if impure {
            return Err(Halt::Trap(if allow_filesystem {
                format!(
                    "machine `{machine_name}` drove a NON-filesystem host-boundary call during \
                     granted build evaluation -- only the Filesystem capability is granted"
                )
            } else {
                format!(
                    "machine `{machine_name}` is not effect-free: it drove a host-boundary call during build-time evaluation"
                )
            }));
        }
        kept.iter()
            .map(|cell| {
                crate::build_time::observe_build_time_value(&cell.borrow(), &|reference| {
                    self.read_reference(reference)
                })
            })
            .collect()
    }

    // ---- explicit data construction ----------------------------------------

    /// Insert a `data` definition's fields (with defaults) into `fields`. Nested `data`
    /// members recurse so their own defaults are populated.
    pub(in crate::interpreter::evaluator) fn populate_data_fields(
        &mut self,
        data: &DataDefinition,
        fields: &mut BTreeMap<crate::value::ValueName, Cell>,
    ) -> EvalResult<()> {
        self.populate_data_fields_with_bindings(data, fields, &[])
    }

    fn populate_data_fields_with_bindings(
        &mut self,
        data: &DataDefinition,
        fields: &mut BTreeMap<crate::value::ValueName, Cell>,
        bindings: &[(
            SymbolHandle,
            String,
            typed_trees::types::TypeReferenceHandle,
        )],
    ) -> EvalResult<()> {
        let program = self.program;
        for member in program.data_members(data) {
            let Some(field) = member.as_field() else {
                continue;
            };
            let name = field.name.as_str().to_owned();
            // Field defaults are retired: every field ZII zero-initializes.
            let value =
                self.default_value_for_type_with_bindings(field.type_reference, bindings)?;
            fields.insert(name.into(), self.allocate_cell(value)?);
        }
        Ok(())
    }

    /// Build a default-initialized value for a declared type, recursing into nested `data`
    /// records (a sub-Struct with its own defaults) and fixed arrays (an `Array` of
    /// per-element default cells). Falls back to the primitive/unit default.
    pub(in crate::interpreter) fn default_value_for_type(
        &mut self,
        type_reference: typed_trees::types::TypeReferenceHandle,
    ) -> EvalResult<Value> {
        self.default_value_for_type_with_bindings(type_reference, &[])
    }

    fn default_value_for_type_with_bindings(
        &mut self,
        type_reference: typed_trees::types::TypeReferenceHandle,
        bindings: &[(
            SymbolHandle,
            String,
            typed_trees::types::TypeReferenceHandle,
        )],
    ) -> EvalResult<Value> {
        if type_reference.is_valid() {
            if let typed_trees::types::TypeReferenceNode::Named { symbol, name } = self
                .program
                .type_reference_table
                .type_reference(type_reference)
                && let Some(argument) =
                    self.generic_binding_argument(*symbol, name.as_str(), bindings)
            {
                return self.default_value_for_type_with_bindings(argument, bindings);
            }

            // See THROUGH a domain constraint (`[i32; N] in Wrapping`, `i32 in Saturating`):
            // the default of a constrained type is the default of its base type (zero in every
            // arithmetic domain). Without this, a domain-constrained ARRAY field falls past the
            // FixedArray case below and defaults to `Unit`, so a later `self.arr[i]` raised
            // "cannot index Unit" and the whole canary was SKIPPED by the differential oracle.
            if let typed_trees::types::TypeReferenceNode::Constrained { base_type, .. } = self
                .program
                .type_reference_table
                .type_reference(type_reference)
            {
                let base_type = *base_type;
                return self.default_value_for_type_with_bindings(base_type, bindings);
            }

            // Fixed array `[T; N]` -> N default-initialized element cells.
            if let typed_trees::types::TypeReferenceNode::FixedArray {
                element_type,
                length,
            } = self
                .program
                .type_reference_table
                .type_reference(type_reference)
            {
                let element_type = *element_type;
                let count = match length {
                    typed_trees::types::FixedArrayLength::Literal(count) => Some(*count),
                    typed_trees::types::FixedArrayLength::ConstParameter { symbol, name } => self
                        .generic_binding_argument(*symbol, name.as_str(), bindings)
                        .and_then(|argument| {
                            self.const_argument_value_with_bindings(argument, bindings, 0)
                        }),
                    typed_trees::types::FixedArrayLength::Expression(_) => {
                        return unsupported(
                            "array extent expression has not completed checked constant evaluation",
                        );
                    }
                    typed_trees::types::FixedArrayLength::ConstCall { name, .. } => {
                        match self.program.closed_fixed_array_length(type_reference) {
                            Some(count) => Some(count),
                            None => {
                                return unsupported(format!(
                                    "array length `{}` has an unresolved build-time evaluation dependency",
                                    name.as_str()
                                ));
                            }
                        }
                    }
                };
                if let Some(count) = count {
                    let mut elements: Vec<Cell> = Vec::with_capacity(count);
                    // Every element shares one element type, so each default
                    // is the same value: derive the first and give every later
                    // element a deep copy with its own metered cells. Defaults
                    // holding metered text still derive per element.
                    let mut copies_by_cells = false;
                    for _ in 0..count {
                        let value = match elements.first() {
                            Some(first) if copies_by_cells => first
                                .borrow()
                                .deep_clone_with(&|value| self.allocate_cell(value))?,
                            _ => {
                                self.default_value_for_type_with_bindings(element_type, bindings)?
                            }
                        };
                        if elements.is_empty() {
                            copies_by_cells = default_copies_by_cells(&value);
                        }
                        elements.push(self.allocate_cell(value)?);
                    }
                    return Ok(Value::Array(elements));
                }
            }

            if let typed_trees::types::TypeReferenceNode::Generic {
                base_symbol,
                base_name,
                arguments,
                ..
            } = self
                .program
                .type_reference_table
                .type_reference(type_reference)
            {
                let program = self.program;
                let definition = validation::field_domains::data_definition_by_symbol_or_name(
                    program,
                    *base_symbol,
                    base_name,
                );
                if let Some(definition) = definition
                    && matches!(
                        DataDefinition::shape_kind_from_members(
                            self.program.data_members(definition)
                        ),
                        typed_trees::data::DataShapeKind::Record
                    )
                {
                    let parameters = self.program.data_type_parameters(definition).to_vec();
                    let arguments = self
                        .program
                        .type_reference_table
                        .type_reference_handles(*arguments)
                        .to_vec();
                    let mut nested_bindings = bindings.to_vec();
                    nested_bindings.extend(parameters.iter().zip(arguments).map(
                        |(parameter, argument)| {
                            (
                                parameter.symbol,
                                parameter.name.as_str().to_owned(),
                                argument,
                            )
                        },
                    ));
                    let mut nested_fields = BTreeMap::new();
                    self.populate_data_fields_with_bindings(
                        definition,
                        &mut nested_fields,
                        &nested_bindings,
                    )?;
                    return Ok(Value::Struct {
                        type_symbol: definition.symbol,
                        type_name: definition.name.as_str().into(),
                        fields: nested_fields,
                    });
                }
            }

            // Nested `data` record -> a sub-Struct of its own defaults.
            if let Some(nested) = self.field_nested_data(type_reference) {
                let mut nested_fields = BTreeMap::new();
                self.populate_data_fields(nested, &mut nested_fields)?;
                return Ok(Value::Struct {
                    type_symbol: nested.symbol,
                    type_name: nested.name.as_str().into(),
                    fields: nested_fields,
                });
            }

            // An enum-shaped field defaults to the ZERO CASE (ZII: tag 0 is
            // the first case) with the case's payload fields zeroed --
            // matching native zero-initialized storage, so tag compares and
            // synthesized structural equality agree on never-assigned sum
            // fields instead of seeing a Unit placeholder.
            if let Some((type_symbol, variant_name, payload_fields)) =
                self.enum_zero_case(type_reference)
            {
                let mut payload = Vec::with_capacity(payload_fields.len());
                for field in payload_fields {
                    let value =
                        self.default_value_for_type_with_bindings(field.type_reference, bindings)?;
                    payload.push((field.name.as_str().into(), self.allocate_cell(value)?));
                }
                return Ok(Value::Enum {
                    type_symbol,
                    variant_name: variant_name.into(),
                    payload,
                });
            }
        }
        self.default_for_type(type_reference)
    }

    fn generic_binding_argument(
        &self,
        symbol: SymbolHandle,
        name: &str,
        bindings: &[(
            SymbolHandle,
            String,
            typed_trees::types::TypeReferenceHandle,
        )],
    ) -> Option<typed_trees::types::TypeReferenceHandle> {
        bindings
            .iter()
            .find(|(parameter, spelling, _)| {
                if symbol.is_valid() {
                    *parameter == symbol
                } else {
                    spelling == name
                }
            })
            .map(|(_, _, argument)| *argument)
    }

    fn const_argument_value_with_bindings(
        &self,
        argument: typed_trees::types::TypeReferenceHandle,
        bindings: &[(
            SymbolHandle,
            String,
            typed_trees::types::TypeReferenceHandle,
        )],
        depth: usize,
    ) -> Option<usize> {
        if depth >= 16 {
            return None;
        }
        if let Some(value) = self
            .program
            .type_reference_table
            .anonymous_numeric_literal_value(argument)
        {
            return Some(value);
        }
        let typed_trees::types::TypeReferenceNode::Named { symbol, name } =
            self.program.type_reference_table.type_reference(argument)
        else {
            return None;
        };
        let argument = self.generic_binding_argument(*symbol, name.as_str(), bindings)?;
        self.const_argument_value_with_bindings(argument, bindings, depth + 1)
    }

    /// The first case of a case-bearing declared type (the ZII zero case),
    /// with the field declarations a zeroed value carries: the COMMON fields
    /// (mixed shapes -- present in every case) followed by the zero case's
    /// payload fields.
    fn enum_zero_case(
        &self,
        type_reference: typed_trees::types::TypeReferenceHandle,
    ) -> Option<(SymbolHandle, String, Vec<typed_trees::data::DataField>)> {
        if self
            .program
            .primitive_type_reference(type_reference)
            .is_some()
        {
            return None;
        }
        let symbol = self.program.type_reference_symbol(type_reference);
        if !symbol.is_valid() {
            return None;
        }
        let data = self.program.data_definition_by_symbol(symbol)?;
        let members = self.program.data_members(data);
        let first_variant = members.iter().find_map(|member| match member {
            DataMember::Variant(variant) => Some(variant),
            _ => None,
        })?;
        let mut fields: Vec<typed_trees::data::DataField> = members
            .iter()
            .filter_map(|member| match member {
                DataMember::Field(field) => Some(field.clone()),
                _ => None,
            })
            .collect();
        fields.extend(self.program.data_payload_fields(first_variant).to_vec());
        Some((data.symbol, first_variant.name.as_str().to_owned(), fields))
    }

    /// If a field's declared type is a (non-primitive) `data` record, return it.
    fn field_nested_data(
        &self,
        type_reference: typed_trees::types::TypeReferenceHandle,
    ) -> Option<&'program DataDefinition> {
        if !type_reference.is_valid() {
            return None;
        }
        if self
            .program
            .primitive_type_reference(type_reference)
            .is_some()
        {
            return None;
        }
        let symbol = self.program.type_reference_symbol(type_reference);
        if !symbol.is_valid() {
            return None;
        }
        self.program
            .data_definition_by_symbol(symbol)
            .filter(|data| {
                // Records instantiate as nested structs; case-bearing data (sums
                // AND mixed shapes) doesn't -- it zero-initializes to the first
                // case via `enum_zero_case`. EMPTY records (e.g. `data Circle {}`)
                // must still instantiate as a typed struct -- the type identity
                // is what a `dyn Trait` receiver dispatches on at runtime.
                !matches!(
                    DataDefinition::shape_kind_from_members(self.program.data_members(data)),
                    typed_trees::data::DataShapeKind::Enum
                        | typed_trees::data::DataShapeKind::Mixed
                )
            })
    }

    pub(in crate::interpreter::evaluator) fn default_for_type(
        &self,
        type_reference: typed_trees::types::TypeReferenceHandle,
    ) -> EvalResult<Value> {
        Ok(
            match self.program.primitive_type_reference(type_reference) {
                Some(PrimitiveType::Bool) => Value::Bool(false),
                Some(PrimitiveType::F32) | Some(PrimitiveType::F64) => Value::Float(0.0),
                Some(_) => Value::Int(0),
                // A `&[u8] in Utf8` text view (the encoding-domain model that retires
                // the retired owned primitive, #66) uses a fat `{ptr,len}` descriptor
                // and the content-compare/literal-store path natively. The
                // zero-initialized field is a zeroed descriptor (empty bytes), so the
                // interpreter must default it to an EMPTY `Str` -- not `Unit`. (A `Unit`
                // default makes `self.name == "literal"` fall through `values_equal`'s
                // int-compare arm where `None == None` is spuriously TRUE, diverging from
                // the native empty-vs-nonempty content compare.)
                None if self.program.is_borrowed_byte_slice(type_reference) => {
                    self.allocate_text(Vec::new())?
                }
                None => Value::Unit,
            },
        )
    }

    // ---- state execution ----------------------------------------------------

    /// Run a state; returns the value produced by a `Value` transition target, if any.
    /// Guards native recursion depth so a deeply recursive program is declined (skipped)
    /// instead of overflowing the host stack.
    pub(in crate::interpreter::evaluator) fn run_state_collect(
        &mut self,
        machine: &'program Machine,
        state: &'program State,
        arguments: Vec<EvaluatedArgument>,
    ) -> EvalResult<Option<Value>> {
        self.call_depth += 1;
        if self.call_depth > CALL_DEPTH_BUDGET {
            self.call_depth -= 1;
            return unsupported("recursion depth budget exceeded");
        }
        let result = self.run_state_collect_inner(machine, state, arguments);
        self.call_depth -= 1;
        result
    }

    fn run_state_collect_inner(
        &mut self,
        machine: &'program Machine,
        state: &'program State,
        arguments: Vec<EvaluatedArgument>,
    ) -> EvalResult<Option<Value>> {
        // MR4 admission: the cross-machine tail transition REBINDS these and
        // continues the loop (a jump, mirroring the native dispatch-loop
        // lowering) instead of recursing -- an admitted measured mutual
        // cycle must not consume interpreter call depth.
        let mut machine = machine;
        let mut state = state;
        let mut current_args = arguments;
        // Bindings accumulated across SAME-machine sibling transitions: the backend models a
        // machine as one frame whose slots persist, so a state re-entered through a
        // named sibling transition keeps its earlier bindings. New arguments bind on
        // top; carried-over bindings stay in the frame.
        let mut carried: Vec<FrameLocal> = Vec::new();

        loop {
            self.tick()?;

            // Tail transitions can change the machine without another call
            // frame. Guard each selected body, not just the entry machine.
            if machine.body_status == typed_trees::machine::MachineBodyStatus::Deferred {
                return unsupported(format!(
                    "machine `{}` requires implementation completion before execution",
                    machine.name.as_str(),
                ));
            }

            // A bodyless declaration — a `boundary requirement`, boundary or
            // admission-claim machine, or an external `via` leaf — retains no
            // checked body to execute. A direct call reaching one was settled
            // for a host-ABI realization the interpreter does not provide;
            // running an empty statement list would silently return unit.
            if !machine.body_is_present {
                return unsupported(format!(
                    "call target `{}` is a bodyless requirement or external declaration; the interpreter has no provider for its selected realization",
                    machine.name.as_str(),
                ));
            }

            let mut frame = self.bind_frame(state, &current_args, machine.symbol, carried)?;
            self.validate_normal_cleanup_selection(machine, state)?;

            // Execute statements, watching for the first satisfied transition. A state
            // whose body ends in a bare expression (`{ 22 }`) returns that expression's
            // value as its result (the backend's value-state form).
            let mut next: Option<TransitionDecision<'program>> = None;
            let mut tail_value: Option<Value> = None;
            let mut exit = checked_trees::FlowClaimJoinExit {
                state_symbol: state.symbol,
                statement_index: self
                    .program
                    .statement_table
                    .statements(state.statement_nodes)
                    .len(),
                kind: checked_trees::FlowClaimJoinExitKind::FinalExpression,
            };
            let order = self
                .program
                .statement_table
                .finite_execution_order(state.statement_nodes)
                .map_err(Halt::Trap)?;
            let Some(order) = order else {
                return unsupported(
                    "cyclic assembly control requires a checked execution plan".to_owned(),
                );
            };
            for statement_index in order {
                let statement_handle = state.statement_nodes.handle_at(statement_index as u32);
                let statement = self.program.statement_table.statement(statement_handle);
                match statement {
                    StatementNode::Transition(transition) => {
                        if let Some((decision, kind)) =
                            self.eval_transition(transition, &mut frame)?
                        {
                            exit.statement_index = statement_index;
                            exit.kind = kind;
                            next = Some(decision);
                            break;
                        }
                    }
                    StatementNode::Expression(expression) => {
                        if self
                            .program
                            .expression_table
                            .call_node(*expression)
                            .and_then(|call| call.native_code_layout.as_ref())
                            .is_some_and(|query| query.discards_result)
                        {
                            continue;
                        }

                        if statement_index + 1
                            == self
                                .program
                                .statement_table
                                .statements(state.statement_nodes)
                                .len()
                        {
                            exit.statement_index = statement_index;
                        }
                        tail_value = Some(self.eval_expression_at_type(
                            *expression,
                            frame.return_type,
                            &mut frame,
                        )?);
                    }
                    StatementNode::Call(call) => {
                        self.eval_call_statement(statement_handle, call, &mut frame)?;
                    }
                    other => {
                        self.exec_statement(other, statement_index, &mut frame)?;
                    }
                }
            }

            match next {
                None => {
                    self.execute_normal_cleanup(machine, state, &frame, exit)?;
                    return Ok(tail_value);
                }
                Some(TransitionDecision::Value(value)) => {
                    self.execute_normal_cleanup(machine, state, &frame, exit)?;
                    return Ok(Some(value));
                }
                Some(TransitionDecision::Terminal) => {
                    self.execute_normal_cleanup(machine, state, &frame, exit)?;
                    return Ok(None);
                }
                Some(TransitionDecision::Named {
                    state: target_state,
                    machine: target_machine,
                    arguments,
                }) => {
                    self.execute_normal_cleanup(machine, state, &frame, exit)?;
                    if target_machine.symbol == machine.symbol {
                        // Carry this state's bindings forward to the sibling state.
                        carried = frame.locals;
                        state = target_state;
                        current_args = arguments;
                        continue;
                    }
                    // Cross-machine named transition: a TAIL JUMP into the
                    // target machine (the arm target is the arm's last
                    // action; whichever machine terminates delivers the
                    // value). Rebind the loop -- constant depth, matching
                    // the native SetDispatchState lowering. The carried
                    // locals clear: the callee binds a fresh frame.
                    machine = target_machine;
                    state = target_state;
                    current_args = arguments;
                    carried = Vec::new();
                    continue;
                }
            }
        }
    }

    /// Bind a state's parameters to their positional argument cells. Seeds
    /// from `carried` (the enclosing same-machine state's bindings) so a re-entered state
    /// still holds its earlier bindings; the state's own params rebind on top.
    fn bind_frame(
        &self,
        state: &State,
        arguments: &[EvaluatedArgument],
        machine_symbol: SymbolHandle,
        carried: Vec<FrameLocal>,
    ) -> EvalResult<Frame> {
        self.check_state_argument_count(state, arguments.len())?;
        let mut frame = Frame {
            return_type: state.return_type,
            locals: carried,
            machine_symbol,
            state_symbol: state.symbol,
            guard_call_results: Vec::new(),
            scalar_expression_depth: 0,
            scalar_expression_values: Vec::new(),
            match_subjects: Vec::new(),
        };
        for (parameter, argument) in self.program.state_parameters(state).iter().zip(arguments) {
            let argument = argument.clone();
            let cell = argument.cell;
            // Coerce a by-value ARGUMENT to the param's declared width/domain at
            // the binding, matching the native truncating/clamping/trapping store
            // at the call boundary. Mirrors the Assignment/LocalData store wraps:
            //   * f32 param: round a `Float` to f32 (an inline `+1.0` arg is f64;
            //     native passes it in an f32 register).
            //   * integer param: wrap/clamp/trap an `Int` to the param's width +
            //     arithmetic domain (a u8 param given `a+b`=300 must read 44).
            // A `&mut` arg carries a `Ref`/place (not a `Float`/`Int`), so it is
            // left untouched and its aliasing preserved (keep the original cell);
            // a by-value scalar is a copy anyway, so a fresh coerced cell is
            // correct. Funnels through `coerce_scalar_with` like every other seam.
            // The resolved (primitive, domain) is also RECORDED so arithmetic on
            // the param applies its declared domain at the operation node.
            let mut scalar = None;
            let cell = match self
                .program
                .primitive_type_reference(parameter.type_reference)
            {
                Some(primitive) => {
                    let domain = self
                        .program
                        .arithmetic_domain_for_type_reference(parameter.type_reference);
                    scalar = Some((primitive, domain));
                    let scalar = match &*cell.borrow() {
                        v @ (Value::Int(_) | Value::Float(_) | Value::UndeterminedNaN(_)) => {
                            Some(v.clone())
                        }
                        _ => None,
                    };
                    match scalar {
                        Some(value) => {
                            let value = self.coerce_scalar_with(value, primitive, domain)?;
                            self.allocate_cell(value)?
                        }
                        None => cell,
                    }
                }
                None => cell,
            };
            frame.bind(FrameLocal {
                symbol: parameter.symbol,
                cell,
                type_reference: parameter.type_reference,
                scalar,
            });
        }
        Ok(frame)
    }
}

/// Whether a default value is copied exactly by duplicating its cells: every
/// leaf is a scalar, so a deep copy allocates the same metered cells a fresh
/// derivation would. Text owns metered bytes and a reference shares its
/// referent, so either keeps per-element derivation.
fn default_copies_by_cells(value: &Value) -> bool {
    match value {
        Value::Unit
        | Value::Int(_)
        | Value::Bool(_)
        | Value::Float(_)
        | Value::UndeterminedNaN(_) => true,
        Value::Str(_) | Value::Ref(_) => false,
        Value::Struct { fields, .. } => fields
            .values()
            .all(|cell| default_copies_by_cells(&cell.borrow())),
        Value::Enum { payload, .. } => payload
            .iter()
            .all(|(_, cell)| default_copies_by_cells(&cell.borrow())),
        Value::Array(elements) => elements
            .iter()
            .all(|cell| default_copies_by_cells(&cell.borrow())),
    }
}
