use crate::contracts::facts::parse_logical_proof_facts_until;
use crate::input::token_cursor::{Input, ParseResult, parse_path_handle_span};
use crate::parameters::parse_generic_parameters::GenericParameterSyntax;
use arena::HandleSpan;
use syntax_trees::SyntaxTrees;
use syntax_trees::expression::ExpressionNode;
use syntax_trees::identifier::Identifier;
use syntax_trees::item::{DomainAliasDefinition, DomainDefinition, ProofFact, ProofMembershipFact};
use syntax_trees::types::TypeReferenceNode;
use tokens::{KeywordKind, PunctuationKind};

pub(super) fn parse_domain_definition<'tokens, 'source>(
    syntax_trees: &mut SyntaxTrees,
    input: Input<'tokens, 'source>,
) -> ParseResult<'tokens, 'source, DomainDefinition> {
    let (generic_parameters, input) =
        crate::parameters::parse_generic_parameters::parse_generic_parameters(
            syntax_trees,
            input,
            GenericParameterSyntax::TypeAndConst,
        )?;
    if !generic_parameters.lifetime_parameters.is_empty() {
        return Err(input.error_here(
            "domain families take a carrier type and proof-static const parameters, not lifetime parameters",
        ));
    }
    // The domain TARGET is normally a named type (`domain String::Utf8`), but it
    // may be a slice/array carrier (`domain [u8]::Utf8`; encoding domains over the
    // `[u8]` slice). A bracket-prefixed target is parsed as a full type reference;
    // every other target stays the bare-identifier path, so existing named-target
    // declarations are completely unchanged (zero fallout).
    let (target_type, target_label, target_identifier, input) =
        if input.at_punctuation(PunctuationKind::LeftBracket) {
            let (handle, input) =
                crate::type_syntax::parse_type::parse_type_reference_handle(syntax_trees, input)?;
            let label = type_reference_target_label(syntax_trees, handle);
            (handle, label, None, input)
        } else {
            let (target_name, input) = input.take_identifier()?;
            let handle = syntax_trees
                .type_references
                .insert(TypeReferenceNode::Named(target_name.clone()));
            (
                handle,
                target_name.as_str(syntax_trees).to_owned(),
                Some(target_name),
                input,
            )
        };
    let input = input.take_punctuation(PunctuationKind::ColonColon, "::")?;
    // A refinement chain (`domain A::B::C`) declares the last segment as a
    // single-parent refinement of the prefix domain `A::B`; each `::Segment`
    // continues the chain and may carry its own indexed application.
    let (first_segment, mut input) = input.take_identifier()?;
    let (first_arguments, rest) =
        crate::type_syntax::parse_type::parse_domain_argument_handles(syntax_trees, input)?;
    let mut name_segments = vec![(first_segment, first_arguments)];
    input = rest;
    while input.at_punctuation(PunctuationKind::ColonColon) {
        let rest = input.take_punctuation(PunctuationKind::ColonColon, "::")?;
        let (segment, rest) = rest.take_identifier()?;
        let (arguments, rest) =
            crate::type_syntax::parse_type::parse_domain_argument_handles(syntax_trees, rest)?;
        name_segments.push((segment, arguments));
        input = rest;
    }
    let domain_name = name_segments
        .last()
        .expect("a domain chain always holds its first segment")
        .0
        .clone();
    let index_arguments = name_segments
        .last()
        .expect("a domain chain always holds its first segment")
        .1;
    let (mut subject, input) = if input.at_punctuation(PunctuationKind::LeftParen) {
        let input = input.take_punctuation(PunctuationKind::LeftParen, "(")?;
        let (subject, input) = input.take_identifier()?;
        if syntax_trees
            .items
            .type_parameters(generic_parameters.type_parameters)
            .iter()
            .any(|parameter| parameter.name.as_str(syntax_trees) == subject.as_str(syntax_trees))
        {
            return Err(input.error_here("domain subject duplicates a generic parameter"));
        }
        let input = input.take_punctuation(PunctuationKind::RightParen, ")")?;
        (Some(subject), input)
    } else {
        (None, input)
    };
    let ((classification, classification_token_count), input) = parse_domain_classification(input)?;
    let (cleanup_selection, input) = parse_cleanup_selection(syntax_trees, input)?;
    // A chained declaration is authored at the last segment and carries the
    // leading subject membership proposition its refinement semantics imply;
    // the parent path spells the chain's own prefix so a bracketed target
    // (`[u8]::A::B`) spells only the domain segments that identifiers can name.
    let refinement_parent = if name_segments.len() > 1 {
        let parent_span = name_segments[name_segments.len() - 2].0.source_span();
        let subject_name = subject
            .get_or_insert_with(|| Identifier::generated("$subject"))
            .clone();
        let subject_path = HandleSpan::from_parts(
            syntax_trees
                .expressions
                .append_identifier_path_member(subject_name),
            1,
        );
        let parent_path = syntax_trees.items.insert_identifier_path_members(
            target_identifier.iter().cloned().chain(
                name_segments[..name_segments.len() - 1]
                    .iter()
                    .map(|(segment, _)| segment.clone()),
            ),
        );
        Some((
            ProofMembershipFact {
                value: syntax_trees
                    .expressions
                    .insert(ExpressionNode::Name(subject_path)),
                domain: parent_path,
                domain_arguments: name_segments[name_segments.len() - 2].1,
            },
            parent_span,
        ))
    } else {
        None
    };
    let name = if generic_parameters.type_parameters.is_empty() {
        // The combined semantic path is synthesized, but the declaration is still authored at
        // the domain-name token. Retaining that span lets symbol provenance recover the exact
        // package owner without treating the combined spelling as an identity oracle.
        Identifier::new(
            format!(
                "{target_label}::{}",
                name_segments
                    .iter()
                    .map(|(segment, _)| segment.as_str(syntax_trees))
                    .collect::<Vec<_>>()
                    .join("::")
            ),
            domain_name.source_span(),
        )
    } else {
        Identifier::new(
            name_segments
                .iter()
                .map(|(segment, _)| segment.as_str(syntax_trees))
                .collect::<Vec<_>>()
                .join("::"),
            domain_name.source_span(),
        )
    };
    let (
        alias,
        authored_routes,
        predicate_body,
        facts,
        operators,
        semantic_clause_token_count,
        input,
    ) = if input.at_punctuation(PunctuationKind::Equal) {
        if refinement_parent.is_some() {
            return Err(input.error_here(
                "a domain refinement chain cannot be an alias; write the parent membership in the alias explicitly",
            ));
        }
        let (alias, input) = parse_domain_alias(syntax_trees, input)?;
        (
            Some(alias),
            Vec::new(),
            language_core::DomainPredicateBody::Bodyless,
            HandleSpan::empty(),
            HandleSpan::empty(),
            0,
            input,
        )
    } else {
        // The implied parent membership leads the proposition list so authored
        // `requires` facts append contiguously behind it (parent-first order).
        let parent_fact = refinement_parent.map(|(membership, parent_span)| {
            let handle = syntax_trees
                .items
                .append_proof_fact(ProofFact::Membership(membership));
            syntax_trees
                .items
                .set_proof_fact_source_span(handle, parent_span);
            handle
        });
        let ((predicate_body, authored_facts, requires_token_count), input) =
            parse_domain_requires(syntax_trees, input)?;
        let (predicate_body, facts) = match parent_fact {
            Some(handle) => (
                language_core::DomainPredicateBody::Present,
                HandleSpan::from_parts(handle, 1 + authored_facts.count()),
            ),
            None => (predicate_body, authored_facts),
        };
        let ((authored_routes, semantic_clause_token_count), input) =
            parse_domain_establishment(input, predicate_body.is_present())?;
        (
            None,
            authored_routes,
            predicate_body,
            facts,
            HandleSpan::empty(),
            requires_token_count.saturating_add(semantic_clause_token_count),
            input,
        )
    };

    Ok((
        DomainDefinition {
            name,
            subject,
            type_parameters: generic_parameters.type_parameters,
            target_type,
            index_arguments,
            is_public: false,
            alias,
            authored_routes,
            cleanup_selection,
            classification,
            predicate_body,
            facts,
            operators,
            semantic_clause_token_count: classification_token_count
                .saturating_add(semantic_clause_token_count),
        },
        input,
    ))
}

fn parse_domain_classification<'tokens, 'source>(
    input: Input<'tokens, 'source>,
) -> ParseResult<'tokens, 'source, (Option<language_core::DomainClassification>, usize)> {
    if !input.at_contextual("satisfies") {
        return Ok(((None, 0), input));
    }
    let start_tokens = input.tokens.len();
    let input = input.take_contextual("satisfies")?;
    let (name, input) = input.take_identifier()?;
    let classification = match name.as_str(&input) {
        "ProgressProfile" => language_core::DomainClassification::ProgressProfile,
        other => {
            return Err(input.error_here(format!(
                "unknown compiler-owned domain classification `{other}`; expected `ProgressProfile`"
            )));
        }
    };
    if input.at_contextual("satisfies") {
        return Err(
            input.error_here("a domain may select at most one compiler-owned classification")
        );
    }
    Ok((
        (
            Some(classification),
            start_tokens.saturating_sub(input.tokens.len()),
        ),
        input,
    ))
}

fn parse_domain_requires<'tokens, 'source>(
    syntax_trees: &mut SyntaxTrees,
    input: Input<'tokens, 'source>,
) -> ParseResult<
    'tokens,
    'source,
    (
        language_core::DomainPredicateBody,
        HandleSpan<ProofFact>,
        usize,
    ),
> {
    if !input.at_contextual("requires") {
        return Ok((
            (
                language_core::DomainPredicateBody::Bodyless,
                HandleSpan::empty(),
                0,
            ),
            input,
        ));
    }

    let input = input.take_contextual("requires")?;
    let ((facts, token_count), input) =
        parse_logical_proof_facts_until(syntax_trees, input, domain_requires_terminator)?;
    if facts.is_empty() {
        return Err(input.error_here("domain `requires` must contain at least one proposition"));
    }
    Ok((
        (
            language_core::DomainPredicateBody::Present,
            facts,
            token_count,
        ),
        input,
    ))
}

fn domain_requires_terminator(input: Input<'_, '_>) -> bool {
    input.at_contextual("established")
        || input.at_contextual("satisfies")
        || input.at_punctuation(PunctuationKind::LeftBrace)
        || input.tokens.is_empty()
        || input.at_keyword(KeywordKind::Public)
        || input.at_keyword(KeywordKind::Data)
        || input.at_keyword(KeywordKind::Machine)
        || input.at_keyword(KeywordKind::Use)
        || input.at_contextual("domain")
        || input.at_contextual("operator")
        || input.at_contextual("boundary")
        || input.at_contextual("trait")
        || input.at_contextual("const")
        || input.at_contextual("export")
        || input.at_contextual("module")
        || input.at_contextual("package")
}

fn parse_domain_alias<'tokens, 'source>(
    syntax_trees: &mut SyntaxTrees,
    input: Input<'tokens, 'source>,
) -> ParseResult<'tokens, 'source, DomainAliasDefinition> {
    let mut input = input.take_punctuation(PunctuationKind::Equal, "=")?;
    let mut constituents = Vec::new();

    loop {
        let (domain, rest) = parse_path_handle_span(input, |member| {
            syntax_trees.items.append_identifier_path_member(member)
        })?;
        constituents.push(domain);
        if !rest.at_punctuation(PunctuationKind::Ampersand) {
            input = rest;
            break;
        }
        input = rest.take_punctuation(PunctuationKind::Ampersand, "&")?;
    }

    let input = input.take_punctuation(PunctuationKind::Semicolon, ";")?;
    Ok((DomainAliasDefinition { constituents }, input))
}

/// A readable label for a domain TARGET type, used to build the domain's name
/// (`[u8]::Utf8`). Covers the carriers an encoding domain attaches to; a named
/// target uses its identifier.
fn type_reference_target_label(
    syntax_trees: &SyntaxTrees,
    handle: syntax_trees::types::TypeReferenceHandle,
) -> String {
    match syntax_trees.type_references.type_reference(handle) {
        TypeReferenceNode::Slice { element_type } => {
            format!(
                "[{}]",
                type_reference_target_label(syntax_trees, *element_type)
            )
        }
        TypeReferenceNode::FixedArray { element_type, .. } => {
            format!(
                "[{}; N]",
                type_reference_target_label(syntax_trees, *element_type)
            )
        }
        TypeReferenceNode::Named(name) => name.as_str(syntax_trees).to_owned(),
        _ => "?".to_owned(),
    }
}

fn parse_domain_establishment<'tokens, 'source>(
    input: Input<'tokens, 'source>,
    requires_consumed: bool,
) -> ParseResult<'tokens, 'source, (Vec<Vec<Identifier>>, usize)> {
    if input.at_punctuation(PunctuationKind::Semicolon) {
        let input = input.take_punctuation(PunctuationKind::Semicolon, ";")?;
        return Ok(((Vec::new(), 0), input));
    }

    if input.at_contextual("satisfies") {
        return Err(input.error_here(
            "a domain classification must appear immediately after the domain head, before `requires`",
        ));
    }

    // A `requires` clause may own the declaration's final semicolon. When its
    // proof-fact parser has already consumed that token, the next root item is
    // the caller's input and this domain has no establishment clause.
    if requires_consumed
        && !input.at_contextual("established")
        && !input.at_punctuation(PunctuationKind::LeftBrace)
        && domain_requires_terminator(input)
    {
        return Ok(((Vec::new(), 0), input));
    }

    if input.at_punctuation(PunctuationKind::LeftBrace) {
        let body = input.take_punctuation(PunctuationKind::LeftBrace, "{")?;
        if body.at_punctuation(PunctuationKind::RightBrace) {
            let input = body.take_punctuation(PunctuationKind::RightBrace, "}")?;
            return Ok(((Vec::new(), 0), input));
        }
        if at_legacy_authored_route(body) {
            return Err(input.error_here(
                "domain route bodies are retired; write \
                 `established by Trait::requirement, ...;` after the domain predicates",
            ));
        }
        if body.at_contextual("operator") || body.at_contextual("boundary") {
            return Err(body.error_here(
                "domain operators must be ordinary top-level declarations; write \
                 `operator Type::Domain::operation ...` outside the domain declaration",
            ));
        }
        return Err(body.error_here(
            "domain predicates must be written in `requires`; establishment routes use \
             `established by Trait::requirement, ...;`",
        ));
    }

    let mut input = input.take_contextual("established")?;
    input = input.take_contextual("by")?;
    let routes_start_tokens = input.tokens.len();
    let mut authored_routes = Vec::new();

    loop {
        let (route, rest) = parse_authored_route(input)?;
        authored_routes.push(route);
        input = rest;
        if !input.at_punctuation(PunctuationKind::Comma) {
            break;
        }
        input = input.take_punctuation(PunctuationKind::Comma, ",")?;
    }

    input = input.take_punctuation(PunctuationKind::Semicolon, ";")?;
    let token_count = routes_start_tokens.saturating_sub(input.tokens.len());
    Ok(((authored_routes, token_count), input))
}

fn at_legacy_authored_route(mut input: Input<'_, '_>) -> bool {
    let Ok((_, rest)) = input.take_identifier() else {
        return false;
    };
    input = rest;
    let mut members = 1usize;
    while input.at_punctuation(PunctuationKind::ColonColon) {
        let Ok(rest) = input.take_punctuation(PunctuationKind::ColonColon, "::") else {
            return false;
        };
        let Ok((_, rest)) = rest.take_identifier() else {
            return false;
        };
        input = rest;
        members += 1;
    }
    members >= 2 && input.at_punctuation(PunctuationKind::Semicolon)
}

fn parse_authored_route<'tokens, 'source>(
    mut input: Input<'tokens, 'source>,
) -> ParseResult<'tokens, 'source, Vec<Identifier>> {
    let mut route = Vec::new();
    loop {
        let (member, rest) = input.take_identifier()?;
        route.push(member);
        input = rest;
        if !input.at_punctuation(PunctuationKind::ColonColon) {
            break;
        }
        input = input.take_punctuation(PunctuationKind::ColonColon, "::")?;
    }
    // A free machine may have a one-segment path. Resolution, not the path's
    // length, distinguishes an exact machine from a trait requirement and
    // rejects ambiguous or ineligible declarations.
    Ok((route, input))
}

/// A cleanup clause selects a declaration, never a runtime call or receiver.
/// Reuse static-application grammar so nested generic arguments retain their
/// own telescope instead of being reparsed as diagnostic text downstream.
pub(super) fn parse_cleanup_selection<'tokens, 'source>(
    syntax_trees: &mut SyntaxTrees,
    input: Input<'tokens, 'source>,
) -> ParseResult<'tokens, 'source, Option<syntax_trees::expression::StaticMachineArgument>> {
    if !input.at_contextual("dropped") {
        return Ok((None, input));
    }
    let input = input.take_contextual("dropped")?.take_contextual("by")?;
    let (path, input) = parse_authored_route(input)?;
    let (application, input) = match crate::expressions::parse_postfix::try_parse_static_symbol_application(syntax_trees, input)? {
        Some((application, input)) => (Some(application), input),
        None if input.at_punctuation(PunctuationKind::Less) => {
            return Err(input.error_here("dropped by requires a complete static machine application"));
        }
        None => (None, input),
    };
    Ok((Some(syntax_trees::expression::StaticMachineArgument {
        type_reference: Default::default(),
        path: path.into_boxed_slice(),
        application,
        const_literal: None,
        evidence_projection: None,
    }), input))
}
