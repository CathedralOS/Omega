//! Machine definitions.
//!
//! `lower_machine_into` sets the lowerer's current-machine context, then lowers
//! the ranking view and termination plan, trait conformances, external
//! binding identity, and every state. `lower_generic_conformance_bounds` is
//! shared with trait definitions. `token_bindings` rejects duplicate direct
//! operator-token bindings once every selection has settled.

use syntax_trees::identifier::JoinedSyntaxPath;
mod token_bindings;

pub(crate) use token_bindings::{
    mark_token_bound_domain_homes, reject_duplicate_direct_token_bindings,
};

use crate::lowering::data::lower_type_parameters;
use crate::lowering::expression::lower_expression_into_table;
use crate::lowering::state::{
    lower_machine_signature_contracts, lower_service_reach_names, lower_signature_invokes,
    lower_state_body, lower_state_node,
};
use crate::resolution::lowerer::Lowerer;
use arena::{Handle, HandleSpan};
use diagnostics::Diagnostic;
use language_semantics::declaration_selection::CollectionMeasure;
use symbol_resolved_trees::machine::{
    GenericConformanceBound, Machine, MachineBodyStatus, MachineStorage, TraitConformance,
};
use symbol_resolved_trees::state::State;
use symbols::SymbolHandle;
use syntax_trees::{self as syntax, SyntaxTrees};

/// Prepared syntax bound to the one declaration roster that indexed it.
/// Compiler-derived machines can rewrite a template's name/attachment; retain
/// that normalized owner rather than rediscovering it by an authored spelling.
#[derive(Debug, Clone)]
pub(crate) struct PendingMachineBody {
    pub(crate) machine_ordinal: usize,
    source: syntax::item::Machine,
    states: Vec<(Handle<State>, syntax::item::StateHandle)>,
}

impl PendingMachineBody {
    pub(crate) fn same_syntax(
        &self,
        other: &Self,
        left: &syntax::SyntaxTextOwner,
        right: &syntax::SyntaxTextOwner,
    ) -> bool {
        use syntax::SyntaxEquivalent;
        let Self {
            machine_ordinal,
            source,
            states,
        } = self;
        *machine_ordinal == other.machine_ordinal
            && *states == other.states
            && source.same_syntax(&other.source, left, right)
    }
}

/// Structural exposure is decided before supply classification erases whether
/// an external leaf used the boundary introducer. Keep it separate from `public`:
/// exported contracts do not make a private declaration source-nameable.
pub(crate) fn machine_interface_exposure(
    machine: &syntax::item::Machine,
) -> language_semantics::declaration_selection::AuthoredDeclarationSelectionExposure {
    use language_semantics::declaration_selection::AuthoredDeclarationSelectionExposure;
    if machine.is_public
        || (machine.boundary
            && !machine.is_top_level_boundary_requirement
            && !crate::lowering::operator::is_token_bearing_boundary_signature(machine))
    {
        AuthoredDeclarationSelectionExposure::PublicInterface
    } else {
        AuthoredDeclarationSelectionExposure::PrivateImplementation
    }
}

pub(crate) fn lower_machine_into(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    machine: &syntax::item::Machine,
) -> Result<(), Diagnostic> {
    lower_lexical_machine_into(lowerer, syntax_trees, machine, Handle::invalid())
}

fn lower_lexical_machine_into(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    machine: &syntax::item::Machine,
    lexical_parent: Handle<Machine>,
) -> Result<(), Diagnostic> {
    // Nesting supplies a lexical name, not the outer declaration's public
    // interface. Every header selects dependencies under its own exposure.
    lowerer.with_authored_expression_exposure(machine_interface_exposure(machine), |lowerer| {
        lower_lexical_machine_parts(lowerer, syntax_trees, machine, lexical_parent)
    })
}

fn lower_lexical_machine_parts(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    machine: &syntax::item::Machine,
    lexical_parent: Handle<Machine>,
) -> Result<(), Diagnostic> {
    if lexical_parent.is_valid()
        && (machine.is_public
            || machine.attached_data.is_some()
            || machine.boundary
            || machine.spelling.is_some())
    {
        return Err(Diagnostic::error(
            "a nested machine is a private independent lexical declaration",
        ));
    }
    if !machine.nested_machines.is_empty()
        && (!machine.type_parameters.is_empty() || !machine.lifetime_parameters.is_empty())
    {
        return Err(Diagnostic::error(
            "nested machines retaining an enclosing static telescope are not yet supported",
        ));
    }
    // OPERATOR-MACHINE-SUPPLY: `machine.spelling` (the optional fixed token
    // after `machine`) is copied onto the symbol-resolved declaration below
    // and flows through the typed machine record, where the typed lowering
    // publishes an operator-signature view so `resolve_spelling` selects the
    // machine by operand type. `token_bindings` rejects a binding whose
    // operands omit its semantic home and an owner-local duplicate
    // token/operand shape after selection. Cross-package ownership, the
    // `operator`-introducer migration, and supply-mode wiring are the next
    // stages: a selected token-bearing machine still executes exactly like
    // its tokenless named form.
    let compiler_selection_partition = compiler_selection_partition(
        lowerer.symbol_resolved_trees.machines.len(),
        syntax_trees,
        machine,
    );
    lowerer.current_compiler_selection_partition = compiler_selection_partition;
    lowerer.current_machine_is_boundary = machine.boundary;
    lowerer.current_machine_root_index = Some(lowerer.symbol_resolved_trees.machines.len());
    lowerer.current_machine_name = Some(machine.name.as_str(syntax_trees).to_owned());
    lowerer.current_evidence_term_names = syntax_trees
        .items
        .capability_contracts(machine.contracts)
        .iter()
        .filter_map(|contract| contract.binding.as_ref())
        .map(|binding| binding.as_str(syntax_trees).to_owned())
        .collect();
    let interface_exposure = machine_interface_exposure(machine);
    let states = lowerer.with_authored_expression_exposure(
        language_semantics::declaration_selection::AuthoredDeclarationSelectionExposure::PrivateImplementation,
        |lowerer| lower_machine_states(lowerer, syntax_trees, machine.states,
            interface_exposure == language_semantics::declaration_selection::AuthoredDeclarationSelectionExposure::PublicInterface),
    )?;
    let body_status = if lowerer.defer_machine_bodies && !machine.bodyless {
        lowerer.pending_machine_bodies.push(PendingMachineBody {
            machine_ordinal: lowerer.symbol_resolved_trees.machines.len(),
            source: machine.clone(),
            states: lowerer
                .symbol_resolved_trees
                .machine_state_handles(states)
                .iter()
                .copied()
                .zip(
                    syntax_trees
                        .items
                        .state_handles(machine.states)
                        .iter()
                        .copied(),
                )
                .collect(),
        });
        MachineBodyStatus::Deferred
    } else {
        MachineBodyStatus::Complete
    };
    lowerer.current_machine_is_boundary = false;
    lowerer.current_machine_root_index = None;
    lowerer.current_machine_name = None;
    lowerer.current_state_name = None;
    lowerer.current_evidence_term_names.clear();
    let type_parameters = lower_type_parameters(lowerer, syntax_trees, machine.type_parameters)?;
    // Each member keeps its own conformances and target-owned `via` locators.
    // Provider selection joins an exact member without promoting it into the
    // portable head or rewriting other members' declarations.
    let sibling_target = machine
        .target
        .as_ref()
        .map(|name| crate::lowering::name::lower_name(syntax_trees, name));
    let satisfies = lower_machine_trait_conformances(lowerer, syntax_trees, machine.satisfies)?;
    let conformance_bounds =
        lower_generic_conformance_bounds(lowerer, syntax_trees, &machine.conformance_bounds)?;
    let ranking_subjects =
        lower_ranking_expressions(lowerer, syntax_trees, machine.ranking_subjects)?;
    let ranking_view = lower_machine_ranking_view(lowerer, syntax_trees, machine.ranking_view);
    // TPR3: argumented-view arguments lower exactly like the subjects.
    let ranking_view_arguments =
        lower_ranking_expressions(lowerer, syntax_trees, machine.ranking_view_arguments)?;
    // TPR3 slice 3: the `in <range>` rank constraint lowers as an ordinary
    // expression; the CHECKER verifies it structurally (v1: floor 0 +
    // ceiling equal to the argumented view's own bound) and fails
    // compilation otherwise -- consumed, never silently dropped.
    let ranking_range = if machine.ranking_range.is_valid() {
        lower_expression_into_table(lowerer, syntax_trees, machine.ranking_range)?
    } else {
        symbol_resolved_trees::expression::ExpressionHandle::invalid()
    };
    let service_reaches = lower_service_reach_names(syntax_trees, machine.service_reaches);
    let invokes = lower_signature_invokes(lowerer, syntax_trees, machine.invokes);
    let contracts =
        lower_machine_signature_contracts(lowerer, syntax_trees, machine.contracts, states)?;
    let machine_name = crate::lowering::name::lower_name(syntax_trees, &machine.name);
    // A member keeps its authored family path and has a distinct
    // `<path>::<target>` symbol. The independent head occupies the portable
    // path; same-target calls bind exact member symbols during resolution.
    let target_symbol_name = match &sibling_target {
        Some(target) => symbol_resolved_trees::name::DiagnosticName::new(
            format!("{}::{}", machine.name.as_str(syntax_trees), target.as_str()),
            machine.name.source_span(),
        ),
        None => symbol_resolved_trees::name::DiagnosticName::default(),
    };
    let attached_data = machine
        .attached_data
        .as_ref()
        .map(|name| crate::lowering::name::lower_name(syntax_trees, name));
    let termination_plan =
        build_termination_plan(lowerer, syntax_trees, machine, states, type_parameters);

    // STR3: the supply mode's ONE population site. Requirement gains its
    // source when trait requirements reach this record; TopLevelRequirement is
    // the explicit `boundary requirement` marker or a bodyless token-bearing
    // boundary machine. Both declare required callable supply, not a proof axiom.
    // An explicit bodyless `satisfies ... via ...` supplies an external leaf,
    // including a `boundary machine`: boundary marks a crossing, not an axiom.
    // Only a declaration without an external realization can instead author
    // an admission claim. Supply is decided before the
    // push so the interner borrow does not overlap the machines borrow.
    let supply_mode = {
        let via_binding = syntax_trees
            .items
            .satisfies_clauses(machine.satisfies)
            .iter()
            .find_map(|clause| clause.via.as_ref())
            .map(|value| external_binding_identity(syntax_trees, value));
        let has_via_expression = syntax_trees
            .items
            .satisfies_clauses(machine.satisfies)
            .iter()
            .any(|clause| clause.via_expression.is_valid());
        if machine.target_family_interface {
            language_semantics::MachineSupplyMode::Requirement
        } else if machine.is_top_level_boundary_requirement
            || crate::lowering::operator::is_token_bearing_boundary_signature(machine)
        {
            language_semantics::MachineSupplyMode::TopLevelRequirement
        } else if machine.bodyless && (via_binding.is_some() || has_via_expression) {
            let (binding, mechanism) = via_binding
                .map(|identity| {
                    let mechanism = identity.mechanism();
                    let binding = lowerer
                        .symbol_resolved_trees
                        .external_bindings
                        .intern(identity);
                    (Some(binding), Some(mechanism))
                })
                .unwrap_or((None, None));
            language_semantics::MachineSupplyMode::ExternalRealization { binding, mechanism }
        } else if machine.bodyless && machine.boundary {
            // A bodyless boundary declaration is an admission claim only when it
            // actually authors a fact. Claim-free symbols such as the
            // axiomatic Real package's operations assert nothing and need no
            // grant; they remain ordinary boundary supply.
            let authors_fact = syntax_trees
                .items
                .capability_contracts(machine.contracts)
                .iter()
                .any(|contract| {
                    matches!(
                        contract.kind,
                        syntax_trees::item::CapabilityContractKind::Ensures
                    ) && !contract.facts.is_empty()
                });
            if authors_fact {
                language_semantics::MachineSupplyMode::AdmissionClaim
            } else {
                language_semantics::MachineSupplyMode::Boundary
            }
        } else if machine.boundary {
            language_semantics::MachineSupplyMode::Boundary
        } else {
            language_semantics::MachineSupplyMode::CheckedBody
        }
    };
    lowerer.pending_machine_service_reaches.push(
        crate::selection::service_reaches::PendingAuthoredServiceReach {
            keyword_source_spans: machine.service_reach_keyword_source_spans.clone(),
            authored: service_reaches,
        },
    );
    // Equation consumers can receive an ordinary generic call's result. Keep
    // that selected telescope too: its substituted result is type evidence even
    // when the producing machine declares no equation of its own.
    if let Some(sources) = &mut lowerer.equation_sources
        && (!machine.where_facts.is_empty() || !machine.type_parameters.is_empty())
    {
        sources.declarations.push((
            lowerer.symbol_resolved_trees.machines.len(),
            machine.clone(),
        ));
    }
    let declaration = lowerer.symbol_resolved_trees.machines.push(Machine {
        symbol: SymbolHandle::invalid(),
        lexical_parent,
        name: machine_name,
        generic_data_origin: symbol_resolved_trees::machine::GenericDataMachineOrigin {
            template_source: crate::lowering::name::lower_name(
                syntax_trees,
                &machine.generic_data_template,
            ),
            ..Default::default()
        },
        trait_default_origin: symbol_resolved_trees::machine::TraitDefaultOrigin {
            trait_source: crate::lowering::name::lower_name(
                syntax_trees,
                &machine.default_body_trait,
            ),
            ..Default::default()
        },
        attached_data,
        attached_data_symbol: SymbolHandle::invalid(),
        attached_data_application: None,
        spelling: machine.spelling,
        is_public: machine.is_public,
        interface_exposure,
        supply_mode,
        body_is_present: !machine.bodyless,
        target: sibling_target,
        authored_target: machine
            .authored_target
            .as_ref()
            .map(|name| crate::lowering::name::lower_name(syntax_trees, name)),
        target_family: SymbolHandle::invalid(),
        target_family_interface: machine.target_family_interface,
        target_family_contracts_prepared: false,
        target_symbol_name,
        has_structural_type_equations: !machine.where_facts.is_empty(),
        structural_type_equations_pending: !machine.where_facts.is_empty()
            && lowerer.structural_type_equations_pending,
        // TPR2: the termination plan's ONE population site (see
        // build_termination_plan below).
        termination_plan,
        service_reach_row: language_semantics::ServiceReachRowId::NULL,
        service_reach_is_installation_bound: machine.service_reach_is_installation_bound,
        admitted_same_stack_bytes: machine.admitted_same_stack_bytes,
        suspends_keyword_source_spans: machine.suspends_keyword_source_spans.clone(),
        blocks_keyword_source_spans: machine.blocks_keyword_source_spans.clone(),
        compiler_selection_partition,
        body_status,
        storage: MachineStorage {
            lifetime_parameters: machine
                .lifetime_parameters
                .iter()
                .map(|name| crate::lowering::name::lower_name(syntax_trees, name))
                .collect(),
            type_parameters,
            owned_data: HandleSpan::empty(),
            satisfies,
            conformance_bounds,
            ranking_subjects,
            ranking_view,
            ranking_view_arguments,
            ranking_range,
            invokes,
            suspends: machine.suspends,
            blocks: machine.blocks,
            contracts,
            states,
        },
    });
    lowerer.current_compiler_selection_partition = None;
    for child in machine.nested_machines.handles() {
        let syntax::item::Item::Machine(child) = syntax_trees.items.item(child) else {
            return Err(Diagnostic::error(
                "a machine lexical scope contains a non-machine declaration",
            ));
        };
        lower_lexical_machine_into(lowerer, syntax_trees, child, declaration)?;
    }
    Ok(())
}

/// Lower a selected implementation without recreating its declaration or its
/// state parameters. Symbols for new locals are appended by the symbol owner.
pub(crate) fn complete_machine_body(
    lowerer: &mut Lowerer,
    syntax: &SyntaxTrees,
    pending: &PendingMachineBody,
) -> Result<(), Diagnostic> {
    let inputs = crate::resolution::type_inputs::TypeInputScope::new(lowerer);
    with_pending_machine_scope(lowerer, syntax, pending, |lowerer| {
        for &(state_handle, syntax_state) in &pending.states {
            let state = lowerer
                .symbol_resolved_trees
                .machine_state(state_handle)
                .clone();
            let statements = lower_state_body(
                lowerer,
                syntax,
                &state,
                syntax.items.state(syntax_state).statements,
            )?;
            lowerer
                .symbol_resolved_trees
                .tables
                .declarations
                .machine_states
                .get_mut(state_handle)
                .statements = statements;
        }
        lowerer.symbol_resolved_trees.machines[pending.machine_ordinal].body_status =
            MachineBodyStatus::Complete;
        Ok(())
    })?;
    let owner = lowerer.symbol_resolved_trees.machines[pending.machine_ordinal].symbol;
    inputs.finish(lowerer, owner);
    Ok(())
}

pub(crate) fn lower_pending_lexical_inputs(
    lowerer: &mut Lowerer,
    syntax: &SyntaxTrees,
    demand: crate::lowering::state::LexicalInputDemand,
) -> Result<Vec<crate::lowering::state::StateLexicalInputs>, Diagnostic> {
    let pending = lowerer.pending_machine_bodies.clone();
    let mut inputs = Vec::new();
    for body in &pending {
        with_pending_machine_scope(lowerer, syntax, body, |lowerer| {
            let machine = lowerer.symbol_resolved_trees.machines[body.machine_ordinal].symbol;
            for &(state, syntax_state) in &body.states {
                inputs.push(crate::lowering::state::lower_state_lexical_inputs(
                    lowerer,
                    syntax,
                    machine,
                    state,
                    syntax.items.state(syntax_state).statements,
                    demand,
                )?);
            }
            Ok(())
        })?;
    }
    Ok(inputs)
}

fn with_pending_machine_scope<T>(
    lowerer: &mut Lowerer,
    syntax: &SyntaxTrees,
    pending: &PendingMachineBody,
    operation: impl FnOnce(&mut Lowerer) -> Result<T, Diagnostic>,
) -> Result<T, Diagnostic> {
    let declaration = lowerer
        .symbol_resolved_trees
        .machines
        .iter()
        .nth(pending.machine_ordinal)
        .ok_or_else(|| Diagnostic::error("deferred body lost its indexed machine"))?;
    if declaration.body_status != MachineBodyStatus::Deferred {
        return Err(Diagnostic::error(
            "machine body completion requires a pending implementation",
        ));
    }
    let partition = declaration.compiler_selection_partition;
    let previous_defer = std::mem::replace(&mut lowerer.defer_machine_bodies, false);
    let previous_partition =
        std::mem::replace(&mut lowerer.current_compiler_selection_partition, partition);
    let previous_boundary = std::mem::replace(
        &mut lowerer.current_machine_is_boundary,
        pending.source.boundary,
    );
    let previous_root = lowerer
        .current_machine_root_index
        .replace(pending.machine_ordinal);
    let previous_name = lowerer
        .current_machine_name
        .replace(pending.source.name.as_str(syntax).to_owned());
    let evidence_names = syntax
        .items
        .capability_contracts(pending.source.contracts)
        .iter()
        .filter_map(|contract| contract.binding.as_ref())
        .map(|binding| binding.as_str(syntax).to_owned())
        .collect();
    let previous_evidence =
        std::mem::replace(&mut lowerer.current_evidence_term_names, evidence_names);
    let result = lowerer.with_authored_expression_exposure(
        language_semantics::declaration_selection::AuthoredDeclarationSelectionExposure::PrivateImplementation,
        operation,
    );
    lowerer.defer_machine_bodies = previous_defer;
    lowerer.current_compiler_selection_partition = previous_partition;
    lowerer.current_machine_is_boundary = previous_boundary;
    lowerer.current_machine_root_index = previous_root;
    lowerer.current_machine_name = previous_name;
    lowerer.current_evidence_term_names = previous_evidence;
    result
}

fn compiler_selection_partition(
    machine_ordinal: usize,
    syntax_trees: &SyntaxTrees,
    machine: &syntax::item::Machine,
) -> Option<language_semantics::declaration_selection::CompilerDerivedSelectionPartition> {
    // Only compiler-derived declarations carry generated names; an authored
    // spelling must never receive a partition.
    if machine.name.is_source_backed() {
        return None;
    }
    let ordinal = u64::try_from(machine_ordinal).ok()?;
    let [requirement] = syntax_trees.items.satisfies_clauses(machine.satisfies) else {
        // Synthesized defaults for parameterized traits rejoin their
        // requirement through the instantiated generic instead of a satisfies
        // clause. The conformance application still needs its own partition:
        // copies of one authored call may select a different exact realization
        // per carrier.
        return machine
            .attached_data
            .is_some()
            .then(|| language_semantics::declaration_selection::CompilerDerivedSelectionPartition::from_compiler_ordinal(ordinal));
    };
    let requirement_name = requirement.requirement.as_ref()?;
    if requirement.trait_name.is_source_backed()
        || requirement_name.is_source_backed()
        || requirement.alias.is_some()
        || requirement.via.is_some()
        || requirement.via_expression.is_valid()
    {
        return None;
    }
    Some(
        language_semantics::declaration_selection::CompilerDerivedSelectionPartition::from_compiler_ordinal(
            ordinal,
        ),
    )
}

pub(crate) fn lower_generic_conformance_bounds(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    bounds: &[syntax::item::GenericConformanceBound],
) -> Result<Vec<GenericConformanceBound>, Diagnostic> {
    bounds
        .iter()
        .map(|bound| {
            Ok(GenericConformanceBound {
                binder: SymbolHandle::invalid(),
                binder_name: crate::lowering::name::lower_name(syntax_trees, &bound.binder),
                trait_symbol: SymbolHandle::invalid(),
                trait_name: crate::lowering::name::lower_name(syntax_trees, &bound.trait_name),
                arguments: crate::lowering::type_reference::lower_child_type_references(
                    lowerer,
                    syntax_trees,
                    bound.arguments,
                )?,
            })
        })
        .collect()
}

/// TPR2 (decision 23): populate the normalized `MachineTerminationPlan` --
/// the plan's ONE population site; every later stage copies, never
/// re-derives.
///
/// - Bare `terminates;` authors the PUBLIC termination guarantee
///   (premises land with TPR4's pinned progress profiles). `terminates by
///   ...` alone publishes NOTHING: it supplies the private witness for a
///   checked body or an inherited claim (the brief's firewall).
/// - `checked_summary` stays `NoGuarantee` here: it is the CHECKER's to
///   establish (TPR3), never claimed at lowering.
/// - The witness records the ranked subjects and the EXPLICIT ranking view.
///   Canonical defaults elaborate immediately where this stage determines
///   them (the two-subject builtin, `.len` subjects, and root-state
///   parameters of unsigned/slice type -- mirroring the checker's inference
///   EXACTLY); the remaining single-subject short forms keep an empty
///   `view_path` until TPR3 folds elaboration into the migrated checker.
fn build_termination_plan(
    lowerer: &Lowerer,
    syntax_trees: &SyntaxTrees,
    machine: &syntax::item::Machine,
    states: HandleSpan<Handle<State>>,
    type_parameters: HandleSpan<symbol_resolved_trees::data::TypeParameter>,
) -> language_semantics::MachineTerminationPlan {
    use language_semantics::{
        MachineTerminationPlan, RankingWitness, TerminationGuarantee, TerminationInterface,
    };

    let interface = if machine.terminates_guarantee {
        TerminationInterface::Published(TerminationGuarantee::Terminates {
            premises: Vec::new(),
        })
    } else if machine.boundary || machine.bodyless {
        TerminationInterface::Published(TerminationGuarantee::NoGuarantee)
    } else {
        TerminationInterface::InternalDerived
    };

    let subjects = syntax_trees
        .expressions
        .expression_handles(machine.ranking_subjects);
    let implementation_witness = (!subjects.is_empty()).then(|| {
        let (ranking_view, view_path) = elaborate_ranking_view(
            lowerer,
            syntax_trees,
            machine,
            states,
            type_parameters,
            subjects,
        );
        RankingWitness {
            subjects: subjects
                .iter()
                .map(|subject| render_ranked_subject(syntax_trees, *subject))
                .collect(),
            ranking_view,
            view_path,
            // TPR3: an argumented view's arguments, rendered source-like in
            // order (`Nat::IncreasingTo(limit)` carries `["limit"]`).
            view_arguments: syntax_trees
                .expressions
                .expression_handles(machine.ranking_view_arguments)
                .iter()
                .map(|argument| render_ranked_subject(syntax_trees, *argument))
                .collect(),
            // TPR3 slice 3: the authored rank-range fact, rendered
            // source-like; the checker verifies it structurally and fails
            // compilation otherwise.
            rank_range: machine.ranking_range.is_valid().then(|| {
                let syntax::expression::ExpressionNode::Range(range) =
                    syntax_trees.expressions.expression(machine.ranking_range)
                else {
                    return language_semantics::RankRange::default();
                };
                language_semantics::RankRange {
                    floor: render_ranked_subject(syntax_trees, range.start),
                    ceiling: render_ranked_subject(syntax_trees, range.end),
                    ceiling_inclusive: range.end_inclusive,
                }
            }),
        }
    });

    MachineTerminationPlan {
        interface,
        checked_summary: TerminationGuarantee::NoGuarantee,
        implementation_witness,
    }
}

/// Render one ranked subject as source-like text for the private witness
/// (mirrors the checker's `decreasing_value_text`).
fn render_ranked_subject(
    syntax_trees: &SyntaxTrees,
    subject: syntax::expression::ExpressionHandle,
) -> String {
    match syntax_trees.expressions.expression(subject) {
        // Range endpoints are commonly literals (`in 0..=capacity`).
        syntax::expression::ExpressionNode::Integer(literal) => literal.to_string(),
        syntax::expression::ExpressionNode::Name(path) => syntax_trees
            .expressions
            .identifier_path_members(*path)
            .joined_path_with_in(syntax_trees, "."),
        syntax::expression::ExpressionNode::Member(member) => format!(
            "{}.{}",
            render_ranked_subject(syntax_trees, member.receiver),
            member.member.as_str(syntax_trees)
        ),
        // A subtraction is not an admissible ranking subject under decision
        // 23, but retaining its exact normalized spelling lets the checked
        // stage issue the directed tuple-view migration diagnostic without
        // consulting the legacy expression-span projection.
        syntax::expression::ExpressionNode::Binary(binary)
            if matches!(
                binary.operator,
                syntax::expression::BinaryOperator::Subtract
            ) =>
        {
            format!(
                "{} - {}",
                render_ranked_subject(syntax_trees, binary.left),
                render_ranked_subject(syntax_trees, binary.right)
            )
        }
        _ => "value".to_string(),
    }
}

/// The witness's explicit view: the authored `-> View` verbatim (canonical
/// builtins get their FIXED ids; a user-declared measure carries `NULL`
/// until TPR3 assigns normalized measure identity), or the canonical
/// default the short form elaborates to.
fn elaborate_ranking_view(
    lowerer: &Lowerer,
    syntax_trees: &SyntaxTrees,
    machine: &syntax::item::Machine,
    states: HandleSpan<Handle<State>>,
    type_parameters: HandleSpan<symbol_resolved_trees::data::TypeParameter>,
    subjects: &[syntax::expression::ExpressionHandle],
) -> (language_semantics::RankingViewId, String) {
    use language_semantics::RankingViewId;

    let order = syntax_trees
        .items
        .identifier_path_members(machine.ranking_view);
    if !order.is_empty() {
        let path = order.joined_path_in(syntax_trees);
        let id = RankingViewId::canonical(&path).unwrap_or(RankingViewId::NULL);
        return (id, path);
    }

    match subjects {
        // The only builtin two-subject view, and therefore the two-subject
        // short-form default (the checker's exact rule).
        [_, _] => canonical_view(RankingViewId::NAT_BOUNDED_DISTANCE),
        [single] => elaborate_single_subject_default(
            lowerer,
            syntax_trees,
            states,
            type_parameters,
            *single,
        ),
        _ => (RankingViewId::NULL, String::new()),
    }
}

fn canonical_view(
    id: language_semantics::RankingViewId,
) -> (language_semantics::RankingViewId, String) {
    (id, id.canonical_path().unwrap_or_default().to_string())
}

/// The single-subject short form's canonical default, mirroring the
/// checker's `decreasing_value_kind` EXACTLY: a `.len` member is nat-like;
/// a plain name ranking a root-state parameter elaborates from the
/// parameter's DECLARED type with constraint shells stripped (ranges and
/// arithmetic domains never change WHAT descends) -- unsigned/bounded
/// scalars descend through the naturals, slices by their length. Anything
/// else stays PENDING (empty path): the checker diagnoses ambiguity as
/// today, and TPR3 folds elaboration into the migrated checker.
fn elaborate_single_subject_default(
    lowerer: &Lowerer,
    syntax_trees: &SyntaxTrees,
    states: HandleSpan<Handle<State>>,
    type_parameters: HandleSpan<symbol_resolved_trees::data::TypeParameter>,
    subject: syntax::expression::ExpressionHandle,
) -> (language_semantics::RankingViewId, String) {
    use language_semantics::RankingViewId;
    use symbol_resolved_trees::types::TypeReference;

    if let syntax::expression::ExpressionNode::Member(member) =
        syntax_trees.expressions.expression(subject)
        && CollectionMeasure::from_authored_spelling(member.member.as_str(syntax_trees))
            == Some(CollectionMeasure::Length)
    {
        return canonical_view(RankingViewId::NAT_DESCENDING);
    }

    let syntax::expression::ExpressionNode::Name(path) =
        syntax_trees.expressions.expression(subject)
    else {
        return (RankingViewId::NULL, String::new());
    };
    let trees = &lowerer.symbol_resolved_trees;
    let pending = (RankingViewId::NULL, String::new());
    let Some(subject_name) = syntax_trees
        .expressions
        .identifier_path_members(*path)
        .last()
    else {
        return pending;
    };
    let Some(root_state) = trees.machine_state_handles(states).first() else {
        return pending;
    };
    let root_state = trees.machine_state(*root_state);
    let declared = trees
        .state_parameters(root_state.parameters)
        .iter()
        .find(|parameter| parameter.name.as_str() == subject_name.as_str(syntax_trees))
        .map(|parameter| &parameter.type_reference)
        .or_else(|| {
            let parameter = trees
                .data_type_parameters(type_parameters)
                .iter()
                .find(|parameter| parameter.name.as_str() == subject_name.as_str(syntax_trees))?;
            match &parameter.kind {
                symbol_resolved_trees::data::TypeParameterKind::Value { type_reference }
                | symbol_resolved_trees::data::TypeParameterKind::Const { type_reference } => {
                    Some(type_reference)
                }
                _ => None,
            }
        });
    let Some(mut base) = declared else {
        return pending;
    };
    loop {
        match base {
            TypeReference::Constrained(constrained) => {
                base = trees.child_type_reference(constrained.base_type);
            }
            TypeReference::Reference(reference) => {
                base = trees.child_type_reference(reference.referee);
            }
            _ => break,
        }
    }
    match base {
        TypeReference::Slice(_) | TypeReference::FixedArray(_) => {
            canonical_view(RankingViewId::SLICE_LENGTH)
        }
        TypeReference::Named { symbol, .. }
            if matches!(
                trees.symbols.builtin_type_atom(*symbol),
                Some(
                    symbols::BuiltinTypeAtom::U8
                        | symbols::BuiltinTypeAtom::U16
                        | symbols::BuiltinTypeAtom::U32
                        | symbols::BuiltinTypeAtom::U64
                )
            ) =>
        {
            canonical_view(RankingViewId::NAT_DESCENDING)
        }
        _ => pending,
    }
}

fn lower_machine_ranking_view(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    order: HandleSpan<syntax::identifier::Identifier>,
) -> HandleSpan<symbol_resolved_trees::name::DiagnosticName> {
    crate::lowering::name::lower_name_members(
        syntax_trees,
        order,
        &mut lowerer
            .symbol_resolved_trees
            .tables
            .declarations
            .ranking_views,
    )
}

fn lower_ranking_expressions(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    source_expressions: HandleSpan<syntax::expression::ExpressionHandle>,
) -> Result<HandleSpan<symbol_resolved_trees::expression::ExpressionHandle>, Diagnostic> {
    let mut lowered = Vec::new();

    for expression in syntax_trees
        .expressions
        .expression_handles(source_expressions)
    {
        let expression = lower_expression_into_table(lowerer, syntax_trees, *expression)?;
        lowered.push(expression);
    }

    Ok(lowerer
        .symbol_resolved_trees
        .tables
        .bodies
        .expressions
        .insert_expression_handles(lowered))
}

fn lower_machine_trait_conformances(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    satisfies: HandleSpan<syntax::item::SatisfiesClause>,
) -> Result<HandleSpan<TraitConformance>, Diagnostic> {
    let mut span = HandleSpan::empty();

    for clause in syntax_trees.items.satisfies_clauses(satisfies) {
        let arguments = crate::lowering::type_reference::lower_child_type_references(
            lowerer,
            syntax_trees,
            clause.arguments,
        )?;
        let external_binding = clause.via.as_ref().map(|binding| {
            lowerer
                .symbol_resolved_trees
                .external_bindings
                .intern(external_binding_identity(syntax_trees, binding))
        });
        let via_expression = clause
            .via_expression
            .is_valid()
            .then(|| lower_expression_into_table(lowerer, syntax_trees, clause.via_expression))
            .transpose()?
            .unwrap_or_else(symbol_resolved_trees::expression::ExpressionHandle::invalid);
        lowerer
            .symbol_resolved_trees
            .tables
            .declarations
            .machine_trait_conformances
            .append_to_span(
                &mut span,
                TraitConformance {
                    symbol: SymbolHandle::invalid(),
                    name: crate::lowering::name::lower_name(syntax_trees, &clause.trait_name),
                    lifetime_arguments: clause
                        .lifetime_arguments
                        .iter()
                        .map(|name| crate::lowering::name::lower_name(syntax_trees, name))
                        .collect(),
                    arguments,
                    requirement: clause
                        .requirement
                        .as_ref()
                        .map(|name| crate::lowering::name::lower_name(syntax_trees, name)),
                    alias: clause
                        .alias
                        .as_ref()
                        .map(|name| crate::lowering::name::lower_name(syntax_trees, name)),
                    external_binding,
                    via_expression,
                    external_binding_source_span: clause.via_keyword_source_span,
                },
            );
    }

    Ok(span)
}

fn external_binding_identity(
    syntax_trees: &syntax_trees::SyntaxTrees,
    binding: &syntax::item::ExternalBinding,
) -> language_semantics::ExternalBindingIdentity {
    use language_semantics::ExternalBindingIdentity;

    match binding {
        syntax::item::ExternalBinding::Syscall { number } => {
            ExternalBindingIdentity::Syscall { number: *number }
        }
        syntax::item::ExternalBinding::CompilerIntrinsic => {
            ExternalBindingIdentity::CompilerIntrinsic
        }
        syntax::item::ExternalBinding::VtableSlot { index } => {
            ExternalBindingIdentity::VtableSlot { index: *index }
        }
        syntax::item::ExternalBinding::VtableField { field } => {
            ExternalBindingIdentity::VtableField {
                field: field.as_str(syntax_trees).to_owned(),
            }
        }
        syntax::item::ExternalBinding::TableFunction { field } => {
            ExternalBindingIdentity::TableFunction {
                field: field.as_str(syntax_trees).to_owned(),
            }
        }
    }
}

fn lower_machine_states(
    lowerer: &mut Lowerer,
    syntax_trees: &SyntaxTrees,
    states: HandleSpan<syntax::item::StateHandle>,
    is_public: bool,
) -> Result<HandleSpan<Handle<State>>, Diagnostic> {
    let mut span = HandleSpan::empty();

    for (ordinal, state) in syntax_trees.items.state_handles(states).iter().enumerate() {
        let authored_type = syntax_trees.items.state(*state).return_type;
        let state = lower_state_node(
            lowerer,
            syntax_trees,
            syntax_trees.items.state(*state),
            is_public && ordinal == 0,
        )?;
        let state = lowerer
            .symbol_resolved_trees
            .tables
            .declarations
            .machine_states
            .append(state);
        if authored_type.is_valid()
            && let Some(sources) = &mut lowerer.equation_sources
        {
            sources.declared_types.push((
                crate::preparation::machine_equations::DeclaredTypeOrigin::Result(state),
                authored_type,
            ));
        }
        lowerer
            .symbol_resolved_trees
            .tables
            .declarations
            .machine_state_handles
            .append_to_span(&mut span, state);
    }

    Ok(span)
}
