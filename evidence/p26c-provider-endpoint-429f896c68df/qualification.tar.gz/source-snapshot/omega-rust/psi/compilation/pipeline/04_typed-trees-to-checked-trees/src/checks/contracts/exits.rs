//! Exit checks: at each normal return, the machine's `ensures` clauses and
//! the declared domains of its result and of its exclusive borrowed referents
//! must be proved from the facts at that exit.
//!
//! `contracts::check_flow_call_contracts` creates one
//! `CyclicHeaderInvariants` for the pass and, for each state, calls:
//!
//! - for each call, `check_state_transfer_result_domains` (`result_domains`);
//! - for each exit, in order, `check_scalar_result_domains`,
//!   `check_exit_ensures`, `check_result_field_domains` and
//!   `check_exclusive_referent_field_domains`.
//!
//! `check_exit_ensures`, defined here, checks each `ensures` fact of an exit.
//! It skips an owner-authorized boundary result, which is established at the
//! admitted crossing. Otherwise the fact holds when the machine's exit
//! entailment proves the expression, when it is a named witness-bearing
//! `ensures` that the evidence-forwarding proof pass discharges, or, when no
//! entry parameter it names lacks an exact incoming origin, when the entry
//! contexts prove it or another exit prover does: result domains
//! (`result_domains`), scalar returns (`scalars`), content preservation,
//! integer embeddings, float meaning reflexivity, integral parameter
//! reflexivity, transparent propositions, collection-predicate premises of a
//! helper theorem or checked store handback, or an authorized domain
//! establishment route. A proved loop header invariant (`cyclic_headers`)
//! also satisfies it. A fact nothing proves is reported with the entry
//! parameters that lack an origin.
//!
//! `cases` observes which case an exit returns, for `scalars` and
//! `result_domains`. `result_domains` also exports `exact_scalar_membership`
//! to the nominal input and field write checks, and domain queries used by
//! flow facts, fact construction, content checks and proof.

use checked_trees::{CheckFacts, FlowStateFact};
use diagnostics::Diagnostic;

use super::prover::semantic_contexts_prove_contract_fact;
use crate::labels::{machine_name, semantic_fact_requirement_label};

mod cases;
mod cyclic_headers;
mod result_domains;
pub(crate) use result_domains::exact_scalar_membership;
mod scalars;
pub(super) use scalars::BoundaryRefutations;

pub(super) use cyclic_headers::CyclicHeaderInvariants;
pub(super) use result_domains::{
    check_exclusive_referent_field_domains, check_result_field_domains,
    check_scalar_result_domains, check_state_transfer_result_domains,
};
pub(crate) use result_domains::{
    exclusive_referent_type, is_readable_mutable_reference, value_provable_domain,
};

fn direct_result_float_meaning_reflexivity_proves_exit(
    facts: &CheckFacts,
    machine_symbol: symbols::SymbolHandle,
    fact: &facts::Fact,
) -> bool {
    let facts::FactPayload::ContractBooleanExpression { expression, .. } = fact.payload else {
        return false;
    };
    facts
        .proof
        .direct_result_float_meaning_reflexivity(machine_symbol, expression)
        .is_some()
}

/// A helper theorem over collections: the machine's own `requires`,
/// including collection-predicate premises explored through the predicate's
/// checked body, prove the `ensures` expression on every normal exit. Supported
/// stores retain distinct arrival/current versions; unknown effects stand down.
fn collection_premises_prove_exit(
    program: &dyn ::validation::CheckingInput,
    state_flow: &FlowStateFact,
    fact: &facts::Fact,
) -> bool {
    let facts::FactPayload::ContractBooleanExpression { expression, .. } = fact.payload else {
        return false;
    };
    program
        .machine(state_flow.machine_symbol)
        .is_some_and(|machine| validation::premises_prove_expression(program, machine, expression))
}

/// Whether one exit's live facts prove a scalar postcondition: the entry
/// contexts prove the predicate, or the exit's exact return and current scalar
/// or live place values evaluate it. Ordinary exit checking and package exit
/// evidence share these routes, alongside separately rechecked component
/// induction. Callers must establish exact invocation origins before using this
/// helper; it grants no assumption, entailment or invariant authority.
pub(super) fn live_contexts_prove_scalar_postcondition<'program>(
    program: &'program dyn ::validation::CheckingInput,
    facts: &CheckFacts,
    exit_flow: &checked_trees::FlowExitFact,
    entry_contexts: &[facts::FactContextHandle],
    fact: &facts::Fact,
    call_frames: Option<&validation::CallFrameResolver<'program>>,
    cached_exit_values: &mut Option<
        Option<(
            &'program typed_trees::machine::Machine,
            crate::checks::current_scalar_values::CurrentScalarValues<'program>,
            typed_trees::expression::ExpressionHandle,
        )>,
    >,
) -> bool {
    matches!(
        fact.payload,
        facts::FactPayload::ContractBooleanExpression { .. }
    ) && (semantic_contexts_prove_contract_fact(
        program,
        facts,
        facts::ProgramPoint::Statement {
            machine_symbol: exit_flow.machine_symbol,
            state_symbol: exit_flow.state_symbol,
            statement_index: exit_flow.statement_index,
        },
        entry_contexts,
        fact,
    ) || super::current_values::proves_exit(
        program,
        facts,
        exit_flow,
        fact,
        call_frames,
        cached_exit_values,
    ) || scalars::proves(program, facts, exit_flow, entry_contexts, fact, call_frames))
}

pub(super) fn check_exit_ensures(
    program: &dyn ::validation::CheckingInput,
    facts: &CheckFacts,
    state_flow: &FlowStateFact,
    exit_flow: &checked_trees::FlowExitFact,
    entailment: &super::entailment::MachineEntailmentOutcome,
    content_plans: &[validation::ContentConservationSourcePlan],
    call_frames: Option<&validation::CallFrameResolver<'_>>,
    cyclic_headers: &mut CyclicHeaderInvariants,
    recipe_obligations: &mut Vec<checked_trees::ConstantRecipeObligation>,
    integer_range_obligations: &mut Vec<checked_trees::IntegerRangeObligation>,
    diagnostics: &mut Vec<Diagnostic>,
) {
    let entry_contexts: Vec<_> = facts
        .flow
        .contexts
        .semantic_context_refs
        .span_or_empty(exit_flow.entry_semantic_contexts)
        .iter()
        .map(|context_ref| context_ref.context)
        .collect();
    let mut cached_exit_values = None;
    for ensures_context in facts
        .flow
        .semantic_constraint_contexts(exit_flow.ensures_constraints)
    {
        let context = facts.semantic.contexts.get(ensures_context);
        for fact in facts.semantic.context_view(context).facts() {
            let contract = match fact.payload {
                facts::FactPayload::ContractBooleanExpression { fact, .. }
                | facts::FactPayload::ContractDomainMembership { fact, .. }
                | facts::FactPayload::ContractCarryPermission { fact, .. }
                | facts::FactPayload::ContractPropositionApplication { fact, .. } => Some(fact),
                _ => None,
            };
            // An owner-authorized boundary result is established at the admitted
            // crossing. Its checked adapter does not originate that authority;
            // direct calls already refuse this authorization in call_contract_evidence.
            // Authored adapter guarantees have no such record and remain obligations.
            let admitted_boundary_result = facts.proof.contract_facts.iter().any(|(_, inherited)| {
                inherited.kind == checked_trees::ContractProofFactKind::Ensures
                    && Some(inherited.fact) == contract
                    && inherited.qualification_authorization.is_some()
                    && matches!(
                        inherited.owner,
                        checked_trees::ContractProofFactOwner::MachineState { machine_symbol, state_symbol }
                            if machine_symbol == state_flow.machine_symbol
                                && state_symbol == state_flow.state_symbol
                    )
            });
            if admitted_boundary_result {
                continue;
            }
            let checked_entailment = match fact.payload {
                facts::FactPayload::ContractBooleanExpression { expression, .. } => {
                    entailment.expressions.contains(&expression)
                }
                _ => false,
            };
            if checked_entailment {
                continue;
            }
            // Named witness-bearing `ensures` lanes are discharged by the
            // separate evidence-forwarding proof pass. That pass validates
            // exact term identity, proposition/interface agreement,
            // single-assignment, and definite assignment on every exit; the
            // ordinary semantic prover has no runtime witness fact to consume.
            let evidence_assignment = match fact.payload {
                facts::FactPayload::ContractPropositionApplication {
                    fact: source_fact, ..
                } => facts.proof.contract_facts.iter().any(|(_, contract)| {
                    contract.kind == checked_trees::ContractProofFactKind::Ensures
                        && contract.owner
                            == (checked_trees::ContractProofFactOwner::Machine {
                                machine_symbol: state_flow.machine_symbol,
                            })
                        && contract.fact == source_fact
                        && contract.evidence_term.is_some()
                }),
                _ => false,
            };
            if evidence_assignment {
                continue;
            }
            let missing_origins = facts
                .flow
                .control
                .exit_parameter_origins
                .span_or_empty(exit_flow.parameter_origins)
                .iter()
                .filter(|origin| {
                    Some(origin.contract) == contract
                        && !origin.state_parameter.is_valid()
                        && !origin.retained_referent_type.is_valid()
                })
                .map(|origin| program.symbols.name(origin.entry_parameter))
                .collect::<Vec<_>>();
            let mut proved_cache = None;
            let mut is_proved = || {
                *proved_cache.get_or_insert_with(|| {
                    if matches!(
                        fact.payload,
                        facts::FactPayload::ContractBooleanExpression { .. }
                    ) {
                        live_contexts_prove_scalar_postcondition(
                            program,
                            facts,
                            exit_flow,
                            &entry_contexts,
                            fact,
                            call_frames,
                            &mut cached_exit_values,
                        )
                    } else {
                        semantic_contexts_prove_contract_fact(
                            program,
                            facts,
                            facts::ProgramPoint::Statement {
                                machine_symbol: exit_flow.machine_symbol,
                                state_symbol: exit_flow.state_symbol,
                                statement_index: exit_flow.statement_index,
                            },
                            &entry_contexts,
                            fact,
                        )
                    }
                })
            };
            let satisfied = (missing_origins.is_empty()
                && (is_proved()
                    || result_domains::proves_result_domain(
                        program,
                        facts,
                        exit_flow,
                        &entry_contexts,
                        fact,
                    )
                    || super::content_preservation::proves_exit(
                        program,
                        facts,
                        state_flow,
                        exit_flow,
                        fact,
                        content_plans,
                    )
                    || crate::checks::content::proves_composed_exit(
                        facts, exit_flow, fact, content_plans,
                    )
                    || super::integer_embeddings::proves_exit_equality(
                        program, state_flow, exit_flow, fact,
                    )
                    || super::integer_embeddings::proves_embedded_literal_exit(
                        program, state_flow, exit_flow, fact,
                    )
                    || direct_result_float_meaning_reflexivity_proves_exit(
                        facts,
                        state_flow.machine_symbol,
                        fact,
                    )
                    || super::entailment::integral_parameter_reflexivity(program, fact)
                    || super::entailment::transparent_proposition_proves_exit(
                        program, facts, entailment, state_flow, fact,
                    )
                    || collection_premises_prove_exit(program, state_flow, fact)
                    || {
                        // Issuer authority establishes the exact returned subject. It
                        // cannot discharge an otherwise unproved guarantee about an input,
                        // even when the same declaration also issues a qualified result.
                        let authorized_route = match fact.payload {
                            facts::FactPayload::ContractDomainMembership {
                                domain_symbol,
                                value,
                                ..
                            } => validation::reserved_result_owner(program, value).is_some_and(
                                |(owner, _)| {
                                    if owner != state_flow.machine_symbol
                                        && owner != state_flow.state_symbol
                                    {
                                        return false;
                                    }
                                    program.machine(state_flow.machine_symbol).is_some_and(
                                        |machine| {
                                            crate::facts::qualification_evidence::machine_has_checked_domain_establishment(
                                                program,
                                                machine,
                                                domain_symbol,
                                            )
                                        },
                                    )
                                },
                            ),
                            _ => false,
                        };
                        authorized_route
                            && match fact.payload {
                                facts::FactPayload::ContractDomainMembership {
                                    domain_symbol,
                                    ..
                                } => program.domain_definition(domain_symbol).is_none_or(
                                    |domain| !domain.predicate_body.is_present() || is_proved(),
                                ),
                                _ => true,
                            }
                    }))
                // A re-entered parameter has no exact origin, so every route
                // above is vetoed; a proved header invariant is the guarantee
                // itself at the header and needs no origin.
                || cyclic_headers.proves(program, facts, exit_flow, fact);

            if !satisfied
                && missing_origins.is_empty()
                && let Some(conditions) = scalars::proves_with_recipe_conditions(
                    program,
                    facts,
                    exit_flow,
                    &entry_contexts,
                    fact,
                    call_frames,
                )
            {
                recipe_obligations.extend(conditions);
                continue;
            }
            if !satisfied
                && missing_origins.is_empty()
                && let Some(conditions) = scalars::proves_with_range_conditions(
                    program,
                    facts,
                    exit_flow,
                    &entry_contexts,
                    fact,
                    call_frames,
                )
            {
                integer_range_obligations.extend(conditions);
                continue;
            }
            if !satisfied {
                let origin_diagnostic = if missing_origins.is_empty() {
                    String::new()
                } else {
                    format!(
                        "; no exact incoming reference origin for {}",
                        missing_origins.join(", ")
                    )
                };
                diagnostics.push(Diagnostic::error(format!(
                    "cannot prove ensures contract for exit from {} at statement {}: {}{}",
                    machine_name(program, state_flow.machine_symbol),
                    exit_flow.statement_index,
                    semantic_fact_requirement_label(program, &facts.semantic, fact),
                    origin_diagnostic,
                )));
            }
        }
    }
}
