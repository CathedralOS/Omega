//! Contract checks: each call's `requires`, each exit's `ensures`, each
//! self-transition arrival requirement and each write into a domain-refined
//! field must be proved from the checked facts at that point.
//!
//! Two entries, both called by
//! `checks::check_checked_facts_recording`:
//! `bind_call_evidence_arguments` runs first among the checks and binds the
//! evidence arguments of contract expressions and calls into the proof facts
//! (`evidence`); `check_flow_call_contracts` runs after the borrow check.
//!
//! `check_flow_call_contracts` builds the content conservation plans and the
//! declared field requirements of nominal parameters (`nominal_inputs`),
//! checks every state's `asm` requires and ensures assertions (`assembly`),
//! and prepares the cyclic header invariants (`exits`). The checks entry owns
//! the exit entailment cache (`entailment`), shared with content composition
//! so both consumers use the same preserved positive judgments. This check
//! then walks each state's flow:
//!
//! 1. for each call: the scalar tail result domains (`exits`) and the call's
//!    requirements (`calls`, which also checks the nominal inputs);
//! 2. for each exit: the scalar result domains, the `ensures` clauses, the
//!    result field domains and the field domains of readable `&mut`
//!    referents (`exits`);
//! 3. writes into domain-refined fields (`writes`).
//!
//! The other children are not steps. `prover` decides whether fact contexts
//! prove a Boolean expression or a contract fact, and reaches `direct`,
//! `domains` and `evaluator`. `calls` also consults `call_bounds`,
//! `guard_operands`, `intervals` and `reference_domains`; `exits` consults
//! `content_preservation` and `integer_embeddings`; both consult
//! `entailment`. `labels`, `places` and `return_values` are shared
//! vocabulary: contract labels, place matching and exit return occurrences.

// The steps: evidence binding, and the checks `check_flow_call_contracts`
// runs.
mod argument_intervals;
mod assembly;
pub(crate) mod calls;
pub(crate) mod contextual_cleanup;
mod evidence;
mod exits;

mod nominal_inputs;
mod writes;

// The fact-context prover and the provers it reaches.
mod direct;
mod domains;
mod evaluator;
pub(in crate::checks) mod prover;
pub(crate) use prover::boolean_value_at_place;
pub(crate) use prover::call_guarantees::captured_place as captured_guarantee_place;
pub(crate) use prover::call_guarantees::current_predicates as current_call_guarantee_predicates;
pub(crate) use prover::call_guarantees::{GuaranteeUse, proves_captured_predicates};
pub(crate) use prover::contexts_prove_proposition_label;

// Provers the call requirement and exit checks consult directly.
mod call_bounds;
mod captured_predicates;
pub(crate) use captured_predicates::cleanup_predicates;
pub(crate) mod call_values;
mod capture_coordinates;
mod content_preservation;
mod current_values;
mod entailment;
pub(super) use entailment::ProvenExitExpressions;
mod float_predicate_domains;
mod guard_operands;
mod integer_embeddings;
mod intervals;
mod reference_domains;

// Shared vocabulary: contract labels, place matching and exit return
// occurrences.
// `pub(super)` so the operator-`requires` discharge (checks/operators) can
// reuse the domain-derived boolean proving labels.
pub(crate) mod labels;
mod places;
mod return_values;

use calls::check_call_requires;
use checked_trees::CheckFacts;
use diagnostics::Diagnostic;
pub(crate) use evaluator::call_site_boolean_contract_expression_value;
pub(crate) use evidence::{
    exact_target_evidence_parameters, instantiate_contract_expression_evidence_parameter,
};
pub(crate) use exits::exact_scalar_membership;
use exits::{CyclicHeaderInvariants, check_exit_ensures};
pub(crate) use exits::{
    exclusive_referent_type, is_readable_mutable_reference, value_provable_domain,
};
use writes::check_domain_field_writes;

pub(super) struct ContractDecisions {
    pub(super) scalar_returns: Vec<checked_trees::CheckedScalarReturnQualification>,
    pub(super) constant_obligations: Vec<checked_trees::ConstantPredicateObligation>,
    pub(super) recipe_obligations: Vec<checked_trees::ConstantRecipeObligation>,
    pub(super) integer_range_obligations: Vec<checked_trees::IntegerRangeObligation>,
    pub(super) call_requires: Vec<checked_trees::DecidedCallRequires>,
    pub(super) value_qualifications: arena::Arena<checked_trees::CheckedValueQualification>,
}

pub(super) fn check_flow_call_contracts(
    program: &dyn ::validation::CheckingInput,
    facts: &CheckFacts,
    incoming_guards: &crate::checks::ranges::incoming_guards::IncomingGuardIndex,
    call_frames: Option<&validation::CallFrameResolver<'_>>,
    entailment: &mut ProvenExitExpressions<'_, '_>,
    expression_intervals: &[validation::ExpressionInterval],
) -> Result<ContractDecisions, Vec<Diagnostic>> {
    let mut diagnostics = phase_profile::scope("05.d.7.3b.0.cleanup_requirements", || {
        crate::facts::contextual_cleanup::check_cleanup_requirements(program, facts)
    });
    let mut decided = Vec::new();
    let mut scalar_returns = Vec::new();
    let mut constant_obligations = Vec::new();
    let mut recipe_obligations = Vec::new();
    let mut integer_range_obligations = Vec::new();
    let mut value_qualifications = arena::Arena::default();
    let constructor_memberships = writes::ConstructorMemberships::new(facts);
    let content_plans = validation::content_conservation_plans(program);
    let nominal_requirements = nominal_inputs::DeclaredFieldRequirements::new(&facts.semantic);
    let mut owned_call_frames = None;
    let call_frames =
        crate::flow::shared_call_frames_or(call_frames, program, &mut owned_call_frames);

    phase_profile::scope("05.d.7.3b.0b.assembly_and_refutations", || {
        assembly::check_assembly_fact_contracts(program, facts, &mut diagnostics);
    });

    // Mathematical applications owe the same substituted premises as runtime
    // calls, even when their result is erased or no guarantee is consumed.
    // Recursive descent establishes termination, not a call's preconditions.
    let proof_only = validation::proof_only_classification(program);
    let mut cyclic_headers = CyclicHeaderInvariants::new();
    let boundary_refutations = exits::BoundaryRefutations::new(program);
    // Call targets carry the callee's ENTRY-STATE symbol (sub-state targets
    // carry that state's); resolve through states as well as the machine
    // symbol itself.
    let is_proof_machine = |symbol: symbols::SymbolHandle| {
        program
            .machine_by_own_or_state_symbol(symbol)
            .is_some_and(|machine| proof_only.is_proof_machine(program, machine))
    };

    static STRUCT_TRACE: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    let struct_trace =
        *STRUCT_TRACE.get_or_init(|| std::env::var_os("OMEGA_STRUCT_TRACE").is_some());
    let has_activation_claim = program
        .data_definitions()
        .iter()
        .any(|data| validation::activation_claim_byte_carrier(program, data.symbol).is_some());

    for (_, state_flow) in facts.flow.control.states.iter() {
        let caller_is_proof = struct_trace && is_proof_machine(state_flow.machine_symbol);
        for call_flow in facts.flow.control.calls.span_or_empty(state_flow.calls) {
            if struct_trace {
                eprintln!(
                    "CALLREQ caller={} proof={} target={} proof={}",
                    crate::labels::machine_name(program, state_flow.machine_symbol),
                    caller_is_proof,
                    crate::labels::call_target_label(program, call_flow.target_symbol),
                    is_proof_machine(call_flow.target_symbol),
                );
            }
            let _s = phase_profile::guard("05.d.7.3b.1.calls");
            exits::check_state_transfer_result_domains(
                program,
                state_flow,
                call_flow,
                &mut diagnostics,
            );
            let before = diagnostics.len();
            check_call_requires(
                program,
                facts,
                state_flow,
                call_flow,
                &nominal_requirements,
                incoming_guards.for_machine(state_flow.machine_symbol),
                expression_intervals,
                call_frames,
                &mut constant_obligations,
                &mut recipe_obligations,
                &mut value_qualifications,
                &mut diagnostics,
            );
            // Every fact is proved here or retained as a constant obligation
            // that target closure must discharge before Terminal production.
            if diagnostics.len() == before
                && let Ok(statement_index) = u32::try_from(call_flow.statement_index)
            {
                decided.push(checked_trees::DecidedCallRequires {
                    state: state_flow.state_symbol,
                    statement_index,
                    target: call_flow.target_symbol,
                });
            }
        }
        for exit_flow in facts.flow.control.exits.span_or_empty(state_flow.exits) {
            let _s = phase_profile::guard("05.d.7.3b.2.exits");
            if has_activation_claim {
                phase_profile::scope("05.d.7.3b.2.exits.a.activation_return", || {
                    return_values::check_activation_return(
                        program,
                        facts,
                        state_flow,
                        exit_flow,
                        &mut diagnostics,
                    )
                });
            }
            phase_profile::scope("05.d.7.3b.2.exits.b.boundary_refutations", || {
                boundary_refutations.check(program, facts, exit_flow, call_frames, &mut diagnostics)
            });
            phase_profile::scope("05.d.7.3b.2.exits.c.scalar_result_domains", || {
                exits::check_scalar_result_domains(
                    program,
                    facts,
                    exit_flow,
                    &mut scalar_returns,
                    &mut diagnostics,
                )
            });
            phase_profile::scope("05.d.7.3b.2.exits.d.exit_ensures", || {
                check_exit_ensures(
                    program,
                    facts,
                    state_flow,
                    exit_flow,
                    entailment.for_machine(facts, state_flow.machine_symbol),
                    &content_plans,
                    call_frames,
                    &mut cyclic_headers,
                    &mut recipe_obligations,
                    &mut integer_range_obligations,
                    &mut diagnostics,
                )
            });
            // An owned nominal result also owes its declared field predicates
            // on the returned value itself -- enforced here so a caller may
            // consume them from the signature (flow/calls.rs).
            let exit_diagnostics = diagnostics.len();
            phase_profile::scope("05.d.7.3b.2.exits.e.result_field_domains", || {
                exits::check_result_field_domains(
                    program,
                    facts,
                    state_flow,
                    exit_flow,
                    call_frames,
                    &mut diagnostics,
                )
            });
            // The return hands every readable `&mut` referent back to the
            // caller, so the field facts it assumed on entry are due again.
            // A reference return into that referent names the same place
            // twice; report each exact place once per exit.
            phase_profile::scope(
                "05.d.7.3b.2.exits.f.exclusive_referent_field_domains",
                || {
                    exits::check_exclusive_referent_field_domains(
                        program,
                        facts,
                        exit_flow,
                        &mut diagnostics,
                    )
                },
            );
            let mut reported = Vec::new();
            for diagnostic in diagnostics.split_off(exit_diagnostics) {
                if !reported.contains(&diagnostic) {
                    reported.push(diagnostic);
                }
            }
            diagnostics.extend(reported);
        }
        // #66 write-enforcement: every assignment into a domain-refined field must
        // establish the value in that domain (the soundness floor for trusting the
        // field's declared domain on read).
        let _s = phase_profile::guard("05.d.7.3b.3.writes");
        check_domain_field_writes(
            program,
            facts,
            &constructor_memberships,
            state_flow,
            call_frames,
            &mut value_qualifications,
            &mut diagnostics,
        );
    }

    if diagnostics.is_empty() {
        writes::check_routed_cast_coverage(program, &value_qualifications, &mut diagnostics);
    }
    if diagnostics.is_empty() {
        Ok(ContractDecisions {
            scalar_returns,
            constant_obligations,
            recipe_obligations,
            integer_range_obligations,
            call_requires: decided,
            value_qualifications,
        })
    } else {
        Err(diagnostics)
    }
}

pub(crate) fn bind_call_evidence_arguments(
    program: &dyn ::validation::CheckingInput,
    facts: &mut CheckFacts,
) -> Result<(), Vec<Diagnostic>> {
    let mut diagnostics = Vec::new();
    evidence::bind_contract_expression_evidence_arguments(program, facts, &mut diagnostics);
    evidence::bind_call_evidence_arguments(program, facts, &mut diagnostics);
    if diagnostics.is_empty() {
        Ok(())
    } else {
        Err(diagnostics)
    }
}
