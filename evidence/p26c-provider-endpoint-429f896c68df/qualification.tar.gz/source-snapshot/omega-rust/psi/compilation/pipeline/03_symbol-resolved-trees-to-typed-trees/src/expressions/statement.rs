//! Typing of one statement in a state body.
//!
//! `lower_statement_node` is called by `declarations::state` for each
//! statement of a state. That caller handles proof-output binding statements
//! itself, so they never reach this function. It dispatches on the statement
//! kind:
//!
//! - root bindings, assembly facts (`requires`/`ensures`), assignments and
//!   expression statements lower their expressions through `arguments`;
//! - calls go to `calls`;
//! - transitions go to `transitions`, with `closes_run` true at the retained
//!   authored dispatch boundary or when the next statement is not a transition;
//! - local data lowers its written type with
//!   `lower_type_reference_handle_from_table`. An inferred local whose
//!   declared type is the `Unit` sentinel, and whose initializer is not a
//!   pattern marker, first asks `hoist_temp_type` for a type derived from its
//!   initializer.

mod arguments;
mod calls;
mod hoist_temp_type;
mod root_bindings;
mod transitions;

use crate::lowerer::Lowerer;
use crate::type_reference::lower_type_reference_handle_from_table;
use diagnostics::Diagnostic;
use symbol_resolved_trees as resolved;
use typed_trees as typed;

use self::arguments::lower_statement_expression;
use self::calls::lower_call_statement;
use self::hoist_temp_type::infer_hoist_temp_type;
use self::transitions::lower_transition_statement;
mod assembly;

/// One source operation can introduce a whole lexical instruction window.
/// The enclosing producer inserts the complete window contiguously.
pub(crate) fn lower_statement(
    lowerer: &mut Lowerer,
    attached_data: Option<&resolved::name::DiagnosticName>,
    state: &resolved::state::State,
    statement: &resolved::statement::StatementNode,
    closes_run: bool,
) -> Result<Vec<typed::statement::StatementNode>, Diagnostic> {
    if let resolved::statement::StatementNode::Assembly(handle) = statement {
        assembly::lower(lowerer, attached_data, state, *handle)
    } else {
        lower_statement_node(lowerer, attached_data, state, statement, closes_run)
            .map(|statement| vec![statement])
    }
}

/// `closes_run` says this statement ends its authored dispatch.
fn lower_statement_node(
    lowerer: &mut Lowerer,
    attached_data: Option<&resolved::name::DiagnosticName>,
    state: &resolved::state::State,
    statement: &resolved::statement::StatementNode,
    closes_run: bool,
) -> Result<typed::statement::StatementNode, Diagnostic> {
    match statement {
        resolved::statement::StatementNode::Assembly(_) => Err(Diagnostic::error(
            "assembly typing requires its complete enclosing statement window",
        )),
        resolved::statement::StatementNode::RootBinding(binding) => {
            root_bindings::lower(lowerer, binding)
        }
        resolved::statement::StatementNode::AssemblyFact(fact) => Ok(
            typed::statement::StatementNode::AssemblyFact(typed::statement::TableAssemblyFact {
                kind: match fact.kind {
                    resolved::statement::AssemblyFactKind::Requires => {
                        typed::statement::AssemblyFactKind::Requires
                    }
                    resolved::statement::AssemblyFactKind::Ensures => {
                        typed::statement::AssemblyFactKind::Ensures
                    }
                },
                fact: crate::contracts::proof_facts::lower_statement_fact(
                    lowerer,
                    fact.expression,
                )?,
            }),
        ),
        resolved::statement::StatementNode::Assignment(assignment) => Ok(
            typed::statement::StatementNode::Assignment(typed::statement::TableAssignment {
                target: lower_statement_expression(lowerer, assignment.target)?,
                value: lower_statement_expression(lowerer, assignment.value)?,
                receiving_type: typed::types::TypeReferenceHandle::invalid(),
            }),
        ),
        resolved::statement::StatementNode::Call(call)
            if call.target.as_str() == "code_layout"
                && !call.target_symbol.is_valid()
                && call.receiver.is_empty() =>
        {
            let mut request = crate::expressions::expression::native_code_layout::lower_request(
                Some(lowerer.source_trees),
                &mut lowerer.typed_trees,
                lowerer.type_reference_exposure,
                &call.machine_arguments,
                call.arguments.len(),
                call.evidence_arguments.len(),
            )?;
            request.discards_result = true;
            let result = crate::expressions::expression::native_code_layout::result_type(
                Some(lowerer.source_trees),
                &mut lowerer.typed_trees,
            )?;
            let expression = lowerer.typed_trees.expression_table.insert(
                typed::expression::ExpressionNode::Call(typed::expression::TableCallExpression {
                    authored_machine_application: Default::default(),
                    exact_coercion_target: Default::default(),
                    requirement_application: Default::default(),
                    receiver: Default::default(),
                    target_symbol: Default::default(),
                    static_machine_parameter: Default::default(),
                    target: crate::lowerer::name::lower_name(&call.target),
                    static_requirement_dispatch: None,
                    machine_arguments: Box::default(),
                    quotient_operation: None,
                    private_layout_operation: None,
                    layout_query: None,
                    native_code_layout: Some(request),
                    build_selection: Default::default(),
                    arguments: Default::default(),
                    evidence_arguments: Box::default(),
                    operational_acknowledgement: call.operational_acknowledgement,
                }),
            );
            lowerer
                .typed_trees
                .expression_table
                .set_constructed_value_type_reference(expression, result);
            lowerer
                .typed_trees
                .expression_table
                .set_source_span(expression, call.target.source_span());
            Ok(typed::statement::StatementNode::Expression(expression))
        }
        resolved::statement::StatementNode::Call(call) => lower_call_statement(lowerer, call),
        resolved::statement::StatementNode::ProofOutputBindingStatement(_) => {
            unreachable!("evidence packages are classified out before runtime statement lowering")
        }
        resolved::statement::StatementNode::Expression(expression) => {
            Ok(typed::statement::StatementNode::Expression(
                lower_statement_expression(lowerer, *expression)?,
            ))
        }
        resolved::statement::StatementNode::LocalData(local_data) => {
            // A hoist temp (`let __hoist_N = self.arr[i];`) is lowered with a
            // `Unit` type by the operand-hoisting normalization, the inference
            // sentinel. Fill in the element type (carrying the collection's
            // arithmetic domain) from the indexed-read initializer now that the
            // resolved data-field types are available -- the language has no
            // local type inference, so the temp needs a concrete declared type
            // for its place/domain/range/layout. Other locals lower as written.
            let declared_is_unit = matches!(
                lowerer
                    .source_trees
                    .tables
                    .types
                    .references
                    .type_reference(local_data.type_reference),
                resolved::types::TypeReferenceNode::Unit
            );
            // Resolution retains whether the binding had an annotation. A
            // source-authored `()` is not an inference sentinel; destructured
            // and proof-output bindings may have authored names but no type.
            // Pattern coverage is metadata about a place, not a snapshot that
            // moves it. Parsing retains that role across copies; computed
            // subject captures and per-field bindings remain ordinary values.
            let type_reference = if declared_is_unit
                && local_data.initial_value.is_valid()
                && local_data.type_is_inferred
                && local_data.role == language_core::LocalBindingRole::Value
            {
                infer_hoist_temp_type(lowerer, attached_data, state, local_data.initial_value)?
            } else {
                None
            };
            let type_reference = match type_reference {
                Some(type_reference) => type_reference,
                None => lower_type_reference_handle_from_table(lowerer, local_data.type_reference)?,
            };
            Ok(typed::statement::StatementNode::LocalData(
                typed::statement::TableLocalData {
                    role: local_data.role,
                    symbol: local_data.symbol,
                    name: crate::lowerer::name::lower_name(&local_data.name),
                    type_reference,
                    initial_value: local_data
                        .initial_value
                        .is_valid()
                        .then(|| lower_statement_expression(lowerer, local_data.initial_value))
                        .transpose()?
                        .unwrap_or_else(typed::expression::ExpressionHandle::invalid),
                    is_mutable: local_data.is_mutable,
                    type_is_inferred: local_data.type_is_inferred,
                    is_operand_capture: local_data.is_operand_capture,
                    relevance: local_data.relevance,
                },
            ))
        }
        resolved::statement::StatementNode::Transition(transition) => {
            Ok(typed::statement::StatementNode::Transition(
                lower_transition_statement(lowerer, transition, closes_run)?,
            ))
        }
    }
}
