//! Admission of supplied operator semantics against the current typed graph.
//! Omega retains provider authority; Psi independently checks the exact authored
//! selection, operand carrier and operation before allowing semantic execution.
//! The private execution graph substitutes implementation bodies, but retains
//! the original declaration selection for package authority and const replay.
use crate::SelectedBuildTimeBinaryOperator;
use typed_trees::{
    TypedTrees,
    expression::{ExpressionHandle, ExpressionNode},
};

/// One selected boundary-requirement use whose meaning is the selected provider's
/// ordinary checked machine body. Omega supplies the exact provider from its
/// settled ProviderPlan; Psi prepares the execution row and independently
/// rechecks the exact authored selection, operand custody, provider ownership,
/// and executable entry before binding it. Execution never fabricates a
/// result: [`prepare_selected_execution`] rebinds the authored expression
/// to the exact provider entry state on a private evaluation copy -- the same
/// ordinary call shape checked-side settlement publishes -- so the checked
/// interpreter runs the real provider body and the caller's result is
/// installed only after the provider returns.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SelectedBuildTimeProviderBody {
    /// The authored operator expression or its normalized requirement call.
    pub expression: ExpressionHandle,
    /// The checked value origin that owned the selection when it was derived.
    pub origin: checked_trees::CheckedValueOrigin,
    /// The selected boundary requirement symbol.
    pub requirement: symbols::SymbolHandle,
    /// The authored operand expressions forwarded to the provider entry state
    /// in their authored order.
    pub operands: Vec<ExpressionHandle>,
    /// The exact selected provider machine symbol.
    pub provider_machine: symbols::SymbolHandle,
    /// The provider's executable entry state symbol.
    pub provider_state: symbols::SymbolHandle,
    /// The nominal provider type the settled plan owns.
    pub provider_type: String,
    /// Exact selecting declaration, independent of the realization's code owner.
    pub provider_declaration: symbols::SymbolHandle,
    /// Capsule under which Omega selected this realization.
    pub target_scope: String,
    /// The settled ProviderPlan commitment; never a name or fingerprint alone.
    pub provider: checked_trees::CheckedProviderPlanCommitment,
}

impl SelectedBuildTimeProviderBody {
    /// Prepare a candidate execution row from the exact provider selected by
    /// Omega. This derives source operands and the provider entry, never a
    /// provider choice. The independent validator below must still rejoin the
    /// source use, signature, conformance, and supplied plan commitment before
    /// this row can execute.
    pub fn prepare(
        program: &TypedTrees,
        expression: ExpressionHandle,
        origin: checked_trees::CheckedValueOrigin,
        requirement: symbols::SymbolHandle,
        provider: &typed_trees::machine::Machine,
        provider_type: String,
        provider_declaration: symbols::SymbolHandle,
        provider_package: Option<semantic_vocabulary::PackageKeyIdentity>,
        target_scope: &str,
        commitment: checked_trees::CheckedProviderPlanCommitment,
    ) -> Result<Self, String> {
        let operands = match program.expression_table.expression(expression) {
            ExpressionNode::Binary(binary) => vec![binary.left, binary.right],
            ExpressionNode::Indexed(indexed) => vec![indexed.collection, indexed.index],
            ExpressionNode::Call(call) => program
                .expression_table
                .expression_handles(call.arguments)
                .to_vec(),
            _ => {
                return Err(
                    "selected build-time provider expression has no callable operands".into(),
                );
            }
        };
        let Some(entry) = program.machine_states(provider).first() else {
            return Err("selected build-time provider has no executable entry state".into());
        };
        if !provider_declaration.is_valid()
            || program.symbols.display_path(provider_declaration, "::") != provider_type
            || program
                .symbols
                .symbol_package_identity(provider_declaration)
                != provider_package
            || (program
                .conformance_by_symbol(provider_declaration)
                .is_none()
                && !program
                    .data_definitions()
                    .iter()
                    .any(|owner| owner.symbol == provider_declaration))
            || target_scope.is_empty()
        {
            return Err(
                "selected build-time provider has ambiguous declaration or absent target custody"
                    .into(),
            );
        }
        Ok(Self {
            expression,
            origin,
            requirement,
            operands,
            provider_machine: provider.symbol,
            provider_state: entry.symbol,
            provider_type,
            provider_declaration,
            target_scope: target_scope.to_owned(),
            provider: commitment,
        })
    }
}

/// Prepare selected checked-body calls and primitive Float operations on one
/// private evaluation copy, only when rewriting is necessary. The caller's tree is never rewritten:
/// the private program is the only thing admission and interpretation see, so
/// the provider body joins the ordinary call closure (termination, suspension,
/// blocking, linear carriers, and selection authority all apply unchanged) and
/// executes through `ExpressionNode::Call` like any other machine call.
pub(crate) fn prepare_selected_execution(
    program: &TypedTrees,
    selected: &[SelectedBuildTimeProviderBody],
    operators: &[SelectedBuildTimeBinaryOperator],
) -> Result<Option<TypedTrees>, String> {
    validate_selected_provider_bodies(program, selected)?;
    validate_selected_operators(program, operators)?;
    if operators.iter().any(|operator| {
        selected.iter().any(|body| {
            body.expression == operator.expression
                && body.origin.machine_symbol() == operator.origin.machine_symbol()
        })
    }) {
        return Err("selected build-time expression has competing executable supplies".into());
    }
    if selected.is_empty()
        && operators.iter().all(|row| {
            matches!(
                program.expression_table.expression(row.expression),
                ExpressionNode::Binary(_)
            )
        })
    {
        return Ok(None);
    }
    let mut program = program.clone();
    // The source selected a requirement, not its executable replacement. Both
    // supplied rosters were checked against that exact source occurrence above.
    // Retain that decision before replacing its syntax: re-checking a provider
    // call or a primitive binary cannot rediscover the original declaration.
    let mut selections = program.authored_declaration_selections().clone();
    for (expression, requirement) in selected
        .iter()
        .map(|row| (row.expression, row.requirement))
        .chain(
            operators
                .iter()
                .map(|row| (row.expression, row.requirement)),
        )
    {
        for occurrence in program
            .expression_table
            .authored_selection_occurrences(expression)
        {
            use language_semantics::declaration_selection::{
                AuthoredDeclarationSelectionLateBinding, AuthoredDeclarationSelectionTarget,
            };
            let selection = selections.get(occurrence).ok_or_else(|| {
                "selected build-time expression lost its authored selection".to_owned()
            })?;
            if let AuthoredDeclarationSelectionTarget::LateBound(
                binding @ (AuthoredDeclarationSelectionLateBinding::CheckedOperator
                | AuthoredDeclarationSelectionLateBinding::CheckedCall),
            ) = selection.target()
            {
                // An already-bound named call selects the requirement entry;
                // a checked operator selects its declaration. Keep the same
                // identity that ordinary source-call finalization would use.
                let target = match program.expression_table.expression(expression) {
                    ExpressionNode::Call(call)
                        if binding == AuthoredDeclarationSelectionLateBinding::CheckedCall
                            && call.target_symbol.is_valid() =>
                    {
                        call.target_symbol
                    }
                    _ => requirement,
                };
                selections
                    .finalize_late_bound(occurrence, binding, target)
                    .map_err(|error| {
                        format!("cannot retain selected build-time requirement: {error:?}")
                    })?;
            }
        }
    }
    program.retain_authored_declaration_selections(selections);
    for row in selected {
        let provider_name = program
            .machine(row.provider_machine)
            .map(|machine| machine.name.as_str().to_owned())
            .ok_or_else(|| "selected build-time provider body lost its exact machine".to_owned())?;
        let arguments = program
            .expression_table
            .insert_expression_handles(row.operands.iter().copied());
        *program.expression_table.expression_mut(row.expression) =
            ExpressionNode::Call(typed_trees::expression::TableCallExpression {
                authored_machine_application: Default::default(),
                requirement_application: Default::default(),
                exact_coercion_target: typed_trees::types::TypeReferenceHandle::invalid(),
                receiver: ExpressionHandle::invalid(),
                target_symbol: row.provider_state,
                static_machine_parameter: symbols::SymbolHandle::invalid(),
                target: typed_trees::name::Identifier::generated(provider_name),
                static_requirement_dispatch: None,
                machine_arguments: Box::new([]),
                quotient_operation: None,
                private_layout_operation: None,
                layout_query: None,
                    native_code_layout: None,
                    build_selection: Default::default(),
                arguments,
                evidence_arguments: Box::new([]),
                operational_acknowledgement:
                    language_semantics::CallOperationalAcknowledgement {
                        origin: language_semantics::CallOperationalAcknowledgementOrigin::CompilerSynthesized,
                        acknowledges_suspend: false,
                        acknowledges_block: false,
                    },
            });
    }
    // Named and normalized Float calls use the same interpreter kernel as
    // spelled uses. Preserve expression identity and authored selection records;
    // only the private execution graph loses the bodyless requirement call.
    for row in operators {
        *program.expression_table.expression_mut(row.expression) =
            ExpressionNode::Binary(typed_trees::expression::TableBinaryExpression {
                left: row.operands[0],
                operator: row.operation,
                right: row.operands[1],
            });
    }
    Ok(Some(program))
}

/// Independently check each supplied provider-body row against the current
/// typed graph. A stale, substituted, padded, or name-only row can never reach
/// execution: the authored use, the selected requirement, the exact provider
/// machine, its executable entry, its nominal owner, and its checked
/// conformance must all rejoin before the private call is formed.
/// Every selected row must name a non-empty provider whose
/// (expression, owning machine) pair is unique — the dedup both custody
/// checks run before counting occurrences. `None` means nothing was
/// selected at all.
fn require_unique_operator_custody<T>(
    program: &TypedTrees,
    selected: &[T],
    object: &str,
    custody: impl Fn(&T) -> Option<(ExpressionHandle, Option<symbols::SymbolHandle>)>,
) -> Result<Option<checked_trees::CheckedOperatorFacts>, String> {
    if selected.is_empty() {
        return Ok(None);
    }
    let facts = validation::derive_pre_flow_operator_selections(program);
    for (index, row) in selected.iter().enumerate() {
        let key = custody(row);
        if key.is_none() || selected[..index].iter().any(|prior| custody(prior) == key) {
            return Err(format!("{object} lacks unique exact provider custody"));
        }
    }
    Ok(Some(facts))
}

pub fn validate_selected_provider_bodies(
    program: &TypedTrees,
    selected: &[SelectedBuildTimeProviderBody],
) -> Result<(), String> {
    let Some(facts) = require_unique_operator_custody(
        program,
        selected,
        "selected build-time provider body",
        |row| (!row.provider.is_empty()).then_some((row.expression, row.origin.machine_symbol())),
    )?
    else {
        return Ok(());
    };
    for row in selected.iter() {
        // A provider body retains exactly one current use: a spelled
        // occurrence, named operator call or normalized requirement call.
        // The fact arenas are disjoint; duplicates across them still reject.
        let spelled_occurrences = facts
            .uses
            .iter()
            .filter(|(_, fact)| {
                fact.expression == row.expression
                    && fact.occurrence == checked_trees::CheckedOperatorOccurrence::Expression
                    && fact.origin.machine_symbol() == row.origin.machine_symbol()
            })
            .count();
        let named_occurrences = facts
            .named_uses
            .iter()
            .filter(|(_, fact)| {
                fact.expression == row.expression
                    && fact.origin.machine_symbol() == row.origin.machine_symbol()
            })
            .count();
        let requirement_occurrences = facts
            .named_requirement_uses()
            .filter(|fact| {
                fact.expression == row.expression
                    && fact.origin.machine_symbol() == row.origin.machine_symbol()
            })
            .count();
        if spelled_occurrences + named_occurrences + requirement_occurrences != 1 {
            return Err(
                "selected build-time expression is shared by distinct current origins".into(),
            );
        }
        let resolved_spelled: Vec<_> = facts
            .uses_with_status(checked_trees::CheckedOperatorResolutionStatus::Resolved)
            .filter(|fact| {
                fact.expression == row.expression
                    && fact.origin == row.origin
                    && fact.occurrence == checked_trees::CheckedOperatorOccurrence::Expression
            })
            .collect();
        let resolved_named: Vec<_> = facts
            .named_uses()
            .map(|fact| (fact.expression, fact.origin, fact.selected_operator_symbol))
            .chain(
                facts
                    .named_requirement_uses()
                    .map(|fact| (fact.expression, fact.origin, fact.requirement_symbol)),
            )
            .filter(|(expression, origin, _)| {
                *expression == row.expression && *origin == row.origin
            })
            .map(|(_, _, requirement)| requirement)
            .collect();
        // The spelled use additionally binds the authored token spelling; a
        // named call selected its requirement by exact path and arity, so it
        // carries no spelling to rejoin.
        let (selected_symbol, spelled_spelling) =
            match (resolved_spelled.as_slice(), resolved_named.as_slice()) {
                ([fact], []) => (fact.selected_operator_symbol, Some(fact.spelling)),
                ([], [requirement]) => (*requirement, None),
                _ => {
                    return Err(
                        "selected build-time provider body has no unique current use".into(),
                    );
                }
            };
        if selected_symbol != row.requirement {
            return Err(
                "selected build-time provider body differs from current requirement".into(),
            );
        }
        let operands = match program.expression_table.expression(row.expression) {
            ExpressionNode::Binary(binary) => vec![binary.left, binary.right],
            ExpressionNode::Indexed(indexed) => {
                match program.expression_table.expression(indexed.index) {
                    ExpressionNode::Range(_) => {
                        return Err(
                            "selected build-time provider use retains a range operand shape with no fixed-token checked-adapter dispatch"
                                .into(),
                        );
                    }
                    _ => vec![indexed.collection, indexed.index],
                }
            }
            // A named operator use is an ordinary call expression; its
            // argument list is the authored operand tuple.
            ExpressionNode::Call(call) => program
                .expression_table
                .expression_handles(call.arguments)
                .to_vec(),
            _ => return Err("selected build-time provider expression disappeared".into()),
        };
        if operands != row.operands {
            return Err(
                "selected build-time provider operands differ from current authored selection"
                    .into(),
            );
        }
        let providers: Vec<_> = program
            .machines()
            .iter()
            .filter(|machine| machine.symbol == row.provider_machine)
            .collect();
        let [provider] = providers.as_slice() else {
            return Err("selected build-time provider machine is not unique".into());
        };
        let named_provider = program.conformance_by_symbol(row.provider_declaration);
        if program.symbols.display_path(row.provider_declaration, "::") != row.provider_type
            || (named_provider.is_none()
                && (provider.attached_data_symbol != row.provider_declaration
                    || program.attached_data_path(provider).as_deref()
                        != Some(row.provider_type.as_str())))
        {
            return Err(
                "selected build-time provider does not belong to its nominal provider type".into(),
            );
        }
        if provider.supply_mode != language_semantics::MachineSupplyMode::CheckedBody {
            return Err("selected build-time provider is not a checked body".into());
        }
        if !program.machine_type_parameters(provider).is_empty() {
            return Err(
                "selected build-time provider is generic; closed substitution must settle the realization first"
                    .into(),
            );
        }
        let Some(entry) = program.machine_states(provider).first() else {
            return Err("selected build-time provider has no executable entry state".into());
        };
        if entry.symbol != row.provider_state {
            return Err(
                "selected build-time provider state is not the provider's executable entry".into(),
            );
        }
        if row.target_scope.is_empty()
            || program
                .machine_authored_target(provider)
                .is_some_and(|target| target != row.target_scope)
        {
            return Err("selected build-time provider belongs to another target capsule".into());
        }
        if program
            .machine_contracts(provider)
            .iter()
            .chain(program.state_contracts(entry).iter())
            .any(|contract| contract.is_crashes())
        {
            return Err(
                "selected build-time provider body crash contracts have no build-time execution support"
                    .into(),
            );
        }
        if let Some((owner, requirement)) = program.trait_machine_signature(row.requirement) {
            if !owner.is_boundary
                || spelled_spelling.is_some_and(|spelling| requirement.spelling != Some(spelling))
            {
                return Err(
                    "selected build-time trait requirement lost its exact boundary identity".into(),
                );
            }
            if !program.trait_type_parameters(owner).is_empty()
                || !requirement.type_parameters.is_empty()
            {
                return Err(
                    "selected build-time requirement needs its closed trait application".into(),
                );
            }
            if program
                .signature_contracts
                .span_or_empty(requirement.contracts)
                .iter()
                .any(|contract| contract.is_crashes())
            {
                return Err(
                    "selected operator crash invocations have no build-time execution support"
                        .into(),
                );
            }
            let parameters = program.state_parameters(entry);
            let required_parameters = program.state_signature_parameters(requirement);
            if parameters.len() != row.operands.len()
                || required_parameters.len() != row.operands.len()
                || program.normalized_type_identity(entry.return_type)
                    != program.normalized_type_identity(requirement.return_type)
                || !parameters
                    .iter()
                    .zip(required_parameters.iter())
                    .all(|(actual, required)| {
                        program.normalized_type_identity(actual.type_reference)
                            == program.normalized_type_identity(required.type_reference)
                    })
            {
                return Err("selected build-time provider entry signature differs from its trait requirement".into());
            }
            let bound = if let Some(declaration) = named_provider {
                // Named code owns a closed map, not an implicit data receiver.
                // Rejoin its exact requirement and entry. Ordinary checking of
                // the evaluation graph retains all conformance obligations.
                validation::revalidate_named_implementation(program, declaration)
                    .map_err(|diagnostics| format!("selected build-time implementation does not satisfy its contracts: {diagnostics:?}"))?;
                declaration
                    .rows
                    .iter()
                    .filter(|mapping| {
                        mapping.declaring_trait == owner.symbol
                            && mapping.requirement == row.requirement
                            && (mapping.realization_machine == provider.symbol
                                && mapping.realization_state == entry.symbol
                                || program.target_machine_families.iter().any(|family| {
                                    family.canonical == mapping.realization_machine
                                        && family.members.iter().any(|member| {
                                            member.machine == provider.symbol
                                                && member.target.as_str() == row.target_scope
                                        })
                                }))
                    })
                    .count()
            } else {
                validation::revalidate_machine_trait_conformances(program, provider)
                    .map_err(|diagnostics| format!("selected build-time provider does not satisfy its contracts: {diagnostics:?}"))?;
                program.machine_trait_conformances(provider).iter().filter(|conformance| {
                    conformance.external_binding.is_none()
                        && matches!(typed_trees::machine::resolve_satisfied_declaration(program, provider, conformance),
                            Some(typed_trees::machine::SatisfiedDeclaration::Trait { definition, requirement })
                                if definition.symbol == owner.symbol && requirement.symbol == row.requirement)
                }).count()
            };
            if bound != 1 {
                return Err(
                    "selected build-time provider has no unique exact trait realization".into(),
                );
            }
            continue;
        }
        let mut requirements = program
            .machines()
            .iter()
            .filter(|machine| machine.symbol == row.requirement);
        let machine_requirement = requirements.next();
        if let Some(requirement) = machine_requirement {
            if requirements.next().is_some() {
                return Err("selected build-time requirement is not unique".into());
            }
            if spelled_spelling.is_some_and(|spelling| requirement.spelling != Some(spelling)) {
                return Err(
                    "selected build-time provider requirement lost its boundary spelling".into(),
                );
            }
            if !program.machine_type_parameters(requirement).is_empty() {
                return Err("selected build-time provider requirement is generic; symbolic application coverage is not part of this execution".into());
            }
            let [required_entry] = program.machine_states(requirement) else {
                return Err("selected build-time requirement has no unique entry signature".into());
            };
            let parameters = program.state_parameters(required_entry);
            if parameters.len() != row.operands.len() {
                return Err(
                    "selected build-time provider requirement arity differs from retained operands"
                        .into(),
                );
            }
            if program
                .machine_contracts(requirement)
                .iter()
                .chain(program.state_contracts(required_entry))
                .any(|contract| contract.is_crashes())
            {
                return Err(
                    "selected operator crash invocations have no build-time execution support"
                        .into(),
                );
            }
            // Token views and plain named requirements have one source owner.
            // Rejoin the exact satisfaction target and independently check its
            // signature, contracts, and operational ceiling on the actual machine.
            let conformances = program
                .machine_trait_conformances(provider)
                .iter()
                .filter(|conformance| {
                    if conformance.external_binding.is_some() {
                        return false;
                    }
                    let Some(typed_trees::machine::SatisfiedDeclaration::TopLevelRequirement(
                        required,
                    )) = typed_trees::machine::resolve_satisfied_declaration(
                        program,
                        provider,
                        conformance,
                    )
                    else {
                        return false;
                    };
                    required.symbol == requirement.symbol
                        && validation::revalidate_top_level_requirement_realization(
                            program,
                            provider,
                            required,
                            conformance,
                        )
                        .is_ok()
                })
                .count();
            if conformances != 1 {
                return Err("selected build-time provider does not bind its requirement through exactly one checked conformance".into());
            }
            let mut bindings = program
                .machine_token_bindings()
                .iter()
                .filter(|binding| binding.symbol == requirement.symbol);
            match (bindings.next(), bindings.next()) {
                (None, None) if requirement.spelling.is_none() => continue,
                (Some(binding), None) if binding.spelling == requirement.spelling => {}
                _ => {
                    return Err(
                        "selected build-time token view differs from its actual requirement".into(),
                    );
                }
            }
            // A normalized named call still owes its token-view signature
            // checks. Only a genuinely untokened requirement has no such view.
        }
        let matching: Vec<_> = program
            .operators()
            .iter()
            .chain(program.machine_token_bindings())
            .filter(|operator| operator.symbol == row.requirement)
            .collect();
        let [operator] = matching.as_slice() else {
            return Err("selected build-time requirement is not unique".into());
        };
        if !operator.is_boundary
            || spelled_spelling.is_some_and(|spelling| operator.spelling != Some(spelling))
        {
            return Err(
                "selected build-time provider requirement lost its boundary spelling".into(),
            );
        }
        if !program.operator_type_parameters(operator).is_empty() {
            return Err(
                "selected build-time provider requirement is generic; symbolic application coverage is not part of this execution"
                    .into(),
            );
        }
        if program
            .signature_contracts
            .span_or_empty(operator.contracts)
            .iter()
            .any(|contract| contract.is_crashes())
        {
            return Err(
                "selected operator crash invocations have no build-time execution support".into(),
            );
        }
        if program.operator_parameters(operator).len() != row.operands.len() {
            return Err(
                "selected build-time provider requirement arity differs from retained operands"
                    .into(),
            );
        }
        let entry_parameters: Vec<_> = program.state_parameters(entry).iter().collect();
        if entry_parameters.len() != row.operands.len()
            || program.normalized_type_identity(entry.return_type)
                != program.normalized_type_identity(operator.return_type)
            || !program
                .operator_parameters(operator)
                .iter()
                .zip(entry_parameters.iter())
                .all(|(requirement, parameter)| {
                    program.normalized_type_identity(requirement.type_reference)
                        == program.normalized_type_identity(parameter.type_reference)
                })
        {
            return Err(
                "selected build-time provider entry signature differs from its requirement".into(),
            );
        }
        if machine_requirement.is_some() {
            continue;
        }
        let [namespace, requirement] = program.operator_path_members(operator.name) else {
            return Err(
                "selected build-time provider requirement has no exact namespace path".into(),
            );
        };
        let conformances =
            program
                .machine_trait_conformances(provider)
                .iter()
                .filter(|conformance| {
                    conformance.external_binding.is_none()
                    && conformance.name.as_str() == namespace.as_str()
                    && conformance.requirement.as_ref().map(|name| name.as_str())
                        == Some(requirement.as_str())
                    && (typed_trees::operator::resolve_satisfied_checked_operator_for_conformance(
                        program, provider, conformance,
                    ).is_some_and(|resolved| resolved.symbol == operator.symbol)
                        || typed_trees::operator::resolve_specialized_checked_operator_application(
                            program,
                            provider,
                            namespace.as_str(),
                            requirement.as_str(),
                        ).is_some_and(|(resolved, _)| resolved.symbol == operator.symbol))
                })
                .count();
        if conformances != 1 {
            return Err(
                "selected build-time provider does not bind its requirement through exactly one checked conformance"
                    .into(),
            );
        }
    }
    Ok(())
}

pub fn validate_selected_operators(
    program: &TypedTrees,
    selected: &[SelectedBuildTimeBinaryOperator],
) -> Result<(), String> {
    if selected
        .iter()
        .any(|operator| operator.has_crash_contract(program))
    {
        return Err(
            "selected operator crash invocations have no build-time execution support".into(),
        );
    }
    let Some(facts) = require_unique_operator_custody(
        program,
        selected,
        "selected build-time operator",
        |row| (!row.provider.is_empty()).then_some((row.expression, row.origin.machine_symbol())),
    )?
    else {
        return Ok(());
    };
    for row in selected.iter() {
        // All source forms address the same expression in its owning frame.
        // Count unresolved and cross-arena occurrences too: neither can borrow
        // another occurrence's supplied execution.
        let occurrences = facts
            .uses
            .iter()
            .filter(|(_, fact)| {
                fact.occurrence == checked_trees::CheckedOperatorOccurrence::Expression
            })
            .map(|(_, fact)| (fact.expression, fact.origin))
            .chain(
                facts
                    .named_uses()
                    .map(|fact| (fact.expression, fact.origin)),
            )
            .chain(
                facts
                    .named_requirement_uses()
                    .map(|fact| (fact.expression, fact.origin)),
            )
            .filter(|(expression, origin)| {
                *expression == row.expression
                    && origin.machine_symbol() == row.origin.machine_symbol()
            })
            .count();
        if occurrences != 1 {
            return Err(
                "selected build-time expression is shared by distinct current origins".into(),
            );
        }
        let mut first_selection = None;
        let mut multiple_selections = false;
        facts.for_each_resolved_expression_selection(
            row.expression,
            |origin, requirement, policy, _| {
                if origin == row.origin {
                    if first_selection.is_none() {
                        first_selection = Some((requirement, policy));
                    } else {
                        multiple_selections = true;
                    }
                }
            },
        );
        let Some((requirement, policy)) = first_selection.filter(|_| !multiple_selections) else {
            return Err("selected build-time operator has no unique current use".into());
        };
        if requirement != row.requirement || policy != row.policy {
            return Err("selected build-time operator differs from current requirement or arithmetic policy".into());
        }
        let operands = match program.expression_table.expression(row.expression) {
            ExpressionNode::Binary(binary) if binary.operator == row.operation => {
                [binary.left, binary.right]
            }
            ExpressionNode::Call(call) => {
                let [left, right] = program.expression_table.expression_handles(call.arguments)
                else {
                    return Err("selected build-time binary requirement has wrong arity".into());
                };
                [*left, *right]
            }
            _ => return Err("selected build-time binary expression disappeared".into()),
        };
        if operands != row.operands {
            return Err(
                "selected build-time operation differs from current authored selection".into(),
            );
        }
        let matching: Vec<_> = program
            .operators()
            .iter()
            .chain(program.machine_token_bindings())
            .filter(|operator| operator.symbol == row.requirement)
            .collect();
        let [operator] = matching.as_slice() else {
            return Err("selected build-time requirement is not unique".into());
        };
        if let Some(requirement) = program.machine(row.requirement) {
            let [entry] = program.machine_states(requirement) else {
                return Err("selected build-time Float requirement has no unique entry".into());
            };
            if requirement.supply_mode != language_semantics::MachineSupplyMode::TopLevelRequirement
                || requirement.body_is_present
                || requirement.spelling != operator.spelling
                || entry.parameters != operator.parameters
                || entry.return_type != operator.return_type
                || requirement.type_parameters != operator.type_parameters
                || requirement.contracts != operator.contracts
            {
                return Err(
                    "selected build-time token view differs from its actual requirement".into(),
                );
            }
        }
        if typed_trees::operator::primitive_float_binary_semantics(program, operator)
            != Some((row.operation, row.format))
        {
            return Err(
                "selected build-time operation has no matching sealed Float meaning".into(),
            );
        }
        let [left, right] = program.operator_parameters(operator) else {
            return Err("selected build-time binary requirement has wrong arity".into());
        };
        let primitive = match row.format {
            numerics::literals::FloatFormat::F32 => typed_trees::types::PrimitiveType::F32,
            numerics::literals::FloatFormat::F64 => typed_trees::types::PrimitiveType::F64,
        };
        if !operator.is_boundary
            || program.primitive_type_reference(left.type_reference) != Some(primitive)
            || program.primitive_type_reference(right.type_reference) != Some(primitive)
        {
            return Err(
                "selected build-time requirement has incompatible boundary or operand carriers"
                    .into(),
            );
        }
    }
    Ok(())
}
