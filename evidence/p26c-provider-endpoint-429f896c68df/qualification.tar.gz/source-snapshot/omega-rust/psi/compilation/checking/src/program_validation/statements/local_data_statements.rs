//! A local data statement: the declared type, its initializer and the
//! value environment it introduces.

use super::{StatementOutputs, StatementScope};
use crate::value_custody::type_references::TypeReferenceOwner;
use crate::value_custody::type_references::validate_type_reference_handle;
use crate::{
    machine_calls::calls, proof_contracts::arithmetic_domains, proof_contracts::domain_weakening,
    value_custody::expression_types, value_custody::struct_literals,
};
use diagnostics::Diagnostic;
use typed_trees::statement::StatementNode;

/// Form the local's authored application before evaluating its initializer.
/// Runtime index subjects capture this point; later initializer writes neither
/// retag that application nor provide premises for its formation. Initializer
/// values still use the ordinary may-write-invalidated environment below.
#[allow(clippy::too_many_arguments)]
pub(in crate::program_validation) fn validate_type_reference(
    program: &dyn crate::CheckingInput,
    machine: &typed_trees::machine::Machine,
    current_state: Option<&typed_trees::state::State>,
    state_name: &str,
    local_data: &typed_trees::statement::TableLocalData,
    symbols: &crate::TopLevelSymbols<'_>,
    value_environment: &arithmetic_domains::ValueEnvironment,
    diagnostics: &mut Vec<Diagnostic>,
) {
    if local_data.role != language_core::LocalBindingRole::Value {
        return;
    }
    let (type_parameters, lifetime_parameters) = program
        .machine_type_reference_scope(machine, |existing, parameter| {
            existing.symbol == parameter.symbol
        });
    validate_type_reference_handle(
        program,
        local_data.type_reference,
        symbols,
        diagnostics,
        TypeReferenceOwner::StateLocalData {
            machine,
            current_state,
            state: state_name,
            local: local_data.name.as_str(),
            value_environment,
            generic_depth: 0,
        },
        crate::value_custody::type_references::TypeParameterScope {
            operand_lifetime_owner: symbols::SymbolHandle::invalid(),
            lexical_owner: machine.symbol,
            type_parameters: &type_parameters,
            lifetime_parameters: &lifetime_parameters,
        },
    );
}

pub(super) fn validate(
    scope: &StatementScope<'_>,
    outputs: &mut StatementOutputs<'_>,
    statement: &StatementNode,
) {
    let Some(local_data) = statement.as_local_data() else {
        unreachable!("dispatched local_data_statements")
    };
    // Pattern markers describe field coverage, not storage. Their subject is
    // not assigned to the marker's Unit sentinel: doing so invents a whole-value
    // move and rejects qualified subjects as implicit domain weakening. The
    // destructure checker validates coverage; actual field bindings retain the
    // Value role and all ordinary store, access, and qualification obligations.
    if !local_data.role.is_runtime_binding() {
        return;
    }
    let StatementScope {
        program,
        machine,
        state_name,
        current_state,
        statement_index,
        ..
    } = *scope;
    let value_environment = &mut *outputs.value_environment;
    let arithmetic_decisions = &mut *outputs.arithmetic_decisions;
    let diagnostics = &mut *outputs.diagnostics;
    // Inferred results and operand captures belong to completed initializer
    // operands, not to an authored receiving application at statement entry.
    if local_data.type_is_inferred || local_data.is_operand_capture {
        validate_type_reference(
            program,
            machine,
            current_state,
            state_name,
            local_data,
            scope.symbols,
            value_environment,
            diagnostics,
        );
    }
    let local_target_primitive = program.primitive_type_reference(local_data.type_reference);
    // An array-literal initializer (`let a: [T; N] = [300, ..]`) is checked
    // element-wise against T.
    if let Some(current_state) = current_state {
        struct_literals::validate_array_literal_elements(
            program,
            machine,
            current_state,
            local_data.initial_value,
            local_data.type_reference,
            diagnostics,
        );
    }
    let owner = format!(
        "machine `{}` state `{state_name}` local `{}`",
        machine.name,
        local_data.name.as_str()
    );
    if local_data.role == language_core::LocalBindingRole::AtomicObservedResult {
        let Some(state) = current_state else {
            diagnostics.push(Diagnostic::error("atomic result requires its source state"));
            return;
        };
        let Some(event) = crate::atomic_result_placeholder(program, state, local_data) else {
            diagnostics.push(Diagnostic::error(
                "atomic result reservation lost its completing event",
            ));
            return;
        };
        let mut before_event = event.operands.clone();
        before_event.push(event.place);
        crate::expression_traversal::collect_type_expressions(
            program,
            local_data.type_reference,
            &mut Vec::new(),
            &mut before_event,
        );
        if crate::expression_traversal::visit_pre_order(
            program,
            before_event,
            |_, node| matches!(node, typed_trees::expression::ExpressionNode::Name(path) if path.symbol == local_data.symbol || path.head_symbol == local_data.symbol),
        ) {
            diagnostics.push(Diagnostic::error(format!(
                "{owner} cannot consume its atomic result before the event completes"
            )));
            return;
        }
        let reference = crate::declared_place_type_raw(program, machine, Some(state), event.place);
        let primitive = reference.and_then(|reference| program.primitive_type_reference(reference));
        if primitive.is_none() || primitive != local_target_primitive {
            diagnostics.push(Diagnostic::error(format!(
                "{owner} requires the exact atomic instruction-observed resident type"
            )));
            return;
        }
        domain_weakening::validate_implicit_domain_weakening(
            program,
            machine,
            Some(state),
            event.place,
            local_data.type_reference,
            &owner,
            diagnostics,
        );
        let interval = arithmetic_domains::atomic_resident_interval(
            program,
            machine,
            Some(state),
            event.place,
        )
        .unwrap_or(arithmetic_domains::Interval::UNBOUNDED);
        arithmetic_domains::check_range_containment(
            program,
            local_data.type_reference,
            arithmetic_domains::IntegerValueObservation {
                machine,
                state: Some(state),
                expression: event.result,
                environment: value_environment,
                interval,
            },
            &owner,
            diagnostics,
        );
        // The reserved name has no initializer value, literal equality or alias.
        arithmetic_domains::record_assignment(
            value_environment,
            Some(local_data.name.to_string()),
            arithmetic_domains::Interval::UNBOUNDED,
            None,
        );
        return;
    }
    if let Some(carrier) = crate::atomic_once_carrier(program, local_data.initial_value) {
        let resident = crate::value_custody::places::declared_place_type(
            program,
            machine,
            current_state,
            carrier.place,
        )
        .filter(|_| crate::place_is_atomic_storage(program, machine, current_state, carrier.place))
        .and_then(|cell| program.primitive_type_reference(cell));
        if !resident.is_some_and(|primitive| {
            crate::atomic_once_result_type(program, local_data.type_reference, primitive)
        }) {
            diagnostics.push(Diagnostic::error(format!(
                "{owner} requires the sealed AtomicCompareExchangeOnceOutcome with the exact resident type"
            )));
        } else {
            super::atomic_establishment::validate_once_resident(
                scope,
                local_data,
                &carrier,
                value_environment,
                arithmetic_decisions,
                &owner,
                diagnostics,
            );
        }
    }
    // Unit is not storage for an initializer's value. Generated
    // bindings can retain an inference sentinel, but an authored
    // annotation must never silently discard a produced value.
    if local_data.initial_value.is_valid()
        && local_data.type_reference.is_valid()
        && !local_data.type_is_inferred
        && matches!(
            program
                .type_reference_table
                .type_reference(local_data.type_reference),
            typed_trees::types::TypeReferenceNode::Unit
        )
    {
        diagnostics.push(Diagnostic::error(format!(
            "{owner} has an explicit Unit type and cannot bind an initializer value; use the value's type or explicitly discard the result"
        )));
    }
    // Cross-class guard: `let x: i32 = true` stores a bool into a numeric
    // local -- a silent miscompile, same as the assignment / arg / field
    // positions. Only an INITIALIZED `let` has a value to class-check (a
    // bare `let x: bool;` filled later by an `&mut` out-param has an invalid
    // initializer). (Narrowing on the initializer is checked below.)
    if local_data.initial_value.is_valid()
        && let Some(target_primitive) = local_target_primitive
    {
        expression_types::report_cross_class_store(
            program,
            Some(machine),
            current_state,
            local_data.initial_value,
            target_primitive,
            &owner,
            "local",
            diagnostics,
        );
    }
    // Nominal guard: `let f: Foo = self.bar` binds a `Bar` value to a `Foo`
    // local -- wrong data type. Only an initialized `let` has a value.
    if local_data.initial_value.is_valid() {
        let prior_statements = current_state.map_or(&[][..], |state| {
            &program.statement_table.statements(state.statement_nodes)[..statement_index]
        });
        let access_refused =
            crate::value_custody::reference_access::report_reference_access_conflict(
                program,
                machine,
                current_state,
                prior_statements,
                local_data.initial_value,
                local_data.type_reference,
                &owner,
                diagnostics,
            );
        // One refused store reports one reason: an access refusal already
        // explains a delivered reference of the wrong access.
        if !access_refused {
            expression_types::report_delivered_type_mismatch(
                program,
                machine.symbol,
                local_data.initial_value,
                local_data.type_reference,
                &owner,
                diagnostics,
            );
        }
        expression_types::report_data_type_conflict(
            program,
            machine,
            current_state,
            local_data.initial_value,
            local_data.type_reference,
            &owner,
            "local",
            diagnostics,
        );
        // Shape guard: `let y: i32 = self.xs` (array -> scalar) or
        // `let xs: [i32; 3] = 5` (scalar -> array) otherwise bind a
        // wrong-shaped value silently (the array case read a ZII 0).
        expression_types::report_array_scalar_shape_mismatch(
            program,
            machine,
            current_state,
            local_data.initial_value,
            local_data.type_reference,
            &owner,
            "local",
            diagnostics,
        );
        expression_types::report_scalar_data_shape_mismatch(
            program,
            machine,
            current_state,
            local_data.initial_value,
            local_data.type_reference,
            &owner,
            "local",
            diagnostics,
        );
        domain_weakening::validate_implicit_domain_weakening(
            program,
            machine,
            current_state,
            local_data.initial_value,
            local_data.type_reference,
            &owner,
            diagnostics,
        );
    }
    calls::report_nested_call_in_local_initializer(
        program,
        machine,
        state_name,
        local_data.initial_value,
        diagnostics,
    );
    let before = diagnostics.len();
    let first_checked_interval = arithmetic_decisions.expression_values.len();
    let local_target_domain =
        program.arithmetic_domain_for_type_reference(local_data.type_reference);
    let (interval, source_primitive, source_domain) =
        arithmetic_domains::validate_anonymous_integer_range(
            program,
            local_data.type_reference,
            local_data.initial_value,
            &owner,
            diagnostics,
        )
        .unwrap_or_else(|| {
            arithmetic_domains::validate_value_range_retaining_decisions(
                program,
                machine,
                current_state,
                local_data.initial_value,
                value_environment,
                local_target_primitive,
                local_target_domain,
                &owner,
                diagnostics,
                arithmetic_decisions,
            )
        });
    // Keep the declared carrier check independent of arithmetic failures.
    if local_data.initial_value.is_valid() {
        let (source_primitive, source_domain) = arithmetic_domains::stored_value_carrier(
            program,
            machine,
            current_state,
            local_data.initial_value,
            source_primitive,
            source_domain,
        );
        arithmetic_domains::check_narrowing_assignment(
            local_target_primitive,
            local_target_domain,
            interval,
            source_primitive,
            source_domain,
            &owner,
            diagnostics,
        );
    }
    if local_data.initial_value.is_valid() && diagnostics.len() == before {
        // Containment against a declared Exact `[a..=b]`: literal
        // initializers refuse through the proof plan, but a
        // NON-LITERAL initializer's interval was never checked --
        // `let idx: u32 [0..=11] = <expr provably up to 12>` stored
        // unproven and the index prover then TRUSTED the range (a
        // confirmed native OOB read, found landing the R3 product
        // rule). The enforced range only exists under Exact shells,
        // so non-Exact declarations are untouched (the
        // `range-constraints-require-exact-domain` gate
        // already rejects range+domain combinations).
        // A reference binding stores the reference, not a fresh value
        // into the referee. Its referee facts are checked by ordinary
        // borrow compatibility and, for a stated recast, by the
        // bidirectional representation judgment. Treating the borrow
        // expression as a numeric store into the referee incorrectly
        // rejects every range-refined reference initializer.
        if !matches!(
            program
                .type_reference_table
                .type_reference(local_data.type_reference),
            typed_trees::types::TypeReferenceNode::Reference { .. }
        ) {
            arithmetic_domains::enforce_symbolic_range(
                program,
                machine,
                current_state,
                local_data.type_reference,
                local_data.initial_value,
                value_environment,
                &owner,
                diagnostics,
            );
            arithmetic_domains::check_range_containment(
                program,
                local_data.type_reference,
                arithmetic_domains::IntegerValueObservation {
                    machine,
                    state: current_state,
                    expression: local_data.initial_value,
                    environment: value_environment,
                    interval,
                },
                &owner,
                diagnostics,
            );
        }
    }
    if local_data.initial_value.is_valid() {
        let mut completed_values = Vec::new();
        let aggregate_with_writes = matches!(
            program
                .expression_table
                .expression(local_data.initial_value),
            typed_trees::expression::ExpressionNode::StructLiteral(_)
                | typed_trees::expression::ExpressionNode::ArrayLiteral(_)
        ) && calls::expression_has_calls(
            program,
            local_data.initial_value,
        ) && scope
            .call_frames
            .and_then(|frames| frames.expression_may_write_paths(machine, local_data.initial_value))
            .is_none_or(|written| !written.is_empty());
        let captured_values = if aggregate_with_writes
            && let Some(state) = current_state
            && let Some(captured) = arithmetic_domains::occurrence_integer_child_values(
                program,
                machine.symbol,
                state.symbol,
                statement_index,
                local_data.initial_value,
            ) {
            let keys = captured
                .iter()
                .map(|value| {
                    (
                        value.expression.arena_index(),
                        value.expression.generation(),
                    )
                })
                .collect::<std::collections::BTreeSet<_>>();
            completed_values.extend(
                arithmetic_decisions.expression_values[first_checked_interval..]
                    .iter()
                    .filter(|value| {
                        !keys.contains(&(
                            value.expression.arena_index(),
                            value.expression.generation(),
                        ))
                    })
                    .cloned(),
            );
            completed_values.extend(captured);
            &completed_values[..]
        } else {
            &arithmetic_decisions.expression_values[first_checked_interval..]
        };
        let mut copied_value = arithmetic_domains::CopiedIntegerValue::capture(
            program,
            machine,
            current_state,
            local_data.initial_value,
            local_data.type_reference,
            value_environment,
            captured_values,
        );
        copied_value.capture_local_relations(
            program,
            machine,
            current_state,
            local_data,
            value_environment,
        );
        let copied_float = arithmetic_domains::capture_float_assignment(
            program,
            machine,
            current_state,
            value_environment,
            local_target_primitive,
            local_data.initial_value,
        );
        let local_name_owned = local_data.name.as_str().to_owned();
        arithmetic_domains::record_assignment(
            value_environment,
            Some(local_name_owned.clone()),
            interval,
            local_data
                .type_reference
                .is_valid()
                .then(|| {
                    arithmetic_domains::enforced_declared_range(program, local_data.type_reference)
                })
                .flatten(),
        );
        arithmetic_domains::publish_slice_length(
            program,
            machine,
            current_state,
            value_environment,
            local_data.name.as_str(),
            local_data.symbol,
            local_data.initial_value,
        );
        if diagnostics.len() == before {
            copied_value.record(
                value_environment,
                Some(local_name_owned.clone()),
                Some(crate::value_custody::places::CanonicalPlace {
                    root: facts::PlaceRoot::Symbol(local_data.symbol),
                    segments: Vec::new(),
                }),
            );
            arithmetic_domains::record_boolean_local(
                program,
                machine,
                current_state,
                value_environment,
                local_data,
            );
            arithmetic_domains::record_unsigned_literal_assignment(
                program,
                value_environment,
                Some(local_name_owned.clone()),
                local_target_primitive,
                local_data.initial_value,
            );
            arithmetic_domains::record_float_assignment(
                value_environment,
                Some(local_name_owned),
                copied_float,
            );
            arithmetic_domains::record_declared_float_fields(
                program,
                value_environment,
                local_data.name.as_str(),
                local_data.type_reference,
            );
        }
    }
}
