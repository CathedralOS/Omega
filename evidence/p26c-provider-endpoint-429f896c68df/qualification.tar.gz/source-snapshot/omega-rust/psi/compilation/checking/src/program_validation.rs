//! Validate typed programs and retain the analyses consumed by checking.

use crate::declarations::standard_declarations;
use crate::declarations::state_signatures::validate_callable_state_signatures;
use crate::declarations::state_signatures::validate_machine_contracts;
use crate::declarations::symbols::MachineSymbols;
use crate::declarations::traits::validate_conformances;
use crate::declarations::traits::validate_external_leaf_native_shapes;
use crate::declarations::traits::validate_external_via_expression;
use crate::declarations::traits::validate_generic_conformance_bounds;
use crate::declarations::traits::validate_machine_trait_conformances;
use crate::declarations::traits::validate_trait_conformance_bounds;
use crate::declarations::traits::validate_trait_requirements;
use crate::machine_calls::calls::validate_proof_machine_recursion;
use crate::machine_calls::calls::validate_self_recursive_call_positions;
use crate::machine_calls::calls::validate_value_position_calls;
use crate::machine_calls::machine_data::validate_owned_data;
use crate::proof_contracts::domains::validate_domain_definitions;
use crate::proof_contracts::proof_facts::validate_proposition_definitions;
use crate::proof_contracts::quotients::QuotientRequestAdmission;
use crate::value_custody::data::validate_data_field_types;
use crate::value_custody::locals::WritableRoots;
use crate::value_custody::locals::validate_local_data_names;
use crate::{
    OpaqueDataPropertyReceipt, TopLevelSymbols, ValidatedBoundaryOperatorApplication,
    ValidatedFloatMeaningEqualityProposition, ValidatedFloatMeaningProjectionInvocation,
    ValidatedIntegerEmbeddingCall, ValidatedProofRecursiveComponent, build_definition_fact_plan,
    collect_dynamic_implementation_selections, declarations::declaration_visibility,
    declarations::operators, declarations::transitions, infer_operational_may,
    infer_service_reaches, machine_calls::call_cycles, machine_calls::callable_overloads,
    machine_calls::calls, machine_calls::fact_call_projections, machine_calls::invocations,
    machine_calls::machine_parameters, proof_contracts::arithmetic_domains,
    proof_contracts::default_domains, proof_contracts::float_projection_bindings,
    proof_contracts::float_projection_invocations, proof_contracts::proof_embeddings,
    proof_contracts::proof_only_faces, proof_contracts::properties,
    proof_contracts::proposition_entailment, proof_contracts::qualification_evidence,
    proof_contracts::quotients, proof_contracts::relevance, value_custody::cleanup,
    value_custody::constants, value_custody::content_conservation,
    value_custody::content_projections, value_custody::destructure, value_custody::literals,
    value_custody::placed_views, value_custody::plan_laid, value_custody::recasts,
    value_custody::struct_literals, value_custody::wire, value_custody::write_only_borrows,
};
use diagnostics::Diagnostic;
use rayon::prelude::*;
use typed_trees::expression::ExpressionHandle;
use typed_trees::statement::StatementNode;

mod contract_queries;
mod dependency_bodies;
mod statements;
pub use contract_queries::{
    validate_checked_operator_realization_contract, validate_generic_machine_contract_entailment,
};
pub use dependency_bodies::DependencyBodyJudgment;
use statements::validate_state_statement_node;

pub use checked_trees::operators::ExactIntegerCastFact;

/// The values an integer expression can take, as the arithmetic walk that
/// checked its evaluation found them; `None` is an unbounded end. Every walk of
/// the expression contributes, so the interval holds wherever it is evaluated.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ExpressionInterval {
    pub expression: ExpressionHandle,
    pub low: Option<i64>,
    pub high: Option<i64>,
}

/// The retained interval of `expression`, from `intervals` in handle order.
pub fn expression_interval(
    intervals: &[ExpressionInterval],
    expression: ExpressionHandle,
) -> Option<&ExpressionInterval> {
    let position = checked_trees::operators::handle_position(expression);
    intervals
        .binary_search_by_key(&position, |interval| {
            checked_trees::operators::handle_position(interval.expression)
        })
        .ok()
        .map(|found| &intervals[found])
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ProgramValidationFacts {
    pub quotient_formations: Vec<quotients::ValidatedQuotientFormation>,
    pub integer_range_obligations: Vec<checked_trees::IntegerRangeObligation>,
    pub static_machine_selections: machine_parameters::ValidatedStaticMachineSelections,
    formed_static_machine_selections: machine_parameters::FormedStaticMachineSelections,
    pub stored_integer_writes: Vec<checked_trees::CheckedStoredIntegerWrite>,
    /// Successful immediate receiving judgments, not invariant-window closure.
    pub integer_assignments: Vec<checked_trees::CheckedIntegerAssignmentDecision>,
    pub boundary_operator_applications: Vec<ValidatedBoundaryOperatorApplication>,
    pub exact_integer_casts: Vec<ExactIntegerCastFact>,
    /// Integer operations whose formation conditions every clean arithmetic
    /// walk decided.
    pub decided_formations: Vec<typed_trees::expression::ExpressionHandle>,
    /// Integer expression intervals, one per expression in handle order,
    /// hulled over every clean arithmetic walk of it.
    pub expression_intervals: Vec<ExpressionInterval>,
    pub float_meaning_projection_invocations: Vec<ValidatedFloatMeaningProjectionInvocation>,
    pub float_meaning_equality_propositions: Vec<ValidatedFloatMeaningEqualityProposition>,
    pub fact_call_projections: Vec<fact_call_projections::ValidatedFactCallProjection>,
    pub specification_calls:
        Vec<crate::machine_calls::denotational_calls::SpecificationCallRequest>,
    pub integer_embedding_calls: Vec<ValidatedIntegerEmbeddingCall>,
    /// Canonical proof-only call SCCs accepted by the structural-subterm
    /// validator. Every exact internal call site retains its own witness.
    pub proof_recursive_components: Vec<ValidatedProofRecursiveComponent>,
    /// Independently judged exact self-call decreases for private progress;
    /// semantic predecessors do not authorize structural induction hypotheses.
    pub self_call_descents: Vec<crate::ValidatedSelfCallDescent>,
    /// For each checked-body machine whose contract entailment this pass
    /// judged, the postconditions it proved — the one judgment over bodies,
    /// consumed by the stage-04 prover. Empty when the machine's entailment
    /// raised a diagnostic or does not cover every exit.
    pub proven_machine_contracts: Vec<(symbols::SymbolHandle, ProvenContractExpressions)>,
}

/// Postconditions retain the observation point used by their proof. Entry-only
/// deductions require a preserved frame before they describe an exit; normal
/// return deductions already account for writes along every observed path.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ProvenContractExpressions {
    pub entry: Vec<ExpressionHandle>,
    pub normal_returns: Vec<ExpressionHandle>,
}

/// Whether opaque property claims must be backed now or remain pending during
/// preliminary build checking. Pending evidence is not final admission.
#[derive(Debug, Clone, Copy)]
pub enum OpaquePropertyValidation<'a> {
    Required(&'a [OpaqueDataPropertyReceipt]),
    PendingBuildSelection,
}

/// Results computed against one immutable typed program. Later stages consume
/// these same analyses; this carrier is not Terminal verification authority.
#[derive(Debug)]
pub struct ProgramValidation {
    pub facts: ProgramValidationFacts,
    pub operational: flow_effects::OperationalPlan,
    pub service_reaches: flow_effects::ServiceReachInferencePlan,
    /// Entailment judgments of non-instance machines, recorded only for a
    /// strict check that the caller will retain. Empty when this pass is not
    /// recording. Consumers remap ordinals into their own arenas.
    pub dependency_body_judgments: Vec<DependencyBodyJudgment>,
}

/// Validate a standalone program, including its generic contracts.
pub fn validate_program(program: &dyn crate::CheckingInput) -> Result<(), Vec<Diagnostic>> {
    validate(
        program,
        OpaquePropertyValidation::Required(&[]),
        QuotientRequestAdmission::AtValidation,
        EffectAdmission::Complete,
        &[],
        false,
    )
    .map(|_| ())
}

/// Prepare formation and source-flow inputs before ownership selects implicit
/// execution dependencies. This is not final effect admission.
pub fn prepare_specialized_program(
    program: &dyn crate::CheckingInput,
    opaque_properties: OpaquePropertyValidation<'_>,
    prior_dependency_bodies: &[DependencyBodyJudgment],
    record_dependency_bodies: bool,
) -> Result<ProgramValidation, Vec<Diagnostic>> {
    validate(
        program,
        opaque_properties,
        QuotientRequestAdmission::AfterCheckedFacts,
        EffectAdmission::AfterOwnership,
        prior_dependency_bodies,
        record_dependency_bodies,
    )
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum EffectAdmission {
    Complete,
    AfterOwnership,
}

fn validate<'program>(
    program: &'program dyn crate::CheckingInput,
    opaque_properties: OpaquePropertyValidation<'_>,
    quotient_admission: QuotientRequestAdmission,
    effect_admission: EffectAdmission,
    prior_dependency_bodies: &[DependencyBodyJudgment],
    record_dependency_bodies: bool,
) -> Result<ProgramValidation, Vec<Diagnostic>> {
    let pre_machine_guard = phase_profile::guard("05.d.2.a.1.pre_machine_validators");
    let mut diagnostics = Vec::new();
    if let Err(mut errors) =
        crate::conformance_applications::validate_conformance_applications(program)
    {
        diagnostics.append(&mut errors);
    }
    if let Err(message) = crate::validate_boundary_completion_declarations(program) {
        diagnostics.push(Diagnostic::error(message));
    }
    literals::validate_anonymous_numeric_formation(program, &mut diagnostics);
    if !diagnostics.is_empty() {
        return Err(diagnostics);
    }
    let mut boundary_operator_applications = Vec::new();
    let mut arithmetic_decisions = arithmetic_domains::ArithmeticDecisions::default();
    let mut stored_integer_writes = Vec::new();
    callable_overloads::validate_named_callable_overload_declarations(program, &mut diagnostics);
    float_projection_bindings::validate_float_projection_operator_bindings(
        program,
        &mut diagnostics,
    );
    crate::value_custody::atomic_fences::validate_atomic_fence_declarations(
        program,
        &mut diagnostics,
    );
    let symbols = TopLevelSymbols::build(program, &mut diagnostics);
    standard_declarations::validate_calling_vocabulary_uniqueness(program, &mut diagnostics);
    let fact_plan = phase_profile::scope("05.d.2.a.1a.definition_fact_plan", || {
        build_definition_fact_plan(program)
    });

    declaration_visibility::collect_declaration_visibility_diagnostics(program, &mut diagnostics);
    cleanup::collect_reserved_cleanup_selection_diagnostics(program, &mut diagnostics);
    validate_proposition_definitions(program, &mut diagnostics);
    phase_profile::scope("05.d.2.a.1a2.proposition_entailment", || {
        proposition_entailment::validate_proposition_entailment(program, &mut diagnostics);
    });

    phase_profile::scope("05.d.2.a.1a2b.domains_and_signatures", || {
        literals::validate_suffix_landings(program, &mut diagnostics);
        literals::validate_suffix_magnitudes(program, &mut diagnostics);
        // Abstract calls consume the same scoped content formation that later
        // fact construction uses. Keep its diagnostic-producing owner first.
        content_projections::validate_content_projection_conformances(program, &mut diagnostics);
        content_conservation::validate_content_conservation_contracts(program, &mut diagnostics);
        validate_domain_definitions(program, &symbols, &fact_plan, &mut diagnostics);
        validate_callable_state_signatures(program, &symbols, &mut diagnostics);
        write_only_borrows::validate_checked_write_only_slice(program, &mut diagnostics);
        arithmetic_domains::validate_abstract_total_specification_arithmetic(
            program,
            &mut diagnostics,
        );
        cleanup::validate_cleanup_machine_declarations(program, &mut diagnostics);
        validate_trait_requirements(program, &symbols, &mut diagnostics);
        for trait_definition in program.traits() {
            validate_trait_conformance_bounds(
                program,
                trait_definition,
                &symbols,
                &mut diagnostics,
            );
        }
        qualification_evidence::validate_qualification_authorization(program, &mut diagnostics);
    });
    let (conformance_operational, conformance_service_reaches) =
        phase_profile::scope("05.d.2.a.1a3.operational_and_service_reaches", || {
            let conformance_operational = infer_operational_may(program);
            let conformance_service_reaches =
                infer_service_reaches(program, &conformance_operational);
            (conformance_operational, conformance_service_reaches)
        });
    if effect_admission == EffectAdmission::Complete {
        phase_profile::scope("05.d.2.a.1a4.validate_conformances", || {
            validate_conformances(
                program,
                &conformance_service_reaches,
                &symbols,
                &mut diagnostics,
            );
            if let Err(mut dynamic_diagnostics) = collect_dynamic_implementation_selections(program)
            {
                diagnostics.append(&mut dynamic_diagnostics);
            }
        });
    }
    let (
        proof_only,
        integer_embedding_calls,
        quotient_formations,
        fact_call_projections,
        specification_calls,
    ) = phase_profile::scope("05.d.2.a.1a4b.data_and_proof_faces", || {
        validate_data_field_types(program, &symbols, &mut diagnostics);
        plan_laid::validate_plans(program, &mut diagnostics);
        placed_views::validate_plans(program, &mut diagnostics);
        relevance::validate_relevance(program, &mut diagnostics);
        // Math roster N1: recursive data is legal and PROOF-ONLY (computed, never
        // spelled); every runtime consumption face refuses with the
        // classification named.
        let proof_only = crate::proof_only_classification(program);
        proof_embeddings::validate_proof_embeddings(program, &proof_only, &mut diagnostics);
        let integer_embedding_calls = if effect_admission == EffectAdmission::Complete {
            proof_embeddings::validate_integer_embedding_calls(program, &mut diagnostics)
        } else {
            Vec::new()
        };
        let quotient_formations = quotients::validate_quotients(
            program,
            &proof_only,
            quotient_admission,
            &mut diagnostics,
        );
        let fact_call_projections = if effect_admission == EffectAdmission::Complete {
            fact_call_projections::validate_fact_call_projections(
                program,
                &conformance_operational,
                &conformance_service_reaches,
                &mut diagnostics,
            )
        } else {
            Vec::new()
        };
        let specification_calls = if effect_admission == EffectAdmission::Complete {
            crate::machine_calls::denotational_calls::validate_specification_calls(
                program,
                &conformance_operational,
                &conformance_service_reaches,
                &mut diagnostics,
            )
        } else {
            Vec::new()
        };
        proof_only_faces::validate_proof_only_consumption(program, &proof_only, &mut diagnostics);
        (
            proof_only,
            integer_embedding_calls,
            quotient_formations,
            fact_call_projections,
            specification_calls,
        )
    });
    // Chapter 3 / MR4: runtime call cycles require the constant-stack tail
    // admission; erased proof-only SCCs instead require strict structural descent.
    let mut self_call_descents = Vec::new();
    let proof_recursive_components =
        phase_profile::scope("05.d.2.a.1a5.call_cycles_and_properties", || {
            let components =
                call_cycles::validate_machine_call_cycles(program, &symbols, &mut diagnostics);
            let (opaque_property_receipts, allow_pending_opaque_copy) = match opaque_properties {
                OpaquePropertyValidation::Required(receipts) => (receipts, false),
                OpaquePropertyValidation::PendingBuildSelection => (&[][..], true),
            };
            properties::validate_data_properties(
                program,
                opaque_property_receipts,
                allow_pending_opaque_copy,
                &mut diagnostics,
            );
            components
        });
    let call_frames = phase_profile::scope("05.d.2.a.1b.call_frame_resolver", || {
        calls::CallFrameResolver::new(program)
    });
    phase_profile::scope("05.d.2.a.1a5b.constants_and_literals", || {
        phase_profile::scope("05.d.2.a.1a5b.1.constants", || {
            constants::validate_constants(program, &mut diagnostics);
        });
        // Bare-payload-case `==` (decision 11) is checked on the RESOLVED trees,
        // before membership lowering synthesizes its internal tag compares; see
        // 03_symbol-resolved-trees-to-typed-trees/src/equality.rs.
        phase_profile::scope("05.d.2.a.1a5b.2.struct_literals", || {
            stored_integer_writes.extend(struct_literals::validate_struct_literal_fields(
                program,
                &mut diagnostics,
                &mut arithmetic_decisions.integer_range_obligations,
            ));
        });
        // Record patterns in LET (owner spec 2026-07-18): the exhaustiveness
        // law on the parse-minted `__destructure#*` marker.
        phase_profile::scope("05.d.2.a.1a5b.3.destructure", || {
            destructure::validate_destructure_exhaustiveness(program, &mut diagnostics);
        });
    });
    // R2 rung 3 slice 1: the default-domain write obligation (strict
    // store-time semantics; obligations before hypotheses).
    phase_profile::scope("05.d.2.a.1a5c.default_domain_writes", || {
        default_domains::validate_default_domain_writes(
            program,
            call_frames.as_ref(),
            &mut diagnostics,
        );
    });
    phase_profile::scope("05.d.2.a.1a5d.recasts_wire_operators", || {
        recasts::validate_recasts(program, call_frames.as_ref(), &mut diagnostics);
        wire::validate_wire_schemas(program, &symbols, &mut diagnostics);
        operators::validate_operator_declarations(program, &symbols, &mut diagnostics);
    });
    let mut static_machine_selections =
        machine_parameters::ValidatedStaticMachineSelections::default();
    let mut formed_static_machine_selections = Default::default();
    let formation_diagnostic_start = diagnostics.len();
    phase_profile::scope("05.d.2.a.1a6.static_machine_selections", || {
        if let Err(mut errors) =
            crate::static_arguments::validate_authored_static_arguments(program)
        {
            diagnostics.append(&mut errors);
        }
        if let Err(mut errors) = crate::static_bindings::validate_static_machine_bindings(program) {
            diagnostics.append(&mut errors);
        }
        formed_static_machine_selections =
            machine_parameters::form_static_machine_selections(program, &mut diagnostics);
        if diagnostics[formation_diagnostic_start..]
            .iter()
            .any(Diagnostic::is_error)
        {
            return;
        }
        if effect_admission == EffectAdmission::Complete {
            match machine_parameters::admit_static_machine_effects(
                program,
                &conformance_operational,
                std::mem::take(&mut formed_static_machine_selections),
            ) {
                Ok(selections) => static_machine_selections = selections,
                Err(mut errors) => diagnostics.append(&mut errors),
            }
            invocations::validate_invocation_contracts(program, &mut diagnostics);
        }
    });
    // A rejected authored application has no well-formed concrete body to
    // check. Report its source contract instead of derivative clone errors.
    if diagnostics[formation_diagnostic_start..]
        .iter()
        .any(Diagnostic::is_error)
    {
        return Err(diagnostics);
    }

    drop(pre_machine_guard);
    let body_index = phase_profile::scope("05.d.2.a.2.dependency_bodies", || {
        dependency_bodies::DependencyBodyIndex::prepare(
            program,
            prior_dependency_bodies,
            record_dependency_bodies,
        )
    });
    let machine_loop_guard = phase_profile::guard("05.d.2.a.2.machine_loop");
    let mut proven_machine_contracts = Vec::new();
    let has_plan_laid_integer_fields = program.plan_laid_layouts.iter().any(|plan| {
        plan.geometries(program.typed_program())
            .any(|geometry| !geometry.integer_fields.is_empty())
    });
    // Each machine is judged independently over the immutable program, so
    // machines are partitioned across workers. A worker owns its machine's
    // outputs and its lazy bound catalog; nothing below reads another
    // machine's rows. Merging in roster order keeps diagnostics, decisions
    // and first-wins contract rows identical to a sequential pass.
    let validate_machine = |machine_index: usize,
                            machine: &typed_trees::machine::Machine,
                            bound_lookup: &mut (
        &'program dyn crate::CheckingInput,
        Option<crate::proof_contracts::immutable_integer_bounds::ImmutableBoundLookup<'program>>,
    )|
     -> MachineValidation {
        let mut diagnostics = Vec::new();
        let mut proven_machine_contract = None;
        let mut arithmetic_decisions = arithmetic_domains::ArithmeticDecisions::default();
        let mut stored_integer_writes = Vec::new();
        let mut boundary_operator_applications = Vec::new();
        let mut self_call_descents = Vec::new();
        let _machine_pkg_guard = phase_profile::enabled().then(|| {
            let is_toolchain_or_std = program
                .symbols
                .symbol_provenance_source_span(machine.symbol)
                .and_then(|span| program.symbols.source_file(span))
                .is_some_and(|file| {
                    file.origin == source::SourceOrigin::Toolchain
                        || file
                            .path
                            .components()
                            .any(|component| component.as_os_str() == "std")
                });
            if is_toolchain_or_std {
                phase_profile::count("05.d.2.a.2.machines.std_or_core", 1);
                phase_profile::guard("05.d.2.a.2.machine.std_or_core")
            } else {
                phase_profile::count("05.d.2.a.2.machines.user_or_other", 1);
                phase_profile::guard("05.d.2.a.2.machine.user_or_other")
            }
        });
        let machine_diagnostic_mark = diagnostics.len();
        let machine_symbols = MachineSymbols::build(program, machine, &mut diagnostics);

        validate_owned_data(program, machine, &symbols, &mut diagnostics);
        validate_generic_conformance_bounds(program, machine, &symbols, &mut diagnostics);
        validate_machine_contracts(program, machine, &mut diagnostics);
        arithmetic_domains::validate_machine_total_specification_arithmetic(
            program,
            machine,
            &mut diagnostics,
        );
        // Pristine templates remain in the frozen roster. Judge their declared
        // abstract envelope here, alongside concrete bodies; preparation cannot
        // grant a blanket prevalidated exemption to either declaration.
        // This is the one judgment over bodies: the stage-04 prover consumes
        // the retained postconditions below. A dependency body already judged
        // in this invocation transfers its raw proved ordinals and still runs
        // exit coverage; it does not grow a second summary of the body.
        let mut captured_entailment = None;
        {
            let _entail_guard = phase_profile::guard("05.d.2.a.2a.contract_entailment");
            if let Some(proven) = body_index.reuse(program, machine, machine_index) {
                phase_profile::count("05.d.2.a.2a.contract_entailment.reused", 1);
                if machine.supply_mode == language_semantics::MachineSupplyMode::CheckedBody {
                    let judged =
                        if crate::proof_contracts::contract_entailment::entailment_covers_all_exits(
                            program, machine,
                        ) {
                            proven
                        } else {
                            ProvenContractExpressions::default()
                        };
                    proven_machine_contract = Some((machine.symbol, judged));
                }
            } else {
                if body_index.active_observation() {
                    phase_profile::count("05.d.2.a.2a.contract_entailment.judged", 1);
                }
                let mut machine_diagnostics = Vec::new();
                let mut proven = ProvenContractExpressions::default();
                crate::proof_contracts::contract_entailment::validate_machine_contract_entailment(
                    program,
                    machine,
                    &mut machine_diagnostics,
                    &mut proven,
                );
                captured_entailment = body_index.capture(program, machine, machine_index, &proven);
                if machine.supply_mode == language_semantics::MachineSupplyMode::CheckedBody {
                    let judged = if machine_diagnostics.is_empty()
                        && crate::proof_contracts::contract_entailment::entailment_covers_all_exits(
                            program, machine,
                        ) {
                        proven
                    } else {
                        ProvenContractExpressions::default()
                    };
                    proven_machine_contract = Some((machine.symbol, judged));
                }
                diagnostics.append(&mut machine_diagnostics);
            }
        }
        if effect_admission == EffectAdmission::Complete {
            validate_machine_trait_conformances(
                program,
                &conformance_service_reaches,
                machine,
                &symbols,
                &mut diagnostics,
            );
        }

        // PRV4 step 1: a `via <Binding>` clause is the EXTERNAL LEAF's
        // realization -- it must never parse and then silently drop. Exactly
        // one via clause, on a bodyless realizing machine, populates
        // ExternalRealization; every other carrier refuses here.
        {
            let conformances = program.machine_trait_conformances(machine);
            let via_count = conformances
                .iter()
                .filter(|conformance| {
                    conformance.external_binding.is_some() || conformance.via_expression.is_valid()
                })
                .count();
            for conformance in conformances {
                if conformance.external_binding.is_some() && conformance.via_expression.is_valid() {
                    diagnostics.push(Diagnostic::error(format!(
                        "machine `{}` retains both a bootstrap binding and an ordinary `via` expression on one conformance",
                        machine.name,
                    )));
                }
                validate_external_via_expression(program, machine, conformance, &mut diagnostics);
            }
            let is_external = matches!(
                machine.supply_mode,
                language_semantics::MachineSupplyMode::ExternalRealization { .. }
            );
            if via_count > 1 {
                diagnostics.push(Diagnostic::error(format!(
                    "machine `{}` carries {via_count} `via` bindings; an external \
                     leaf has exactly one realization",
                    machine.name,
                )));
            } else if via_count == 1 && !is_external {
                diagnostics.push(Diagnostic::error(format!(
                    "machine `{}` carries a `via` binding but is not an external \
                     leaf: `satisfies Requirement via <Binding>;` belongs on a \
                     BODYLESS external realization (a composite lowering is an \
                     ordinary checked body; an accepted axiom carries no \
                     realization)",
                    machine.name,
                )));
            }
            if via_count == 1 && is_external {
                validate_external_leaf_native_shapes(program, machine, &mut diagnostics);
            }
        }

        // Arrival analysis covers the entire immutable machine. State-local
        // statement validation borrows that batch and mutates only its clone.
        let mut incoming_environments = None;
        let is_content_projection_machine =
            content_projections::is_content_projection_machine(program, machine);
        let is_proof_machine = proof_only.is_proof_machine(program, machine);
        let _states_guard = phase_profile::guard("05.d.2.a.2b.state_statements");
        for (state_index, state) in program.machine_states(machine).iter().enumerate() {
            crate::value_custody::reference_local_establishment::validate(
                program,
                machine,
                state,
                &mut diagnostics,
            );
            // A state that DECLARES a return type but has an EMPTY body can
            // never produce the value -- callers would silently bind 0 (ZII),
            // and native/interp diverge on what that zero reads as. GENERIC
            // machines are exempt: the core/std container surface (`machine
            // Vec::as_slice<T>(&self) -> &[T] { }`) is deliberately
            // type-check-only, and value calls to generics are already fenced
            // (fence_generic_value_callee).
            if state.return_type.is_valid()
                && program.machine_type_parameters(machine).is_empty()
                // A SPECIALIZED generic keeps its declaration symbol while
                // MP4 substitution consumes its type parameters in place --
                // it inherits the generic exemption (the core container
                // surface is type-check-only; value calls stay fenced). The
                // exemption follows the specialization either way: the first
                // instance may reuse the template symbol, later instances are
                // fresh clones.
                && !program.machine_specializations.iter().any(|specialization| {
                    specialization.template == machine.symbol
                        || specialization.instance == machine.symbol
                })
                // A signature-only callable declares a result contract, not
                // an empty executable body. Requirement and external supply
                // obey the same body-presence rule as boundary declarations.
                && machine.supplies_checked_body()
                && program
                    .statement_table
                    .statements(state.statement_nodes)
                    .is_empty()
            {
                diagnostics.push(Diagnostic::error(format!(
                    "machine `{}` state `{}` declares a return type but its body is \
                     empty -- it can never produce the value (callers would silently \
                     bind 0). Return a value or drop the `-> T`.",
                    machine.name,
                    state.name.as_str(),
                )));
            }
            validate_local_data_names(
                program.statement_table.statements(state.statement_nodes),
                &machine_symbols,
                program.state_parameters(state),
                machine.name.as_str(),
                state.name.as_str(),
                &mut diagnostics,
            );
            // S4: a per-state-body value environment tracks each place's proven
            // interval along the straight-line prefix, so the exact-overflow proof
            // can use actual values (`self.v = 10; self.v += 5`) instead of the
            // full type range. The ENTRY state (first) is pre-seeded with the
            // machine's `requires` bounds on its parameters (`requires amount <=
            // 100`), so bounded param arithmetic stays exact. Statements are
            // validated in order so the environment is current at each use.
            let mut value_environment = if state_index == 0 {
                arithmetic_domains::requires_value_environment(program, machine, state)
            } else {
                // A non-entry state may assume the facts established by every
                // incoming guarded transition. Multiple predecessors join at
                // their common facts and widest admitted interval; call,
                // continuation, and self-loop entries remain conservative
                // fences.
                incoming_environments
                    .get_or_insert_with(|| {
                        arithmetic_domains::incoming_guard_environments(
                            program,
                            machine,
                            call_frames.as_ref(),
                        )
                    })
                    .iter()
                    .find_map(|(symbol, environment)| {
                        (*symbol == state.symbol).then(|| environment.clone())
                    })
                    .unwrap_or_default()
            };
            // Value facts follow control edges, not source order. Still check
            // every authored statement: unreachable instructions are validated
            // separately with no predecessor facts and cannot affect the live
            // path's observations. Before control admission an unknown graph
            // likewise supplies no sequential value evidence.
            let statements = program.statement_table.statements(state.statement_nodes);
            let mut order = program
                .statement_table
                .finite_execution_order(state.statement_nodes)
                .ok()
                .flatten()
                .unwrap_or_default();
            let executed_count = order.len();
            let mut executed = vec![false; statements.len()];
            for &statement_index in &order {
                executed[statement_index] = true;
            }
            order.extend((0..statements.len()).filter(|index| !executed[*index]));
            for (position, statement_index) in order.into_iter().enumerate() {
                if position >= executed_count {
                    value_environment.clear();
                }
                let statement_handle = state.statement_nodes.handle_at(statement_index as u32);
                let statement = &statements[statement_index];
                let statement_diagnostic_mark = diagnostics.len();
                let writable_roots = WritableRoots {
                    program,
                    machine,
                    machine_symbols: &machine_symbols,
                    statements: &program.statement_table.statements(state.statement_nodes)
                        [..statement_index],
                    parameters: program.state_parameters(state),
                };
                let transition_values = transitions::TransitionValueEnvironments::collect(
                    program,
                    machine,
                    state,
                    statement,
                    &value_environment,
                    call_frames.as_ref(),
                );
                if let Some(local) = statement.as_local_data()
                    && !local.type_is_inferred
                    && !local.is_operand_capture
                {
                    statements::validate_local_type_reference(
                        program,
                        machine,
                        Some(state),
                        &state.name,
                        local,
                        &symbols,
                        &value_environment,
                        &mut diagnostics,
                    );
                }
                // R5 value-call frame: conservatively apply the aggregate
                // may-write set of every call nested in this statement before
                // checking general value uses. Transition arguments retain
                // their individual evaluation-point environments above. Other
                // uses give up evaluation-order precision within one expression
                // rather than carry pre-call facts across a mutating call. A
                // call-free expression reports an empty frame; any unresolved
                // call retires mutable-storage facts; copied immutable scalars
                // retain their already established value snapshots.
                let value_written = call_frames.as_ref().and_then(|frames| {
                    frames.statement_value_may_write_paths_for_symbols(
                        machine,
                        &machine_symbols,
                        statement,
                    )
                });
                // Conflicting top-level declarations can prevent creating a
                // resolver at all. That does not give a call-free statement
                // unknown effects: preserve its incoming facts, as the
                // resolver's empty value-call frame would. An unresolved
                // value call still clears mutable-storage facts; direct writes and calls
                // remain the statement validator's responsibility below.
                if let Some(written) = value_written {
                    value_environment.invalidate_call_paths(program, Some(state), &written);
                } else if call_frames.is_some()
                    || calls::statement_value_expression_roots(program, statement)
                        .iter()
                        .any(|expression| calls::expression_has_calls(program, *expression))
                {
                    value_environment.invalidate_unknown_writes(program, Some(state));
                }
                // VALUE-position calls inside this statement's expression trees
                // (LocalData initializers, transition arguments, guard subjects,
                // etc.) are not reached by `validate_state_statement_node`; run
                // their bound + argument checks here, before the statement records
                // its own writes. The flow-sensitive environment has already
                // crossed every nested value-call frame above, so no argument can
                // rely on a fact an earlier or opaque call may invalidate.
                if !is_content_projection_machine {
                    validate_value_position_calls(
                        program,
                        machine,
                        state,
                        statement,
                        &symbols,
                        &writable_roots,
                        &value_environment,
                        &transition_values,
                        &mut boundary_operator_applications,
                        &mut diagnostics,
                    );
                }
                // PROOF MACHINES (free machines over proof-only data) are
                // exempt from the tail-only rule: they emit no runtime code,
                // so there is no frame to survive a non-tail call --
                // structural recursion (`Succ { prev: double(prev) }`) is
                // the induction the measure licenses. What still applies is
                // the measure itself: every self-call must structurally
                // descend (N2d gateway).
                if is_proof_machine {
                    self_call_descents.extend(validate_proof_machine_recursion(
                        program,
                        machine,
                        state,
                        statement_index,
                        statement,
                        &mut diagnostics,
                    ));
                } else {
                    validate_self_recursive_call_positions(
                        program,
                        machine,
                        state,
                        statement,
                        &mut diagnostics,
                    );
                }
                let direct_written = match statement {
                    StatementNode::Call(call) => call_frames
                        .as_ref()
                        .and_then(|frames| frames.may_write_paths(machine, call)),
                    StatementNode::Assignment(_) => call_frames.as_ref().and_then(|frames| {
                        frames
                            .assignment_write_frame(machine, statement)
                            .into_complete_paths()
                    }),
                    _ => None,
                };
                let local_write_origins = if matches!(statement, StatementNode::Assignment(_))
                    && has_plan_laid_integer_fields
                {
                    call_frames.as_ref().and_then(|frames| {
                        frames.local_write_origins_before_statement(machine, statement)
                    })
                } else {
                    Some(Vec::new())
                };
                validate_state_statement_node(
                    program,
                    machine,
                    &state.name,
                    Some(state),
                    &machine_symbols,
                    &symbols,
                    &writable_roots,
                    statement_handle,
                    statement_index,
                    statement,
                    &mut value_environment,
                    &transition_values,
                    direct_written,
                    local_write_origins.as_deref(),
                    call_frames.as_ref(),
                    &mut arithmetic_decisions,
                    &mut stored_integer_writes,
                    &mut boundary_operator_applications,
                    bound_lookup,
                    &mut diagnostics,
                );
                // Statement-adjacent checks above this point mint only
                // message text; the statement under validation owns the
                // authored position every consumer attributes them to.
                if diagnostics.len() > statement_diagnostic_mark
                    && let Some(source_span) = statements::statement_source_span(program, statement)
                {
                    for diagnostic in &mut diagnostics[statement_diagnostic_mark..] {
                        if diagnostic.source_span.is_none() {
                            diagnostic.source_span = Some(source_span);
                        }
                    }
                }
            }
        }
        // Machine-level checks mint only message text; the machine's own
        // declaration owns their authored position.
        if diagnostics.len() > machine_diagnostic_mark {
            let machine_source_span = program
                .symbols
                .symbol_provenance_source_span(machine.symbol)
                .filter(|source_span| *source_span != source::SourceSpan::default());
            for diagnostic in &mut diagnostics[machine_diagnostic_mark..] {
                if diagnostic.source_span.is_none() {
                    diagnostic.source_span = machine_source_span;
                }
            }
        }
        MachineValidation {
            diagnostics,
            proven_machine_contract,
            captured_entailment,
            arithmetic_decisions,
            stored_integer_writes,
            boundary_operator_applications,
            self_call_descents,
        }
    };
    let machines = program.machines();
    let judged = checking_thread_pool().install(|| {
        machines
            .par_iter()
            .enumerate()
            .map_init(
                || (program, None),
                |bound_lookup, (machine_index, machine)| {
                    validate_machine(machine_index, machine, bound_lookup)
                },
            )
            .collect::<Vec<_>>()
    });
    let mut captured_entailments = Vec::with_capacity(judged.len());
    for machine in judged {
        captured_entailments.push(machine.captured_entailment);
        diagnostics.extend(machine.diagnostics);
        if let Some((symbol, judged)) = machine.proven_machine_contract
            && !proven_machine_contracts
                .iter()
                .any(|(existing, _)| *existing == symbol)
        {
            proven_machine_contracts.push((symbol, judged));
        }
        arithmetic_decisions.append(machine.arithmetic_decisions);
        stored_integer_writes.extend(machine.stored_integer_writes);
        // A site validated twice keeps its first application and reports an
        // inconsistent second one, exactly as one shared roster did.
        for application in machine.boundary_operator_applications {
            crate::declarations::operators::retain_validated_boundary_operator_application(
                &mut boundary_operator_applications,
                application,
                &mut diagnostics,
            );
        }
        self_call_descents.extend(machine.self_call_descents);
    }
    let dependency_body_judgments = body_index.judgments(&captured_entailments);
    drop(machine_loop_guard);
    let _post_machine_guard = phase_profile::guard("05.d.2.a.3.post_machine_validators");

    let arithmetic_domains::ArithmeticDecisions {
        integer_range_obligations,
        mut exact_integer_casts,
        mut integer_assignments,
        mut decided_formations,
        expression_values: walked_intervals,
    } = arithmetic_decisions;
    let mut expression_intervals = Vec::<ExpressionInterval>::new();
    let mut walked_intervals = walked_intervals;
    walked_intervals
        .sort_by_key(|value| checked_trees::operators::handle_position(value.expression));
    for value in walked_intervals {
        let expression = value.expression;
        let interval = value.interval;
        // Each walk bounds the evaluations it saw; their hull bounds them all.
        match expression_intervals.last_mut() {
            Some(previous) if previous.expression == expression => {
                previous.low = previous.low.zip(interval.low()).map(|(a, b)| a.min(b));
                previous.high = previous.high.zip(interval.high()).map(|(a, b)| a.max(b));
            }
            _ => expression_intervals.push(ExpressionInterval {
                expression,
                low: interval.low(),
                high: interval.high(),
            }),
        }
    }
    // Qualification consumes these same occurrence-bound operand judgments.
    // It follows flow checking so locals, guards, selected calls and writes
    // have one value owner; the asserted target never supplies its own premise.
    crate::value_custody::qualification_casts::validate(
        program,
        &expression_intervals,
        &mut diagnostics,
    );
    finish_diagnostics(diagnostics)?;
    // Warning collection follows all formation and flow checks: a warning must
    // not make a clean assignment skip its range or value-environment update.
    // A missing anonymous bitwise carrier matters only when no source error
    // already explains why the program cannot form.
    let mut anonymous_bitwise = Vec::new();
    literals::validate_anonymous_bitwise(program, &mut anonymous_bitwise);
    finish_diagnostics(anonymous_bitwise)?;
    finish_diagnostics(literals::anonymous_integer_landing_warnings(program))?;
    decided_formations
        .sort_by_key(|expression| checked_trees::operators::handle_position(*expression));
    decided_formations.dedup();
    // The receiving declaration is immutable across arithmetic walks. Retain
    // each exact assignment once, after every walk has returned clean.
    integer_assignments.sort_by_key(|decision| {
        (
            (
                decision.machine.arena_index(),
                decision.machine.generation(),
            ),
            (decision.state.arena_index(), decision.state.generation()),
            decision.statement_index,
        )
    });
    integer_assignments.dedup();
    exact_integer_casts
        .sort_by_key(|fact| (fact.expression.arena_index(), fact.expression.generation()));
    exact_integer_casts.dedup_by(|right, left| {
        if left.expression != right.expression {
            return false;
        }
        left.minimum = left.minimum.clone().min(right.minimum.clone());
        left.maximum = left.maximum.clone().max(right.maximum.clone());
        true
    });
    let (float_meaning_projection_invocations, float_meaning_equality_propositions) =
        float_projection_invocations::collect_float_meaning_projection_invocations(program)?;
    Ok(ProgramValidation {
        operational: conformance_operational,
        service_reaches: conformance_service_reaches,
        facts: ProgramValidationFacts {
            quotient_formations,
            integer_range_obligations,
            static_machine_selections,
            formed_static_machine_selections,
            stored_integer_writes,
            integer_assignments,
            boundary_operator_applications,
            exact_integer_casts,
            decided_formations,
            expression_intervals,
            float_meaning_projection_invocations,
            float_meaning_equality_propositions,
            fact_call_projections,
            specification_calls,
            integer_embedding_calls,
            proof_recursive_components,
            self_call_descents,
            proven_machine_contracts,
        },
        dependency_body_judgments,
    })
}

/// Errors fail the build; a WARNING-only batch surfaces on stderr and
/// passes (the Decision-12 relaxation: uniform compilation, deadness
/// outside proofs warns). stderr is the v1 warning channel -- report
/// integration is recorded in TASKS.md.
pub(crate) fn finish_diagnostics(diagnostics: Vec<Diagnostic>) -> Result<(), Vec<Diagnostic>> {
    if diagnostics.iter().any(Diagnostic::is_error) {
        return Err(diagnostics);
    }
    for warning in &diagnostics {
        eprintln!("{warning}");
    }
    Ok(())
}

/// Complete effect-sensitive source admission against the dependency graph
/// retained by the caller's prepared-effect scope. Formation and source flow
/// have already run; no source is reparsed or revalidated wholesale here.
pub fn admit_prepared_program_effects(
    program: &dyn crate::CheckingInput,
    operational: &flow_effects::OperationalPlan,
    facts: &mut ProgramValidationFacts,
) -> Result<(), Vec<Diagnostic>> {
    let mut diagnostics = Vec::new();
    crate::value_custody::atomic_fences::validate_atomic_fence_declarations(
        program,
        &mut diagnostics,
    );
    let symbols = TopLevelSymbols::build(program, &mut diagnostics);
    let service_reaches = infer_service_reaches(program, operational);
    validate_conformances(program, &service_reaches, &symbols, &mut diagnostics);
    if let Err(mut errors) = collect_dynamic_implementation_selections(program) {
        diagnostics.append(&mut errors);
    }
    match machine_parameters::admit_static_machine_effects(
        program,
        operational,
        std::mem::take(&mut facts.formed_static_machine_selections),
    ) {
        Ok(selections) => facts.static_machine_selections = selections,
        Err(mut errors) => diagnostics.append(&mut errors),
    }
    invocations::validate_invocation_contracts(program, &mut diagnostics);
    for machine in program.machines() {
        validate_machine_trait_conformances(
            program,
            &service_reaches,
            machine,
            &symbols,
            &mut diagnostics,
        );
    }
    facts.integer_embedding_calls =
        proof_embeddings::validate_integer_embedding_calls(program, &mut diagnostics);
    facts.fact_call_projections = fact_call_projections::validate_fact_call_projections(
        program,
        operational,
        &service_reaches,
        &mut diagnostics,
    );
    facts.specification_calls =
        crate::machine_calls::denotational_calls::validate_specification_calls(
            program,
            operational,
            &service_reaches,
            &mut diagnostics,
        );
    if let Err(mut errors) = crate::validate_behavior_plan(program, operational) {
        diagnostics.append(&mut errors);
    }
    validate_cleanup_normal_completion(program, operational, &mut diagnostics);
    finish_diagnostics(diagnostics)
}

/// A hook is an internal invocation, but the cleanup continuation requires a
/// normal completion. Check the exact selected boundary requirements in its
/// transitive graph; Console reach alone neither proves nor excludes exit.
fn validate_cleanup_normal_completion(
    program: &dyn crate::CheckingInput,
    operational: &flow_effects::OperationalPlan,
    diagnostics: &mut Vec<Diagnostic>,
) {
    for (_, dependency) in operational.cleanup_dependencies.iter() {
        let mut pending = vec![dependency.target_machine];
        let mut visited = Vec::new();
        while let Some(target) = pending.pop() {
            if target == dependency.caller_machine {
                diagnostics.push(Diagnostic::error(format!(
                    "selected cleanup dependency from `{}` to `{}` creates a recursive call component without an exact cleanup-edge ranking witness",
                    program.symbols.name(dependency.caller_machine),
                    program.symbols.name(dependency.target_machine),
                )));
                break;
            }
            if visited.contains(&target) {
                continue;
            }
            visited.push(target);
            let Some(index) = operational.machine_index_by_symbol(target) else {
                continue;
            };
            let machine = &operational.machines()[index];
            let exits = operational
                .states
                .span_or_empty(machine.states)
                .iter()
                .any(|state| {
                    operational
                        .calls
                        .span_or_empty(state.calls)
                        .iter()
                        .any(|call| {
                            if call.target_machine_symbol.is_valid() {
                                pending.push(call.target_machine_symbol);
                            }
                            let requirement = crate::exact_external_leaf_boundary_requirement(
                                program,
                                call.target_state_symbol,
                            )
                            .map_or(call.target_state_symbol, |(requirement, _)| requirement);
                            matches!(
                                crate::boundary_requirement_completion(program, requirement),
                                semantic_vocabulary::BoundaryCompletion::External(_)
                            )
                        })
                });
            if exits {
                diagnostics.push(Diagnostic::error(format!(
                    "cleanup machine `{}` must return normally; its selected call closure permits external process exit",
                    program.symbols.name(dependency.target_machine))));
                break;
            }
            pending.extend(
                operational
                    .cleanup_dependencies
                    .iter()
                    .filter_map(|(_, child)| {
                        (child.caller_machine == target).then_some(child.target_machine)
                    }),
            );
        }
    }
}

/// One machine's validation outputs, produced by a worker that owns them and
/// merged into the program's rows in roster order.
struct MachineValidation {
    diagnostics: Vec<Diagnostic>,
    proven_machine_contract: Option<(symbols::SymbolHandle, ProvenContractExpressions)>,
    captured_entailment: Option<dependency_bodies::CapturedEntailment>,
    arithmetic_decisions: arithmetic_domains::ArithmeticDecisions,
    stored_integer_writes: Vec<checked_trees::CheckedStoredIntegerWrite>,
    boundary_operator_applications: Vec<ValidatedBoundaryOperatorApplication>,
    self_call_descents: Vec<crate::ValidatedSelfCallDescent>,
}

/// Checking recurses as deeply as the compile thread does, so the stage's
/// workers carry that thread's stack budget instead of the host default.
/// The stage owns this pool; no caller configures the process-wide one.
const CHECKING_STACK_SIZE: usize = 256 * 1024 * 1024;

pub fn checking_thread_pool() -> &'static rayon::ThreadPool {
    static POOL: std::sync::OnceLock<rayon::ThreadPool> = std::sync::OnceLock::new();
    POOL.get_or_init(|| {
        rayon::ThreadPoolBuilder::new()
            .thread_name(|index| format!("omega-check-{index}"))
            .stack_size(CHECKING_STACK_SIZE)
            .build()
            .expect("machine validation worker pool")
    })
}
