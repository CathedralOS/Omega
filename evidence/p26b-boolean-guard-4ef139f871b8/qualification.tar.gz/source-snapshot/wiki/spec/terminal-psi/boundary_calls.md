# Terminal Psi boundary calls and realization

[Portable product](product.md) | [Byte views](byte_views.md)

These are semantic and evidence requirements, not a claim that every described
native route is implemented. Unsupported routes reject at their owning consumer.
Boundary [content conservation](../resources/content_custody.md#call-conservation)
and [installed component publication](../build/component_publication.md) have
separate contracts; selecting a provider does not establish either by itself.

## Call and requirement identity

A static bodyless call retains its boundary-machine identity; provider selection
does not rewrite it into a chosen implementation. Declarations retain ordered
scalar parameter types, and calls retain matching ordered value identities
alongside the independent structural argument lane. The optional primitive
scalar result is a separate lane. Encoding binds the orders; verification checks
arity, definition, dominance, and exact types. Interpretation evaluates scalar
inputs before invoking the effect handler. Lowering must preserve both lanes.

Each declaration also retains the exact runtime interleave as scalar/structural
parameter tags. Reading a tag consumes the next parameter from that lane; the
tag counts must cover both lanes exactly. Scalar contract IDs and structural
custody positions remain lane-local. Erased formals do not receive tags. A
boundary call separately retains its exact static provider-slot application and
selected-plan demand; no source routing argument or hidden service-receiver lane
is encoded.
Private callback parameters enter only through the evaluated calling plan.
Native placement and independent replay join both semantic lanes to that plan
in retained runtime order, never scalar-first by convention.

Borrowed arguments retain the caller's referent across completion. Only owned
arguments transfer custody; eventual owner cleanup remains separate even when
another argument in that call is consumed.

A mutable byte-view parameter lends the exact writable range selected by the
caller. [Bounded line input](../resources/bounded_input.md) returns a count and
stopping reason; it does not resize that range or replace its owner's live
length. Source access, initialization, disjointness, and completion checks still
apply. A fixed array may supply its range without changing fixed-array length;
a slice of a variable-fill owner does not expose unused capacity.

The current interpreter's boundary-only bounded-field replacement carrier is a
migration implementation, not source authority to resize through an ordinary
slice. Its exact path, capacity, and staged length-writeback evidence do not
establish the settled `read_line` contract. Remove this use from the line-input
route as source signatures, checked providers, and consumers migrate together.
Independently specified whole-field stores retain their explicit destination
and immutable source under [structural access](structural_access.md).

Boundary calls name exact trait requirements. The retired standalone top-level
boundary-requirement kind is not a second canonical operation identity; migrate
its package-qualified operations to boundary traits and retain the trait
application, requirement, static telescope, signature, contract and visibility.
A bodyless implementation, bounded effect row or provider selection cannot
synthesize requirement identity.

Executable trait requirements retain their exact owning service identity as a
declaration field. Invoking the requirement contributes that service and its
parent closure regardless of the selected provider's body. Consumers do not
recover this relationship by parsing a callable name or reopening checked
source. Non-trait requirements carry no owning service. Non-executable
retained-borrow contract rows do not introduce an invocation by being retained.

## Boundary crash contracts

The boundary declaration retains its published crash routes, independently of
any selected provider. A scalar route uses declaration-local formal value IDs:
scalar argument ordinal plus one, typed by the declaration's existing scalar
signature. These IDs are not executable caller values, even when their numeric
coordinates coincide. Mixed structural/scalar signatures retain the scalar
lane's order; structural arguments do not consume scalar formal positions.

At each `BoundaryCall`, verification simultaneously substitutes its exact scalar
actuals into those routes and checks same-cause caller coverage. The declaration
and executable arguments are sufficient to reconstruct the obligation; a second
encoded continuation roster is not required. Neither successful provider
selection nor a narrower provider body changes the published requirement.
This is the boundary form of [call crash composition](calls_and_outcomes.md#call-contracts).

A host-reported crash is permitted only when a same-cause route evaluates true
for that invocation's already evaluated scalar inputs. Mathematical integer
predicates retain their unbounded denotation after substitution, not the input
carrier's wrapping arithmetic. Unsupported, undefined, or resource-exhausted
evaluation cannot authorize a crash or be reported as a false guard. Consumer
evaluation limits are service limits, not mathematical integer widths or a new
language restriction. A true guard still permits normal completion; checking a
reported crash establishes no normal result, disposition, or staged writeback.

## Structural domain requirements

A boundary structural requirement identifies an argument position and an exact
domain identity. Admission checks that identity in the argument's carried
qualification roster. The qualification was established through whatever proof
and/or sealed introduction its domain requires; the boundary call does not
establish it again.

This requirement is not a proposition term or conclusion and creates no
`ObligationId`. Boundary calls have no positional proof-obligation vector for
these requirements. Encoding a structural qualification as a trivially true
proposition cannot substitute for the carried identity.

## Scalar requires

A requirement's scalar `requires` clauses, and its integer parameter ranges,
are part of the contract the declaration retains. They are propositions in the
crash routes' declaration-local scalar-formal namespace, in canonical order,
naming no structural place or caller value. Each `BoundaryCall` carries one
`ObligationId` per row at the same index, as an ordinary call's `requires`
lane does. Verification instantiates the row at that call's scalar actuals and
proves it from the caller's facts before the call. A clause that is wholly
structural membership stays a structural domain requirement and has no row.

Selecting a provider does not remove or weaken these obligations. A checked
candidate may be installed for the call only when its own requirements follow
from the declaration's rows. Scalar normal-return guarantees use the same
formal namespace, with the scalar result immediately after the inputs. A
successful call substitutes the exact actuals and its produced result and
imports those guarantees. Checked provider admission requires each declared
guarantee in the provider's verified ensures roster after substitution; a
stronger provider contract never silently strengthens the caller's assumptions.
The declaration carries only supported scalar consequences of its authored
contract. A sealed mathematical meaning equation may supply a weaker runtime
predicate, but policy flags and selected provider identity supply no guarantee.

A proof condition may constrain a permitted use but cannot replace a domain's
sealed introduction or routed provenance. Qualification transfer must preserve
the exact argument path, identity, and establishment lineage under
[optimization](../build/optimizations.md#evidence-and-control-flow).

## Checked providers

Checked satisfiers are ordinary Terminal machines with canonical implementation
rows. A row binds the exact boundary-trait requirement, nominal provider, canonical
adapter, artifact-local machine, signature, and checked service refinement.
Resolve selected adapters by exact overload, provider implementation, and adapter identity
against the verified catalog, then admit only those machine identities for the
exact artifact. A cataloged boundary without that installation rejects; it must
not fall through to a generic host effect handler.

Provider conformance rejoins parameter and result declarations rather than
adding an independently encoded signature copy. Structural results retain exact
type, multiplicity, and qualifications. Candidate result places and caller
operation-result places remain distinct. Admission of a conformance does not
widen the supported candidate-body, claim, content, or crash-contract vocabulary.

A requirement's authorized root qualifications belong to that selected crossing,
not the adapter's ordinary direct-call result declaration. Descendant memberships
still come from the returned carrier. Linear results and linear children of an
affine result use the ordinary returning-edge claim correspondence by typed path;
neither catalog admission nor result multiplicity manufactures claims.

Execution transfers actual input custody through the ordinary structural-call
continuation and establishes the caller's result only after the selected
provider's successful, fuel-charged normal return. Suspension does not repeat the call
or invoke a host result fabricator. Projected consumers keep the same residual
complement and cleanup obligations as ordinary calls.

The canonical [process-exit requirement](../language/process_exit.md) instead
retains a closed external completion with no normal result. Conformance must
preserve its exact terminal identity, arguments, and progress contract. A
returning, divergent, or aborting provider is not a substitute merely because
its signature or reach matches. Exit produces no successful-disposition receipt
for abandoned obligations. A simulator terminates the bound simulated domain,
not its embedding host. Conditional ordinary helpers retain their return paths.

For projected claim transfer, replay the exact record/fixed-array argument path,
completion receipt, and complete caller claim-source catalog. The provider's
whole-root claim must match the resulting leaf type and rebase to that caller
path without dropping sibling sources. Replay access attenuation and linear
multiplicity separately. Path, receipt, provider, type, or qualification drift
rejects. Claim transfer alone cannot prove residual content geometry.

A boundary invocation inside an expression uses the same ordered operands
and caller-local completion receipts as a statement invocation. Completing
operand evaluation does not mint replacement claims. The retained computation
graph contributes its boundary dependencies to provider discovery, including
calls inside ordinary scalar helpers and constructed values; selected provider
installation still joins the exact requirement and candidate identities.

## Assumed runtime relationships

A root-selected [assumed binding contract](../build/assumed_binding_contracts.md)
is not a checked-provider conformance row. Retain the original requirement,
the supplied requirement and selected checked implementation, exact argument/
result correspondence, admitted entry/exit facts, authority receipts and full
assumption closure. Verify runtime-shape, operational and custody compatibility
independently of the assumed semantic relationship. A result fact is established
only for the actual successful return; direct calls to the supplied implementation
do not acquire caller-facing qualifications. Entry qualifications are scoped to
that exact admitted crossing, not added to arbitrary caller values.

The interpreter and native installation consume the same relationship. Neither
may rewrite it into proved conformance, hide the selected implementation, or
fabricate a successful result after a failed/suspended call. Build and automatic
test execution reject these relationships and their assumption-dependent helpers
before execution, even if the runtime root accepted them.

## Host result validation

An embedding handler distinguishes Unit, exactly typed scalar, and opaque
structural responses. Structural responses bind the exact declared type,
ordered qualifications, and whole-root path before result custody is installed.
Unsupported result capability rejects before invoking the handler. A malformed
response does not commit interpreter receipts or ownership changes, but this
does not roll back effects already performed by the host.

The host must supply a legitimate owned value. An opaque identity number does
not establish global allocation freshness against interpreter-created values
or suspended callers. Shape validation alone is not external ownership proof.
Current interpreter limits are described beside
[effect handling](../../../omega-rust/psi/interpreter/terminal-interpreter/README.md).

## Reachability and attachments

An installation-bound requirement may retain an upper-bound reachability row.
It is keyed by that exact requirement, its normalized service union bound, and
all internal call-graph dependencies. Equal service sets do not merge distinct
requirements. Do not replace the row with Boolean formulas or a caller-selected
implementation.

The boundary declaration retains explicitly declared fixed service and synchronous-invocation
contributions separately from that bound. Its published ceiling is their normalized
union. Installation substitutes only the bound: an explicitly declared service remains
concrete even when the selected provider is quiet or the same service also occurs
in the bound. Neither widening the bound nor subtracting it from the flattened
ceiling reconstructs this distinction.
The requirement/trait identity remains a selection and call-identity key; it
does not enter service reach unless explicitly named in a reach clause.

Installation verifies the selected concrete operation row is contained in the
bound and substitutes it through the complete root closure. Preselection
manifests retain the unresolved identity and bound; selected manifests add the
provider and operation; final admission rejects unresolved rows. Such unresolved
rows cannot cross an ordinary callable package or component boundary.

Verification reconstructs reachable fixed boundary rows, primitive service uses,
and exact installation dependencies from executable operations. That closure
must equal the retained root declaration: missing, padded, stale, or unused rows
reject. A primitive service use does not disappear because the service also
appears in an abstract row's bound.

Each boundary declaration retains its authored owner kind: machine, trait
signature, or legacy operator. Absence of a nominal attachment does not make
an operator a trait call. The kind participates in canonical identity. Machine
declarations include token-bearing machines and top-level requirements, so
this classification does not replace closed-application or physical-child
custody.

An ordinary explicit context parameter retains its exact record type, access
and multiplicity. A boundary call retains the exact closed requirement
application selected by source and the matching static provider-slot demand,
independently of whether the call is a statement or an operand inside an
expression. It gains no implicit `self` value or declaration-attachment
authority. Ordinary callees retain their own direct requirements and receive
existing contexts explicitly. Their signatures do not construct storage.
Generated native entry provisioning must establish and lend that context under
the selected [entry shape](../build/entry_roots.md#entry-shape-and-arrival-bridge);
an erased field's zero-payload layout proves no authority. A carrier-qualified
machine name supplies neither a parameter nor permission to provision one.

For a target-selected entry, provider-demand evidence binds each exact source
boundary call occurrence, closed requirement application, target slot, schema,
and selected Fused plan. Derive rows after exact selection and replay their
sorted roster at native settlement. Targetless checking and entries whose
executable closure does not contain the call establish no such row. Omission,
duplication, reordering, or requirement/plan substitution rejects. This evidence
is not source data, a publication event, or a protocol instance handle.

## Consumer-owned settlement

Join each demanded evaluated import to one exact retained selected plan.
Provider-execution evidence and same-stack contributions require independently
supplied admission. Callers cannot choose a replacement plan/index, locator,
target, builtin, or checked-source receipt at this join. Replay the complete
plan, external row, atomic locator, target, and strong stack commitment.
Missing, extra, duplicate, or builtin-substituted demanded settlements reject.
Selected but unreachable imports retain identity without requiring execution
inputs. [Callback use](../build/private_callbacks.md) additionally needs combined callback and checked-scope
custody; neither half authorizes the other.

Native provider executions must match the exact canonical requirement before
projection into numeric execution records. Similar Unit signatures do not make
two boundaries interchangeable. Catalog selection binds exact requirement and
realization symbols, accepted package/toolchain custody, normalized signatures,
conformance, and target profile. A targetless plan cannot infer a physical target
from the compiler host.

Compiler-builtin settlement uses the representation-level
`CompilerBuiltinExecution` catalog, not the planner's classification identity.
Its conversion must be one exhaustive checked mapping returning an optional
catalog entry, not a guard and an independently constructed payload. Unclassified
roles reject. Retain complete admitted settlement content for later replay;
a commitment alone cannot reconstruct it.

Physical nonreturning behavior does not itself prove source-semantic successful
external termination. That observation needs the exact canonical ProcessExit
requirement's explicit boundary/Terminal completion and effect identity, not a
separate provider-selected name. A containment trap after an unexpectedly
returning native exit does not authorize a source crash; it contains a violated
provider premise. Exact semantic exit arguments remain separate from the target's
physical status presentation. Likewise, image bytes and provider selection do
not by themselves establish executable publication.

## Operator applications and physical children

Generic demand is not coverage. A symbolic row binds the producer package,
callable, exact operator coordinate, requirement, and declared-binder mapping.
Only final closed substitution can yield coverage. Const identity is evaluated
value in its declared carrier, not spelling. Type/const applications are the
initial supported categories; unsupported lifetime/machine categories reject.

Within a compilation, ordinary machine and selected-provider specialization
reach a fixed point over immutable authored templates. Saved ordinary calls
rejoin by exact callee template and complete canonical tuple; another direct
instantiation cannot donate call choices. Specialized concrete uses receive
the same checks as direct uses, while open template occurrences remain symbolic.
This is not cross-artifact completeness evidence.

Specialization rechecks substituted semantics, target, admission, selected plan,
and realization. Bodyless/external supply remains exact-only; bootstrap lowering
cannot publish authoritative coverage.

A cross-artifact substitution must independently join producer and operator-owner
reviews, complete producer specialization, and the consumer's reviewed closed
selected plan. Every producer binder appears exactly once and every substitution
is used by the reviewed mapping. Rejoin requirement, coordinate, application,
selected artifact, and nonzero strong plan identity; retain original mapping and
specialization for replay. Deduplication follows that join. Checking supplied
requests does not prove they exhaust reachable specializations or establish
realization, admission, Terminal/native, or installation authority. Complete-set
composition remains an independent obligation, not an install/update prerequisite.

### Closed application and physical occurrence

A boundary operator's checked application must be closed after specialization.
The source-free demand retains exact occurrence, requirement coordinate, and
ordered tagged type/constant application. The strong selected-plan identity,
semantic realization, and specialized-body, nongeneric-body, builtin, or external
authority role remain in the exactly bound companion. Replay joins both.
Source spelling, arity, optional fields, compact fingerprints, or zero commitments
cannot substitute for that evidence.

An operator with a zero-length telescope has one canonical empty application.
A boundary-trait machine has no such telescope construct; absence is not an
empty operator application. Open applications and unsupported binder categories
reject authoritative publication.

Each surviving executable boundary occurrence has exactly one physical child.
Its parent is a role-tagged choice between a reconstructible operator-application
coverage reference and a retained, replayable boundary-trait settlement.
The latter reuses `BoundaryExecutionBinding`; its builtin commitment uses
`CompilerBuiltinExecution`. Role discriminants participate in identity.

Equal applications may share a semantic parent, but surviving optimized
occurrences and their children remain distinct. The child binds the parent,
surviving operation, target, selection, assignment, relocation, and emitted-span
identities. Replay derives the surviving occurrence set from the validated
published projection. Missing, duplicate, stale, substituted, padded, or
role-swapped children reject. An eliminated occurrence whose elimination is
checked needs no child. A byte digest, plan fingerprint, application string, or dispatch
rewrite alone establishes no semantic-to-physical correspondence.

For foreign calls, replay additionally joins the exact Terminal scalar values
and types to retained source, placement, home, and materialization rows. A
direct callback joins its exact registrar occurrence, context, and private
function identity. The child spans the full semantic-code attribution interval
and exact unresolved import and callback relocations, through object/image bytes
and final image-symbol identity. Partial structural, ranked, port, or callback
custody cannot be published as complete coverage.
