//! Structural const values under exact declaration-site carrier selection.
//!
//! The header resolver selects each nominal type and constructor in its own
//! authored source, including nested field carriers. Compare those declarations
//! before erasing names into the existing canonical atom. Field order and leaf
//! landing still determine the encoded value; final resolution independently
//! checks the receiving parameter's nominal carrier.
//!
//! Structural encoding recursively lands anonymous scalar leaves at the declared
//! component type. A suffixed leaf has already landed: erasing that carrier or
//! arithmetic domain would equate a differently typed value with this component,
//! even when its numeric payload fits. Check the landing before encoding it.
//! Array eligibility, element rosters and encoded carrier labels close geometry
//! through one source-selected integer extent. Generic bindings retain priority;
//! a completed named constant is read from its declaration, never a root-name map.
//! Ordinary declaration materialization does not request const-index eligibility.
//! Its recursively selected data and active-case predicates still discharge over
//! the completed value before encoding. Index requests share that membership
//! proof while retaining their stronger structural/canonical carrier judgment.
use super::super::{
    CanonicalConstValue, ConstDefinition, DataDefinition, DataMember, ExpressionHandle,
    ExpressionNode, FixedArrayLength, HandleSpan, HashSet, Identifier, Item, SyntaxTrees,
    TypeReferenceHandle, TypeReferenceNode,
};
use syntax_trees::identifier::JoinedSyntaxPath;

use crate::preparation::declaration_selection::{
    ConstantSelection, GenericApplicationSubstitution, resolved_generic_argument,
    substituted_generic_arguments,
};
use crate::preparation::generic_data::ClosedArgumentIdentity;
use crate::preparation::generic_data::ConstFactValue;
use crate::preparation::generic_data::arguments::{
    closed_argument_identity, monomorphizable_argument_slugs,
};
use crate::preparation::generic_data::integer_literal_value;
use crate::preparation::generic_data::qualified_const_name;
use numerics::literals::LandedIntegerType;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(in crate::preparation::generic_data) enum CanonicalConstNode {
    Integer {
        type_name: String,
        value: i128,
    },
    Boolean(bool),
    Float {
        format: numerics::literals::FloatFormat,
        bits: u64,
    },
    Array {
        type_name: String,
        values: Vec<CanonicalConstNode>,
    },
    Record {
        type_name: String,
        fields: Vec<(String, CanonicalConstNode)>,
    },
    Variant {
        type_name: String,
        case_name: String,
        fields: Vec<(String, CanonicalConstNode)>,
    },
}

impl CanonicalConstNode {
    pub(in crate::preparation::generic_data) fn encoding(&self) -> String {
        match self {
            Self::Integer { type_name, value } => {
                framed("integer", [type_name.clone(), value.to_string()])
            }
            Self::Boolean(value) => framed("boolean", [if *value { "true" } else { "false" }]),
            Self::Float { format, bits } => match format {
                numerics::literals::FloatFormat::F32 => format!("float:f32:{bits:08x}"),
                numerics::literals::FloatFormat::F64 => format!("float:f64:{bits:016x}"),
            },
            Self::Array { type_name, values } => framed(
                "array",
                std::iter::once(type_name.as_str().to_owned())
                    .chain(values.iter().map(Self::encoding)),
            ),
            Self::Record { type_name, fields } => framed(
                "record",
                std::iter::once(type_name.clone()).chain(
                    fields
                        .iter()
                        .flat_map(|(name, value)| [name.clone(), value.encoding()]),
                ),
            ),
            Self::Variant {
                type_name,
                case_name,
                fields,
            } => framed(
                "variant",
                [type_name.clone(), case_name.clone()].into_iter().chain(
                    fields
                        .iter()
                        .flat_map(|(name, value)| [name.clone(), value.encoding()]),
                ),
            ),
        }
    }

    pub(in crate::preparation::generic_data) fn display(&self) -> String {
        match self {
            Self::Integer { value, .. } => value.to_string(),
            Self::Boolean(value) => value.to_string(),
            Self::Float { format, bits } => match format {
                numerics::literals::FloatFormat::F32 => {
                    format!("{:?}f32", f32::from_bits(*bits as u32))
                }
                numerics::literals::FloatFormat::F64 => format!("{:?}f64", f64::from_bits(*bits)),
            },
            Self::Array { values, .. } => format!(
                "[{}]",
                values
                    .iter()
                    .map(Self::display)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            Self::Record { type_name, fields } => format!(
                "{type_name} {{ {} }}",
                fields
                    .iter()
                    .map(|(name, value)| format!("{name}: {}", value.display()))
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            Self::Variant {
                type_name,
                case_name,
                fields,
            } if fields.is_empty() => format!("{type_name}::{case_name}"),
            Self::Variant {
                type_name,
                case_name,
                fields,
            } => format!(
                "{type_name}::{case_name} {{ {} }}",
                fields
                    .iter()
                    .map(|(name, value)| format!("{name}: {}", value.display()))
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
        }
    }
}

pub(in crate::preparation::generic_data) fn framed(
    tag: &str,
    pieces: impl IntoIterator<Item = impl AsRef<str>>,
) -> String {
    let mut encoded = tag.to_owned();
    for piece in pieces {
        let piece = piece.as_ref();
        encoded.push_str(&piece.len().to_string());
        encoded.push(':');
        encoded.push_str(piece);
    }
    encoded
}

pub(in crate::preparation::generic_data) fn canonicalize_const_definition(
    syntax: &SyntaxTrees,
    definition: &ConstDefinition,
    parameter_type: TypeReferenceHandle,
) -> Result<CanonicalConstValue, String> {
    canonicalize_selected_const_definition(syntax, definition, parameter_type, None)
}

pub(in crate::preparation) fn canonicalize_selected_const_definition(
    syntax: &SyntaxTrees,
    definition: &ConstDefinition,
    parameter_type: TypeReferenceHandle,
    selection: Option<&ConstantSelection>,
) -> Result<CanonicalConstValue, String> {
    canonicalize_selected_const_definition_in_application(
        syntax,
        definition,
        parameter_type,
        selection,
        &GenericApplicationSubstitution::new(),
    )
}

pub(in crate::preparation::generic_data) fn canonicalize_selected_const_definition_in_application(
    syntax: &SyntaxTrees,
    definition: &ConstDefinition,
    parameter_type: TypeReferenceHandle,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
) -> Result<CanonicalConstValue, String> {
    let declared = syntax_type_identity(syntax, definition.type_reference)?;
    let required = substituted_type_label(syntax, parameter_type, substitution, selection)?;
    if !same_carrier_in_application(
        syntax,
        definition.type_reference,
        parameter_type,
        selection,
        substitution,
    )? {
        return Err(format!(
            "const `{}` declares type `{declared}`, but the parameter requires `{required}`",
            qualified_const_name(syntax, definition)
        ));
    }
    canonicalize_scoped_index_expression(
        syntax,
        definition.type_reference,
        &GenericApplicationSubstitution::new(),
        parameter_type,
        substitution,
        definition.value,
        selection,
    )
}

pub(in crate::preparation::generic_data) fn canonicalize_selected_index_expression(
    syntax: &SyntaxTrees,
    value_type: TypeReferenceHandle,
    parameter_type: TypeReferenceHandle,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
) -> Result<CanonicalConstValue, String> {
    canonicalize_scoped_index_expression(
        syntax,
        value_type,
        &GenericApplicationSubstitution::new(),
        parameter_type,
        &GenericApplicationSubstitution::new(),
        expression,
        selection,
    )
}

pub(in crate::preparation::generic_data) fn canonicalize_selected_index_expression_in_application(
    syntax: &SyntaxTrees,
    parameter_type: TypeReferenceHandle,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
) -> Result<CanonicalConstValue, String> {
    canonicalize_scoped_index_expression(
        syntax,
        parameter_type,
        substitution,
        parameter_type,
        substitution,
        expression,
        selection,
    )
}

fn canonicalize_scoped_index_expression(
    syntax: &SyntaxTrees,
    value_type: TypeReferenceHandle,
    value_scope: &GenericApplicationSubstitution,
    parameter_type: TypeReferenceHandle,
    parameter_scope: &GenericApplicationSubstitution,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
) -> Result<CanonicalConstValue, String> {
    validate_selected_const_index_type(
        syntax,
        parameter_type,
        &mut Vec::new(),
        selection,
        parameter_scope,
    )?;
    let node =
        canonicalize_const_expression(syntax, value_type, expression, selection, value_scope)?;
    canonical_const_result_in_application(syntax, parameter_type, node, selection, parameter_scope)
}

pub(in crate::preparation::generic_data) fn syntax_type_identity(
    syntax: &SyntaxTrees,
    type_reference: TypeReferenceHandle,
) -> Result<String, String> {
    Ok(
        match syntax.tables.type_references.type_reference(type_reference) {
            TypeReferenceNode::Named(name) => name.as_str(syntax).to_owned(),
            TypeReferenceNode::FixedArray {
                element_type,
                length: FixedArrayLength::Literal(length),
            } => format!(
                "[{}; {length}]",
                syntax_type_identity(syntax, *element_type)?
            ),
            TypeReferenceNode::Constrained { base_type, .. } => {
                syntax_type_identity(syntax, *base_type)?
            }
            TypeReferenceNode::Generic {
                base_name,
                arguments,
                ..
            } => {
                let argument_handles = syntax
                    .tables
                    .type_references
                    .type_reference_handles(*arguments);
                if argument_handles.is_empty() {
                    // A synthesized instance's lookup spelling carries its full
                    // name in `base_name`.
                    base_name.as_str(syntax).to_owned()
                } else {
                    let mut parts = Vec::with_capacity(argument_handles.len());
                    for argument in argument_handles {
                        parts.push(syntax_type_identity(syntax, *argument)?);
                    }
                    format!("{}<{}>", base_name.as_str(syntax), parts.join(", "))
                }
            }
            TypeReferenceNode::Unit => "()".to_owned(),
            TypeReferenceNode::ConstExpression(expression) => {
                match syntax.expressions.expression(*expression) {
                    syntax_trees::expression::ExpressionNode::Integer(literal) => {
                        super::integer_literal_value(literal)
                            .map(|value| value.to_string())
                            .ok_or_else(|| "integer literal exceeds const envelope".to_owned())?
                    }
                    syntax_trees::expression::ExpressionNode::Name(path) => {
                        let [member] = syntax.expressions.identifier_path_members(*path) else {
                            return Err("unsupported path in const expression".to_owned());
                        };
                        member.as_str(syntax).to_owned()
                    }
                    _ => {
                        return Err(
                            "structured const parameter types must be a canonical scalar, fixed array, or declared data value"
                                .to_owned(),
                        );
                    }
                }
            }
            _ => {
                return Err(
                "structured const parameter types must be a canonical scalar, fixed array, or declared data value"
                    .to_owned(),
            );
            }
        },
    )
}

// Encoded labels are consistency claims. Nominal equality is established from
// the selected declarations before values lose their authored spelling; the
// receiving generic slot independently rejoins that declared carrier later.
pub(super) fn selected_data<'syntax>(
    syntax: &'syntax SyntaxTrees,
    name: &Identifier,
    selection: Option<&ConstantSelection>,
) -> Result<&'syntax DataDefinition, String> {
    if let Some(selection) = selection {
        return selection.data(syntax, name);
    }
    let mut definitions = syntax.root_items().filter_map(|item| match item {
        Item::Data(definition) if definition.name.as_str(syntax) == name.as_str(syntax) => {
            Some(definition)
        }
        _ => None,
    });
    let definition = definitions.next().ok_or_else(|| {
        format!(
            "`{name}` is not a declared canonical data type",
            name = name.as_str(syntax)
        )
    })?;
    if definitions.next().is_some() {
        return Err(format!(
            "`{name}` has ambiguous nominal declarations",
            name = name.as_str(syntax)
        ));
    }
    Ok(definition)
}

/// Select a synthesized closed instance by its exact display name. Synthesized
/// declarations are pushed after the header symbol pass, so name law lookup
/// cannot reach them; their `generic_instance` evidence is what distinguishes
/// one from an authored declaration that happens to share the spelling.
fn selected_synthesized_instance<'syntax>(
    syntax: &'syntax SyntaxTrees,
    name: &Identifier,
) -> Result<&'syntax DataDefinition, String> {
    let mut candidates = syntax.root_items().filter_map(|item| match item {
        Item::Data(definition)
            if definition.generic_instance.is_some()
                && definition.name.as_str(syntax) == name.as_str(syntax) =>
        {
            Some(definition)
        }
        _ => None,
    });
    let instance = candidates.next().ok_or_else(|| {
        format!(
            "`{name}` does not select one declared canonical data type",
            name = name.as_str(syntax)
        )
    })?;
    if candidates.next().is_some() {
        return Err(format!(
            "`{name}` has ambiguous nominal declarations",
            name = name.as_str(syntax)
        ));
    }
    Ok(instance)
}

fn selected_constructor<'syntax>(
    syntax: &'syntax SyntaxTrees,
    name: &Identifier,
    selection: Option<&ConstantSelection>,
) -> Result<(&'syntax DataDefinition, Option<Identifier>), String> {
    if let Some(selection) = selection {
        return selection.constructor(syntax, name);
    }
    let record = selected_data(syntax, name, None).ok();
    let case = name.as_str(syntax).rsplit_once("::").and_then(|(owner, case)| {
        let owner = Identifier::new(owner, name.source_span());
        selected_data(syntax, &owner, None)
            .ok()
            .filter(|definition| {
                syntax.items.data_members(definition.members).iter().any(|member| {
                    matches!(member, DataMember::Variant(variant) if variant.name.as_str(syntax) == case)
                })
            })
            .map(|definition| (definition, Identifier::new(case, name.source_span())))
    });
    match (record, case) {
        (Some(definition), None) => Ok((definition, None)),
        (None, Some((definition, case))) => Ok((definition, Some(case))),
        _ => Err(format!(
            "`{name}` does not select one declared constructor carrier",
            name = name.as_str(syntax)
        )),
    }
}

/// The shared canonical-leaf packaging: re-label the selected type, gate a
/// `Rat` carrier through its canonical-form check, and wrap the node.
fn canonical_const_result(
    syntax: &SyntaxTrees,
    type_reference: TypeReferenceHandle,
    node: CanonicalConstNode,
    selection: Option<&ConstantSelection>,
) -> Result<CanonicalConstValue, String> {
    canonical_const_result_in_application(
        syntax,
        type_reference,
        node,
        selection,
        &GenericApplicationSubstitution::new(),
    )
}

fn canonical_const_result_in_application(
    syntax: &SyntaxTrees,
    type_reference: TypeReferenceHandle,
    node: CanonicalConstNode,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
) -> Result<CanonicalConstValue, String> {
    let required = substituted_type_label(syntax, type_reference, substitution, selection)?;
    if required == "Rat" {
        validate_canonical_rat(&node)?;
    }
    Ok(CanonicalConstValue::new(
        required,
        node.encoding(),
        node.display(),
    ))
}

fn selected_type_label(
    syntax: &SyntaxTrees,
    reference: TypeReferenceHandle,
    selection: Option<&ConstantSelection>,
) -> Result<String, String> {
    match syntax.type_references.type_reference(reference) {
        TypeReferenceNode::Named(name)
            if !crate::constant::is_builtin_scalar_carrier(name.as_str(syntax))
                && name.as_str(syntax) != "string" =>
        {
            // A rewritten instance spelling labels through its retained
            // authored application so the label is the synthesized name the
            // instance itself will own.
            let origin = syntax.type_references.generic_application_origin(reference);
            if origin.is_valid() && origin != reference {
                return selected_type_label(syntax, origin, selection);
            }
            Ok(selected_data(syntax, name, selection)?
                .name
                .as_str(syntax)
                .to_owned())
        }
        TypeReferenceNode::Generic {
            base_name,
            arguments,
            ..
        } => {
            let argument_handles = syntax.type_references.type_reference_handles(*arguments);
            if argument_handles.is_empty() {
                // A synthesized instance's lookup spelling selects the
                // instance declaration itself.
                return Ok(selected_synthesized_instance(syntax, base_name)?
                    .name
                    .as_str(syntax)
                    .to_owned());
            }
            let definition = selected_data(syntax, base_name, selection)?;
            generic_application_label(syntax, definition, argument_handles, selection)
        }
        TypeReferenceNode::FixedArray {
            element_type,
            length: FixedArrayLength::Literal(length),
        } => Ok(format!(
            "[{}; {length}]",
            selected_type_label(syntax, *element_type, selection)?
        )),
        TypeReferenceNode::Constrained { base_type, .. } => {
            selected_type_label(syntax, *base_type, selection)
        }
        _ => syntax_type_identity(syntax, reference),
    }
}

/// The canonical carrier label of one closed generic application: the exact
/// name the synthesized instance owns (`synthetic_name`), matching the
/// downstream `definition.name` label contract. When the instance already
/// exists its declaration name is authoritative — the deduplicated `__n`
/// spellings can only be reproduced that way. Before synthesis completes, the
/// same leaf-plus-slugs construction predicts it.
fn generic_application_label(
    syntax: &SyntaxTrees,
    definition: &DataDefinition,
    argument_handles: &[TypeReferenceHandle],
    selection: Option<&ConstantSelection>,
) -> Result<String, String> {
    if let Some(instance) = synthesized_instance(syntax, selection, definition, argument_handles) {
        return Ok(instance.name.as_str(syntax).to_owned());
    }
    let argument_names =
        if let Some(names) = monomorphizable_argument_slugs(syntax, argument_handles, selection) {
            names
        } else {
            // Declaration evaluation precedes instance synthesis. A nested closed
            // application still has its authored Generic node here, so it has no
            // synthesized slug yet. Require an exact closed identity before using
            // the same recursive label that later instance publication will use.
            let parameters = syntax.items.type_parameters(definition.type_parameters);
            if parameters.len() != argument_handles.len() {
                return Err(
                    "generic const carrier is not a closed monomorphizable application".to_owned(),
                );
            }
            parameters
                .iter()
                .zip(argument_handles)
                .map(|(parameter, argument)| {
                    if let Some(slug) = crate::preparation::generic_data::type_reference_slug(
                        syntax, *argument, selection,
                    ) {
                        return Ok(slug);
                    }
                    closed_argument_identity(
                        syntax,
                        selection,
                        *argument,
                        parameter.kind.is_const_or_value(),
                    )
                    .ok_or("generic const carrier is not a closed monomorphizable application")?;
                    let label = selected_type_label(syntax, *argument, selection)?;
                    if let TypeReferenceNode::Generic { base_name, .. } =
                        syntax.type_references.type_reference(*argument)
                        && let Some(selection) = selection
                        && let Some(path) = selection.data_lookup_path(syntax, base_name)
                        && let Some((prefix, _)) = path.rsplit_once("::")
                    {
                        Ok(format!("{prefix}::{label}"))
                    } else {
                        Ok(label)
                    }
                })
                .collect::<Result<Vec<_>, String>>()?
        };
    Ok(format!(
        "{}<{}>",
        definition.name.as_str(syntax),
        argument_names.join(", ")
    ))
}

/// The already-synthesized instance for one selected template and closed
/// argument tuple, found by the same `Instance` identity deduplication uses —
/// never by rendered-name equality.
fn synthesized_instance<'syntax>(
    syntax: &'syntax SyntaxTrees,
    selection: Option<&ConstantSelection>,
    template: &DataDefinition,
    argument_handles: &[TypeReferenceHandle],
) -> Option<&'syntax DataDefinition> {
    let parameters = syntax.items.type_parameters(template.type_parameters);
    if parameters.len() != argument_handles.len() {
        return None;
    }
    let identity = parameters
        .iter()
        .zip(argument_handles)
        .map(|(parameter, argument)| {
            closed_argument_identity(
                syntax,
                selection,
                *argument,
                parameter.kind.is_const_or_value(),
            )
        })
        .collect::<Option<Vec<_>>>()?;
    let template_handle = syntax.root_item_handles().iter().copied().find(|handle| {
        matches!(syntax.root_item(*handle), Item::Data(data) if std::ptr::eq(data, template))
    })?;
    syntax.root_items().find_map(|item| match item {
        Item::Data(data) => {
            let origin = data.generic_instance?;
            match closed_argument_identity(syntax, selection, origin, false) {
                Some(ClosedArgumentIdentity::Instance(declaration, identities))
                    if declaration == template_handle && identities == identity =>
                {
                    Some(data)
                }
                _ => None,
            }
        }
        _ => None,
    })
}

/// Receiving formals substitute once. Inserted caller types are then compared
/// outside this telescope; original array children keep the receiving scope.
fn same_carrier_in_application(
    syntax: &SyntaxTrees,
    declared: TypeReferenceHandle,
    required: TypeReferenceHandle,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
) -> Result<bool, String> {
    if let TypeReferenceNode::Named(name) = syntax.type_references.type_reference(required)
        && let Some(actual) = substitution.get(name.as_str(syntax))
    {
        return same_carrier(syntax, declared, *actual, selection);
    }
    match (
        syntax.type_references.type_reference(declared),
        syntax.type_references.type_reference(required),
    ) {
        (
            TypeReferenceNode::FixedArray {
                element_type: actual,
                length: actual_length,
            },
            TypeReferenceNode::FixedArray {
                element_type: demanded,
                length: demanded_length,
            },
        ) => Ok(closed_fixed_array_length(
            syntax,
            actual_length,
            &GenericApplicationSubstitution::new(),
            selection,
        )? == closed_fixed_array_length(syntax, demanded_length, substitution, selection)?
            && same_carrier_in_application(syntax, *actual, *demanded, selection, substitution)?),
        (TypeReferenceNode::Constrained { base_type, .. }, _) => {
            same_carrier_in_application(syntax, *base_type, required, selection, substitution)
        }
        (_, TypeReferenceNode::Constrained { base_type, .. }) => {
            same_carrier_in_application(syntax, declared, *base_type, selection, substitution)
        }
        _ => same_carrier(syntax, declared, required, selection),
    }
}

fn same_carrier(
    syntax: &SyntaxTrees,
    declared: TypeReferenceHandle,
    required: TypeReferenceHandle,
    selection: Option<&ConstantSelection>,
) -> Result<bool, String> {
    // One shared reference node is trivially one carrier; the structural
    // comparison below exists for separately spelled references.
    if declared == required {
        return Ok(true);
    }
    // A retained generic-application origin — on either a surviving `Generic`
    // spelling or the `Named` instance spelling synthesis rewrote it to —
    // identifies the carrier by its selected template and closed argument
    // tuple, never by which spelling reached this comparison.
    if syntax
        .type_references
        .generic_application_origin(declared)
        .is_valid()
        || syntax
            .type_references
            .generic_application_origin(required)
            .is_valid()
    {
        return Ok(
            closed_argument_identity(syntax, selection, declared, false).is_some()
                && closed_argument_identity(syntax, selection, declared, false)
                    == closed_argument_identity(syntax, selection, required, false),
        );
    }
    match (
        syntax.type_references.type_reference(declared),
        syntax.type_references.type_reference(required),
    ) {
        (TypeReferenceNode::Named(left), TypeReferenceNode::Named(right)) => {
            let primitive =
                |name: &str| crate::constant::is_builtin_scalar_carrier(name) || name == "string";
            if primitive(left.as_str(syntax)) || primitive(right.as_str(syntax)) {
                return Ok(left.as_str(syntax) == right.as_str(syntax));
            }
            // These references borrow the same immutable syntax owner. Its
            // exact declaration entries distinguish derived declarations too;
            // a shared template source span does not establish their identity.
            Ok(std::ptr::eq(
                selected_data(syntax, left, selection)?,
                selected_data(syntax, right, selection)?,
            ))
        }
        (
            TypeReferenceNode::FixedArray {
                element_type: left,
                length: left_length,
            },
            TypeReferenceNode::FixedArray {
                element_type: right,
                length: right_length,
            },
        ) => Ok(left_length.same_value(right_length, syntax)
            && same_carrier(syntax, *left, *right, selection)?),
        (TypeReferenceNode::Constrained { base_type, .. }, _) => {
            same_carrier(syntax, *base_type, required, selection)
        }
        (_, TypeReferenceNode::Constrained { base_type, .. }) => {
            same_carrier(syntax, declared, *base_type, selection)
        }
        // Generic applications compare by their selected template declaration
        // and closed argument tuple — the same identity the instance
        // synthesizer uses — never by their rendered spelling.
        (TypeReferenceNode::Generic { .. }, _) | (_, TypeReferenceNode::Generic { .. }) => {
            match (
                closed_argument_identity(syntax, selection, declared, false),
                closed_argument_identity(syntax, selection, required, false),
            ) {
                (Some(declared_identity), Some(required_identity)) => {
                    Ok(declared_identity == required_identity)
                }
                _ => Ok(false),
            }
        }
        (TypeReferenceNode::Unit, TypeReferenceNode::Unit) => Ok(true),
        _ => Ok(false),
    }
}

pub(in crate::preparation::generic_data) fn validate_const_index_type(
    syntax: &SyntaxTrees,
    type_reference: TypeReferenceHandle,
    _visiting: &mut HashSet<String>,
) -> Result<(), String> {
    validate_selected_const_index_type(
        syntax,
        type_reference,
        &mut Vec::new(),
        None,
        &GenericApplicationSubstitution::new(),
    )
}

/// Payload encoding and destination establishment are different judgments.
/// Only the compile-time owner may keep a pending payload private or consume
/// an exact checked destination receipt. Neither encoding mode proves a fact.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(in crate::preparation::generic_data) enum ConstPredicateAdmission {
    ProveSyntax,
    PendingDestination,
    CheckedDestination,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ConstValuePurpose {
    Declaration,
    Index,
}

fn validate_selected_const_index_type(
    syntax: &SyntaxTrees,
    type_reference: TypeReferenceHandle,
    visiting: &mut Vec<source::SourceSpan>,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
) -> Result<(), String> {
    validate_selected_const_type(
        syntax,
        type_reference,
        visiting,
        selection,
        substitution,
        ConstValuePurpose::Index,
    )
}

pub(in crate::preparation::generic_data) fn canonicalize_selected_declaration_value(
    syntax: &SyntaxTrees,
    definition: &ConstDefinition,
    selection: Option<&ConstantSelection>,
) -> Result<CanonicalConstValue, String> {
    if definition.pending_qualification.is_some() {
        return Err("constant destination qualification remains pending".to_owned());
    }
    canonicalize_selected_declaration_value_with_admission(
        syntax,
        definition,
        selection,
        ConstPredicateAdmission::ProveSyntax,
    )
}

pub(in crate::preparation::generic_data) fn canonicalize_selected_declaration_value_with_admission(
    syntax: &SyntaxTrees,
    definition: &ConstDefinition,
    selection: Option<&ConstantSelection>,
    admission: ConstPredicateAdmission,
) -> Result<CanonicalConstValue, String> {
    // Materializable declaration values and structural static indices are
    // different judgments. Determined floats and proved data predicates permit
    // ordinary declarations, while index requests retain their stronger fences.
    let substitution = GenericApplicationSubstitution::new();
    validate_selected_const_type(
        syntax,
        definition.type_reference,
        &mut Vec::new(),
        selection,
        &substitution,
        ConstValuePurpose::Declaration,
    )?;
    let node = canonicalize_const_expression_with_admission(
        syntax,
        definition.type_reference,
        definition.value,
        selection,
        &substitution,
        admission,
    )?;
    canonical_const_result(syntax, definition.type_reference, node, selection)
}

/// Close structural array geometry through the same selected declaration used
/// for its value. A spelling is not an extent: source custody selects the owner,
/// canonical scalar validation establishes its carrier, and only a completed
/// literal is observable here. Calls and unresolved values remain with the
/// evaluation scheduler; reading them here would invent dependency readiness.
pub(crate) fn closed_fixed_array_length(
    syntax: &SyntaxTrees,
    length: &FixedArrayLength,
    substitution: &GenericApplicationSubstitution,
    selection: Option<&ConstantSelection>,
) -> Result<usize, String> {
    match length {
        FixedArrayLength::Literal(length) => Ok(*length),
        FixedArrayLength::ConstParameter(name) => {
            if let Some(argument) = substitution.get(name.as_str(syntax)) {
                return syntax
                    .type_references
                    .type_reference(*argument)
                    .as_named()
                    .ok_or_else(|| {
                        "array extent binding is not a completed integer literal".to_owned()
                    })?
                    .as_str(syntax)
                    .parse::<usize>()
                    .map_err(|_| {
                        "array extent binding is not a nonnegative host-sized integer".to_owned()
                    });
            }
            let selection = selection.ok_or_else(|| {
                "array extent requires an exact selected constant declaration".to_owned()
            })?;
            let definition = selection
                .select(syntax, name)
                .map_err(|diagnostic| diagnostic.message.to_string())?
                .ok_or_else(|| {
                    "array extent requires an exact selected constant declaration".to_owned()
                })?;
            // Reject an aggregate pretending to be its own scalar extent before
            // recursively validating its carrier: no cyclic type can acquire
            // readiness merely because its initializer is spelled as an integer.
            let mut carrier = definition.type_reference;
            while let TypeReferenceNode::Constrained { base_type, .. } =
                syntax.type_references.type_reference(carrier)
            {
                carrier = *base_type;
            }
            if !matches!(syntax.type_references.type_reference(carrier), TypeReferenceNode::Named(name)
                if matches!(selection.builtin_type(syntax, name), Some(symbols::BuiltinTypeAtom::I8 | symbols::BuiltinTypeAtom::I16 | symbols::BuiltinTypeAtom::I32 | symbols::BuiltinTypeAtom::I64 | symbols::BuiltinTypeAtom::U8 | symbols::BuiltinTypeAtom::U16 | symbols::BuiltinTypeAtom::U32 | symbols::BuiltinTypeAtom::U64)))
            {
                return Err("array extent constant must have an integer carrier".to_owned());
            }
            if !matches!(
                syntax.expressions.expression(definition.value),
                ExpressionNode::Integer(_)
            ) {
                return Err("array extent constant is not a completed integer literal".to_owned());
            }
            let value = super::super::canonicalize_selected_declared_const_definition(
                syntax,
                &definition,
                Some(selection),
            )?;
            let Some(language_semantics::const_value::DecodedCanonicalConstValue::Integer {
                value,
                ..
            }) = value.decode_encoding()
            else {
                return Err("array extent constant must have an integer carrier".to_owned());
            };
            usize::try_from(value).map_err(|_| {
                "array extent constant is not a nonnegative host-sized integer".to_owned()
            })
        }
        FixedArrayLength::Expression(value) => syntax
            .type_references
            .type_reference(*value)
            .as_named()
            .and_then(|value| value.as_str(syntax).parse::<usize>().ok())
            .ok_or_else(|| {
                "array extent expression requires completed constant evaluation".to_owned()
            }),
        FixedArrayLength::ConstCall(_) => {
            Err("array extent call requires completed constant evaluation".to_owned())
        }
    }
}

fn validate_selected_const_type(
    syntax: &SyntaxTrees,
    type_reference: TypeReferenceHandle,
    visiting: &mut Vec<source::SourceSpan>,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
    purpose: ConstValuePurpose,
) -> Result<(), String> {
    // A carrier spelled as a bare parameter reselects the enclosing
    // application's already-closed argument handle.
    if let Some(name) = syntax
        .tables
        .type_references
        .type_reference(type_reference)
        .as_named()
        && let Some(argument) = substitution.get(name.as_str(syntax))
    {
        return validate_selected_const_type(
            syntax,
            *argument,
            visiting,
            selection,
            &GenericApplicationSubstitution::new(),
            purpose,
        );
    }
    // A rewritten `Named` instance spelling validates through its retained
    // authored application rather than the synthesized name.
    let origin = syntax
        .type_references
        .generic_application_origin(type_reference);
    if origin.is_valid() && origin != type_reference {
        return validate_selected_const_type(
            syntax,
            origin,
            visiting,
            selection,
            substitution,
            purpose,
        );
    }
    let no_bindings = GenericApplicationSubstitution::new();
    match syntax.tables.type_references.type_reference(type_reference) {
        TypeReferenceNode::Named(name) => {
            if crate::constant::is_structural_scalar_carrier(name.as_str(syntax)) {
                return Ok(());
            }
            if purpose == ConstValuePurpose::Declaration
                && matches!(name.as_str(syntax), "f32" | "f64")
            {
                return Ok(());
            }
            if matches!(name.as_str(syntax), "f32" | "f64" | "string") {
                return Err(format!(
                    "`{name}` is not eligible as a const index: runtime floating/text identity is not canonical structural data"
                , name = name.as_str(syntax)));
            }
            let definition = selected_data(syntax, name, selection)?;
            let declaration = definition.name.source_span();
            if visiting.contains(&declaration) {
                return Ok(());
            }
            if !definition.type_parameters.is_empty() || !definition.lifetime_parameters.is_empty() {
                return Err("generic data const carriers require closed template normalization".to_owned());
            }
            visiting.push(declaration);
            if definition.supply_mode == language_semantics::DataSupplyMode::BoundaryOpaque {
                return Err(format!(
                    "boundary-opaque data `{name}` is not eligible as a const index"
                , name = name.as_str(syntax)));
            }
            if definition.quotient.is_some() {
                return Err(format!(
                    "quotient data `{name}` is not eligible as a structural const index until quotient-backed canonical representatives land"
                , name = name.as_str(syntax)));
            }
            // A nongeneric declaration's members never see an enclosing
            // application's parameters: a member spelling `T` there selects
            // whatever `T` resolves to in this declaration's own scope.
            for member in syntax.tables.items.data_members(definition.members) {
                match member {
                    DataMember::Field(field) => validate_selected_const_type(syntax,
                        field.type_reference,
                        visiting,
                        selection,
                        &no_bindings, purpose)?,
                    DataMember::Variant(variant) => {
                        for field in syntax.tables.items.data_payload_fields(variant.payload) {
                            validate_selected_const_type(syntax, field.type_reference, visiting, selection, &no_bindings, purpose)?;
                        }
                    }
                    DataMember::Retired(_) => {}
                }
            }
            visiting.pop();
            Ok(())
        }
        TypeReferenceNode::Generic {
            base_name,
            lifetime_arguments,
            arguments,
        } => {
            // A closed application is eligible exactly when its selected
            // template is: parameters bind to the authored argument handles
            // and each member validates under those bindings.
            let argument_handles = syntax
                .tables
                .type_references
                .type_reference_handles(*arguments);
            if argument_handles.is_empty() {
                // A synthesized instance's spelling selects the substituted
                // declaration; its members are already closed.
                let definition = selected_synthesized_instance(syntax, base_name)?;
                let declaration = definition.name.source_span();
                if visiting.contains(&declaration) {
                    return Ok(());
                }
                visiting.push(declaration);
                for member in syntax.tables.items.data_members(definition.members) {
                    match member {
                        DataMember::Field(field) => validate_selected_const_type(syntax,
                            field.type_reference,
                            visiting,
                            selection,
                            &no_bindings, purpose)?,
                        DataMember::Variant(variant) => {
                            for field in
                                syntax.tables.items.data_payload_fields(variant.payload)
                            {
                                validate_selected_const_type(syntax,
                                    field.type_reference,
                                    visiting,
                                    selection,
                                    &no_bindings, purpose)?;
                            }
                        }
                        DataMember::Retired(_) => {}
                    }
                }
                visiting.pop();
                return Ok(());
            }
            let definition = selected_data(syntax, base_name, selection)?;
            let parameters = syntax.items.type_parameters(definition.type_parameters);
            if !lifetime_arguments.is_empty()
                || !definition.lifetime_parameters.is_empty()
                || argument_handles.len() != arguments.len()
                || parameters.len() != definition.type_parameters.len()
                || parameters.len() != argument_handles.len()
            {
                return Err(
                    "generic const carriers require closed lifetime-free applications"
                        .to_owned(),
                );
            }
            if definition.supply_mode == language_semantics::DataSupplyMode::BoundaryOpaque {
                return Err(format!(
                    "boundary-opaque data `{base_name}` is not eligible as a const index"
                , base_name = base_name.as_str(syntax)));
            }
            if definition.quotient.is_some() {
                return Err(format!(
                    "quotient data `{base_name}` is not eligible as a structural const index until quotient-backed canonical representatives land"
                , base_name = base_name.as_str(syntax)));
            }
            let declaration = definition.name.source_span();
            if visiting.contains(&declaration) {
                return Ok(());
            }
            visiting.push(declaration);
            let next_substitution = substituted_generic_arguments(syntax, parameters, argument_handles, substitution)?;
            for member in syntax.tables.items.data_members(definition.members) {
                match member {
                    DataMember::Field(field) => validate_selected_const_type(syntax,
                        field.type_reference,
                        visiting,
                        selection,
                        &next_substitution, purpose)?,
                    DataMember::Variant(variant) => {
                        for field in syntax.tables.items.data_payload_fields(variant.payload) {
                            validate_selected_const_type(syntax, field.type_reference, visiting, selection, &next_substitution, purpose)?;
                        }
                    }
                    DataMember::Retired(_) => {}
                }
            }
            visiting.pop();
            Ok(())
        }
        TypeReferenceNode::FixedArray {
            element_type,
            length,
        } => {
            closed_fixed_array_length(syntax, length, substitution, selection)?;
            validate_selected_const_type(syntax,
                *element_type,
                visiting,
                selection,
                substitution, purpose)
        }
        TypeReferenceNode::Constrained { base_type, .. } => {
            validate_selected_const_type(syntax, *base_type, visiting, selection, substitution, purpose)
        }
        TypeReferenceNode::Unit => Ok(()),
        TypeReferenceNode::Reference { .. }
        | TypeReferenceNode::Slice { .. }
        | TypeReferenceNode::DynamicTrait { .. }
        | TypeReferenceNode::ConstExpression(_)
 => Err(
            "const index types require finite structural values with decidable equality and one canonical form"
                .to_owned(),
        ),
    }
}

pub(in crate::preparation::generic_data) fn canonicalize_const_expression(
    syntax: &SyntaxTrees,
    expected_type: TypeReferenceHandle,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
) -> Result<CanonicalConstNode, String> {
    canonicalize_const_expression_with_admission(
        syntax,
        expected_type,
        expression,
        selection,
        substitution,
        ConstPredicateAdmission::ProveSyntax,
    )
}

pub(in crate::preparation::generic_data) fn canonicalize_const_expression_with_admission(
    syntax: &SyntaxTrees,
    expected_type: TypeReferenceHandle,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
    admission: ConstPredicateAdmission,
) -> Result<CanonicalConstNode, String> {
    // A carrier spelled as a bare parameter reselects the enclosing
    // application's already-closed argument handle.
    if let Some(name) = syntax
        .tables
        .type_references
        .type_reference(expected_type)
        .as_named()
        && let Some(argument) = substitution.get(name.as_str(syntax))
    {
        return canonicalize_const_expression_with_admission(
            syntax,
            *argument,
            expression,
            selection,
            &GenericApplicationSubstitution::new(),
            admission,
        );
    }
    // A rewritten `Named` instance spelling canonicalizes through its
    // retained authored application rather than the synthesized name.
    let origin = syntax
        .type_references
        .generic_application_origin(expected_type);
    if origin.is_valid() && origin != expected_type {
        return canonicalize_const_expression_with_admission(
            syntax,
            origin,
            expression,
            selection,
            substitution,
            admission,
        );
    }
    match syntax.tables.type_references.type_reference(expected_type) {
        TypeReferenceNode::Constrained {
            base_type,
            constraints,
        } => {
            let node = canonicalize_const_expression_with_admission(
                syntax,
                *base_type,
                expression,
                selection,
                substitution,
                admission,
            )?;
            // A leaf landing under `in <domain>` owes the declaration-site
            // domain discharge the declaration's own constrained carrier gets:
            // nested positions are the construction-site parallel of the
            // runtime field-domain gate.
            if admission == ConstPredicateAdmission::ProveSyntax {
                crate::preparation::generic_data::prove_const_leaf_domain_constraints(
                    syntax,
                    syntax.tables.type_references.constraints(*constraints),
                    &node,
                    selection,
                )?;
            }
            Ok(node)
        }
        TypeReferenceNode::Named(type_name)
            if LandedIntegerType::from_name(type_name.as_str(syntax)).is_some() =>
        {
            let ExpressionNode::Integer(literal) = syntax.expressions.expression(expression) else {
                return Err(format!(
                    "expected an integer literal for `{type_name}`",
                    type_name = type_name.as_str(syntax)
                ));
            };
            if literal.landing().is_some_and(|landing| {
                landing.landed_type.name() != type_name.as_str(syntax)
                    || landing.domain != numerics::arithmetic::ArithmeticDomain::Exact
            }) {
                return Err(format!(
                    "integer literal landing conflicts with declared const component `{type_name}`",
                    type_name = type_name.as_str(syntax)
                ));
            }
            let value = integer_literal_value(literal)
                .ok_or_else(|| "integer literal exceeds the const-value envelope".to_owned())?;
            validate_syntax_integer_range(type_name.as_str(syntax), value)?;
            Ok(CanonicalConstNode::Integer {
                type_name: type_name.as_str(syntax).to_owned(),
                value,
            })
        }
        TypeReferenceNode::Named(type_name) if type_name.as_str(syntax) == "bool" => {
            let ExpressionNode::Boolean(value) = syntax.expressions.expression(expression) else {
                return Err("expected a boolean literal for `bool`".to_owned());
            };
            Ok(CanonicalConstNode::Boolean(*value))
        }
        TypeReferenceNode::Named(type_name)
            if matches!(type_name.as_str(syntax), "f32" | "f64") =>
        {
            use numerics::literals::{FloatFormat, FloatLiteral};
            let format = if type_name.as_str(syntax) == "f32" {
                FloatFormat::F32
            } else {
                FloatFormat::F64
            };
            let literal = match syntax.expressions.expression(expression) {
                ExpressionNode::Float(text) => FloatLiteral::parse(text.as_str(syntax)),
                ExpressionNode::Integer(integer) if integer.landing().is_none() => integer
                    .value_bignum()
                    .and_then(|value| FloatLiteral::parse(&value.to_string())),
                _ => None,
            }
            .ok_or_else(|| {
                format!(
                    "initializer conflicts with declared floating carrier `{type_name}`",
                    type_name = type_name.as_str(syntax)
                )
            })?;
            if literal.landing().is_some_and(|landing| landing != format) {
                return Err(format!(
                    "initializer conflicts with declared floating carrier `{type_name}`",
                    type_name = type_name.as_str(syntax)
                ));
            }
            // Round directly from exact literal meaning into the declared format;
            // an f64 intermediate would round binary32 midpoint cases twice.
            let bits = match format {
                FloatFormat::F32 if !literal.value_f32().is_nan() => {
                    u64::from(literal.value_f32().to_bits())
                }
                FloatFormat::F64 if !literal.value_f64().is_nan() => literal.value_f64().to_bits(),
                _ => {
                    return Err(
                        "floating declaration identity requires explicit NaN representation bits"
                            .into(),
                    );
                }
            };
            Ok(CanonicalConstNode::Float { format, bits })
        }
        TypeReferenceNode::Named(type_name) => canonicalize_data_const_expression_with_admission(
            syntax, type_name, expression, selection, admission,
        ),
        TypeReferenceNode::Generic {
            base_name,
            lifetime_arguments,
            arguments,
        } => {
            let argument_handles = syntax
                .tables
                .type_references
                .type_reference_handles(*arguments)
                .to_vec();
            if argument_handles.is_empty() {
                // A synthesized instance's lookup spelling already selects the
                // fully substituted declaration.
                let definition = selected_synthesized_instance(syntax, base_name)?;
                return canonicalize_selected_data_const_expression_with_admission(
                    syntax,
                    definition,
                    definition.name.as_str(syntax),
                    expression,
                    selection,
                    &GenericApplicationSubstitution::new(),
                    admission,
                );
            }
            let definition = selected_data(syntax, base_name, selection)?;
            let parameters = syntax.items.type_parameters(definition.type_parameters);
            if !lifetime_arguments.is_empty()
                || !definition.lifetime_parameters.is_empty()
                || argument_handles.len() != arguments.len()
                || parameters.len() != definition.type_parameters.len()
                || parameters.len() != argument_handles.len()
            {
                return Err(
                    "generic const carrier is not a closed monomorphizable application".to_owned(),
                );
            }
            let mut next_substitution = GenericApplicationSubstitution::new();
            let mut resolved_arguments = Vec::with_capacity(argument_handles.len());
            for (parameter, argument) in parameters.iter().zip(argument_handles.iter()) {
                let resolved = resolved_generic_argument(syntax, *argument, substitution)?;
                next_substitution.insert(parameter.name.as_str(syntax).to_owned(), resolved);
                resolved_arguments.push(resolved);
            }
            // The label must render the resolved arguments: an authored `T`
            // contributes its argument's slug to the synthesized name.
            let label =
                generic_application_label(syntax, definition, &resolved_arguments, selection)?;
            // Constructor normalization may already have selected the closed
            // instance. Rejoin it through the exact template/argument tuple,
            // not its rendered label, before comparing constructor ownership.
            // Before synthesis the same operation uses the template and its
            // explicit substitutions; neither route accepts another tuple.
            if let Some(instance) =
                synthesized_instance(syntax, selection, definition, &resolved_arguments)
            {
                return canonicalize_selected_data_const_expression_with_admission(
                    syntax,
                    instance,
                    &label,
                    expression,
                    selection,
                    &GenericApplicationSubstitution::new(),
                    admission,
                );
            }
            canonicalize_selected_data_const_expression_with_admission(
                syntax,
                definition,
                &label,
                expression,
                selection,
                &next_substitution,
                admission,
            )
        }
        TypeReferenceNode::FixedArray {
            element_type,
            length,
        } => {
            let length = closed_fixed_array_length(syntax, length, substitution, selection)?;
            let ExpressionNode::ArrayLiteral(values) = syntax.expressions.expression(expression)
            else {
                return Err("expected an array literal for fixed-array const value".to_owned());
            };
            let values = syntax.expressions.expression_handles(*values);
            if values.len() != length {
                return Err(format!(
                    "fixed-array const value requires {length} elements but has {}",
                    values.len()
                ));
            }
            // Element carriers live in the owning declaration's scope, so the
            // enclosing bindings still apply to their spellings.
            let values = values
                .iter()
                .map(|value| {
                    canonicalize_const_expression_with_admission(
                        syntax,
                        *element_type,
                        *value,
                        selection,
                        substitution,
                        admission,
                    )
                })
                .collect::<Result<Vec<_>, _>>()?;
            Ok(CanonicalConstNode::Array {
                type_name: substituted_type_label(syntax, expected_type, substitution, selection)?,
                values,
            })
        }
        TypeReferenceNode::Unit => Err(
            "unit const values do not yet have a source literal; use an empty declared record"
                .to_owned(),
        ),
        _ => Err("const value expression has an ineligible parameter type".to_owned()),
    }
}

/// The canonical carrier label after the enclosing application's bindings have
/// been applied: a member spelled `T` or `Pair<T>` labels as its resolved
/// closed carrier, never its template spelling.
fn substituted_type_label(
    syntax: &SyntaxTrees,
    reference: TypeReferenceHandle,
    substitution: &GenericApplicationSubstitution,
    selection: Option<&ConstantSelection>,
) -> Result<String, String> {
    match syntax.type_references.type_reference(reference) {
        TypeReferenceNode::Named(name) if substitution.contains_key(name.as_str(syntax)) => {
            selected_type_label(syntax, substitution[name.as_str(syntax)], selection)
        }
        TypeReferenceNode::Named(_)
            if syntax
                .type_references
                .generic_application_origin(reference)
                .is_valid() =>
        {
            selected_type_label(
                syntax,
                syntax.type_references.generic_application_origin(reference),
                selection,
            )
        }
        TypeReferenceNode::Generic {
            base_name,
            arguments,
            ..
        } => {
            let argument_handles = syntax
                .type_references
                .type_reference_handles(*arguments)
                .to_vec();
            if argument_handles.is_empty() {
                return selected_type_label(syntax, reference, selection);
            }
            let definition = selected_data(syntax, base_name, selection)?;
            let resolved = argument_handles
                .iter()
                .map(|argument| resolved_generic_argument(syntax, *argument, substitution))
                .collect::<Result<Vec<_>, _>>()?;
            generic_application_label(syntax, definition, &resolved, selection)
        }
        TypeReferenceNode::FixedArray {
            element_type,
            length,
        } => {
            let length = closed_fixed_array_length(syntax, length, substitution, selection)?;
            Ok(format!(
                "[{}; {length}]",
                substituted_type_label(syntax, *element_type, substitution, selection)?
            ))
        }
        TypeReferenceNode::Constrained { base_type, .. } => {
            substituted_type_label(syntax, *base_type, substitution, selection)
        }
        _ => selected_type_label(syntax, reference, selection),
    }
}

pub(in crate::preparation::generic_data) fn canonicalize_data_const_expression(
    syntax: &SyntaxTrees,
    type_name: &Identifier,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
) -> Result<CanonicalConstNode, String> {
    canonicalize_data_const_expression_with_admission(
        syntax,
        type_name,
        expression,
        selection,
        ConstPredicateAdmission::ProveSyntax,
    )
}

pub(in crate::preparation::generic_data) fn canonicalize_data_const_expression_with_admission(
    syntax: &SyntaxTrees,
    type_name: &Identifier,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
    admission: ConstPredicateAdmission,
) -> Result<CanonicalConstNode, String> {
    let definition = selected_data(syntax, type_name, selection)?;
    // A directly named declaration's members never see an enclosing
    // application's parameters.
    canonicalize_selected_data_const_expression_with_admission(
        syntax,
        definition,
        definition.name.as_str(syntax),
        expression,
        selection,
        &GenericApplicationSubstitution::new(),
        admission,
    )
}

fn canonicalize_selected_data_const_expression_with_admission(
    syntax: &SyntaxTrees,
    definition: &DataDefinition,
    type_name: &str,
    expression: ExpressionHandle,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
    admission: ConstPredicateAdmission,
) -> Result<CanonicalConstNode, String> {
    let value = match syntax.expressions.expression(expression) {
        ExpressionNode::StructLiteral(literal) => {
            let (constructed, case_name) =
                selected_constructor(syntax, &literal.constructor_name, selection)?;
            // A generic application's constructor selects its template, which
            // is the declaration this expression canonicalizes against. When
            // `definition` is a synthesized instance the same constructor
            // legitimately names the instance's template.
            if !std::ptr::eq(constructed, definition) {
                let instance_template = definition
                    .generic_instance
                    .and_then(
                        |origin| match syntax.type_references.type_reference(origin) {
                            TypeReferenceNode::Generic { base_name, .. } => Some(base_name.clone()),
                            _ => None,
                        },
                    )
                    .and_then(|base_name| selected_data(syntax, &base_name, selection).ok());
                if !instance_template.is_some_and(|template| std::ptr::eq(template, constructed)) {
                    return Err(format!(
                        "const constructor `{}` selects a different nominal carrier than `{type_name}`",
                        literal.constructor_name.as_str(syntax)
                    ));
                }
            }
            if let Some(case_name) = &case_name {
                let variant = syntax
                    .tables
                    .items
                    .data_members(definition.members)
                    .iter()
                    .find_map(|member| match member {
                        DataMember::Variant(variant)
                            if variant.name.as_str(syntax) == case_name.as_str(syntax) =>
                        {
                            Some(variant)
                        }
                        _ => None,
                    })
                    .ok_or_else(|| {
                        format!("`{type_name}` has no case `{}`", case_name.as_str(syntax))
                    })?;
                let declared_fields = syntax
                    .tables
                    .items
                    .data_payload_fields(variant.payload)
                    .iter()
                    .collect::<Vec<_>>();
                let fields = canonicalize_named_fields_with_admission(
                    syntax,
                    &declared_fields,
                    literal.fields,
                    selection,
                    substitution,
                    admission,
                )?;
                Ok(CanonicalConstNode::Variant {
                    type_name: type_name.to_owned(),
                    case_name: case_name.as_str(syntax).to_owned(),
                    fields,
                })
            } else {
                if syntax
                    .tables
                    .items
                    .data_members(definition.members)
                    .iter()
                    .any(|member| matches!(member, DataMember::Variant(_)))
                {
                    return Err(format!(
                        "`{type_name}` is case data; its const value must name one case"
                    ));
                }
                let declared_fields = syntax
                    .tables
                    .items
                    .data_members(definition.members)
                    .iter()
                    .filter_map(|member| match member {
                        DataMember::Field(field) => Some(field),
                        _ => None,
                    })
                    .collect::<Vec<_>>();
                let fields = canonicalize_named_fields_with_admission(
                    syntax,
                    &declared_fields,
                    literal.fields,
                    selection,
                    substitution,
                    admission,
                )?;
                Ok(CanonicalConstNode::Record {
                    type_name: type_name.to_owned(),
                    fields,
                })
            }
        }
        ExpressionNode::Name(path) => {
            let path = syntax.expressions.identifier_path_members(*path);
            let Some((case_name, owner)) = path.split_last() else {
                return Err(format!("expected a `{type_name}` structural literal"));
            };
            let Some(first) = owner.first() else {
                return Err(format!("expected a `{type_name}` case owner"));
            };
            let head = Identifier::new(owner.joined_path_in(syntax), first.source_span());
            let selected = selected_data(syntax, &head, selection)?;
            // A payloadless case spelled through the template still selects the
            // same carrier as the synthesized instance it materializes into.
            let same_carrier = std::ptr::eq(selected, definition)
                || definition
                    .generic_instance
                    .and_then(
                        |origin| match syntax.type_references.type_reference(origin) {
                            TypeReferenceNode::Generic { base_name, .. } => Some(base_name.clone()),
                            _ => None,
                        },
                    )
                    .and_then(|base_name| selected_data(syntax, &base_name, selection).ok())
                    .is_some_and(|template| std::ptr::eq(template, selected));
            if !same_carrier {
                return Err(format!(
                    "expected a `{type_name}` value, got `{}`",
                    head.as_str(syntax)
                ));
            }
            let variant = syntax
                .tables
                .items
                .data_members(definition.members)
                .iter()
                .find_map(|member| match member {
                    DataMember::Variant(variant)
                        if variant.name.as_str(syntax) == case_name.as_str(syntax) =>
                    {
                        Some(variant)
                    }
                    _ => None,
                })
                .ok_or_else(|| {
                    format!(
                        "`{type_name}` has no case `{case_name}`",
                        case_name = case_name.as_str(syntax)
                    )
                })?;
            if !variant.payload.is_empty() {
                return Err(format!(
                    "case `{type_name}::{case_name}` requires named payload fields",
                    case_name = case_name.as_str(syntax)
                ));
            }
            Ok(CanonicalConstNode::Variant {
                type_name: type_name.to_owned(),
                case_name: case_name.as_str(syntax).to_owned(),
                fields: Vec::new(),
            })
        }
        _ => Err(format!("expected a `{type_name}` structural literal")),
    }?;
    if admission == ConstPredicateAdmission::ProveSyntax {
        super::facts::prove_const_data_predicates(
            syntax,
            definition,
            &value,
            substitution,
            selection,
        )?;
    }
    Ok(value)
}

fn canonicalize_named_fields_with_admission(
    syntax: &SyntaxTrees,
    declared_fields: &[&syntax_trees::item::DataField],
    literal_fields: HandleSpan<syntax_trees::expression::TableStructLiteralField>,
    selection: Option<&ConstantSelection>,
    substitution: &GenericApplicationSubstitution,
    admission: ConstPredicateAdmission,
) -> Result<Vec<(String, CanonicalConstNode)>, String> {
    let authored = syntax.expressions.struct_fields(literal_fields);
    let mut canonical = Vec::with_capacity(declared_fields.len());
    for declared in declared_fields {
        let matches = authored
            .iter()
            .filter(|field| field.name.as_str(syntax) == declared.name.as_str(syntax))
            .collect::<Vec<_>>();
        let [field] = matches.as_slice() else {
            return Err(if matches.is_empty() {
                format!("missing const field `{}`", declared.name.as_str(syntax))
            } else {
                format!("duplicate const field `{}`", declared.name.as_str(syntax))
            });
        };
        canonical.push((
            declared.name.as_str(syntax).to_owned(),
            canonicalize_const_expression_with_admission(
                syntax,
                declared.type_reference,
                field.value,
                selection,
                substitution,
                admission,
            )?,
        ));
    }
    for field in authored {
        if !declared_fields
            .iter()
            .any(|declared| declared.name.as_str(syntax) == field.name.as_str(syntax))
        {
            return Err(format!(
                "unknown const field `{}`",
                field.name.as_str(syntax)
            ));
        }
    }
    Ok(canonical)
}

pub(in crate::preparation::generic_data) fn validate_syntax_integer_range(
    type_name: &str,
    value: i128,
) -> Result<(), String> {
    let Some(integer_type) = LandedIntegerType::from_name(type_name) else {
        return Err(format!("`{type_name}` is not an integer const type"));
    };
    let (minimum, maximum) = integer_type.bounds();
    if value < minimum || value > maximum {
        Err(format!("const value `{value}` does not fit `{type_name}`"))
    } else {
        Ok(())
    }
}

pub(in crate::preparation::generic_data) fn validate_canonical_rat(
    value: &CanonicalConstNode,
) -> Result<(), String> {
    let CanonicalConstNode::Record { fields, .. } = value else {
        return Err("`Rat` index value must be a structural record".to_owned());
    };
    let numerator = fields
        .iter()
        .find(|(name, _)| name == "num")
        .map(|(_, value)| value)
        .ok_or_else(|| "`Rat` index value is missing `num`".to_owned())?;
    let denominator = fields
        .iter()
        .find(|(name, _)| name == "den")
        .map(|(_, value)| nat_value(value))
        .transpose()?
        .ok_or_else(|| "`Rat` index value is missing `den`".to_owned())?;
    let CanonicalConstNode::Record { fields, .. } = numerator else {
        return Err("`Rat.num` must be an `IntPair` record".to_owned());
    };
    let negative = fields
        .iter()
        .find(|(name, _)| name == "neg")
        .map(|(_, value)| nat_value(value))
        .transpose()?
        .ok_or_else(|| "`Rat.num` is missing `neg`".to_owned())?;
    let positive = fields
        .iter()
        .find(|(name, _)| name == "pos")
        .map(|(_, value)| nat_value(value))
        .transpose()?
        .ok_or_else(|| "`Rat.num` is missing `pos`".to_owned())?;
    if denominator == 0 {
        return Err("`Rat` index denominator must be positive".to_owned());
    }
    if negative != 0 && positive != 0 {
        return Err(
            "`Rat` index signed coordinates must be cancelled (at least one of `num.neg` and `num.pos` must be zero)"
                .to_owned(),
        );
    }
    let magnitude = negative.max(positive);
    if gcd_usize(magnitude, denominator) != 1 {
        return Err(
            "`Rat` index numerator magnitude and denominator must be gcd-reduced".to_owned(),
        );
    }
    Ok(())
}

pub(in crate::preparation::generic_data) fn nat_value(
    value: &CanonicalConstNode,
) -> Result<usize, String> {
    match value {
        CanonicalConstNode::Variant {
            type_name,
            case_name,
            fields,
        } if type_name == "Nat" && case_name == "Zero" && fields.is_empty() => Ok(0),
        CanonicalConstNode::Variant {
            type_name,
            case_name,
            fields,
        } if type_name == "Nat" && case_name == "Succ" => {
            let previous = fields
                .iter()
                .find(|(name, _)| name == "prev")
                .map(|(_, value)| nat_value(value))
                .transpose()?
                .ok_or_else(|| "`Nat::Succ` is missing `prev`".to_owned())?;
            previous
                .checked_add(1)
                .ok_or_else(|| "`Nat` const value is too large".to_owned())
        }
        _ => Err("`Rat` canonicality requires structural core `Nat` fields".to_owned()),
    }
}

pub(in crate::preparation::generic_data) fn gcd_usize(mut left: usize, mut right: usize) -> usize {
    while right != 0 {
        let remainder = left % right;
        left = right;
        right = remainder;
    }
    left
}

pub(in crate::preparation::generic_data) fn const_integer_in_envelope(value: i128) -> Option<i128> {
    (value >= i128::from(i64::MIN) && value <= i128::from(u64::MAX)).then_some(value)
}

pub(in crate::preparation::generic_data) fn checked_fact_integer(
    value: Option<i128>,
    operation: &str,
) -> Result<ConstFactValue, String> {
    value
        .and_then(const_integer_in_envelope)
        .map(ConstFactValue::Integer)
        .ok_or_else(|| format!("{operation} exceeds the signed/unsigned 64-bit envelope"))
}
