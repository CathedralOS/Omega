# Value-dependent facts and views

Range predicates, contracts, and layout/view conditions may name in-scope program
values. These are flow-sensitive facts about exact values and places, not
arbitrary runtime computation of nominal types. This systems contract does not
restrict the general mathematical quantification of the
[selected foundation](../proofs/foundation.md). Its
[mathematical source binders](../proofs/mathematical_bindings.md) and the
[W-based profile](../proofs/inductive_profile.md) are selected but still need
their required metatheory, encodings and checker implementation.

## Static indices and runtime witnesses

| Dependency | Representation and checking |
| --- | --- |
| Const index | Canonical static value or licensed symbolic expression participating in static application identity. |
| Runtime-capable generic index | Exact value subject bound by a non-const value binder; its runtime content is not a static specialization key. |
| Stored witness | Ordinary field/parameter whose value constrains another field or region. |
| View witness | Ordinary value such as count or stride fixed when a borrowed view is established. |
| Flow fact | Erased proposition valid for its exact subjects and current program point. |

Runtime dependencies do not become const-generic arguments. They may supply
runtime-capable value binders under [generic staging](generics.md#value-binders-and-const-requirements).
Static eligibility and canonical encoding follow
[semantic evaluation](evaluation.md#canonical-static-identities); runtime-index
compatibility instead retains exact subjects and checked relationships.
Type relevance and erased witness identity/multiplicity follow
[proof erasure](../proofs/contracts.md#identity-availability-and-erasure), not a
blanket prohibition on proof-only values.

A slice's stored length and a case arm's selected payload facts are ordinary
examples of dependence. A runtime descriptor view may use `count` and `stride`;
access must prove the actual range lies inside its backing extent, not substitute
the compiled record size for the foreign stride. Row-major access similarly
needs the relation between dimensions, coordinates, and total extent. Boundary
output parameters can serve as stored witnesses through exact postconditions.

Dynamic-sized regions live behind checked views or provisioned buffers/storage;
runtime witnesses do not imply variable-sized stack locals, implicit boxing,
or a hidden global layout descriptor. The sanctioned route to a runtime-sized
region inside an activation is an explicit bounded extent claim under
[runtime-sized activation storage](../resources/activation_storage.md).
[Layout plans](../layouts/plans.md) and
[recasts](../layouts/recasts.md) determine representation and view legality.
Runtime values have no implicit proof tuple or hidden witness allocation merely
because a fact names them.

`Buffer<count>` can retain a runtime extent when Buffer declares a runtime-capable
value binder and has a valid storage realization. It does not by itself allocate
count elements, instantiate count-specific code, or authorize runtime-sized inline
stack storage — that stays a bounded claim under
[runtime-sized activation storage](../resources/activation_storage.md), including
when the buffer's realization is activation-local. A `const` binder still requires
static knowledge. Existing
const-indexed domain families retain their declared binding time; runtime-capable
indices do not reinterpret them or turn arbitrary runtime data into nominal types.

## Establishment and witness loans

Prove a dependency statically, establish it through a visible guard or contracted
decode/validator, or reject the use. `as` follows
[domain qualification](domains.md#exact-coercion-and-erasure). The compiler does
not insert residual checks to make an unproved refinement true. An explicit
runtime check owns its ordinary false outcome; a decoder establishes only the
predicates it checks, not firmware truth or routed authority.

A live borrow of a dependent place also read-loans the witnesses on which its
validity relies. Those witnesses cannot change while the dependent borrow is
live. Facts and loans are checked together before erasure; forgetting a layout
parameter or a displayed qualification cannot remove this obligation.

Across calls, transport facts only through their exact parameter/result
substitution and checked contract. Machine-arrival requirements are proved on
every incoming edge and assumed only at arrival. Mutation invalidates stale
entry facts; a backedge cannot prove itself from a premise invalidated by its
own writes. See [invocation contracts](state_contracts.md).

## Default domains and zero initialization

A data declaration's field qualifications and `where` clauses define its default
domain; omission adds no predicates beyond its ordinary field/type obligations.
An optional data-declaration `dropped by` clause contributes the default domain's
[automatic cleanup selection](domains.md#domain-selected-automatic-cleanup),
independently of those validity predicates.
This does not mean an uninhabited domain. Zero-initializability is a storage
representation guarantee, not universal semantic membership or ambient write
authority. A zeroed storage representation can be accessed as an established
value only after its default-domain obligations hold.

Field qualifications may also carry
[domain-owned read/write restrictions](domains.md#domain-owned-read-and-write-authority).
Establishing validity does not grant access forbidden by that policy. It remains
attached to the governed field through parent borrows, projections, whole-place
replacement, and qualification forgetting. Invariant windows permit temporary
invalidity only under otherwise-authorized access; they do not waive a reader or
writer restriction. Fresh construction and policy installation follow the domain
establishment rules, not an implicit file-local or constructor privilege.

Constraints on common fields and active-case payloads are written in data
`where`. Its `self` denotes the complete value, as in named-domain predicates.
Payload projections require a prior case guard; case declarations do not accept
`where`. See [case-dependent default domains](data_and_literals.md#case-constraints).
Bracketed scalar range suffixes are not a second default-domain syntax.

Boundary provider slots are not data fields and add no default-domain obligation.
Provider planning must satisfy every demanded exact requirement application
before realization; that independent check neither changes the containing data's
validity nor manufactures authority or storage.

[Case-dependent default predicates](data_and_literals.md#case-constraints) can
relate the active case to type parameters and payload values. Common-field and
data-level obligations remain conjunctive with that case's payload validity. The zero
representation keeps the first declared case, even when its constraints fail
for a particular specialization; there is no selection of a first possible case.

If zero satisfies the default domain, the value is zero-constructible. Otherwise
the type is gated: construction or checked qualification must establish the
domain before observation. A literal supplies every field whose zero value
would violate it and proves the complete coupling. Establishment is monotone as
observed: later mutation may temporarily open an invariant window, but no
consumption sees the value outside its required domain.

Generic bodies prove establishment from their declared contracts and available
flow facts. They may use proved zero-validity, but cannot rely on a later
specialization to justify an otherwise unchecked observation. Zeroing storage is
permitted independently of establishing a value. For `Value<T>` in the case-constraint
example, `T == i32` suffices to establish the all-zero Integer value, whereas an
unconstrained `T` does not and `Value<bool>` remains gated until valid construction.

Permitting [uninhabited domain declarations](domains.md#uninhabited-domains)
does not relax this establishment gate. An impossible qualification cannot be
established merely because storage was allocated or zeroed.

Gating propagates through containment; a zero-valid first sum case can represent
emptiness without constructing a gated payload. Machine-owned storage may begin
zeroed while gated fields remain inaccessible until established. Storage
validity is not a claim that partially established runtime-indexed arrays are
automatically proved; such uses need exact element/extent establishment evidence.
Proof propositions and proof-only values with no runtime representation acquire
neither ZII nor layout obligations.

<a id="mutable-receivers-and-declared-field-domains"></a>
### Mutable arguments and declared field domains

An ordinary `value: &mut T` argument carries the declared field/default-domain
obligations of `T` at call, entry, and return. The
caller establishes them, the callee assumes them, and returning execution
restores them under the ordinary invariant-window rules. Whether zero satisfies
those domains is irrelevant to an already established incoming value.

Contracts may state `requires value in Domain` and corresponding
`ensures`. An additional input domain
need not survive a call unless the ordinary contract guarantees it. Zeroed or
partially established storage still needs establishment before a readable borrow;
a qualified machine name grants no construction or validity exception.

That predicate-fact rule does not authorize dropping a governed subject's access
policy. Forgetting the displayed domain or invalidating a flow predicate cannot
create a reader/writer grant; retained restrictions follow their governed lifetime.

### Collection invariants

For `per-element-array-bounds`, use an ordinary pure, total, terminating
machine over the collection as a predicate in `where` or `requires`. Its body
walks the elements with ordinary recursive machines; collection invariants introduce no
`forall`, `foreach`, or bracketed scalar-range type suffix.

For example, a field `cells: [i32; 16]` can be constrained by
`where cells_valid(&cells) == true;`. The ordinary machine
`cells_valid(cells: &[i32; 16]) -> bool` recognizes precisely arrays whose
elements are each zero or one. Its use in a proposition must meet the ordinary
[semantic evaluation](evaluation.md) admission rules. This asserts its
denotation, not an implicit runtime traversal on every write.

Construction proves the collection predicate; mutation preserves or restores
it under the ordinary invariant-window rules. A checked helper theorem can
establish that a selected element is zero or one from that predicate and a
valid index. Merely naming an arbitrary predicate does not grant the checker
its elementwise consequences: those follow from checked reasoning about the
machine, not a new quantifier or an unchecked decomposition rule.

## Invariant windows

An invariant window is compiler-derived proof debt, not a source `relax` mode,
runtime poison flag, or mutable truth bit.
[Exclusive storage recasts](../layouts/recasts.md#deferred-establishment-on-exclusive-storage-casts)
may open initial target-establishment debt before a valid target value exists.
Geometry, authority and custody are immediate requirements; target-shaped storage
is not a valid value merely because a cast names its type. Field initialization
and checked evidence must establish the whole before ordinary typed consumption.
The cast's pending-view formation is allowed, not a general exception for later
borrow creation, calls or publication. Source handback and partially initialized
resource cleanup remain separate obligations.
[Borrowed-storage ownership windows](ownership.md#borrowed-storage-invariant-windows)
apply the same discipline to temporarily absent content: a move records exact
restoration debt, and an establishing store closes it. A hole has no current value
to reason about, unlike present contents whose domain is temporarily unproved.
Ownership restoration and domain restoration are separate obligations; satisfying
one cannot discharge the other. The ownership rules govern calls on detached
values and disjoint siblings without weakening the domain fences below.

A write known to preserve the default domain keeps it established. Otherwise
the write opens a window on the place,
whose actual new contents remain available to ordinary flow reasoning.
The domain must be proved again at the next consumption point:

- A read relying on the domain or a dependent coupling.
- Borrow creation or a call.
- Terminal transfer, return, or scope expiration.
- Boundary/capability-carrying calls, even when they do not name the place.

An unclosed window rejects with both the opening write or storage cast and the
failing consumption point. Borrow exclusivity prevents another observer seeing it; a dependent loan
pins its witnesses, so a conflicting write cannot open a window in the first
place. Write-only access must restore validity from written values, structure,
and supplied facts, never by reading its referent.

Recoverable failure does not cancel a window. Once established, a value cannot
be discarded while its cleanup or obligations rely on a broken invariant.
Failed initial establishment instead creates no value, leaving raw storage under
its existing storage claim. A crash may abandon an open window but supplies no
survivor-safety theorem; [crash semantics](../terminal-psi/calls_and_outcomes.md#crash)
governs that distinct outcome.

## Mutation frames

The conservative call frame includes places reachable through exclusive borrows
and separately authorized capability state. Checked implementations may derive
a narrower complete frame; opaque or unknown dynamic calls retain the
signature/authority ceiling. A complete empty frame differs from an unknown
one. Include argument/index evaluation writes as well as callee writes.

Invalidate flow refinements atom by atom on overlapping written places; exact
outcome guarantees may restore them or preserve untouched paths. Default-domain
obligations and explicit domain qualifications must be re-established before
consumption, not assumed to be unchanged values. Body-derived frames are implementation evidence,
not changes to public contract or specialization identity.

Frames retain exact subject substitution across aliases, calls, and terminal
transitions. Where only collection-level origin is known, later field
projections cannot recover narrower precision without new evidence. An
unrepresentable origin or incomplete recursive summary uses the conservative
ownership ceiling, never an empty write set. Frame inference grants no borrow
authority and cannot preserve facts through unmodeled external writes.
Current analysis bounds belong beside
[checking](../../../omega-rust/psi/compilation/pipeline/04_typed-trees-to-checked-trees/README.md),
not in the language's dependent-value limits.
