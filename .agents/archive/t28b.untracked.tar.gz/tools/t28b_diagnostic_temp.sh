#!/bin/sh
set -eu
mbx build -p omega -j 8
mkdir -p build/swarm/t28b
set +e
./target/debug/omega run --both samples/cli/facts/loop_storage_address_identity/local/main.omg > build/swarm/t28b/retention-census.log 2>&1
status=$?
set -e
cat build/swarm/t28b/retention-census.log
exit "$status"
