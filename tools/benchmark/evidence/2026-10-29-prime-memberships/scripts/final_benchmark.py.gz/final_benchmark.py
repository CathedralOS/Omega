import json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2]
home=root/'build/prime-preparation-3'
trial=home/f'final-{time.time_ns()}';trial.mkdir()
project=root/'samples/cli/arithmetic/prime_counter'
for name in ['omega.lock','build']:
 path=project/name
 if path.exists():
  assert path.resolve().is_relative_to(project.resolve())
  path.rename(trial/('previous-'+name))
environment=dict(os.environ,LOCALAPPDATA=str(trial/'cache'),OMEGA_LIBRARY_ROOT=str(root/'source/library'))
command=['python','tools/benchmark/benchmark.py','measure','--root','samples/cli/arithmetic/prime_counter/main.omg','--target','windows_x86_64','--omega',str(home/'candidate/omega.exe'),'--compile-samples','3','--run-samples','9','--expected-exit','8','--note','Preparation uses a fresh private LOCALAPPDATA cache and no project lock; includes update, review acceptance and resume. Compile samples use that prepared cache. File caches and host load are uncontrolled.','--note','Retained producer Rust inputs exactly match 9faf48f97ab27e2be5dce33d3901826be50c066c, release opt-level 3. Prime sources and bounds are unchanged. Runtime includes startup; project LOC excludes std.']
try:
 with (trial/'benchmark.txt').open('wb') as output:
  completed=subprocess.run(command,cwd=root,env=environment,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,timeout=360)
 assert completed.returncode==0,(trial/'benchmark.txt').read_text(encoding='utf-8',errors='replace')
 record_path=root/'tools/benchmark/records/prime_counter__windows_x86_64__default.json'
 record=json.loads(record_path.read_text(encoding='utf-8'))
 assert record['measurement']['source_clean'] and record['measurement']['dependency_lock_stable']
 assert record['metrics']['runtime_ms']['exit_codes']==[8]*9
 (trial/'raw-record.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
 prep=record['metrics']['package_preparation_ms']['median_ms']/1000
 record['observation_warnings']=[f'Cold package review: {prep:.0f} s; compile samples use the accepted cache']
 record_path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
 print('BENCHMARK_RESULT',trial,flush=True)
 print(json.dumps({name:value for name,value in record['metrics'].items() if name in ['package_preparation_ms','compile_time_ms','runtime_ms']}),flush=True)
finally:
 for name in ['omega.lock','build']:
  path=project/name
  if path.exists():path.rename(trial/('produced-'+name))
  previous=trial/('previous-'+name)
  if previous.exists():previous.rename(path)
