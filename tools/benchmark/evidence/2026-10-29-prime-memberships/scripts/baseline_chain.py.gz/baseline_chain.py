import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[2]
home=root/'build/prime-preparation-3'
with (home/'baseline-cargo.jsonl').open('wb') as output:
 result=subprocess.run(['mbx','build','--release','-p','omega','--message-format=json'],cwd=root,stdout=output,stderr=subprocess.STDOUT)
assert result.returncode==0,'baseline build failed; inspect baseline-cargo.jsonl'
for command in [
 ['python','build/prime-preparation-3/replay.py','preserve','baseline'],
 ['python','build/prime-preparation-3/replay.py','prepare','baseline','--cold','--profile','--sample','--both'],
]:
 print('STEP',command,flush=True)
 result=subprocess.run(command,cwd=root)
 if result.returncode:sys.exit(result.returncode)

