import pathlib,subprocess,sys
home=pathlib.Path('build/prime-preparation-3')
import time
started=time.monotonic()
while not (home/'quality-harness-ready').exists():
 if time.monotonic()-started>180:raise SystemExit('harness preflight deadline')
 time.sleep(1)
for name, command in [
 ('quality',[sys.executable,'tools/qualification.py','run-pending','--state',str(home/'qualification-state.json'),'--revision','0','--base','e91e31365edf6e760f6199a04d444e727c902cc0']),
 ('unit-tests',['mbx','nextest','run','--release','-p','typed-trees-to-checked-trees','--lib']),
 ('final-benchmark',[sys.executable,str(home/'final_benchmark.py')]),
 ('record-validation',[sys.executable,'tools/benchmark/benchmark.py','validate','tools/benchmark/records/prime_counter__windows_x86_64__default.json']),
]:
 print('CHECK',name,flush=True)
 with (home/(name+'.log')).open('wb') as output:
  result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 print('CHECK_RESULT',name,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
