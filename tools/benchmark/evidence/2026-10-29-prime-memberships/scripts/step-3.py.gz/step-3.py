import pathlib,subprocess,sys
root=pathlib.Path.cwd();home=root/'build/prime-preparation-3'
with (home/'final-benchmark.log').open('wb') as output:
 result=subprocess.run([sys.executable,'build/prime-preparation-3/final_benchmark.py'],stdout=output,stderr=subprocess.STDOUT)
print('FINAL_BENCHMARK_EXIT',result.returncode,flush=True)
if result.returncode:sys.exit(result.returncode)
(home/'stop-chain').touch()
