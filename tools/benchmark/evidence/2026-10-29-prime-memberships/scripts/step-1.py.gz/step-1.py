import pathlib,subprocess,sys,time
root=pathlib.Path.cwd(); home=root/'build/prime-preparation-3'
started=time.monotonic()
while not (home/'candidate-ready').exists():
 if time.monotonic()-started>360:raise SystemExit('candidate edit deadline')
 time.sleep(1)
with (home/'candidate-cargo.jsonl').open('wb') as output:
 result=subprocess.run(['mbx','build','--release','-p','omega','--message-format=json'],stdout=output,stderr=subprocess.STDOUT)
assert result.returncode==0,'candidate build failed'
for command in [['python','build/prime-preparation-3/replay.py','preserve','candidate'],['python','build/prime-preparation-3/replay.py','prepare','candidate','--cold','--profile','--both']]:
 result=subprocess.run(command)
 if result.returncode:sys.exit(result.returncode)
