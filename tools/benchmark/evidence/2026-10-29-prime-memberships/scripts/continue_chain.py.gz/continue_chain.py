import pathlib,subprocess,sys,time
home=pathlib.Path(__file__).resolve().parent
for number in range(1,8):
 path=home/f'step-{number}.py'
 print('AWAIT_STEP',str(path),'deadline=180s',flush=True)
 (home/'ready-step.txt').write_text(str(number))
 started=time.monotonic()
 while not path.exists():
  if (home/'stop-chain').exists() or time.monotonic()-started>180:sys.exit(0)
  time.sleep(1)
 result=subprocess.run([sys.executable,str(path)],cwd=home.parents[1])
 print('STEP_COMPLETED',number,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
