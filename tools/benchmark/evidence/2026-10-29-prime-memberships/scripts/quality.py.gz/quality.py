import hashlib, importlib.util, json, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parents[2]
home = root/'build/prime-preparation-3'
spec = importlib.util.spec_from_file_location('benchmark',root/'tools/benchmark/benchmark.py')
benchmark = importlib.util.module_from_spec(spec);spec.loader.exec_module(benchmark)
cases = [('pass', 'facts/borrowed_result_field_domains_local'), ('fail', 'facts/borrowed_result_field_domains_local'), ('pass', 'facts/borrowed_result_field_domains_field'), ('fail', 'facts/borrowed_result_field_domains_field'), ('pass', 'facts/borrowed_result_field_domains_parameter'), ('fail', 'facts/borrowed_result_field_domains_parameter'), ('pass', 'facts/borrowed_result_field_domains_call_result'), ('fail', 'facts/borrowed_result_field_domains_call_result'), ('pass', 'facts/borrowed_result_field_domains_match_join'), ('fail', 'facts/borrowed_result_field_domains_match_join'), ('pass', 'facts/borrowed_result_field_domains_const_name'), ('fail', 'facts/borrowed_result_field_domains_const_name'), ('pass', 'facts/borrowed_result_field_domains_other_state'), ('fail', 'facts/borrowed_result_field_domains_other_state'), ('pass', 'facts/borrowed_result_field_domains_other_machine'), ('fail', 'facts/borrowed_result_field_domains_other_machine'), ('pass', 'facts/borrowed_result_field_domains_target_body'), ('fail', 'facts/borrowed_result_field_domains_target_body'), ('pass', 'facts/borrowed_result_field_domains_indexed_sibling_write_local_exit'), ('fail', 'facts/borrowed_result_field_domains_indexed_sibling_write_local_rejected'), ('pass', 'facts/borrowed_result_field_domains_indexed_sibling_write_field_exit'), ('fail', 'facts/borrowed_result_field_domains_indexed_sibling_write_field_rejected'), ('pass', 'facts/borrowed_result_field_domains_indexed_sibling_write_parameter_exit'), ('fail', 'facts/borrowed_result_field_domains_indexed_sibling_write_parameter_rejected'), ('pass', 'facts/borrowed_result_field_domains_indexed_sibling_write_call_result_exit'), ('fail', 'facts/borrowed_result_field_domains_indexed_sibling_write_call_result_rejected'), ('fail', 'calls/copied_nominal_argument_precedes_field_repair'), ('fail', 'generics/closed_indexed_domain_mismatch')]
attempt='quality3-'+str(time.time_ns())
result_file=home/'quality-results.json'
if result_file.exists():result_file.rename(home/('quality-results-prior-'+str(time.time_ns())+'.json'))
results=[]
for label in ['baseline','candidate']:
 binary=home/label/'omega.exe'
 benchmark.require_optimized(binary)
 for outcome, fixture in cases:
  source=root/'tests/omega'/outcome/fixture
  if any(row['producer']==label and row['fixture']==str(source.relative_to(root)) for row in results):continue
  project=home/attempt/outcome/source.name
  if not project.exists():
   project.mkdir(parents=True,exist_ok=True)
   (project/'main.omg').write_bytes((source/'main.omg').read_bytes())
   (project/'build.omg').write_text('machine build(builder: &mut Build) {\n Build::application(builder, "quality");\n'+''.join(f' Build::bind(builder, {target}::ProgramEntry, main);\n' for target in ['windows_x86_64','linux_x86_64','macos_arm64','linux_arm64'])+'}\n',encoding='utf-8')
   for authored in source.glob('*.omg'):
    (project/authored.name).write_bytes(authored.read_bytes())
  observations=[]
  logs=home/(attempt+'-observations')/label/outcome/source.name
  logs.mkdir(parents=True,exist_ok=True)
  if label=='candidate':
   for name in ['omega.lock','build']:
    current=project/name; archived=logs/('previous-'+name)
    if current.exists():
     assert current.resolve().is_relative_to(project.resolve()) and archived.resolve().is_relative_to(home.resolve())
     current.rename(archived)
  def invoke(command,cwd=None):
   started=time.monotonic()
   completed=subprocess.run(list(map(str,command)),cwd=cwd or root,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
   text=completed.stdout.decode('utf-8','replace')
   transcript=logs/f'command-{len(observations)}.txt';transcript.write_text(text,encoding='utf-8')
   observations.append(dict(command=list(map(str,command)),exit_code=completed.returncode,seconds=time.monotonic()-started,transcript=str(transcript.relative_to(home))))
   return completed.returncode,text
  benchmark.run_plain=invoke
  prepared=True
  try:benchmark.settle_package_review(binary,project,'windows_x86_64')
  except SystemExit:prepared=False
  if outcome=='pass':
   assert prepared,observations
   code,text=invoke([binary,'run','--both','--keep',project/'main.omg'])
   assert code==0 and 'interp exit: 0' in text,text
   import re
   kept=pathlib.Path(re.search(r'build dir kept: (.+)',text).group(1).strip())
   products={str(p.relative_to(kept)):hashlib.sha256(p.read_bytes()).hexdigest() for p in kept.rglob('*') if p.is_file() and p.suffix in ['.exe','.oterm']}
   assert products, text
  else:
   if prepared:code,text=invoke([binary,'--check','--target','windows_x86_64',project/'main.omg'])
   else:code,text=observations[-1]['exit_code'],(home/observations[-1]['transcript']).read_text(encoding='utf-8')
   expected=[line.strip() for line in (source/'expected.txt').read_text(encoding='utf-8').splitlines() if line.strip()]
   if fixture=='proofs/conditional_boolean_return_is_not_first_arm':
    expected=['violates required fact `value == true`','structurally false']
   assert code!=0 and all(fragment in text for fragment in expected),text
  products = products if outcome=='pass' else {}
  if label=='candidate' and outcome=='pass':
   previous=next(r for r in results if r['producer']=='baseline' and r['fixture']==str(source.relative_to(root)))
   assert previous['products']==products, (source,previous['products'],products)
  results.append(dict(source_inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in project.glob('*.omg')},producer_sha256=benchmark.sha256_file(binary),products=products,producer=label,fixture=str(source.relative_to(root)),source_sha256=hashlib.sha256((source/'main.omg').read_bytes()).hexdigest(),outcome=outcome,observations=observations))
  (home/'quality-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
  print(label,outcome,fixture,'OK',flush=True)


assert len(results)==len(cases)*2
print("QUALITY_COMPLETE",len(results),"cases",sum(r["outcome"]=="pass" for r in results),"engine pairs",flush=True)
print("PRODUCT_DIGESTS",json.dumps([{k:r[k] for k in ["producer","fixture","products"]} for r in results if r["products"]]),flush=True)
