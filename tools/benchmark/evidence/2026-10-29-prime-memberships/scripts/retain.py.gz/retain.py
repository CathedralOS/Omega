import gzip,hashlib,json,pathlib,shutil,statistics,subprocess
root=pathlib.Path.cwd();home=root/'build/prime-preparation-3';dest=root/'tools/benchmark/evidence/2026-10-29-prime-memberships'
trials=[]
for path in sorted(home.glob('*/result.json')):
 r=json.loads(path.read_text(encoding='utf8'))
 if r.get('cold') and r.get('engines_agree'):trials.append((path.parent,r))
cold=sorted([(p,r) for p,r in trials if not r['profile'] and not r['sampled']],key=lambda row:int(row[0].name.rsplit('-',1)[1]))
assert len(cold)==4
assert len({r['cache_root'] for _,r in cold})==4
assert len({json.dumps(r['products'],sort_keys=True) for _,r in trials})==1
assert len({r['lock_without_compiler_identity_sha256'] for _,r in trials})==1
assert len({json.dumps(r['source_hashes'],sort_keys=True) for _,r in trials})==1
assert all(r['observations'][-1]['exit_code']==8 for _,r in trials)
values={label:[r['seconds'] for p,r in cold if p.name.startswith(label+'-')] for label in ['baseline','candidate']}
assert all(len(v)==2 for v in values.values()) and max(values['candidate'])<min(values['baseline'])
quality=json.loads((home/'quality-results.json').read_text());assert len(quality)==56
for label in ['baseline','candidate']:
 assert sum(r['outcome']=='pass' and r['producer']==label for r in quality)==13
 assert sum(r['outcome']=='fail' and r['producer']==label for r in quality)==15
for r in quality:
 if r['producer']=='candidate' and r['outcome']=='pass':assert r['products']==next(a['products'] for a in quality if a['producer']=='baseline' and a['fixture']==r['fixture'])
state=json.loads((home/'qualification-state.json').read_text());assert not state['running'] and len(state['runs'])==1 and state['runs'][0]['exit']==0 and not state['runs'][0]['invalidations']
assert '16 passed' in (home/'unit-tests.log').read_text(encoding='utf8')
assert 'Finished' in (home/'clippy.log').read_text(encoding='utf8')
record_path=root/'tools/benchmark/records/prime_counter__windows_x86_64__default.json';record=json.loads(record_path.read_text())
assert record['subject']['source_revision']=='9faf48f97ab27e2be5dce33d3901826be50c066c' and record['measurement']['source_clean'] and record['measurement']['dependency_lock_stable'] and record['metrics']['runtime_ms']['exit_codes']==[8]*9
assert subprocess.check_output(['git','rev-parse','3e0d1079680:source/library'])==subprocess.check_output(['git','rev-parse','9faf48f97ab:source/library'])
dest.mkdir(parents=True,exist_ok=False)
for path,r in trials:
 out=dest/'trials'/path.name;out.mkdir(parents=True)
 for file in path.glob('command-*.txt'):shutil.copyfile(file,out/file.name)
 for name in ['result.json','produced-omega.lock']:
  file=path/name
  if file.exists():shutil.copyfile(file,out/name)
 for file in path.glob('stack-*.txt'):
  with gzip.open(out/(file.name+'.gz'),'wb') as z:z.write(file.read_bytes())
for label in ['baseline','candidate']:
 out=dest/'producers'/label;out.mkdir(parents=True)
 for name in ['producer.json','omega.exe.compiler-profile.json']:shutil.copyfile(home/label/name,out/name)
for name in ['quality-results.json','qualification-config.json','qualification-state.json','quality.log','clippy.log','unit-tests.log','record-validation.log','final-benchmark.log']:
 shutil.copyfile(home/name,dest/name)
shutil.copytree(home/'qualification-state.records',dest/'qualification-state.records')
for r in quality:
 for observation in r['observations']:
  file=home/observation['transcript'];out=dest/observation['transcript'];out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,out)
final=next(home.glob('final-*/raw-record.json'))
shutil.copyfile(final,dest/'final-raw-record.json');shutil.copyfile(record_path,dest/'benchmark-record.json')
for name in ['replay.py','baseline_chain.py','comparison.py','quality.py','final_benchmark.py','remaining_chain.py','continue_chain.py','step-1.py','step-2.py','step-3.py']:
 out=dest/'scripts'/name;out.parent.mkdir(exist_ok=True);shutil.copyfile(home/name,out)
with gzip.open(dest/'rejected-changing-inputs-build.jsonl.gz','wb') as z:z.write((home/'candidate-rejected-changing-inputs-cargo.jsonl').read_bytes())
summary={'fixed_base':'e91e31365edf6e760f6199a04d444e727c902cc0','baseline_revision':'3e0d10796805c66c16ca0a2499c65d399de89522','candidate_revision':'9faf48f97ab27e2be5dce33d3901826be50c066c','order':[p.name.split('-')[0] for p,r in cold],'seconds':values,'median_seconds':{k:statistics.median(v) for k,v in values.items()},'reduction_percent':(1-statistics.median(values['candidate'])/statistics.median(values['baseline']))*100,'unchanged_products':trials[0][1]['products'],'unchanged_lock_without_compiler_identity_sha256':trials[0][1]['lock_without_compiler_identity_sha256'],'quality_cases':len(quality),'fresh_engine_pairs':26,'intended_refusals':30,'compiler_input_classification':'Invocation-local evidence indexing; no language or package policy change.'}
(dest/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps(summary,indent=2))
