import pathlib,subprocess,sys
root=pathlib.Path.cwd();home=root/'build/prime-preparation-3'
for name,command in [
 ('comparison',[sys.executable,'build/prime-preparation-3/comparison.py']),
 ('quality',[sys.executable,'build/prime-preparation-3/quality.py']),
 ('clippy',['mbx','clippy','--release','-p','typed-trees-to-checked-trees','--lib']),
 ('unit-tests',['mbx','nextest','run','--release','-p','typed-trees-to-checked-trees','--lib']),
]:
 print('CHECK',name,flush=True)
 with (home/(name+'.log')).open('wb') as output:
  result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 print('CHECK_RESULT',name,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
