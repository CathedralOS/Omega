A machine declared to return `u8` could complete a transition arm with Unit; nonempty and generic bodies could also fall through without a result. One completion checker now admits Unit against the declared carrier over the existing instruction order and exhaustive dispatches, preserving crash and nonreturning paths. It replaces the generic empty-body exemption.

Two bundled Nat lemmas now explicitly return their declared mathematical witnesses while retaining their postconditions. The change also removes an unreferenced policy-observation module left by an earlier integration.

Validation on macOS ARM64:

- Nine executable places agree in native and Terminal execution; all nine Unit-arm twins reject.
- 28 source and 12 runtime fixtures pinned, including generic, array, reference, fallthrough and nonreturn controls.
- Corrupting the expected result traps in both engines; the Nat metric module checks all 18 sources.
- Focused source checks cover 68 fixtures; runtime checks observe 15 agreements among 17 fixtures. The existing Vec reject diagnostic mismatch and a fixture lacking a macOS native entry reproduce on baseline and remain unverified.
- Scoped Rust Clippy and formatting pass.

Continues NESTED-MACHINE-UNIFICATION; product migration, customer UI acceptance and other-host native runs remain open. Fixed base: `7dbc69b6df5bab680e1b112e68454a5cc81cd28b`. Parent outcome base: `baf1b6ea0633681bcc2cf34d563d748a47fadb36`. Claim: `dd0818296e934b4594710ab44bc05a6a`.

Implemented by the root Codex agent (GPT-6); parallel workers retain their independent outcomes.
