from pathlib import Path
r=Path('samples/cli/facts/nested_machine_invocation/completion_result/controls')
examples={
'implicit_empty':('machine missing() -> u8 {}',True),
'implicit_after_write':('machine missing(output: &mut u8) -> u8 { output = 7; }',True),
'conditional_fallthrough':('machine missing(ready: bool) -> u8 { transition ready { true -> 19u8 } }',True),
'generic_empty':('machine missing<T>(value: T) -> T {}',True),
'generic_unit_arm':('machine missing<T>(value: T, ready: bool) -> T { transition ready { true -> value false -> {} } }',True),
'array_unit_arm':('machine missing(ready: bool) -> [u8; 2] { transition ready { true -> [19u8, 37u8] false -> {} } }',True),
'reference_unit_arm':("machine missing<'a>(value: &'a u8, ready: bool) -> &'a u8 { transition ready { true -> value false -> {} } }",True),
'unit_and_crash':('machine succeed(ready: bool) crashes Trap { transition ready { true -> {} false -> bad() } machine bad() crashes Trap { crash Trap; } }',False),
'crash_only':('machine missing() -> u8 crashes Trap { crash Trap; }',False),
'nonreturning_call':('machine wait() { transition { _ -> wait() } }\nmachine missing() -> u8 { wait(); }',False),
}
for name,(declaration,invalid) in examples.items():
 p=r/name;p.mkdir(parents=True,exist_ok=True)
 (p/'main.omg').write_text('// Expected exit: 0\n'+declaration+'\nmachine main() {}\n')
 (p/'build.omg').write_text(Path('samples/cli/facts/nested_machine_invocation/completion_result/local/build.omg').read_text().replace('completion_result_local','completion_result_'+name))
Path('build/completion-result/controls.json').write_text(__import__('json').dumps({n:v[1] for n,v in examples.items()},indent=2)+'\n')
