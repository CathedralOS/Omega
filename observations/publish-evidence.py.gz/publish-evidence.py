from pathlib import Path
import gzip,json,hashlib,os,subprocess,sys
sys.path.insert(0,'tools')
from corpus_gate import retain_record_source
r=Path('build/product-declarations/integrated');s=json.loads((r.parent/'qualification.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert s['running'] is None and s['runs'][-1]['revision']==head and s['runs'][-1]['exit']==0 and not s['runs'][-1]['invalidations'];assert all(a['action']=='reuse' for a in s['assessments'][-1]['checks']);assert s['base']=='05e1922eb7b4d554a7d5ee84e47f99ebb3304827';files={}
for source,name in [(r.parent/'qualification.json','state.json.gz'),(r/'qualification-config.json','config.json.gz')]:
 p=r/name
 with gzip.open(p,'wb',compresslevel=1) as f:f.write(source.read_bytes())
 files['qualification/'+name]=p
for i,run in enumerate(s['runs']):
 p=r/('receipt-'+str(i)+'.json.gz')
 with gzip.open(p,'wb',compresslevel=1) as f:f.write(Path(run['receipt']['path']).read_bytes())
 files['qualification/'+p.name]=p
 for stream in ['stdout','stderr']:files['qualification/'+str(i)+'-'+stream+'.txt']=Path(run[stream]['path'])
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.py','.jsonl'] and p.name not in ['evidence-manifest.json','evidence-publication.json']:
  dest=r/(p.name+'.gz')
  with gzip.open(dest,'wb',compresslevel=1) as f:f.write(p.read_bytes())
  files['observations/'+dest.name]=dest
assert retain_record_source(head) is None
files['source/'+head+'.bundle']=Path('build/corpus-source')/(head+'.bundle')
manifest=dict(submitted_head=head,fixed_author_base=s['base'],integration=json.loads((r/'integration.json').read_text()),original_evidence='cf68c110db56c50c53c8acd7e28ff33baf200dd9 at work/nested-unit-completion-evidence preserves original5a qualification, actual producer5792/runner860 captures, old05e baseline attribution, frozen oracles/replay programs and source bundles.',acceptance=json.loads((r/'acceptance.json').read_text()),files=[dict(path=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in files.items()]);(r/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files['manifest.json']=r/'evidence-manifest.json'
env=dict(os.environ,GIT_INDEX_FILE=str((r/'evidence.index').resolve()));subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for name,p in files.items():
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo',f'100644,{blob},{name}'],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree],input='psi: retain integrated Unit completion execution evidence\n',text=True).strip();ref='work/nested-unit-completion-integrated-evidence';subprocess.run(['git','push','origin',f'{commit}:refs/heads/{ref}'],check=True);(r/'evidence-publication.json').write_text(json.dumps(dict(commit=commit,ref=ref),indent=2)+'\n');print(commit)
