from pathlib import Path
import json,gzip,hashlib,subprocess,os,sys
sys.path.insert(0,'tools')
from corpus_gate import retain_record_source
r=Path('build/product-declarations');s=json.loads((r/'qualification.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert s['running'] is None and s['runs'][-1]['exit']==0 and not s['runs'][-1]['invalidations'] and s['runs'][-1]['revision']==head;assert all(a['action']=='reuse' for a in s['assessments'][-1]['checks'])
files={}
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.jsonl','.py','.txt'] and p.name not in ['evidence-manifest.json','evidence-publication.json']:
  dest=r/(p.name+'.gz')
  with gzip.open(dest,'wb',compresslevel=1) as f:f.write(p.read_bytes())
  files['observations/'+dest.name]=dest
for i,run in enumerate(s['runs']):
 p=r/('receipt-'+str(i)+'.json.gz')
 with gzip.open(p,'wb',compresslevel=1) as f:f.write(Path(run['receipt']['path']).read_bytes())
 files['qualification/'+p.name]=p
 for stream in ['stdout','stderr']:files['qualification/'+str(i)+'-'+stream+'.txt']=Path(run[stream]['path'])
for p in r.rglob('*.omg'):files['replay/'+str(p.relative_to(r))]=p
for name in ['main.omg','build.omg','harness.omg']:files['replay/parser-baseline/'+name]=Path('build/product-nested/parser-baseline')/name
for name in ['omega-producer.json','corpus_runner-producer.json']:files['baseline/'+name]=Path('build/wrapping-integration')/name
prerequisite=Path('/Users/zcanann/Documents/Projects/Omega/.agents/worktree/joint-rank/build/statement-completion/producer-independent-premises/receipt.json');files['prototype-unit-prerequisite-receipt.json']=prerequisite
revisions={head,'5792c1685e9e7ba6bdd976d0bafb4ca514acaef9','860b169d5798c3ad0b8e94ed8fb634d9d3db7ff3','05e1922eb7b4d554a7d5ee84e47f99ebb3304827','c3d0af5c9cb3d9e965a1a8a10f5559bda21fdbcc'}
for revision in revisions:
 assert retain_record_source(revision) is None
 files['source/'+revision+'.bundle']=Path('build/corpus-source')/(revision+'.bundle')
manifest=dict(submitted_head=head,fixed_author_base=s['base'],parent_fixed_base='baf1b6ea0633681bcc2cf34d563d748a47fadb36',acceptance=json.loads((r/'acceptance.json').read_text()),historical_identity='CLI5792 and runner860 have identical compiler/library inputs to submitted source. Actual baseline05e captures the previous behavior on these unchanged source/oracles. Prototype c3 is a retained comparison that also refuses the count probe; it is not a prerequisite or accepted producer for this repair. Full parser replays timed out on both candidate and baseline; unused module checks pass on both. Neither supplies product runtime acceptance.',files=[dict(path=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in files.items()]);(r/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files['manifest.json']=r/'evidence-manifest.json'
env=dict(os.environ,GIT_INDEX_FILE=str((r/'evidence.index').resolve()));subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for name,p in files.items():
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo',f'100644,{blob},{name}'],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree],input='psi: retain Unit completion execution evidence\n',text=True).strip();ref='work/nested-unit-completion-evidence';subprocess.run(['git','push','origin',f'{commit}:refs/heads/{ref}'],check=True);(r/'evidence-publication.json').write_text(json.dumps(dict(commit=commit,ref=ref),indent=2)+'\n');print(commit)
