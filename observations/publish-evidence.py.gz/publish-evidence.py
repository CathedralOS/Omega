from pathlib import Path
import json,gzip,hashlib,subprocess,os
r=Path('build/completion-result');s=json.loads((r/'qualification.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert s['running'] is None and s['runs'][-1]['exit']==0 and not s['runs'][-1]['invalidations'] and s['runs'][-1]['revision']==head;assert all(x['action']=='reuse' for x in s['assessments'][-1]['checks'])
archive=r/'archive';archive.mkdir(exist_ok=True);files={}
for p in sorted(r.rglob('*')):
 if not p.is_file() or archive in p.parents or p.name.startswith('evidence') or p.suffix not in ['.json','.jsonl','.log','.txt','.py','.md','.stdout','.stderr']:continue
 name=str(p.relative_to(r));destination=archive/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True)
 with gzip.open(destination,'wb',compresslevel=1) as f:f.write(p.read_bytes())
 files['observations/'+name+'.gz']=destination
for p in sorted(r.rglob('*.omg')):files['replay/'+str(p.relative_to(r))]=p
bundle=archive/'source.bundle';subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+s['base']],check=True);files['source.bundle']=bundle
manifest=dict(submitted_head=head,fixed_base=s['base'],parent_fixed_base='baf1b6ea0633681bcc2cf34d563d748a47fadb36',acceptance=json.loads((r/'acceptance.json').read_text()),identity='Actual baseline7dbc, initial repair27e (failed prelude admission retained), b6 (before required Nat migration), and final5b observations keep their exact binary/source identities. Qualification verifies retained observations on unchanged authored sources and compiler/library closure; it does not represent another engine execution. Immutable compiler binaries remain local; source bundle extends published main baseline7dbc. The two declared Nat result witnesses were necessary to preserve existing consumers, and their mathematical obligations still check.',files=[dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for name,p in files.items()]);m=r/'evidence-manifest.json';m.write_text(json.dumps(manifest,indent=2)+'\n');files['manifest.json']=m
env=dict(os.environ,GIT_INDEX_FILE=str((archive/'evidence.index').resolve()));subprocess.run(['git','read-tree','--empty'],env=env,check=True)
for name,p in files.items():
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo',f'100644,{blob},{name}'],env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree],input='psi: retain declared completion result evidence\n',text=True).strip();ref='work/nested-completion-results-evidence';subprocess.run(['git','push','origin',f'{commit}:refs/heads/{ref}'],check=True);(r/'evidence-publication.json').write_text(json.dumps(dict(commit=commit,ref=ref),indent=2)+'\n');print(commit)
