from pathlib import Path
import json,shutil,subprocess,hashlib,sys
r=Path('build/completion-result')/sys.argv[1]
a=[json.loads(line) for line in (r/'build.jsonl').read_text().splitlines() if line.startswith('{')]
a=[a for a in a if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['name']=='omega'][-1]
p=r/'omega';shutil.copy2(a['executable'],p);profile=json.loads(subprocess.check_output([str(p.resolve()),'--build-profile'],text=True));assert profile['opt_level']=='1'
(r/'producer.json').write_text(json.dumps(dict(revision=sys.argv[2] if len(sys.argv)>2 else subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),profile=profile,artifact=a),indent=2)+'\n')
