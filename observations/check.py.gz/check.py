from pathlib import Path
import json,shutil,subprocess,hashlib,os,time
r=Path('build/product-declarations/integrated');original=r.parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def run(command,name,expected=None):
 t=time.monotonic()
 with (r/(name+'.log')).open('w') as f:p=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMEGA_CORPUS_JOBS='4'),timeout=900)
 x=dict(command=command,exit=p.returncode,elapsed_seconds=time.monotonic()-t,revision=head);(r/(name+'-command.json')).write_text(json.dumps(x,indent=2)+'\n');print(name,p.returncode,round(x['elapsed_seconds'],2),flush=True)
 if expected is not None:assert p.returncode==expected,(name,p.returncode)
for file,binary in [('build-cli.jsonl','omega'),('build-runner.jsonl','corpus_runner')]:
 artifacts=[]
 for s in (r/file).read_text().splitlines():
  try:a=json.loads(s)
  except json.JSONDecodeError:continue
  if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['name']==binary:artifacts.append(a)
 assert artifacts,file
 a=artifacts[-1];p=r/'producer'/binary;shutil.copy2(a['executable'],p);profile=json.loads(subprocess.check_output([str(p.resolve()),'--build-profile'],text=True));assert profile['opt_level']=='1';(r/(binary+'-producer.json')).write_text(json.dumps(dict(revision=head,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),profile=profile,cargo_artifact=a),indent=2)+'\n')
cli=str((r/'producer/omega').resolve());runner=str((r/'producer/corpus_runner').resolve())
for file,name in [('run-row.py','row'),('run-controls.py','controls')]:
 s=(original/file).read_text().replace("Path('build/product-declarations/row-'+label+'.json')","Path('build/product-declarations/integrated/row.json')").replace("Path('build/product-declarations/controls-'+label+'.json')","Path('build/product-declarations/integrated/controls.json')");(r/file).write_text(s);run(['python3',str(r/file),cli,'integrated','both'],name,0)
for mode in ['source','both']:
 command=['python3','tools/corpus_gate.py','--runner',runner,'--filter',(original/'focused-filter.txt').read_text().strip(),'--json',str(r/('corpus-'+mode+'.json'))]
 if mode=='both':command+=['--both']
 run(command,'corpus-'+mode)
paths=['omega-rust/psi/compilation/checking/src/proof_contracts/contract_entailment/structural_case_arms.rs','omega-rust/psi/compilation/checking/src/proof_contracts/contract_entailment/structural_judgment/normal_returns/body_completion.rs']
run(['rustfmt','--check','--edition','2024','--config','skip_children=true',*paths],'format',0)
run(['cargo','clippy','--locked','-p','validation','--no-deps'],'clippy',0)
p=original/'counterfactual/main.omg';command=[cli,'run','--both',str(p)];x=subprocess.run(command,input='',capture_output=True,text=True,timeout=120);(r/'counterfactual.json').write_text(json.dumps(dict(command=command,exit=x.returncode,stdout=x.stdout,stderr=x.stderr,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n');print('counterfactual',x.returncode,x.stderr,flush=True)
