from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path('build/completion-result');cli=str(Path(sys.argv[1]).resolve());label=sys.argv[2];rows=[]
for name,invalid in json.loads((r/'controls.json').read_text()).items():
 p=Path('samples/cli/facts/nested_machine_invocation/completion_result/controls')/name/'main.omg';command=[cli,'--check',str(p)] if invalid else [cli,'run','--both',str(p)];start=time.monotonic();x=subprocess.run(command,input='',capture_output=True,text=True,timeout=120);rows.append(dict(name=name,invalid=invalid,source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),command=command,exit=x.returncode,stdout=x.stdout,stderr=x.stderr,elapsed_seconds=time.monotonic()-start));print(name,x.returncode,x.stderr.strip(),flush=True)
(r/('controls-'+label+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
