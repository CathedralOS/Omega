from pathlib import Path
import concurrent.futures,json,subprocess,hashlib,sys
root=Path('samples/cli/facts/nested_machine_invocation/private_arithmetic/default_domain');cli=str(Path(sys.argv[1]).resolve());label=sys.argv[2];both=len(sys.argv)>3 and sys.argv[3]=='both'
def run(p):
 invalid=p.parent.name=='invalid';cmd=[cli,'--check',str(p)] if invalid or not both else [cli,'run','--both',str(p)];x=subprocess.run(cmd,input='',capture_output=True,text=True,timeout=120);a=dict(source=str(p),command=cmd,invalid=invalid,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),exit=x.returncode,stdout=x.stdout,stderr=x.stderr);print(str(p.relative_to(root)),x.returncode,x.stderr.strip(),flush=True);return a
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,sorted(root.glob('*/main.omg'))+sorted(root.glob('*/invalid/main.omg'))))
Path('build/product-declarations/integrated/row.json').write_text(json.dumps(rows,indent=2)+'\n')
