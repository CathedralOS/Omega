from pathlib import Path
import json,hashlib
root=Path('samples/cli/facts/nested_machine_invocation/private_arithmetic/default_domain');s=(root/'local/main.omg').read_text();variants={}
no_store=s.replace('window.bytes[0] = value;','').replace('first_byte == 37','first_byte == 7').replace('full_byte == 37','full_byte == 7').replace('second_byte == 11','second_byte == 7').replace('window.bytes[0] == 11','window.bytes[0] == 7')
variants['no_indexed_store']=(False,no_store)
variants['explicit_unit']=(False,s.replace('window.count = window.count + 1;','window.count = window.count + 1;\n        transition { _ -> {} }'))
variants['stale_count']=(True,s.replace('window.bytes[0] = value;','window.bytes[0] = value;\n        window.count = 4;'))
start=s.index('machine probe(');end=s.index('machine main()')
flow='''machine probe(window: &mut Window, enabled: bool, value: u8) {
    transition enabled { true -> strict(window, value) false -> loose(window, value) }
    machine strict(window: &mut Window, value: u8) {
        let ready: bool = window.count < 4;
        transition { _ -> route(window, ready, value) }
    }
    machine loose(window: &mut Window, value: u8) {
        let ready: bool = window.count < 5;
        transition { _ -> route(window, ready, value) }
    }
    machine route(window: &mut Window, ready: bool, value: u8) {
        transition ready { true -> read(window, value) false -> {} }
    }
    machine read(window: &mut Window, value: u8) {
        window.bytes[0] = value;
        window.count = window.count + 1;
    }
}
'''
variants['same_site_insufficient_arrival']=(True,s[:start]+flow+s[end:])
variants['unformed_child']=(True,s.replace('window.count + 1','(window.count - 1) + 2'))
variants['unresolved_sibling']=(True,s.replace('false -> {}','false -> missing()',1))
mismatch=s.replace('machine probe(window: &mut Window, enabled: bool, value: u8) {','machine probe(window: &mut Window, enabled: bool, value: u8) -> u8 {').replace('machine read(window: &mut Window, value: u8) {','machine read(window: &mut Window, value: u8) -> u8 {').replace('window.count = window.count + 1;','window.count = window.count + 1;\n        0').replace('    probe(&mut window,','    _ = probe(&mut window,')
variants['unit_result_mismatch']=(True,mismatch)
for name,(bad,text) in variants.items():
 p=root/'controls'/name;p.mkdir(parents=True,exist_ok=True);(p/'main.omg').write_text(text);(p/'build.omg').write_text((root/'local/build.omg').read_text().replace('default_domain_increment_local','default_domain_increment_'+name))
 if bad:(p/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['where' if name in ['stale_count','same_site_insufficient_arrival'] else '']),indent=2)+'\n')
files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'controls').rglob('*') if p.is_file()}
Path('build/product-declarations/frozen-controls.json').write_text(json.dumps(dict(files=files),indent=2)+'\n')
