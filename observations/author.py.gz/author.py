from pathlib import Path
import json
root=Path('samples/cli/facts/nested_machine_invocation/completion_result')
sentence='Every normal completion supplies the declared u8 result, so transporting the selected result preserves its value.'
select='''machine select(ready: bool) -> u8 {
    transition ready { true -> 37u8 false -> 19u8 }
}
'''
places={
'local':('','let value: u8 = select(false);'),
'field':('data Result { value: u8; }\n','let result: Result = Result { value: select(false) };\n    let value: u8 = result.value;'),
'parameter':('machine consume(value: u8) -> u8 { value }\n','let value: u8 = consume(select(false));'),
'call_result':('machine forward() -> u8 { select(false) }\n','let value: u8 = forward();'),
'match_join':('machine joined(first: bool) -> u8 {\n    transition first { true -> select(false) false -> select(true) }\n}\n','let value: u8 = joined(true);\n    let alternate: u8 = joined(false);\n    transition alternate == 37 { false -> bad() }'),
'const_name':('const READY: bool = false;\n','let value: u8 = select(READY);'),
'other_state':('', 'let value: u8 = forward();'),
'other_machine':('machine forward() -> u8 { transition { _ -> select(false) } }\n','let value: u8 = forward();'),
}
for place,(declarations,body) in places.items():
 tail='\n    machine forward() -> u8 { select(false) }' if place=='other_state' else ''
 main=f'// {sentence}\n// Expected exit: 0\n'+select+declarations+f'''machine main() crashes Trap {{
    {body}
    let alternate: u8 = select(true);
    transition value == 19 && alternate == 37 {{ true -> {{}} false -> bad() }}
    machine bad() crashes Trap {{ crash Trap; }}{tail}
}}
'''
 for invalid in [False,True]:
  directory=root/place/('invalid' if invalid else '')
  directory.mkdir(parents=True,exist_ok=True)
  (directory/'main.omg').write_text(main.replace('false -> 19u8','false -> {}') if invalid else main)
  (directory/'build.omg').write_text(f'''machine build(builder: &mut Build) {{
    Build::application(builder, "completion_result_{place}");
    Build::bind(builder, windows_x86_64::ProgramEntry, main);
    Build::bind(builder, linux_x86_64::ProgramEntry, main);
    Build::bind(builder, linux_arm64::ProgramEntry, main);
    Build::bind(builder, macos_arm64::ProgramEntry, main);
}}
''')
place='target_body'
main=f'''// {sentence}
// Expected exit: 0
boundary trait Select {{ machine apply(ready: bool) -> u8 reaches; }}
Selected satisfies Select {{
    machine apply(ready: bool) -> u8 {{
        transition ready {{ true -> 37u8 false -> 19u8 }}
    }}
}}
machine main() crashes Trap {{
    let value: u8 = Select::apply(false);
    let alternate: u8 = Select::apply(true);
    transition value == 19 && alternate == 37 {{ true -> {{}} false -> bad() }}
    machine bad() crashes Trap {{ crash Trap; }}
}}
'''
build=(root/'local/build.omg').read_text().replace('completion_result_local','completion_result_target_body')
build=build.replace('    Build::application', '    Build::bind(builder, windows_x86_64::Select, Selected);\n    Build::bind(builder, linux_x86_64::Select, Selected);\n    Build::bind(builder, macos_arm64::Select, Selected);\n    Build::bind(builder, linux_arm64::Select, Selected);\n    Build::application')
for invalid in [False,True]:
 directory=root/place/('invalid' if invalid else '');directory.mkdir(parents=True,exist_ok=True)
 (directory/'main.omg').write_text(main.replace('false -> 19u8','false -> {}') if invalid else main)
 (directory/'build.omg').write_text(build)
r=Path('build/completion-result')
previous=json.loads(Path('build/product-declarations/context-config.json').read_text())
previous['context']={'parent':'NESTED-MACHINE-UNIFICATION','parent_fixed_base':'baf1b6ea0633681bcc2cf34d563d748a47fadb36','fixed_base':'7dbc69b6df5bab680e1b112e68454a5cc81cd28b','requirement':'Every normal completion supplies its invocation declared result; reject Unit completion in non-Unit invocation, including explicit arm and implicit fallthrough.','baseline':'Retained1f optimized producer incorrectly accepts frozen Unit false arm of u8 invocation. New fixed-base build will replay all nine before implementation.'}
previous['semantic_contracts'][0]['implementation']=['omega-rust/psi/compilation/checking/src/program_validation.rs','omega-rust/psi/compilation/checking/src/program_validation/completion_results.rs']
previous['semantic_contracts'][0]['reason']='Missing ordinary completion admission, not a new language rule. Inspect declared carrier independently of lexical nesting and unify explicit/implicit Unit completion; preserve no-normal-return paths, source-control order, full result types and body presence. Remove generic empty-body exemption rather than add another source-shape path.'
(r/'context-config.json').write_text(json.dumps(previous,indent=2)+'\n')
