from pathlib import Path
import hashlib,json,subprocess,sys,time,concurrent.futures
root=Path('samples/cli/facts/nested_machine_invocation/completion_result');cli=str(Path(sys.argv[1]).resolve());label=sys.argv[2]
def run(p):
 invalid=p.parent.name=='invalid';command=[cli,'--check',str(p)] if invalid else [cli,'run','--both',str(p)];start=time.monotonic();x=subprocess.run(command,input='',capture_output=True,text=True,timeout=120)
 a=dict(source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),command=command,exit=x.returncode,stdout=x.stdout,stderr=x.stderr,elapsed_seconds=time.monotonic()-start,invalid=invalid)
 print(str(p.relative_to(root)),x.returncode,x.stderr.strip(),flush=True);return a
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,sorted(root.glob('*/main.omg'))+sorted(root.glob('*/invalid/main.omg'))))
Path('build/completion-result/'+label+'.json').write_text(json.dumps(rows,indent=2)+'\n')
