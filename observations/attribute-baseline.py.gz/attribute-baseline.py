from pathlib import Path
import json,subprocess,hashlib,os,time
r=Path('build/product-declarations');old=Path('build/wrapping-integration/producer/corpus_runner').resolve();metadata=json.loads(Path('build/wrapping-integration/corpus_runner-producer.json').read_text());assert hashlib.sha256(old.read_bytes()).hexdigest()==metadata['sha256'];assert metadata['revision']=='05e1922eb7b4d554a7d5ee84e47f99ebb3304827';report={}
for mode in ['source','both']:
 x=json.loads((r/('corpus-'+mode+'.json')).read_text());bad=[]
 for a in x['observations']:
  if mode=='source':okay=a['status']==('rejected' if a['tier']=='fail' else 'checked') and(a['tier']!='fail' or a['expected_satisfied'] is True)
  else:okay=(a['status']=='checked' and not a['facts']) or(a['status']=='built' and a['facts'].get('interpreter')=='agrees' and a['facts'].get('exit')==a['facts'].get('interpreter-exit'))
  if not okay:bad.append(a)
 if not bad:report[mode]=dict(inherited=[]);continue
 assert not any('nested_machine_default_domain_' in a['fixture'] for a in bad),bad
 for a in bad:subprocess.run(['git','diff','--exit-code','05e1922eb7b4d554a7d5ee84e47f99ebb3304827','HEAD','--',str(Path('tests/omega')/a['fixture']),'source/library'],check=True)
 cmd=['python3','tools/corpus_gate.py','--runner',str(old),'--filter',','.join(a['fixture'] for a in bad),'--json',str(r/('baseline-'+mode+'.json'))]
 if mode=='both':cmd+=['--both']
 t=time.monotonic()
 with (r/('baseline-'+mode+'.log')).open('w') as f:p=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMEGA_CORPUS_JOBS='2'),timeout=600)
 base=json.loads((r/('baseline-'+mode+'.json')).read_text());assert not base['infrastructure_error'];lookup={a['fixture']:a for a in base['observations']};fields=['status','expected_satisfied','diagnostics'] if mode=='source' else ['status','facts','diagnostics']
 for a in bad:assert all(a[k]==lookup[a['fixture']][k] for k in fields),(mode,a,lookup[a['fixture']])
 report[mode]=dict(command=cmd,exit=p.returncode,elapsed_seconds=time.monotonic()-t,inherited=[a['fixture'] for a in bad],comparison_fields=fields)
(r/'baseline-attribution.json').write_text(json.dumps(dict(producer=metadata,comparison=report,reason='Exact unchanged fixtures and dynamic library source; retained old05e compiler actually reproduces every remaining refusal. Old runner identity remains distinct from current fixture checkout and new producer.'),indent=2)+'\n');print(json.dumps(report))
