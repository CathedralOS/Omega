from pathlib import Path
import subprocess,json,shutil,hashlib,os,time
r=Path('build/product-declarations')
def invoke(cmd,name,expected=None):
 t=time.monotonic()
 with (r/(name+'.log')).open('w') as f:p=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMEGA_CORPUS_JOBS='4'),timeout=900)
 x=dict(command=cmd,exit=p.returncode,elapsed_seconds=time.monotonic()-t,revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip());(r/(name+'-command.json')).write_text(json.dumps(x,indent=2)+'\n');print(name,p.returncode,round(x['elapsed_seconds'],2),flush=True)
 if expected is not None:assert p.returncode==expected,(name,p.returncode)
 return p.returncode
rows=[json.loads(s) for s in (r/'runner-build.jsonl').read_text().splitlines() if s.startswith('{')];a=[x for x in rows if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']=='corpus_runner'][-1];p=r/'producer/corpus_runner';shutil.copy2(a['executable'],p);profile=json.loads(subprocess.check_output([str(p.resolve()),'--build-profile'],text=True));assert profile['opt_level']=='1';(r/'runner-producer.json').write_text(json.dumps(dict(revision='860b169d5798c3ad0b8e94ed8fb634d9d3db7ff3',sha256=hashlib.sha256(p.read_bytes()).hexdigest(),profile=profile,cargo_artifact=a),indent=2)+'\n')
runner=str(p.resolve())
for mode in ['source','both']:
 cmd=['python3','tools/corpus_gate.py','--runner',runner,'--filter','facts/nested_machine_default_domain_','--record','--json',str(r/('pins-'+mode+'.json'))]
 if mode=='both':cmd+=['--both']
 invoke(cmd,'pins-'+mode,0)
subprocess.run(['git','add','tests/omega/corpus_outcomes.txt','tests/omega/corpus_both_macos_arm64.txt'],check=True)
subprocess.run(['git','commit','-m','psi: record bounded data stores through Unit paths','-m','Pin25 source outcomes and11 native/Terminal exit0 agreements from optimized860b runtime producer. The splice is restricted to this repair and preserves all unrelated rows.'],check=True)
for mode in ['source','both']:
 cmd=['python3','tools/corpus_gate.py','--runner',runner,'--filter',(r/'focused-filter.txt').read_text().strip(),'--json',str(r/('corpus-'+mode+'.json'))]
 if mode=='both':cmd+=['--both']
 invoke(cmd,'corpus-'+mode)
paths=['omega-rust/psi/compilation/checking/src/proof_contracts/contract_entailment/structural_case_arms.rs','omega-rust/psi/compilation/checking/src/proof_contracts/contract_entailment/structural_judgment/normal_returns/body_completion.rs']
invoke(['rustfmt','--check','--edition','2024','--config','skip_children=true',*paths],'format',0)
invoke(['cargo','clippy','--locked','-p','validation','--no-deps'],'clippy',0)
cmd=[str((r/'producer/omega').resolve()),'run','--both',str(r/'counterfactual/main.omg')];x=subprocess.run(cmd,input='',capture_output=True,text=True,timeout=120);(r/'counterfactual.json').write_text(json.dumps(dict(command=cmd,exit=x.returncode,stdout=x.stdout,stderr=x.stderr,sha256=hashlib.sha256((r/'counterfactual/main.omg').read_bytes()).hexdigest()),indent=2)+'\n');print('counterfactual',x.returncode,x.stderr,flush=True)
