from pathlib import Path
import json,hashlib,subprocess,collections
r=Path('build/product-declarations/integrated');old=r.parent
load=lambda p:json.loads(Path(p).read_text())
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for name in ['omega','corpus_runner']:
 m=load(r/(name+'-producer.json'));assert m['revision']==head and digest(r/'producer'/name)==m['sha256'] and m['profile']['opt_level']=='1'
for p,h in load(old/'frozen-row.json')['files'].items():assert digest(p)==h,p
for p,h in load(old/'frozen-controls.json')['files'].items():
 if Path(p).name in ['main.omg','build.omg']:assert digest(p)==h,p
for name,count in [('row.json',18),('controls.json',7)]:
 rows=load(r/name);assert len(rows)==count
 for a in rows:
  p=Path(a['source']);assert digest(p)==a['sha256'];bad=a['invalid'];place=p.parent.parent.name if p.parent.name=='invalid' else p.parent.name;pin=Path('tests/omega')/('fail' if bad else 'pass')/'facts'/('nested_machine_default_domain_'+place+('_rejected' if bad else '_exit'))
  for n in ['main.omg','build.omg']:assert(p.parent/n).read_bytes()==(pin/n).read_bytes(),pin
  if bad:assert a['exit']==1 and(pin/'expected.txt').read_text().strip() in a['stderr'],a
  else:assert a['exit']==0 and'native exit 0' in a['stderr'] and'interp exit: 0' in a['stderr'],a
baseline=load(old/'baseline-attribution.json');totals={}
for mode,count in [('source',287),('both',155)]:
 x=load(r/('corpus-'+mode+'.json'));previous={a['fixture']:a for a in load(old/('corpus-'+mode+'.json'))['observations']};assert len(x['observations'])==count and not x['dirty'] and not x['infrastructure_error'];assert x['revision']==head;fields=['status','expected_satisfied','diagnostics'] if mode=='source' else ['status','facts','diagnostics']
 for a in x['observations']:assert all(a[k]==previous[a['fixture']][k] for k in fields),(mode,a,previous[a['fixture']])
 for a in baseline['comparison'][mode]['inherited']:subprocess.run(['git','diff','--exit-code','5a92d9be95a2b909fbbfe47a2c278acf4b9e6d49','HEAD','--',str(Path('tests/omega')/a),'source/library'],check=True)
 totals[mode]=dict(observations=count,semantics_identical_to_original=True,statuses=dict(collections.Counter(a['status'] for a in x['observations'])),inherited=baseline['comparison'][mode]['inherited'])
for mode,count in [('source',25),('both',11)]:
 x=load(old/('pins-'+mode+'.json'));assert len(x['observations'])==count and x['verdict']=='recorded' and not x['oracle_failures'] and not x['infrastructure_error'];assert all(a['recorded_at']=='860b169d5798' for a in x['observations'])
 for a in x['observations']:subprocess.run(['git','diff','--exit-code',x['revision'],'HEAD','--',str(Path('tests/omega')/a['fixture'])],check=True)
x=load(r/'counterfactual.json');assert digest(x['command'][-1])==x['sha256'] and x['exit']==255 and'native signal 5' in x['stderr'] and'interp crash: Trap (host presentation agrees)' in x['stderr']
for name in ['row','controls','format','clippy']:assert load(r/(name+'-command.json'))['exit']==0
assert not(r/'format.log').read_text() and'Finished' in(r/'clippy.log').read_text() and'error:' not in(r/'clippy.log').read_text()
metadata=baseline['producer'];assert digest('build/wrapping-integration/producer/corpus_runner')==metadata['sha256'] and metadata['revision']=='05e1922eb7b4d554a7d5ee84e47f99ebb3304827'
acceptance=dict(source=head,fixed_author_base='05e1922eb7b4d554a7d5ee84e47f99ebb3304827',integration=load(r/'integration.json'),target='macos_arm64',fresh_nine_positive_places_and_nine_twins=True,fresh_positive_controls=2,fresh_negative_controls=5,focused=totals,runtime=dict(native_terminal_exit_agreements=108,declaration_only=42,terminal_only_foreign_native_unmeasured=3,refusals=2),counterfactual='Native signal5/Terminal Trap agreement',remaining='Full product declaration-model migration and checking workflow remain unfinished. Original parser timeouts remain unverified historical observations; no new full-parser replay or other-host native acceptance claimed.')
encoded=json.dumps(acceptance,indent=2)+'\n';p=r/'acceptance.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded)
