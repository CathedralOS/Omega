from pathlib import Path
import json,hashlib,subprocess,collections
r=Path('build/product-declarations');root=Path('samples/cli/facts/nested_machine_invocation/private_arithmetic/default_domain')
def load(n):return json.loads((r/n).read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
compiler_inputs=['omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml']
for name,binary in [('producer.json','omega'),('runner-producer.json','corpus_runner')]:
 m=load(name);assert digest(r/'producer'/binary)==m['sha256'] and m['profile']['opt_level']=='1';subprocess.run(['git','diff','--exit-code',m['revision'],'HEAD','--',*compiler_inputs],check=True)
for p,h in load('frozen-row.json')['files'].items():assert digest(p)==h,p
for p,h in load('frozen-controls.json')['files'].items():
 if Path(p).name in ['main.omg','build.omg']:assert digest(p)==h,p
baseline=load('row-baseline.json');assert len(baseline)==18
for a in baseline:assert digest(a['source'])==a['sha256'] and a['exit']==1 and "assignment stores a value not provably within its data's `where` facts" in a['stderr'],a
for name,count in [('row-repaired.json',18),('controls-repaired.json',7)]:
 rows=load(name);assert len(rows)==count
 for a in rows:
  p=Path(a['source']);assert digest(p)==a['sha256'];bad=a['invalid'];place=p.parent.parent.name if p.parent.name=='invalid' else p.parent.name;pin=Path('tests/omega')/('fail' if bad else 'pass')/'facts'/('nested_machine_default_domain_'+place+('_rejected' if bad else '_exit'))
  for n in ['main.omg','build.omg']:assert (p.parent/n).read_bytes()==(pin/n).read_bytes(),pin
  if bad:assert a['exit']==1 and (pin/'expected.txt').read_text().strip() in a['stderr'],a
  else:assert a['exit']==0 and 'native exit 0' in a['stderr'] and 'interp exit: 0' in a['stderr'],a
old_controls=load('controls-baseline.json');assert len(old_controls)==7
for a in old_controls:assert digest(a['source'])==a['sha256'] and a['exit']==1,a
for mode,count in [('source',25),('both',11)]:
 x=load('pins-'+mode+'.json');assert len(x['observations'])==count and x['verdict']=='recorded' and not x['oracle_failures'] and not x['infrastructure_error'];assert all(a['recorded_at']=='860b169d5798' for a in x['observations'])
 for a in x['observations']:
  if mode=='source':assert a['status']==('rejected' if a['tier']=='fail' else 'checked') and(a['tier']!='fail' or a['expected_satisfied'] is True)
  else:assert a['status']=='built' and a['facts'].get('interpreter')=='agrees' and a['facts'].get('exit')==a['facts'].get('interpreter-exit')=='0'
comparison=load('baseline-attribution.json')['comparison'];totals={}
for mode,count in [('source',287),('both',155)]:
 x=load('corpus-'+mode+'.json');base={a['fixture']:a for a in load('baseline-'+mode+'.json')['observations']};assert len(x['observations'])==count and not x['dirty'] and not x['infrastructure_error'];assert set(base)==set(comparison[mode]['inherited']);fields=comparison[mode]['comparison_fields']
 for a in x['observations']:
  if a['fixture'] in base:assert all(a[k]==base[a['fixture']][k] for k in fields),(mode,a)
  elif mode=='source':assert a['status']==('rejected' if a['tier']=='fail' else 'checked') and(a['tier']!='fail' or a['expected_satisfied'] is True),a
  else:assert(a['status']=='checked' and not a['facts']) or(a['status']=='built' and a['facts'].get('interpreter')=='agrees' and a['facts'].get('exit')==a['facts'].get('interpreter-exit')),a
 totals[mode]=dict(observations=count,inherited=comparison[mode]['inherited'],statuses=dict(collections.Counter(a['status'] for a in x['observations'])))
source=load('corpus-source.json');false_contract=next(a for a in source['observations'] if a['fixture']=='fail/calls/unit_normal_completion_false_contract');assert false_contract['status']=='rejected' and false_contract['expected_satisfied'] is True
x=load('counterfactual.json');assert digest(x['command'][-1])==x['sha256'] and x['exit']==255 and 'native signal 5' in x['stderr'] and 'interp crash: Trap (host presentation agrees)' in x['stderr']
for n in ['format','clippy']:assert load(n+'-command.json')['exit']==0
assert not(r/'format.log').read_text() and 'Finished' in (r/'clippy.log').read_text() and 'error:' not in (r/'clippy.log').read_text()
old=load('baseline-attribution.json')['producer'];assert old['revision']=='05e1922eb7b4d554a7d5ee84e47f99ebb3304827' and digest('build/wrapping-integration/producer/corpus_runner')==old['sha256']
customer=load('parser-customer-check.json');assert len(customer)==2 and all(a['exit']=='timeout' for a in customer)
coverage=load('source-unit-customer.json');assert all(a['exit']==0 for a in coverage)
x=dict(parent='NESTED-MACHINE-UNIFICATION',parent_fixed_base='baf1b6ea0633681bcc2cf34d563d748a47fadb36',fixed_author_base='05e1922eb7b4d554a7d5ee84e47f99ebb3304827',submitted_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),producer=load('producer.json')['revision'],runner=load('runner-producer.json')['revision'],target='macos_arm64',nine_positive_places=True,nine_fact_sensitive_twins=True,positive_controls=2,negative_controls=5,pinned_source_outcomes=25,pinned_native_terminal_zero_agreements=11,counterfactual='Native signal5 and Terminal Trap agree',focused=totals,runtime=dict(native_terminal_exit_agreements=108,declaration_only=42,terminal_only_foreign_native_unmeasured=3,refusals=2),remaining='Full product declaration-model migration remains unfinished. Full parser replay timed out90s on both compilers and is unverified; unused SourceUnit module checks pass on both and are coverage only. Other-host native execution remains unverified. Raw corpus gates remain3 for exact inherited outcomes; no unrelated rows repinned.')
encoded=json.dumps(x,indent=2)+'\n';p=r/'acceptance.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded)
