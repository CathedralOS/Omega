from pathlib import Path
import json,hashlib,subprocess,collections
r=Path('build/completion-result');current=r/'library-migration'
def load(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
producer='5b8ead0dbfc55e783be2e292da620b8bc71346f6'
for file,binary in [('producer.json','omega'),('runner-producer.json','corpus_runner')]:
 x=load(current/file);assert x['revision']==producer and digest(current/binary)==x['sha256'] and x['profile']['opt_level']=='1'
subprocess.run(['git','diff','--exit-code',producer,'HEAD','--','omega-rust','source/library','Cargo.toml','Cargo.lock','rust-toolchain.toml'],check=True)
for p,h in load(r/'frozen.json').items():assert digest(Path(p))==h,p
baseline=load(r/'baseline.json');assert len(baseline)==18
for a in baseline:
 assert digest(Path(a['source']))==a['sha256'] and a['exit']==0
 if not a['invalid']:assert 'native exit 0' in a['stderr'] and 'interp exit: 0' in a['stderr']
base=load(r/'base/producer.json');assert base['revision']=='7dbc69b6df5bab680e1b112e68454a5cc81cd28b' and digest(r/'base/omega')==base['sha256']
for file,count in [('library-migration.json',18),('controls-library-migration.json',10)]:
 for a in load(r/file):
  assert digest(Path(a['source']))==a['sha256']
  source=Path(a['source']);name=a.get('name') or (source.parent.parent.name if a['invalid'] else source.parent.name);pin=Path('tests/omega')/('fail' if a['invalid'] else 'pass')/'facts'/('nested_machine_completion_result_'+name+('_rejected' if a['invalid'] else '_exit'))
  for authored in ['main.omg','build.omg']:assert (source.parent/authored).read_bytes()==(pin/authored).read_bytes()
  if a['invalid']:
   assert a['exit']==1
   source=Path(a['source']);name=a.get('name') or source.parent.parent.name;pin=Path('tests/omega/fail/facts')/('nested_machine_completion_result_'+name+'_rejected');expected=(pin/'expected.txt').read_text().strip();assert expected in a['stderr'],a
  else:assert a['exit']==0 and 'native exit 0' in a['stderr'] and 'interp exit: 0' in a['stderr'],a
 assert len(load(r/file))==count
for mode,count in [('source',28),('both',12)]:
 x=load(current/('pinned-'+mode+'.json'));assert len(x['observations'])==count and not x['oracle_failures'] and not x['infrastructure_error'] and x['verdict']=='recorded'
 for a in x['observations']:
  assert a['recorded_at']=='5b8ead0dbfc5'
  if mode=='source':assert a['status']==('rejected' if a['tier']=='fail' else 'checked') and(a['tier']!='fail' or a['expected_satisfied'] is True)
  else:assert a['status']=='built' and a['facts'].get('interpreter')=='agrees' and a['facts'].get('exit')==a['facts'].get('interpreter-exit')=='0'
source=load(current/'focused-source.json');assert len(source['observations'])==68 and not source['oracle_failures'] and not source['infrastructure_error']
for a in source['observations']:
 assert a['status']==('rejected' if a['tier']=='fail' else 'checked')
 if a['tier']=='fail' and a['fixture']!='fail/borrow/vec_view_invalidated_by_push':assert a['expected_satisfied'] is True,a
vec=load(r/'baseline-vec-view.json');assert vec['exit']==1 and 'cannot form specification operator' in vec['stderr'] and 'while local borrow `view` is still active' not in vec['stderr']
both=load(current/'focused-both.json');assert len(both['observations'])==17 and not both['infrastructure_error']
for a in both['observations']:
 if a['fixture']=='pass/control_flow/unconditional_unit_completion_exit':assert a['status']=='built' and a['facts']=={'interpreter-exit':'0'}
 else:assert(a['status']=='checked' and not a['facts']) or(a['status']=='built' and a['facts'].get('interpreter')=='agrees' and a['facts'].get('exit')==a['facts'].get('interpreter-exit')=='0'),a
old=load(r/'baseline-unconditional-unit.json');assert old['exit']==200 and 'no bound required root slot' in old['stderr']
nat=load(current/'nat-metric.json');assert nat['exit']==0 and 'compiled 18 source file(s)' in nat['stdout'] and not nat['stderr']
counter=load(current/'counterfactual.json');assert counter['exit']==255 and 'native signal 5' in counter['stderr'] and 'interp crash: Trap (host presentation agrees)' in counter['stderr'] and digest(r/'counterfactual/main.omg')==counter['source_sha256']
subprocess.run(['git','diff','--exit-code','b6e0b4b0c03e458d3ce94542c83fbc004e648f34','HEAD','--','omega-rust','Cargo.toml','Cargo.lock','rust-toolchain.toml','clippy.toml','rustfmt.toml'],check=True)
assert not(r/'format.log').read_text();clippy=(r/'clippy.log').read_text();assert 'Finished' in clippy and 'error:' not in clippy
print(json.dumps(dict(accepted=True,producer=producer,target='macos_arm64',row_positive_native_terminal_agreements=9,row_invalid_refusals=9,controls=dict(native_terminal_normal_main_agreements=3,reject_controls=7),pinned_source=28,pinned_native_terminal=12,focused_source=68,inherited_source_wrong_fragment=['fail/borrow/vec_view_invalidated_by_push'],focused_native_terminal_agreements=15,focused_declaration_only=1,inherited_terminal_only_no_macos_entry=1,math_library='nat_metric checked18sources, explicit witness results preserve existing postconditions',counterfactual='nativeSIG5/TerminalTrap agree',rust_checks='b6 exact same Rust/toolchain/config; no source reuse across semantic changes',remaining='Full nested-machine outcome, product migration, customer UI native acceptance, and other-host runtime remain open'),indent=2))
