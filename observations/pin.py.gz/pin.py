from pathlib import Path
import shutil,json
root=Path('samples/cli/facts/nested_machine_invocation/completion_result')
for p in sorted(root.glob('*/main.omg'))+sorted(root.glob('*/invalid/main.omg')):
 invalid=p.parent.name=='invalid';place=p.parent.parent.name if invalid else p.parent.name;target=Path('tests/omega')/('fail' if invalid else 'pass')/'facts'/('nested_machine_completion_result_'+place+('_rejected' if invalid else '_exit'));target.mkdir(parents=True,exist_ok=True)
 for name in ['main.omg','build.omg']:shutil.copy2(p.parent/name,target/name)
 if invalid:(target/'expected.txt').write_text('a terminal arm supplies Unit, but the invocation returns `u8`\n')
for name,invalid in json.loads(Path('build/completion-result/controls.json').read_text()).items():
 target=Path('tests/omega')/('fail' if invalid else 'pass')/'facts'/('nested_machine_completion_result_'+name+('_rejected' if invalid else '_exit'));target.mkdir(parents=True,exist_ok=True)
 for file in ['main.omg','build.omg']:shutil.copy2(root/'controls'/name/file,target/file)
 if invalid:
  expected='declares a return type but its body is empty' if name in ['implicit_empty','generic_empty'] else 'can fall through' if name=='conditional_fallthrough' else 'implicit body completion supplies Unit' if name=='implicit_after_write' else 'a terminal arm supplies Unit'
  (target/'expected.txt').write_text(expected+'\n')
c=Path('build/completion-result/counterfactual');c.mkdir(exist_ok=True)
for file in ['main.omg','build.omg']:
 text=(root/'local'/file).read_text()
 if file=='main.omg':text=text.replace('value == 19','value == 18')
 (c/file).write_text(text)
