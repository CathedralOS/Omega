from pathlib import Path
import json,hashlib
root=Path('samples/cli/facts/nested_machine_invocation/private_arithmetic/default_domain');template=Path('samples/cli/facts/nested_machine_invocation/private_arithmetic/wrapping_index');places=['local','field','parameter','call_result','match_join','const_name','other_state','other_machine','target_body']
sentence='The recorded count is below 4, so its exact increment preserves the buffer count <= 4 default domain.'
main='''machine main() crashes Trap {
    let mut window: Window;
    window.canary = 33;
    window.count = 3;
    window.bytes[0] = 7;
    PROBE(&mut window, true, 37);
    let first_count: u64 = window.count;
    let first_byte: u8 = window.bytes[0];
    PROBE(&mut window, true, 19);
    let full_count: u64 = window.count;
    let full_byte: u8 = window.bytes[0];
    window.count = 0;
    PROBE(&mut window, true, 11);
    let second_count: u64 = window.count;
    let second_byte: u8 = window.bytes[0];
    window.count = 2;
    PROBE(&mut window, false, 23);
    transition first_count == 4 && first_byte == 37 && full_count == 4 && full_byte == 37
        && second_count == 1 && second_byte == 11 && window.count == 2
        && window.bytes[0] == 11 && window.canary == 33 {
        true -> {} false -> bad()
    }
    machine bad() crashes Trap { crash Trap; }
}
'''
for place in places:
 s=(template/place/'main.omg').read_text();s=s[:s.index('machine main()')]
 s=s.replace(s.splitlines()[0],'// '+sentence)
 s=s.replace('data Window { bytes: [u8; 512]; offset: u64 in Wrapping; index: u64 in Wrapping; canary: u64; }','data Window where count <= 4 { bytes: [u8; 4]; count: u64; canary: u64; }')
 s=s.replace('offset','count').replace('u64 in Wrapping','u64').replace('495','4').replace('enabled: bool','enabled: bool, value: u8').replace(') -> u8',')')
 s=s.replace('read(window)','read(window, value)').replace('gate(window, ready, enabled)','gate(window, ready, enabled, value)').replace('route(window, ready, enabled)','route(window, ready, enabled, value)')
 s=s.replace('machine read(window: &mut Window)', 'machine read(window: &mut Window, value: u8)')
 s=s.replace('false -> 0','false -> {}').replace('window.index = window.count + 17;\n        window.bytes[window.index]','window.bytes[0] = value;\n        window.count = window.count + 1;')
 # The decision helpers return bool, so the blanket Unit conversion above
 # changes only the original u8 probe/read/application signatures.
 s+=main.replace('PROBE','HostedProbe::apply' if place=='target_body' else 'probe')
 assert 'index' not in s and '+ 17' not in s
 build=(template/place/'build.omg').read_text().replace('wrapping_index_','default_domain_increment_')
 for invalid in [False,True]:
  p=root/place/('invalid' if invalid else '');p.mkdir(parents=True,exist_ok=True)
  source=s.replace('< 4','< 5').replace('OFFSET_LIMIT: u64 = 4','OFFSET_LIMIT: u64 = 5') if invalid else s
  (p/'main.omg').write_text(source);(p/'build.omg').write_text(build)
  if invalid:(p/'sample.json').write_text(json.dumps(dict(role='intended-invalid',entry='main.omg',rejection_contains=['assignment stores a value not provably within its data\'s `where` facts']),indent=2)+'\n')
files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
Path('build/product-declarations/frozen-row.json').write_text(json.dumps(dict(sentence=sentence,files=files),indent=2)+'\n')
