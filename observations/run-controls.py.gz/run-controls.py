from pathlib import Path
import subprocess,json,sys,hashlib
cli=str(Path(sys.argv[1]).resolve());label=sys.argv[2];both=len(sys.argv)>3 and sys.argv[3]=='both';rows=[];root=Path('samples/cli/facts/nested_machine_invocation/private_arithmetic/default_domain/controls')
for p in sorted(root.glob('*/main.omg')):
 bad=(p.parent/'sample.json').exists();cmd=[cli,'run','--both',str(p)] if both and not bad else [cli,'--check',str(p)];x=subprocess.run(cmd,input='',capture_output=True,text=True,timeout=90);rows.append(dict(source=str(p),invalid=bad,command=cmd,exit=x.returncode,stdout=x.stdout,stderr=x.stderr,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));print(p.parent.name,x.returncode,x.stderr,flush=True)
Path('build/product-declarations/integrated/controls.json').write_text(json.dumps(rows,indent=2)+'\n')
